# -*- coding: utf-8 -*-

import os
import subprocess
import xbmc
import xbmcaddon

addon = xbmcaddon.Addon()
log_path = addon.getSetting("log_path") or "/storage/logfiles/journalctl.log"

xbmc.log("[Autoexec] Journal Logger started", level=xbmc.LOGINFO)

try:
    with open(log_path, "w") as log_file:
        subprocess.run(["journalctl", "-b"], stdout=log_file, check=True)
    xbmc.log(f"[Autoexec] Journal log saved to {log_path}", level=xbmc.LOGINFO)
except Exception as e:
    xbmc.log(f"[Autoexec] Error saving journal log: {e}", level=xbmc.LOGERROR)
    
    
# -*- coding: utf-8 -*-

# import os
# import subprocess
# import xbmc
# import xbmcaddon
# import time

# addon = xbmcaddon.Addon()
# log_path = addon.getSetting("log_path") or "/storage/logfiles/journalctl.log"

# xbmc.log("[Autoexec] Journal Logger started", level=xbmc.LOGINFO)

# try:
    ## Spuštění příkazu `journalctl` na prvních 60 vteřin
    # with open(log_path, "w") as log_file:
        ## Příkaz bude běžet pouze 60 sekund
        # process = subprocess.Popen(["journalctl", "-b", "--since", "0", "--until", "60s"], stdout=log_file)
        # time.sleep(60)  # Čeká 60 sekund, než ukončí proces
        # process.terminate()  # Ukončí proces po 60 sekundách
    # xbmc.log(f"[Autoexec] Journal log saved to {log_path}", level=xbmc.LOGINFO)
# except Exception as e:
    # xbmc.log(f"[Autoexec] Error saving journal log: {e}", level=xbmc.LOGERROR)

