# -*- coding: utf-8 -*-

import xbmcaddon

from resources.lib.utils import logNot
import resources.lib.script as script

if __name__ == '__main__':
    logNot('Script start')
    gui = script.Gui('default.xml', xbmcaddon.Addon().getAddonInfo('path'), 'default', '1080i')
    gui.doModal()
    logNot('Script stop')
    del gui
        