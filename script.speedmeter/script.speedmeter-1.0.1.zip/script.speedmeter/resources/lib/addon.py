# -*- coding: utf-8 -*-

# import xbmc
# import xbmcgui
import xbmcaddon
import xbmcvfs
import os

class ADDON:
    ADDON = xbmcaddon.Addon()
    ID = ADDON.getAddonInfo('id')
    NAME = ADDON.getAddonInfo('name')
    LANG = ADDON.getLocalizedString
    VERSION = ADDON.getAddonInfo('version')
    PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
    PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    ICON = xbmcvfs.translatePath(os.path.join(PATH, 'resources', 'icon.png'))
