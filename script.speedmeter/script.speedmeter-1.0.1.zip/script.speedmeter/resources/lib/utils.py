# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

import os

from resources.lib.const import SYSTEM
from resources.lib.addon import ADDON

WINDOW_HOME = 10000
TRACKING = True
SYSTEMS = [SYSTEM.LINUX,
SYSTEM.WINDOWS,
# SYSTEM.OSX,
# SYSTEM.IOS,
# SYSTEM.DARWIN,
SYSTEM.ANDROID,
SYSTEM.UWP]

def log(message, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON.NAME,message), level)

def logNot(message):
    log(message,level=xbmc.LOGINFO)

def logWrn(message):
    log(message,level=xbmc.LOGWARNING)

def logDbg(message):
    log(message,level=xbmc.LOGDEBUG)

def logErr(message):
    log(message,level=xbmc.LOGFATAL)
    
def logTracking(message):
    if TRACKING:
        log('[TRACKING] %s' % message,level=xbmc.LOGNOTICE)

def notification(message, icon=ADDON.ICON, time=5000):
    if icon == 'INFO':
        icon = xbmcgui.NOTIFICATION_INFO
    elif icon == 'WARNING':
        icon = xbmcgui.NOTIFICATION_WARNING
    elif icon == 'ERROR':
        icon = xbmcgui.NOTIFICATION_ERROR
    xbmc.executebuiltin('XBMC.Notification(%s,%s,%i,%s)' % (ADDON.NAME, message, time, icon))

def getSystem():
    for system in SYSTEMS:
        if xbmc.getCondVisibility('System.Platform.{}'.format(system)):
            return system
    return ''

def getSettingBool(addon, param):
    return True if addon.getSetting(param).upper() == 'TRUE' else False

def getSettingInt(addon, param):
    return int(addon.getSetting(param))

def getSettingNumber(addon, param):
    return float(addon.getSetting(param))

def getSettingStr(addon, param):
    return addon.getSetting(param)
    
def getProperty(variable):
    return xbmcgui.Window(WINDOW_HOME).getProperty(variable)

def setProperty(variable, value):
    xbmcgui.Window(WINDOW_HOME).setProperty(variable, value)

def clearProperty(variable):
    xbmcgui.Window(WINDOW_HOME).clearProperty(variable)

def clearProperties(variables):
    for propty in variables:
        clearProperty(propty)

def secToMinSec(seconds):
    return ('%i:%02i' % (seconds // 60, seconds % 60))
    
def jsonString(json, name):
        try: return json[name]
        except: return None

def jsonNum(json, name):
        try: num = json[name]
        except: num = None
        return num

def jsonBoolean(json, name, default):
        try: logical = json[name]
        except: logical = default
        return logical

def jsonTimeSec(json, name, form):
        try: timeSec = time.mktime(time.strptime(json[name], form))
        except: timeSec = 0
        return timeSec

def increment(value, increase, minimum, maximum):
    value += increase
    if value > maximum: value = minimum
    return value
    
def decrement(value, decrease, minimum, maximum):
    value -= decrease
    if value < minimum: value = maximum
    return value
