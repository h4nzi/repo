# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

import os
import time
import json
import datetime
import socket
import subprocess

from resources.lib.utils import logNot, logErr, logTracking, notification, \
    getSettingBool, getSettingInt, getSettingStr, \
    getProperty, setProperty, clearProperty, clearProperties, jsonString, \
    getSystem
from resources.lib.const import SETTINGS, SERVICE, SOCKET, SYSTEM
import resources.lib.system as system

def timeOver (endtime):
    return time.time() > endtime

def open_channel(addr, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind((addr, port))
    sock.settimeout(SOCKET.TIMEOUT)
    return sock

def readChannel(sock):
    try:
        logNot('Service Wait...')
        data = sock.recvfrom(SOCKET.BUFFER)
        logNot('Service Read It')
        return str(data)
    except:
        setProperty(SOCKET.STATE, SOCKET.STATE_TIMEOUT)
        logNot('Service Socket read timeout')
        return None

def decodeMessage(message):
        header = jsonString(message, 'header')
        if header == None:
            setProperty(SOCKET.TEXT, message)
            setProperty(SOCKET.STATE, SOCKET.STATE_IDLE)
        else:
            logNot('Unknown message type: %s' % str(message))
            setProperty(SOCKET.STATE, SOCKET.STATE_UNKNOWN)
        return

def startJournal():
    logNot('Start journal')
    now = time.time()
    name = time.strftime('journal-%Y%m%d-%H%M%S.csv', time.localtime(now))
    addon = xbmcaddon.Addon()
    fileName = xbmcvfs.translatePath(os.path.join(addon.getAddonInfo('profile'), name))
    logNot('fileName: %s' % fileName)
    with xbmcvfs.File(fileName, 'w') as file:
        pass
    file.close()
    return fileName

def stopJournal():
    logNot('Stop journal')

def addJournal(name, time, rx, tx):
    # logNot('Add journal - Time: %s RX: %s TX: %s' % (time, rx, tx))
    file = open(name, 'a')
    file.write('%s,%s,%s\n' % (time, rx, tx))

ISJOURNAL = True
isJournal = False

buffer_rx = []
buffer_tx = []
for i in range(SERVICE.BUFFER):
    buffer_rx.append(['', ''])
    buffer_tx.append(['', ''])
message_rx = {'if': SERVICE.INTERFACE, 'down': True, 'pointer': 0, 'buffer': buffer_rx, 'data': ''}
message_tx = {'if': SERVICE.INTERFACE, 'down': False, 'pointer': 0, 'buffer': buffer_tx, 'data': ''}

class XBMCMonitor(xbmc.Monitor):

    def __init__(self, *args, **kwargs):
        xbmc.Monitor.__init__(self)
        self.SettingsChanged = False

    def onSettingsChanged(self):
        self.SettingsChanged = True

class Monitor(XBMCMonitor):

    def __init__(self):
        XBMCMonitor.__init__(self)
        logNot('Service start')
        self.getSettings()
        self.logSettings()

    def getSettings(self):
        logNot('Get addon settings')
        addon = xbmcaddon.Addon()

        self.syncClear = getSettingBool(addon, SETTINGS.SYNC_CLEAR)
        self.directionDown = getSettingBool(addon, SETTINGS.DIRECTION_DOWN)

        self.serviceRestart = getSettingBool(addon, SETTINGS.SERVICE_RESTART)
        self.serviceSleep = getSettingBool(addon, SETTINGS.SERVICE_SLEEP)
        self.serviceStartDelay = getSettingInt(addon, SETTINGS.SERVICE_START_DELAY)
        self.serviceActivePeriod = getSettingInt(addon, SETTINGS.SERVICE_ACTIVE_PERIOD)
        self.serviceIdlePeriod = getSettingInt(addon, SETTINGS.SERVICE_IDLE_PERIOD)
        self.serviceSleepPeriod = getSettingInt(addon, SETTINGS.SERVICE_SLEEP_PERIOD)
        self.serviceNotify = getSettingBool(addon, SETTINGS.SERVICE_NOTIFY)
        self.serviceProperty = getSettingBool(addon, SETTINGS.SERVICE_PROPERTY)

        self.serviceTracking = getSettingBool(addon, SETTINGS.SERVICE_TRACKING)
        self.serviceDebugNotify = getSettingBool(addon, SETTINGS.SERVICE_DEBUG_NOTIFY)

        self.SettingsChanged = False

    def logSettings(self):
        logNot('Service settings (re)loaded...')
        logNot('  syncClear:           %s' % (self.syncClear))
        logNot('  directionDown:       %s' % (self.directionDown))
        logNot('  serviceSleep:        %s' % (self.serviceSleep))
        logNot('  serviceStartDelay:   %s sec' % (self.serviceStartDelay))
        logNot('  serviceActivePeriod: %s sec' % (self.serviceActivePeriod))
        logNot('  serviceTracking:     %s' % (self.serviceTracking))
        
    def clear(self):
        pass
        
    def end(self, monitor, period):
        return monitor.abortRequested() or (period > 0 and monitor.waitForAbort(period))

    def timeToPeriod(self, start_time, period_setting):
        end_time = time.time()
        period = period_setting - (end_time - start_time)
        if period < 0:
            logNot('Service Period is less than zero!')
            period = 0
        return period

    def sleepToIdle(self, start_time, period_setting, sleep):
        delta = time.time() - start_time
        if  delta < period_setting:
            xbmc.sleep(sleep * 1000)
        return

    def start(self):
        notification('Service started')

        setProperty(SERVICE.SPEEDMETER_STATE, SERVICE.SPEEDMETER_STATE_IDLE)
        monitor = xbmc.Monitor()
        endtime = 0
        
        rx_bytes_last = 0
        tx_bytes_last = 0
        
        time_last = 0
        playing_last = False
        
        clearProperties({SERVICE.NET_RX_MBPS, SERVICE.NET_TX_MBPS, 'speedmeter'})

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((SOCKET.IP, SOCKET.PORT))
        command = ''

        # buffer_rx = []
        # buffer_tx = []
        # for i in range(37):
            # buffer_rx.append(['', '0.00'])
            # buffer_tx.append(['', '0.00'])
        # message_rx = {'if': INTERFACE, 'down': True, 'pointer': 0, 'buffer': buffer_rx, 'data': ''}
        # message_tx = {'if': INTERFACE, 'down': False, 'pointer': 0, 'buffer': buffer_tx, 'data': ''}

        lenght = len(buffer_rx)
        pointer = 0

        systemName = getSystem()
        if systemName == SYSTEM.LINUX:
            interface = system.InterfaceLinux()
        elif systemName == SYSTEM.WINDOWS or system == SYSTEM.UWP:
            interface = system.InterfaceWindows()
        else:
            interface = None
            logErr('Unsuported system: {}'.format(systemName))
            serviceError = True
        if interface != None:
            serviceError, rx_dat_start, tx_dat_start = interface.read('eth0')
        if serviceError:
            logErr('Interface data error reading')
        else:
            rx_dat_clear = rx_dat_start
            tx_dat_clear = tx_dat_start

        # fileName = startJournal()
        
        while not serviceError and not monitor.abortRequested():
            setProperty(SERVICE.SPEEDMETER_STATE, SERVICE.SPEEDMETER_STATE_ACTIVE)
            start_time = time.time()
            if self.SettingsChanged:
                self.getSettings()
                logNot('Service Settings changed')
                
            if self.syncClear:
                setProperty(SERVICE.SPEEDMETER_SYNC, SERVICE.SPEEDMETER_SYNC_ON)
            else:
                setProperty(SERVICE.SPEEDMETER_SYNC, SERVICE.SPEEDMETER_SYNC_OFF)
                
            playing = xbmc.Player().isPlaying()
            
            time_act = time.time()
            time_diff = (time_act - time_last) * 131072

            serviceError, rx_bytes, tx_bytes = interface.read('eth0')
            if serviceError:
                break

            rx_speed = (rx_bytes - rx_bytes_last) / time_diff
            tx_speed = (tx_bytes - tx_bytes_last) / time_diff
            # logNot('Service pointer: %i RX: %f TX: %f' % (pointer, rx_speed, tx_speed))

            time_last = time_act

            setProperty(SERVICE.NET_RX_MBPS, ('%0.2f' % rx_speed))
            setProperty(SERVICE.NET_TX_MBPS, ('%0.2f' % tx_speed))
            
            setProperty(SERVICE.NET_RX_DAT, ('%d' % int((rx_bytes - rx_dat_start) / 1048576)))
            setProperty(SERVICE.NET_TX_DAT, ('%d' % int((tx_bytes - tx_dat_start) / 1048576)))

            if not playing_last and playing and self.syncClear:
                logNot('Service Synchro clear')
            command = getProperty('speedmeter')
            if (len(command) > 0):
                logNot('Service Command %s' % command)
                command_clear = command == 'CLEAR'
            clearProperty('speedmeter')
            command_clear = command or (not playing_last and playing and self.syncClear)

            if command_clear:
                for i in range(SERVICE.BUFFER):
                    # logNot('Service Buffer clearing: %i' % i)
                    message_rx['buffer'][i][0] = ''
                    message_rx['buffer'][i][1] = ''
                    message_tx['buffer'][i][0] = ''
                    message_tx['buffer'][i][1] = ''
                pointer = 0
                rx_dat_clear = rx_bytes_last
                tx_dat_clear = tx_bytes_last

            message_rx['pointer'] = pointer
            message_tx['pointer'] = pointer
            
            time_string = time.strftime('%H:%M:%S', time.localtime(time_last))
            
            message_rx['buffer'][pointer][0] = time_string
            message_tx['buffer'][pointer][0] = time_string
            message_rx['buffer'][pointer][1] = ('%3.2f' % rx_speed)
            message_tx['buffer'][pointer][1] = ('%3.2f' % tx_speed)
            
            message_rx['data'] = ('%d' % int((rx_bytes - rx_dat_clear) / 1048576))
            message_tx['data'] = ('%d' % int((tx_bytes - tx_dat_clear) / 1048576))

            try:
                self.sock.sendto(json.dumps(message_rx).encode(), (SOCKET.IP, SOCKET.PORT))
            except:
                logNot('Service Message_rx not send')
            try:
                self.sock.sendto(json.dumps(message_tx).encode(), (SOCKET.IP, SOCKET.PORT))
            except:
                logNot('Service Message_tx not send')
            
            # addJournal(fileName, time_string, ('%3.2f' % rx_speed), ('%3.2f' % tx_speed))

            rx_bytes_last = rx_bytes
            tx_bytes_last = tx_bytes

            playing_last = playing

            pointer += 1
            pointer %= lenght

            self.sleepToIdle(start_time, SERVICE.PERIOD_ACTIVE, 1)
            setProperty(SERVICE.SPEEDMETER_STATE, SERVICE.SPEEDMETER_STATE_IDLE)
            if serviceError or self.end(monitor, self.timeToPeriod(start_time, SERVICE.PERIOD_ACTIVE)):
                break

    def stop(self):
        clearProperties({SERVICE.NET_RX_MBPS, SERVICE.NET_TX_MBPS, SERVICE.SPEEDMETER_STATE})
        self.sock.close()
        # stopJournal()
        notification('Service stoped')
