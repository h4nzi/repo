# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

import os
import time
import json
import datetime
import socket
import platform

from resources.lib.utils import logNot, logErr, logTracking, notification, \
    getSettingBool, getSettingInt, getSettingStr, \
    getProperty, setProperty, clearProperty, clearProperties, jsonString, \
    decrement, increment
from resources.lib.addon import ADDON
from resources.lib.const import SETTINGS, TABLE, TRANSPARENCY, MONITOR, SOCKET, ACTIONS, PARAMS, FORMAT
from resources.lib.skin import ID

monitor = xbmc.Monitor()

def timeOver (endtime):
    return time.time() > endtime

def open_channel(addr, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind((addr, port))
    sock.settimeout(SOCKET.TIMEOUT)
    return sock

def readChannel(sock):
    try:
        receiveFrom = sock.recvfrom(SOCKET.BUFFER)
        data = receiveFrom[0]
        addr = receiveFrom[1]
        # logNot('readChannel: Data: %s Addr: %s' % (data, addr))
        return data
    except:
        # logNot('readChannel: no data!')
        pass

class Gui(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self.positionMapping()

    def onInit(self):
        self.getControl(ID.MAXIMIZE).setVisible(False)
        self.getControl(ID.MINIMIZE).setVisible(False)
        self.hideLimits({ID.MINIMUM + 1, ID.AVERAGE + 1, ID.MAXIMUM + 1, ID.MINIMUM_MINI, ID.AVERAGE_MINI, ID.MAXIMUM_MINI})
        self.hideTransparency()
        self.getSettings()
        self.transparencySetting(self.transparencyLevel, TRANSPARENCY.DIFFUSE)
        if self.startMinimized:
            self.getControl(ID.MAXIMIZE).setVisible(False)
            self.getControl(ID.MINIMIZE).setVisible(True)
            self.minimizeWindow = True
            self.moveMinimize(self.positionMinimized)
        else:
            self.getControl(ID.MAXIMIZE).setVisible(True)
            self.getControl(ID.MINIMIZE).setVisible(False)
            self.minimizeWindow = False
        self.systemInfo(ID.BOTTOM)
        self.getControl(ID.MENU).setVisible(False)
        self.menuVisible = False
        self.exitScript = False
        clearProperty('speedmeter')
        self.commandService = ''
        self.startGraph()

    def getSettings(self):
        self.startMinimized = getSettingBool(ADDON.ADDON, SETTINGS.START_MINIMIZED)
        self.syncClear = getSettingBool(ADDON.ADDON, SETTINGS.SYNC_CLEAR)
        self.directionDown = getSettingBool(ADDON.ADDON, SETTINGS.DIRECTION_DOWN)
        self.transparencyLevel = getSettingInt(ADDON.ADDON, SETTINGS.TRANSPARENCY_LEVEL)
        self.positionMinimized = getSettingInt(ADDON.ADDON, SETTINGS.POSITION_MINIMIZED)
        # For future...
        self.scriptTracking = getSettingBool(ADDON.ADDON, SETTINGS.SCRIPT_TRACKING)
        self.scriptDebugNotify = getSettingBool(ADDON.ADDON, SETTINGS.SCRIPT_DEBUG_NOTIFY)
        
    def setSettings(self):
        ADDON.ADDON.setSettingBool(SETTINGS.SYNC_CLEAR, self.syncClear)
        ADDON.ADDON.setSettingBool(SETTINGS.DIRECTION_DOWN, self.directionDown)
        ADDON.ADDON.setSettingInt(SETTINGS.TRANSPARENCY_LEVEL, self.transparencyLevel)
        ADDON.ADDON.setSettingInt(SETTINGS.POSITION_MINIMIZED, self.positionMinimized)

    def onAction(self, action):
        # logNot('getId: %i getButton: %i getWindowDialogId: %i' % (action.getId(), action.getButtonCode(), xbmcgui.getCurrentWindowDialogId()))
        actionCode = action.getId()
        focusCode = self.getFocusId()
        buttonCode = action.getButtonCode()
        if self.menuVisible:
            # logNot('onAction call routerMenu')
            self.routerMenu(actionCode, focusCode)
        elif self.minimizeWindow: 
            # logNot('onAction call routerMinimize')
            self.routerMinimize(actionCode, buttonCode)
        else:
            # logNot('onAction call routerGeneral')
            self.routerGeneral(actionCode, buttonCode)

    def positionMapping(self):
        self.MAP = [[0, 3, 6],[1, 4, 7],[2, 5, 8]]
        self.INV = [[0, 0], [1, 0], [2, 0], [0, 1], [1, 1], [2, 1],[0, 2],[1, 2],[2, 2]]
        W = self.getWidth()
        H = self.getHeight()
        w = 600
        h = 425
        d = int((W - 3 * w) / 6)
        x1 = int(d)
        x2 = int(3 * d + w)
        x3 = int(5 * d + 2 * w)
        y1 = d
        y2 = int((H - h) / 2)
        y3 = H - h - d
        self.POS = [[x1, y1], [x2, y1], [x3, y1], [x1, y2], [x2, y2], [x3, y2],[x1, y3],[x2, y3],[x3, y3]]
  
    def routerGeneral(self, actionCode, buttonCode):
        self.setStatus(MONITOR.PHASE_WAIT)
        if actionCode == ACTIONS.ACTION_NAV_BACK or actionCode == ACTIONS.ACTION_PREVIOUS_MENU:
            # logNot('routerGeneral set exitScript call close')
            self.setStatus(MONITOR.PHASE_WAIT)
            self.exitScript = True
            self.close()
        elif actionCode == ACTIONS.ACTION_SELECT_ITEM:
            # logNot('routerGeneral set menuVisible')
            self.menuVisible = True
            self.getControl(ID.MENU).setVisible(True)
            self.setFocusId(ID.MENU_LIST)
        else:
            pass

    def moveMinimize(self, position):
        self.getControl(ID.MINIMIZE).setPosition(self.POS[position][0], self.POS[position][1])

    def routerMinimize(self, actionCode, buttonCode):
        if actionCode == ACTIONS.ACTION_NAV_BACK or actionCode == ACTIONS.ACTION_PREVIOUS_MENU:
            self.exitScript = True
            self.close()
        elif actionCode == ACTIONS.ACTION_SELECT_ITEM:
            self.menuVisible = True
            self.minimizeWindow = False
            self.getControl(ID.MAXIMIZE).setVisible(True)
            self.getControl(ID.MINIMIZE).setVisible(False)
            self.getControl(ID.MENU).setVisible(True)
            self.setFocusId(ID.MENU_LIST)
        elif actionCode == ACTIONS.ACTION_MOVE_LEFT or actionCode == ACTIONS.ACTION_MOVE_RIGHT:
            posx = self.INV[self.positionMinimized][0]
            if actionCode == ACTIONS.ACTION_MOVE_LEFT:
                posx = decrement(posx, 1, 0, 2)
            else:
                posx = increment(posx, 1, 0, 2)
            self.positionMinimized = self.MAP[posx][self.INV[self.positionMinimized][1]]
            self.moveMinimize(self.positionMinimized)
        elif actionCode == ACTIONS.ACTION_MOVE_UP or actionCode == ACTIONS.ACTION_MOVE_DOWN:
            posy = self.INV[self.positionMinimized][1]
            if actionCode == ACTIONS.ACTION_MOVE_UP:
                posy = decrement(posy, 1, 0, 2)
            else:
                posy = increment(posy, 1, 0, 2)
            self.positionMinimized = self.MAP[self.INV[self.positionMinimized][0]][posy]
            self.moveMinimize(self.positionMinimized)
        else:
            pass

    def routerMenu(self, actionCode, focusCode):
        if actionCode == ACTIONS.ACTION_NAV_BACK or actionCode == ACTIONS.ACTION_PREVIOUS_MENU:
            self.menuVisible = False
            self.getControl(ID.MENU).setVisible(False)
            self.setFocusId(0)
        elif actionCode == ACTIONS.ACTION_SELECT_ITEM:
            if focusCode == ID.MENU_MINIMIZE:
                self.menuVisible = False
                self.minimizeWindow = True
                self.getControl(ID.MAXIMIZE).setVisible(False)
                self.getControl(ID.MINIMIZE).setVisible(True)
                self.moveMinimize(self.positionMinimized)
            elif focusCode == ID.MENU_DIRECTION:
                self.setStatus(MONITOR.PHASE_WAIT)
                self.directionDown = not self.directionDown
                self.commandService='DIRECTION'
            elif focusCode == ID.MENU_TRANSPARENCY:
                self.transparencyLevel += 1
                self.transparencyLevel %= 8
                self.transparencySetting(self.transparencyLevel, TRANSPARENCY.DIFFUSE)
            elif focusCode == ID.MENU_BUFFER:
                self.setStatus(MONITOR.PHASE_WAIT)
                self.commandService='CLEAR'
                setProperty('speedmeter','CLEAR')
            elif focusCode == ID.MENU_SYNC:
                self.setStatus(MONITOR.PHASE_WAIT)
                self.syncClear = not getSettingBool(ADDON.ADDON, SETTINGS.SYNC_CLEAR)
                ADDON.ADDON.setSettingBool(SETTINGS.SYNC_CLEAR, self.syncClear)
            elif focusCode == ID.MENU_SETTINGS:
                self.setSettings()
                ADDON.ADDON.openSettings()
                self.getSettings()
            else:
                pass
        else:
            pass

    def transparencySetting(self, index, diffuse):
        self.getControl(ID.MAXIMAZE_BACKGROUND).setColorDiffuse(diffuse[index][0])
        self.getControl(ID.MAXIMAZE_BACKGROUND).setVisible(True)
        self.getControl(ID.MAXIMAZE_HEADER).setColorDiffuse(diffuse[index][1])
        self.getControl(ID.MAXIMAZE_HEADER).setVisible(True)
        self.getControl(ID.MINIMAZE_BACKGROUND).setColorDiffuse(diffuse[index][0])
        self.getControl(ID.MINIMAZE_BACKGROUND).setVisible(True)
        self.getControl(ID.MENU_TRANSPARENCY_LEVEL).setLabel('%i' % index)

    def hideTransparency(self):
        self.getControl(ID.MAXIMAZE_BACKGROUND).setVisible(False)
        self.getControl(ID.MAXIMAZE_HEADER).setVisible(False)
        self.getControl(ID.MINIMAZE_BACKGROUND).setVisible(False)

    def systemInfo(self, pos):
        info = (FORMAT.SYSTEM_INFO % (platform.system(), platform.release()))
        self.getControl(pos).setLabel(info)

    def calcLimits(self, buffer):
        minimum = 9999.9
        maximum = 0.0
        average = 0
        count = 0
        for i in range(len(buffer)):
            if len(buffer[i][0]) > 0:
                value = float(buffer[i][1])
                if value > PARAMS.AVERAGE_LIMIT:
                    count +=1
                    average += value
                if value < minimum:
                    minimum = value
                if value > maximum:
                    maximum = value
        if count > 0:
            average /=count
        else:
            average = 0
        return minimum, average, maximum

    def setStatus(self, status):
        self.getControl(ID.REFRESH).setLabel('[B]'+status+'[/B]')

    def setScale(self, value, limit):
        index = 1
        multi = 0
        for i in range(1, len(TABLE.AXIS) - 1):
            if value <= TABLE.AXIS[i][limit]:
                break
            index += 1
        multi = 100.0 / TABLE.AXIS[index][5]
        # logNot('Value: %s Scale index: %i' % (str(value), index))
        if index == 1 or index == 2:
            num = '%.1f'
        else:
            num = '%3i'
        for i in range(6):
            self.getControl(TABLE.AXIS[0][i]).setLabel(num % TABLE.AXIS[index][i])
            self.getControl(ID.AXIS_MINI + i + 1).setLabel(num % TABLE.AXIS[index][i])
            # logNot('%i:[B]%3i[/B]' % (TABLE.AXIS[0][i], TABLE.AXIS[index][i]))
        return multi
            
    def setLimit(self, id, value = 0, multi = 1):
        percent = value * multi
        self.getControl(id + 1).setVisible(percent > 0 and percent < 100)
        self.getControl(id + 1).setPosition(x=int(percent * 10), y=0)

    def setLimitMini(self, id, value = 0, multi = 1):
        percent = value * multi
        self.getControl(id).setVisible(percent > 0 and percent < 100)
        self.getControl(id).setPosition(x=int(percent * 10), y=0)
        
    def hideLimits(self, ids):
        for id in ids:
            self.getControl(id).setVisible(False)

    def startGraph(self):
        logNot('startGraph')
        self.setStatus(MONITOR.PHASE_INIT)
        self.setLimit(ID.MINIMUM)
        self.setLimit(ID.MAXIMUM)
        self.setLimit(ID.AVERAGE)
        self.sock = open_channel(SOCKET.IP, SOCKET.PORT)
        while not monitor.abortRequested():
            try:
                data = readChannel(self.sock).decode("utf-8")
                message = json.loads(data)
                if self.directionDown and not message['down'] or not self.directionDown and message['down']:
                    continue
            except:
                if monitor.waitForAbort(1) or self.exitScript:
                    ADDON.ADDON.setSettingInt(SETTINGS.TRANSPARENCY_LEVEL, self.transparencyLevel)
                    self.setSettings()
                    logNot('stopGraph')
                    self.close()
                    break
            else:
                self.commandService = ''
                self.setStatus(MONITOR.PHASE_REFRESH)
                if self.directionDown:
                    direction = FORMAT.DOWNLOAD
                else:
                    direction = FORMAT.UPLOAD
                self.getControl(ID.DOWN_UP).setLabel(direction)
                interface = (FORMAT.INTERFACE % message['if'])
                self.getControl(ID.INTERFACE).setLabel(interface)
                buffer = message['buffer']
                minimum, average, maximum = self.calcLimits(buffer)
                info = (FORMAT.INFO % (minimum, average, maximum, message['data']))
                self.getControl(ID.INFO).setLabel(info)
                multi = self.setScale(maximum, 5)
                self.setLimit(ID.MINIMUM, minimum, multi)
                self.setLimit(ID.AVERAGE, average, multi)
                self.setLimit(ID.MAXIMUM, maximum, multi)
                self.setLimitMini(ID.MINIMUM_MINI, minimum, multi / 2)
                self.setLimitMini(ID.AVERAGE_MINI, average, multi / 2)
                self.setLimitMini(ID.MAXIMUM_MINI, maximum, multi / 2)
                pointer = message['pointer']
                lenght = len(buffer)
                self.getControl(ID.MAXIMIZE).setVisible(not self.minimizeWindow)
                self.getControl(ID.MINIMIZE).setVisible(self.minimizeWindow)
                for i in range(lenght):
                    self.getControl(ID.GRAPH_TIME + i).setLabel(buffer[pointer][0])
                    self.getControl(ID.GRAPH_VALUE + i).setLabel(buffer[pointer][1])
                    if len(buffer[pointer][1]) > 0:
                        percent = float(buffer[pointer][1]) * multi
                    else:
                        percent = 0
                    self.getControl(ID.GRAPH + i).setPercent(percent)
                    self.getControl(ID.GRAPH_MINI + i).setPercent(percent)
                    pointer = decrement(pointer, 1, 0, lenght - 1)
                if len(getProperty('speedmeter')) > 0:
                    self.setStatus(MONITOR.PHASE_WAIT)
                else:
                    self.setStatus(MONITOR.PHASE_IDLE)
                if monitor.waitForAbort(1) or self.exitScript:
                    self.setSettings()
                    logNot('stopGraph')
                    self.close()
                    break
                    
