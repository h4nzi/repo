# -*- coding: utf-8 -*-

import subprocess
import re

from resources.lib.utils import logNot

LINUX_RX_COMMAND = ('ifconfig {} | grep "RX bytes:" | sed -re "s/.*RX bytes:([0-9]*).*/\\1/"')
LINUX_TX_COMMAND = ('ifconfig {} | grep "TX bytes:" | sed -re "s/.*TX bytes:([0-9]*).*/\\1/"')

LINUX_GET_ROUTE = ('route | grep "^{}" | grep -o "[^ ]*$"')


WINDOWS_COMMAND = ('netstat -e')

def systemCommand(command):
    return subprocess.Popen(command, stdout=subprocess.PIPE, shell=True).stdout.read().rstrip()

class InterfaceLinux():

    def __init__(self):
        pass

    def read(self, interface):
        try:
            return False, int(systemCommand(LINUX_RX_COMMAND.format(interface))), int(systemCommand(LINUX_TX_COMMAND.format(interface)))
        except:
            return True, -1, -1

    def getRoute(self, route):
        try:
            return False, str(systemCommand(LINUX_GET_ROUTE.format(route)))
        except:
            return True, None


class InterfaceWindows():

    def __init__(self):
        pass

    def read(self, interface = 'default'):
        try:
            lineBytes = re.search('Bytes\s*[0-9]*\s*[0-9]*', str(systemCommand(WINDOWS_COMMAND))).group()
            logNot('lineBytes: {}'.format(lineBytes))
            data = re.split("\s+", str(lineBytes))
            return False, int(data[1]), int(data[2])
        except:
            return True, -1, -1
