# -*- coding: utf-8 -*-

from resources.lib.skin import ID

class SYSTEM:
    LINUX = 'Linux'
    WINDOWS = 'Windows'
    OSX = 'OSX'
    IOS = 'IOS'
    DARWIN = 'Darwin'
    ANDROID = 'Android'
    UWP = 'UWP'

class SETTINGS:
    START_MINIMIZED = 'start_minimized'
    SYNC_CLEAR = 'sync_clear'
    DIRECTION_DOWN = 'direction_down'
    TRANSPARENCY_LEVEL = 'transparency_level'
    POSITION_MINIMIZED = 'position_minimized'

    DIFFUSE_WINDOW_HEADER = 'diffuse_window_header'
    DIFFUSE_WINDOW_BACKGROUND = 'diffuse_window_background'
    DIFFUSE_PROGRESS_FOREGROUND = 'diffuse_progress_foreground'
    DIFFUSE_PROGRESS_BACKGROUND = 'diffuse_progress_background'

    SERVICE_RESTART = 'service_restart'
    SERVICE_SLEEP = 'service_sleep'
    SERVICE_START_DELAY = 'service_start_delay'
    SERVICE_ACTIVE_PERIOD = 'service_active_period'
    SERVICE_IDLE_PERIOD = 'service_idle_period'
    SERVICE_SLEEP_PERIOD = 'service_sleep_period'
    SERVICE_NOTIFY = 'service_notify'
    SERVICE_PROPERTY = 'service_property'
    
    SERVICE_TRACKING = 'service_tracking'
    SERVICE_DEBUG_NOTIFY = 'service_debug_notify'

    SCRIPT_TRACKING = 'script_tracking'
    SCRIPT_DEBUG_NOTIFY = 'script_debug_notify'

class SERVICE:
    PERIOD_ACTIVE = 5
    PERIOD_SLEEP = 5

    TRACKING = True

    SPEEDMETER_PERIOD = 'speedmeter_period'
    SPEEDMETER_STATE = 'speedmeter_state'
    SPEEDMETER_SYNC = 'speedmeter_sync'

    SPEEDMETER_STATE_ACTIVE = 'ACTIVE'
    SPEEDMETER_STATE_ERROR = 'ERROR'
    SPEEDMETER_STATE_IDLE = 'IDLE'
    SPEEDMETER_STATE_READ = 'ACTIVE'
    SPEEDMETER_STATE_RUN = 'ACTIVE'
    SPEEDMETER_STATE_SLEEP = 'SLEEP'
    SPEEDMETER_STATE_STOP = ''

    SPEEDMETER_SYNC_ON = 'ON'
    SPEEDMETER_SYNC_OFF = 'OFF'

    NET_RX_MBPS = 'speedmeter_rx_mbps'
    NET_TX_MBPS = 'speedmeter_tx_mbps'

    NET_RX_DAT = 'speedmeter_rx_dat'
    NET_TX_DAT = 'speedmeter_tx_dat'

    INTERFACE = 'eth0'

    RX_BYTES = ('ifconfig %s | grep "RX bytes:" | sed -re "s/.*RX bytes:([0-9]*).*/\\1/"' % INTERFACE)
    TX_BYTES = ('ifconfig %s | grep "TX bytes:" | sed -re "s/.*TX bytes:([0-9]*).*/\\1/"' % INTERFACE)
    
    BUFFER = 37

class SOCKET:
    TEXT = 'socket_text'
    STATE = 'socket_state'

    STATE_ACTIVE = 'ACTIVE'
    STATE_TIMEOUT = 'TIMEOUT'
    STATE_UNKNOWN = 'UNKNOWN'
    STATE_EROR = 'ERROR'
    STATE_IDLE = 'IDLE'

    IP = '127.0.0.1'
    PORT = 57750
    BUFFER = 1024
    TIMEOUT = 2

class TABLE:
    AXIS = [
    [ID.AXIS + 1, ID.AXIS + 2, ID.AXIS + 3, ID.AXIS + 4, ID.AXIS + 5, ID.AXIS + 6],
    [0.0, 0.1, 0.2, 0.3, 0.4, 0.5],
    [0.0, 0.2, 0.4, 0.6, 0.8, 1.0],
    [0, 1, 2, 3, 4, 5],
    [0, 2, 4, 6, 8, 10],
    [0, 4, 8, 12, 16, 20],
    [0, 10, 20, 30, 40, 50],
    [0, 20, 40, 60, 80, 100],
    [0, 40, 80, 120, 160, 200],
    [0, 100, 200, 300, 400, 500],
    [0, 200, 400, 600, 800, 1000]
    ]

class TRANSPARENCY:
    DIFFUSE = [
    ['FF1A2123', 'FF12A0C7', 'FFFFFFFF', 'FF12A0C7'],
    ['EF1A2123', 'EF12A0C7', 'DFFFFFFF', 'EF12A0C7'],
    ['DF1A2123', 'DF12A0C7', 'BFFFFFFF', 'DF12A0C7'],
    ['CF1A2123', 'CF12A0C7', '9FFFFFFF', 'CF12A0C7'],
    ['BF1A2123', 'BF12A0C7', '7FFFFFFF', 'BF12A0C7'],
    ['AF1A2123', 'AF12A0C7', '5FFFFFFF', 'AF12A0C7'],
    ['9F1A2123', '9F12A0C7', '3FFFFFFF', '9F12A0C7'],
    ['7F1A2123', '7F12A0C7', '1FFFFFFF', '7F12A0C7']
    ]

class MONITOR:
    PERIOD = 'monitor_period'
    PHASE = 'monitor_phase'

    PHASE_STOP = ''
    PHASE_SLEEP = 'SLEEP'
    PHASE_ACTIVE = 'ACTIVE'
    PHASE_RUN = 'ACTIVE'
    PHASE_IDLE = 'IDLE'
    PHASE_WAIT = 'WAITING'
    PHASE_REFRESH = 'REFRESH'
    PHASE_INIT = 'INIT'

class ACTIONS:
    ACTION_MOVE_LEFT = 1
    ACTION_MOVE_RIGHT = 2
    ACTION_MOVE_UP = 3
    ACTION_MOVE_DOWN = 4
    ACTION_SELECT_ITEM = 7
    ACTION_PREVIOUS_MENU = 10
    ACTION_NAV_BACK = 92

    REMOTE_0 = 58
    REMOTE_1 = 59
    REMOTE_2 = 60
    REMOTE_3 = 61
    REMOTE_4 = 62
    REMOTE_5 = 63
    REMOTE_6 = 64
    REMOTE_7 = 65
    REMOTE_8 = 66
    REMOTE_9 = 67

class PARAMS:
    AVERAGE_LIMIT = 0.01
    AVERAGE_SWITCH = 5

class FORMAT:
    DOWNLOAD = '[B]Download[/B]'
    UPLOAD = '[B]Upload[/B]'
    INTERFACE = '[B]%s[/B]'
    INFO = 'Min: [COLOR=green][B]%3.2f[/B][/COLOR][B] · [/B]Avg: [COLOR=yellow][B]%3.3f[/B][/COLOR][B] · [/B]Max: [COLOR=red][B]%3.2f[/B][/COLOR] Mbps[B] · [/B]Data: [B]%s[/B] MB'
    SYSTEM_INFO = '[B][/B]System: [B]%s[/B][B] · [/B]Release: [B]%s[/B]'