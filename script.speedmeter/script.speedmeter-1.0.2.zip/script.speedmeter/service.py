# -*- coding: utf-8 -*-

from resources.lib.utils import logNot
import resources.lib.service as service

if __name__ == '__main__':
    addon = service.Monitor()
    addon.start()
    addon.stop()
    logNot('Service stop')
    del addon
        