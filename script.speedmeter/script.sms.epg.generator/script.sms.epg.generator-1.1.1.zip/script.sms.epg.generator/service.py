import xbmc
import xbmcaddon
import xbmcgui
import time

addon = xbmcaddon.Addon()

def update():
    if addon.getSetting("start_enabled") == "true":
        time.sleep(120)
        xbmcgui.Dialog().notification("SMS EPG Generator","Aktualizace po startu spuštěna", xbmcgui.NOTIFICATION_INFO, 4000, sound = True)
        xbmc.executebuiltin('RunScript("special://home/addons/script.sms.epg.generator/resources/lib/start.py")')

if __name__ == '__main__':
    update()

