import xbmcgui
import xbmcplugin
import xbmc
import sys
import urllib.parse
import unicodedata
import re
import requests

HANDLE = int(sys.argv[1])

def Msg(message):
    xbmc.log(f"[FilmFinder] {message}", level=xbmc.LOGINFO)

def make_slug(title):
    title = unicodedata.normalize('NFD', title)
    title = title.encode('ascii', 'ignore').decode('utf-8')
    title = title.lower()
    title = re.sub(r'[^a-z0-9]+', '-', title)
    title = title.strip('-')
    return title

def run():
    keyboard = xbmcgui.Dialog().input("Zadej název filmu", type=xbmcgui.INPUT_ALPHANUM)
    if not keyboard:
        return

    Msg(f"Zadaný název: {keyboard}")
    query = urllib.parse.quote_plus(keyboard)

    url = f"https://www.sledujteto.cz/services/get-files?limit=32&me=0&page=1&query={query}&sort=relevance"
    Msg(f"Načítám API: {url}")
    
    try:
        response = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'})
        data = response.json()

        if data.get("error") or not data.get("files"):
            xbmcgui.Dialog().ok("Film Finder", "Nenalezeny žádné výsledky.")
            return

        for item in data["files"]:
            title = item.get("name", "Neznámý název")
            full_url = item.get("full_url")
            preview = item.get("preview")
            filesize = item.get("filesize", "")
            duration = item.get("movie_duration", "")
            label = f"{title} ({filesize}, {duration})"

            li = xbmcgui.ListItem(label=label)
            li.setArt({"thumb": preview, "icon": preview, "poster": preview})
            li.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=full_url, listitem=li, isFolder=False)

    except Exception as e:
        Msg(f"Chyba při načítání JSON: {str(e)}")
        xbmcgui.Dialog().ok("Chyba", "Nepodařilo se načíst výsledky z API.")

    xbmcplugin.endOfDirectory(HANDLE)
