from resources.lib import filmfinder

if __name__ == "__main__":
    filmfinder.run()
