import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

addon = xbmcaddon.Addon(id='service.birthdays.reminder')
userpath = addon.getAddonInfo('profile')
folder = addon.getSetting('folder')
file_name = addon.getSetting('file_name')

birthday_file = os.path.join(userpath, 'addons', addon.getAddonInfo('id'), folder, file_name)
custom_names_path = xbmcvfs.translatePath("%s/my_names.txt" % userpath)
if not xbmcvfs.exists(userpath):
    xbmcvfs.mkdir(userpath)

try:
    with open(birthday_file, 'r') as file:
        content = file.read()
        dialog = xbmcgui.Dialog()
        dialog.textviewer('Obsah souboru', content)
        
except FileNotFoundError:
    xbmc.log("Soubor nenalezen.", level=1)
except IOError:
    xbmc.log("Chyba při čtení souboru.", level=1)

