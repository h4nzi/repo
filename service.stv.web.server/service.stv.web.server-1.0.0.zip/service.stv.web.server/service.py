# -*- coding: utf-8 -*-

import xbmcaddon, sys, xbmc, os, xbmcgui, bottle, xbmcvfs, requests, json, socket
from bottle import route, redirect, default_app, response, request, static_file, template, TEMPLATE_PATH
from wsgiref.simple_server import WSGIServer, WSGIRequestHandler, make_server
from socketserver import ThreadingMixIn
from threading import Thread
from resources.lib.providers.stvcz import scz
from urllib.parse import urlparse, urlencode, parse_qsl, quote, unquote
from resources.lib import czech_sort
from datetime import datetime

addon = xbmcaddon.Addon()
addon_dir = xbmcvfs.translatePath(addon.getAddonInfo('path'))
addon_icon = os.path.join(addon_dir, "icon.png")
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
app = default_app()
bottle.debug(True)
PORT = addon.getSetting("port")

# Nastavení cesty k šablonám
TEMPLATE_PATH.append(os.path.join(addon_dir, 'resources', 'lib', 'templates'))



def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)
# Msg(f"[STV Server] Dev {deviceId}")


def get_catchup():
    if xbmcaddon.Addon().getSetting("catchup_mode") == "0":
        catchup = ' catchup="append" catchup-source="?utc={utc}&utcend={utcend}",'
    else:
        catchup = ' timeshift="15",'
    return catchup


def get_inputstream():
    if xbmcaddon.Addon().getSetting("inputstream") == "true":
        input_stream = "#KODIPROP:inputstream=inputstream.adaptive\n#KODIPROP:inputstream.adaptive.manifest_type=hls\n#KODIPROP:mimetype=application/vnd.apple.mpegurl\n"
    else:
        input_stream = ""
    return input_stream


def getNetworkIp():
    HOST = xbmcaddon.Addon().getSetting("localhost")
    if HOST == "0":
        i = "localhost"
    else:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            i = s.getsockname()[0]
            s.close()
        except:
            i = "localhost"
    return i


IP = getNetworkIp()
input_stream = get_inputstream()
catchup = get_catchup()


def patch_url(url, **kwargs):
    return urlparse(url)._replace(query=urlencode(dict(parse_qsl(urlparse(url).query), **kwargs))).geturl()


@route('/files/<filename:path>')
def send_static(filename):
    return static_file(filename, root= xbmcaddon.Addon().getSetting("files_dir"))


@route("/own/playlist")
def own_playlist():
    try:
        with open(custom_channels_path, 'r') as openfile:
            data = json.load(openfile)
    except:
        return ""
    t = ""

    if "stvcz" in data.keys():
        for x,y in data["stvcz"]["playlist"].items():
            if y["type"] == "tv":
                t = t + '#EXTINF:-1 provider="SledovaniTV.cz" tvg-logo="' +y["logo"] + '"' + catchup + y["name"] + "\n" + input_stream + "http://" + str(IP) + ":" + str(PORT)  + "/stvcz/" + str(x) + ".m3u8\n"
            else:
                t = t + '#EXTINF:-1 provider="SledovaniTV.cz" radio="true" tvg-logo="' +y["logo"] + '"' + catchup + y["name"].replace(" HD", "") + "\nhttp://" + str(IP) + ":" + str(PORT)  + "/stvcz/" + str(x) + ".m3u8\n"
    
    if t != "":
        t = "#EXTM3U\n" + t
    response.content_type = 'text/plain; charset=UTF-8'
    return t

@route("/stvcz/vod/<id>")
def stvcz_vod_play(id):
    stream = scz.get_vod_stream(id)
    response.content_type = "application/vnd.apple.mpegurl"
    return redirect(stream)


@route("/stvcz/vod/playlist")
def stvcz_vod_playlist():
    t = ""
    movies = scz.vod_favorites()
    if movies != {}:
        for x,y in movies.items():
            t = t + '#EXTINF:-1 provider="SledovaniTV.cz" tvg-logo="' + y["logo"] + '",' + y["name"] + "\n#EXT-X-PLAYLIST-TYPE:VOD\n" + "http://" + str(IP) + ":" + str(PORT)  + "/stvcz/vod/" + str(x) + ".m3u8\n"
    if t != "":
        t = "#EXTM3U\n" + t
    response.content_type = 'text/plain; charset=UTF-8'
    return t


@route("/stvcz/vod/list")
def stvcz_vod_list():
    names = []
    info = {'title': 'SledovaniTV.cz VOD'}
    try:
        for x,y in scz.vod_favorites().items():
            names.append(('/stvcz/vod/' + str(x) + '.m3u8', y["name"]))    
        info["names"] = names
    except:
        return ""
    return template(style_links, info)


@route("/stvcz/playlist")
def stvcz_playlist():
    t = ""
    for x,y in scz.channels.items():
        if y["type"] == "tv":
            t = t + '#EXTINF:-1 provider="SledovaniTV.cz" group-title="' + y["group"] + '" tvg-logo="' +y["logo"] + '"' + catchup + y["name"] + "\n" + input_stream + "http://" + str(IP) + ":" + str(PORT)  + "/stvcz/" + str(x) + ".m3u8\n"
        else:
            t = t + '#EXTINF:-1 provider="SledovaniTV.cz" radio="true" group-title="' + y["group"] + '" tvg-logo="' +y["logo"] + '"' + catchup + y["name"].replace(" HD", "") + "\nhttp://" + str(IP) + ":" + str(PORT)  + "/stvcz/" + str(x) + ".m3u8\n"
    if xbmcaddon.Addon().getSetting("stvcz_favorite") == "true":
        movies = scz.vod_favorites()
        if movies != {}:
            for x,y in movies.items():
                t = t + '#EXTINF:-1 provider="SledovaniTV.cz" group-title="Nahrávky" tvg-logo="' + y["logo"] + '",' + y["name"] + "\n#EXT-X-PLAYLIST-TYPE:VOD\n" + input_stream + "http://" + str(IP) + ":" + str(PORT)  + "/stvcz/vod/" + str(x) + ".m3u8\n"
    if t != "":
        t = "#EXTM3U\n" + t
    response.content_type = 'text/plain; charset=UTF-8'
    return t


@route("/stvcz/<id>")
def stvcz_play(id):
    if 'utc' in request.query:
        stream = scz.get_catchup(id,
 request.query["utc"], "")
    else:
        stream = scz.channels[id.split(".")[0]]["url"]
        if "PHPSESSID" in stream:
            sessid = scz.get_sessid()
            stream = patch_url(stream, PHPSESSID=sessid)
    response.content_type = "application/vnd.apple.mpegurl"
    return redirect(stream)


@route("/stvcz/list")
def stvcz_list():
    names = []
    info = {'title': 'SledovaniTV.cz'}
    try:
        for x,y in scz.channels.items():
            names.append(('/stvcz/' + str(x) + '.m3u8', y["name"].replace(" HD", "")))    
        info["names"] = names
    except:
        return ""
    return template('links.tpl', info)


@route("/")
def home():
    return template('home.tpl')


def begin():
    xbmcgui.Dialog().notification("IPTV Web Server","http://" + str(IP) + ":" + str(PORT), sound = False, icon = addon_icon)
    Msg("[STV Server] Web server running at: http://" + str(IP) + ":" + str(PORT))
    httpd.serve_forever()


def restart_pvr():
    try:
        xbmc.sleep(2000)
        xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":false}}}}'.format('pvr.iptvsimple'))
        xbmc.sleep(2000)
        xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":true}}}}'.format('pvr.iptvsimple'))
    except:
        pass


class SilentWSGIRequestHandler(WSGIRequestHandler):
    """Custom WSGI Request Handler with logging disabled"""
    protocol_version = 'HTTP/1.1'

    def log_message(self, *args, **kwargs):
        """Disable log messages"""
        pass


class ThreadedWSGIServer(ThreadingMixIn, WSGIServer):
    """Multi-threaded WSGI server"""
    allow_reuse_address = True
    daemon_threads = True
    timeout = 1


httpd = make_server(str(IP), int(PORT), app,
                    server_class=ThreadedWSGIServer,
                    handler_class=SilentWSGIRequestHandler)


def main():
    thread = Thread(target = begin)
    thread.daemon = True
    thread.start()
    if addon.getSetting("pvr") == "true":
        restart_pvr()
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            httpd.shutdown()
            break


if __name__ == '__main__':
    main()