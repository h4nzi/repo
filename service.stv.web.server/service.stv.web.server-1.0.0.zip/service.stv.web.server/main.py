# -*- coding: utf-8 -*-


import routing, xbmcgui, xbmcaddon, xbmcvfs, os, json, xbmcplugin, requests, socket


plugin = routing.Plugin()
addon = xbmcaddon.Addon()
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
addon_dir = xbmcvfs.translatePath( addon.getAddonInfo('path') )
addon_icon = os.path.join(addon_dir, "icon.png")

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)
# Msg(f"[STV Server] Dev {deviceId}")


def getNetworkIp():
    HOST = xbmcaddon.Addon().getSetting("localhost")
    if HOST == "0":
        i = "localhost"
    else:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            i = s.getsockname()[0]
            s.close()
        except:
            i = "localhost"
    return i

@plugin.route('/stvcz_login')
def stvcz_login():
    from resources.lib.providers.stvcz import login
    login.main()
    
@plugin.route('/own_playlist_save')
def own_playlist_save():
    dialog = xbmcgui.Dialog()
    fd = dialog.browse(3, 'Vyberte umístění', "files")
    if fd != "":
        try:
            ip = getNetworkIp()
            url = "http://" + str(ip) + ":" + str(xbmcaddon.Addon().getSetting("port")) + "/own/playlist"
            req = requests.get(url).text
            if req != "":
                with open(fd + "own_playlist.m3u", "w", encoding="utf-8") as outfile:
                    outfile.write(req)
                xbmcgui.Dialog().notification("STV Web Server", "Uloženo", icon = addon_icon)
            else:
                xbmcgui.Dialog().notification("STV Web Server", "Žádné kanály", icon = addon_icon)
        except:
            xbmcgui.Dialog().notification("STV Web Server", "Nelze uložit", icon = addon_icon)



@plugin.route('/own_playlist_stvcz')
def own_playlist_stvcz():
    icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.stv.web.server'),'resources', 'lib', 'providers', 'stvcz', 'icon.png')
    from resources.lib.providers.stvcz import scz
    data  = scz.channels
    Msg(f"[STV Server] Data {data}")
    channels = []
    for x,y in data.items():
        channels.append(y["name"])
    if channels == []:
        xbmcgui.Dialog().notification("STV.cz", "Žádné kanály", icon = icon)
        Msg(f"[STV Server] Žádné kanály")
        return
    try:
        with open(own_channels_path, 'r') as openfile:
            select = json.load(openfile)["stvcz"]["select"]
        ch_preselect = []
        for x,y in data.items():
            if x in select:
                i = channels.index(y["name"])
                ch_preselect.append(i)
    except:
        ch_preselect = []
    dialog = xbmcgui.Dialog()
    d = dialog.multiselect("STV.cz", channels, preselect=ch_preselect)
    if d is None:
        pass
    else:
        channels_select = []
        for index in d:
            ii = list(data)[index]
            channels_select.append(ii)
        playlist = {}
        for x,y in data.items():
            if x in channels_select:
                playlist[x] = y
        save_own_channels("stvcz", channels_select, playlist)

if (__name__ == "__main__"):
    plugin.run()