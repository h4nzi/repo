from .impl import sorted, key

__all__ = ['sorted', 'key']
