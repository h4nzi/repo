# -*- coding: utf-8 -*-


import xbmc, xbmcaddon


addon = xbmcaddon.Addon()


def main():
    title = xbmc.getInfoLabel('Listitem.Title')
    provider = xbmc.getInfoLabel('Listitem.ChannelName')
    if provider == "O2 TV":
        from resources.lib.providers.o2 import o2
        o2.del_record(title)
    elif provider == "SledovaniTV.cz":
        from resources.lib.providers.stvcz import scz
        scz.del_record(title)
    elif provider == "PODA.tv":
        from resources.lib.providers.poda import pod
        pod.del_record(title)
    elif provider == "SledovanieTV.sk":
        from resources.lib.providers.stvsk import ssk
        ssk.del_record(title)
    elif provider == "T-Mobile TV GO":
        from resources.lib.providers.tm import tvgo
        tvgo.del_record(title)
    elif provider == "Magio GO":
        from resources.lib.providers.mag import maggo
        maggo.del_record(title)


if __name__ == "__main__":
    main()