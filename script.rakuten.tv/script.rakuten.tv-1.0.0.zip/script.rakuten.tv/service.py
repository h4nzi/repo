# -*- coding: utf-8 -*-
import sys
import xbmc
import xbmcaddon
import xbmcgui

import time
from main import generate_epg

addon = xbmcaddon.Addon()
time.sleep(60)
if not addon.getSetting('epg_interval'):
    interval = 24*60*60
else:
    interval = int(addon.getSetting('epg_interval'))*60*60
next = time.time()

if addon.getSetting('autogen') == 'true':
    if len(addon.getSetting('output_dir')) == 0:
        xbmcgui.Dialog().notification('Sledování O2TV', 'Problém s stažením streamu', xbmcgui.NOTIFICATION_ERROR, 5000)           
        sys.exit()
    while not xbmc.Monitor().abortRequested():
        if(next < time.time()):
            if addon.getSetting('autogen') == 'true':
                generate_epg()      
            if not addon.getSetting('epg_interval'):
                interval = 24*60*60
            else:
                interval = int(addon.getSetting('epg_interval'))*60*60      
            next = time.time() + float(interval)
        if xbmc.Monitor().waitForAbort(2):
            break
addon = None