# -*- coding: utf-8 -*-
import sys
import xbmcaddon
import xbmcgui
import xbmcvfs

from urllib.parse import parse_qsl
from datetime import datetime
import time
import requests

def generate_playlist():
    addon = xbmcaddon.Addon()
    if addon.getSetting('output_dir') is None or len(addon.getSetting('output_dir')) == 0:
        xbmcgui.Dialog().notification('Rakuten.tv', 'Nastav adresář pro playlist a EPG!', xbmcgui.NOTIFICATION_ERROR, 5000)
        sys.exit()     
    filename = addon.getSetting('output_dir') + 'playlist.m3u'        
    try:
        file = xbmcvfs.File(filename, 'w')
        if file == None:
            xbmcgui.Dialog().notification('Rakuten.tv', 'Chyba při uložení playlistu', xbmcgui.NOTIFICATION_ERROR, 5000)
        else:
            file.write(bytearray(('#EXTM3U\n').encode('utf-8')))
            url = 'https://gizmo.rakuten.tv/v3/live_channels?classification_id=272&device_identifier=web&device_stream_audio_quality=2.0&device_stream_hdr_type=NONE&device_stream_video_quality=FHD&locale=cs&market_code=cz&per_page=100'
            response = requests.get(url = url)
            if response.status_code == 200:
                data = response.json()
                if 'data' in data:
                    url = 'https://gizmo.rakuten.tv/v3/avod/streamings?classification_id=272&device_identifier=web&device_stream_audio_quality=2.0&device_stream_hdr_type=NONE&device_stream_video_quality=FHD&disable_dash_legacy_packages=false&locale=cs&market_code=cz'
                    for item in data['data']:
                        post = {'classification_id' : '272', 'device_serial' : 'not implemented', 'audio_language' : item['labels']['languages'][0]['id'], 'audio_quality' : '2.0', 'subtitle_language' : 'MIS', 'content_id' : item['id'], 'content_type' : 'live_channels', 'player' : 'web:HLS-NONE:NONE', 'strict_video_quality' : False, 'video_type' : 'stream'}
                        response = requests.post(url = url, data = post)
                        if response.status_code == 200:
                            stream_data = response.json()
                            if 'data' in stream_data and 'stream_infos' in stream_data['data'] and len(stream_data['data']['stream_infos']) > 0:
                                logo = item['images']['artwork']
                                line = '#EXTINF:-1 tvg-chno="' + str(item['channel_number']) + '" tvg-id="' + item['title'] + '" tvh-epg="0" tvg-logo="' + logo + '",' + item['title']
                                file.write(bytearray((line + '\n').encode('utf-8')))
                                line = stream_data['data']['stream_infos'][0]['url']
                                print(line)
                                file.write(bytearray((line + '\n').encode('utf-8')))
                    file.close()
            xbmcgui.Dialog().notification('Rakuten.tv', 'Playlist byl uložený', xbmcgui.NOTIFICATION_INFO, 5000)    
    except Exception:
        file.close()
        xbmcgui.Dialog().notification('Rakuten.tv', 'Chyba při uložení playlistu', xbmcgui.NOTIFICATION_ERROR, 5000)

def generate_epg():
    addon = xbmcaddon.Addon()
    if addon.getSetting('output_dir') is None or len(addon.getSetting('output_dir')) == 0:
        xbmcgui.Dialog().notification('Rakuten.tv', 'Nastav adresář pro playlist a EPG!', xbmcgui.NOTIFICATION_ERROR, 5000)
        sys.exit()     
    file = xbmcvfs.File(addon.getSetting('output_dir') + 'rakuten_epg.xml', 'w')
    if file == None:
        xbmcgui.Dialog().notification('Rakuten.tv', 'Chyba při uložení EPG', xbmcgui.NOTIFICATION_ERROR, 5000)
    else:
        today_date = datetime.today() 
        today_start_ts = int(time.mktime(datetime(today_date.year, today_date.month, today_date.day) .timetuple()))
        start_ts = today_start_ts - (int(addon.getSetting('num_days_back'))*24*60*60)
        start_dt = datetime.fromtimestamp(start_ts).strftime('%Y-%m-%dT%H:%M:%S')
        end_ts = today_start_ts + (int(addon.getSetting('num_days'))*24*60*60)
        end_dt = datetime.fromtimestamp(end_ts).strftime('%Y-%m-%dT%H:%M:%S')
        url = 'https://gizmo.rakuten.tv/v3/live_channels?classification_id=272&device_identifier=web&device_stream_audio_quality=2.0&device_stream_hdr_type=NONE&device_stream_video_quality=FHD&'
        url = url + 'epg_duration_minutes=8640&epg_ends_at=' + end_dt + '.000Z&epg_ends_at_timestamp=' + str(end_ts) + '000&epg_starts_at=' + start_dt + '.000Z&epg_starts_at_timestamp=' + str(end_ts) + '000'
        url = url + '&locale=cs&market_code=cz&page=1&per_page=100'
        response = requests.get(url = url)
        if response.status_code == 200:
            data = response.json()
            if 'data' in data:
                file.write(bytearray(('<?xml version="1.0" encoding="UTF-8"?>\n').encode('utf-8')))
                file.write(bytearray(('<tv generator-info-name="EPG grabber">\n').encode('utf-8')))
                for item in data['data']:
                    content = ''
                    logo = item['images']['artwork']
                    content = content + '    <channel id="' + item['title'].replace('&','&amp;').replace('<','&lt;').replace('>','&gt;') + '">\n'
                    content = content + '            <display-name lang="cs">' + item['title'].replace('&','&amp;').replace('<','&lt;').replace('>','&gt;') + '</display-name>\n'
                    content = content + '            <icon src="' + logo + '" />\n'
                    content = content + '    </channel>\n'
                    file.write(bytearray((content).encode('utf-8')))
                cnt = 0
                for item in data['data']:
                    content = ''
                    for epg in item['live_programs']:
                        starttime = epg['starts_at']
                        endtime = epg['ends_at']
                        content = content + '    <programme start="' + starttime.replace(':','').replace('-','').replace('T','').replace('.000+0100', ' +0100') + '" stop="' + endtime.replace(':','').replace('-','').replace('T','').replace('.000+0100', ' +0100') + '" channel="' + item['title'].replace('&','&amp;').replace('<','&lt;').replace('>','&gt;') + '">\n'
                        content = content + '       <title lang="cs">' + epg['title'].replace('&','&amp;').replace('<','&lt;').replace('>','&gt;') + '</title>\n'
                        content = content + '    </programme>\n'
                        cnt = cnt + 1
                        if cnt > 20:
                            file.write(bytearray((content).encode('utf-8')))
                            content = ''
                            cnt = 0
                    file.write(bytearray((content).encode('utf-8')))
                file.write(bytearray(('</tv>\n').encode('utf-8')))
                file.close()
                xbmcgui.Dialog().notification('Rakuten.tv', 'EPG bylo uložené', xbmcgui.NOTIFICATION_INFO, 5000)   
            else:
                xbmcgui.Dialog().notification('Rakuten.tv', 'Nevrácena žádná data', xbmcgui.NOTIFICATION_ERROR, 5000)   
        else:
            xbmcgui.Dialog().notification('Rakuten.tv', 'Nevrácena žádná data', xbmcgui.NOTIFICATION_ERROR, 5000)   

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if  params['action'] == 'generate_playlist':
            generate_playlist()
        elif params['action'] == 'generate_epg':
            generate_epg()
        else:
            raise ValueError('Neznámý parametr: {0}!'.format(paramstring))

if __name__ == '__main__':
    router(sys.argv[2][1:])
