import hashlib
import requests
import xml.etree.ElementTree as ET
import xbmc
import xbmcgui
import xbmcaddon
from resources.lib.md5crypt import md5crypt

BASE = 'https://webshare.cz'
API = BASE + '/api/'
REALM = ':Webshare:'
HEADERS = {
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36",
    'Referer': BASE
}

addon = xbmcaddon.Addon()
_session = requests.Session()
_session.headers.update(HEADERS)

def Info(message, heading=addon.getAddonInfo('name'), icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)

def api(fnct, data):
    return _session.post(API + fnct + "/", data=data)

def is_ok(xml):
    return xml.findtext('status') == 'OK'

def login():
    username = addon.getSetting('wsuser')
    password = addon.getSetting('wspass')
    if not username or not password:
        addon.openSettings()
        return

    response = api('salt', {'username_or_email': username})
    xml = ET.fromstring(response.content)
    if not is_ok(xml):
        addon.openSettings()
        return

    salt = xml.findtext('salt')
    if not salt:
        return

    encrypted_pass = hashlib.sha1(md5crypt(password.encode('utf-8'), salt.encode('utf-8')).encode('utf-8')).hexdigest()
    pass_digest = hashlib.md5(username.encode('utf-8') + REALM.encode('utf-8') + encrypted_pass.encode('utf-8')).hexdigest()



    response = api('login', {
        'username_or_email': username,
        'password': encrypted_pass,
        'digest': pass_digest,
        'keep_logged_in': 1
    })
    xml = ET.fromstring(response.content)
    if is_ok(xml):
        token = xml.findtext('token')
        addon.setSetting('token', token)
        return token
        
def revalidate():
    token = addon.getSetting('token')
    if not token:
        return login() or None
    response = api('user_data', { 'wst': token })
    xml = ET.fromstring(response.content)
    if is_ok(xml):
        return token
    else:
        return login()
        
def get_vip_link(ident, token):
    device_uuid = addon.getSetting('duuid')
    data = {'ident': ident, 'wst': token, 'device_uuid': device_uuid}
    response = api('file_link', data)
    try:
        xml = ET.fromstring(response.content)
        if is_ok(xml):
            return xml.findtext('link')
        else:
            Msg("API odpověď není OK.")
    except ET.ParseError as e:
        Msg(f"Chyba při zpracování XML: {e}")
    return None

__all__ = ['login', 'revalidate', 'api', 'is_ok', 'HEADERS', 'REALM']
