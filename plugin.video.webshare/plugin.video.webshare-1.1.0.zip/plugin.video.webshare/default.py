import sys
import xbmcplugin
import xbmcaddon
import xbmcgui
import xbmc
import urllib.parse

from resources.lib.db import get_all_videos, clear_db
from resources.lib.search import search_videos
from resources.lib.login import get_vip_link, login, revalidate

ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ARGS = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}
addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])


def Msg(message):
    xbmc.log(f"[Webshare] {message}", level=xbmc.LOGINFO)

def build_url(query):
    return BASE_URL + '?' + urllib.parse.urlencode(query)

def router():
    action = ARGS.get('action', [None])[0]

    if action is None:
        show_main_menu()
    elif action == 'list':
        list_videos()
    elif action == 'play':
        play_video(ARGS.get('ident', [None])[0])
    elif action == 'search':
        search_videos()
    elif action == 'clear_db':
        clear_database()
    elif action == 'settings':
        addon.openSettings()
    else:
        xbmcgui.Dialog().ok("Neznámá akce", f"Akce: {action}")
        
def format_size(bytes_size):
    """Převede velikost v bajtech na čitelný formát (např. 1.2 GB)"""
    if not bytes_size:
        return ""
    try:
        bytes_size = float(bytes_size)
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if bytes_size < 1024.0:
                return f"{bytes_size:.1f} {unit}"
            bytes_size /= 1024.0
    except (TypeError, ValueError):
        return ""

def show_main_menu():
    revalidate()
    menu_items = [
        {'label': 'Seznam videí', 'action': 'list'},
        {'label': 'Vyhledat nové soubory', 'action': 'search'},
        {'label': 'Smazat databázi', 'action': 'clear_db'},
        {'label': 'Nastavení', 'action': 'settings'}
    ]
    for item in menu_items:
        url = build_url({'action': item['action']})
        li = xbmcgui.ListItem(label=item['label'])
        is_folder = True
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=is_folder)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_videos():
    videos = get_all_videos()

    xbmcplugin.setContent(ADDON_HANDLE, 'movies')  # nebo 'movies', podle potřeby

    for ident, title, size, tmdb_id, year, overview, rating, poster_url, runtime in videos:
        url = build_url({'action': 'play', 'ident': ident})

        li = xbmcgui.ListItem(label=title)
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'size': size,})

        # InfotagVideo
        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(title)
        info_tag.setPlot(overview or "")
        info_tag.setDuration(int(runtime * 60) if runtime else 0)  # sekundová hodnota
        li.setProperty("custom_size", f"[{size / (1024 * 1024*1024):.2f} GB]")
        if year:
            info_tag.setYear(year)
        if rating:
            info_tag.setRating(float(rating))
        #info_tag.setGenre("Webshare")
        li.setArt({'poster': poster_url, 'thumb': poster_url, 'fanart': poster_url, 'icon': poster_url})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)


def play_video(ident):
    if not ident:
        xbmcgui.Dialog().notification("Chyba", "Neplatný identifikátor", xbmcgui.NOTIFICATION_ERROR)
        return

    token = login()
    stream_url = get_vip_link(ident, token)

    if not stream_url:
        xbmcgui.Dialog().notification("Chyba", "Nepodařilo se získat odkaz na video", xbmcgui.NOTIFICATION_ERROR)
        return

    li = xbmcgui.ListItem(path=stream_url)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=li)

def clear_database():
    if xbmcgui.Dialog().yesno("Potvrzení", "Opravdu chcete smazat databázi?"):
        clear_db()
        xbmcgui.Dialog().notification("Hotovo", "Databáze byla vymazána.", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")

def open_settings():
    xbmc.executebuiltin(f"Addon.OpenSettings({BASE_URL})")

if __name__ == '__main__':
    router()
