import xbmcaddon
import xbmcgui
import subprocess

addon_id = 'script.mediainfo'
selfAddon = xbmcaddon.Addon(addon_id)
__version__ = selfAddon.getAddonInfo('version')

File = selfAddon.getSetting("file")

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)

def mediainfo():
    try:
        # Spustíme příkaz mediainfo a zachytíme jeho výstup
        cmd = ["mediainfo", File]
        media_info_output = subprocess.check_output(cmd, stderr=subprocess.STDOUT, universal_newlines=True)
        
        # Vytvoříme instanci dialog.textviewer
        dialog = xbmcgui.Dialog()
        dialog.textviewer("Media Info  " + File, media_info_output)
    except Exception as e:
        Msg("Chyba při získávání informací o médiu: {}".format(e))

if __name__ == '__main__':
    mediainfo()
