# -*- coding: utf-8 -*-
# Version: 1.0.8
# Author: Fastshare.cz
# Support: info@fastshare.cz

#define ACTION_SHOW_SUBTITLES 25

import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import sys, os, re, base64, time, datetime, urllib, json
import urllib.request
import socket
import time

_url = sys.argv[0]
_handle = int(sys.argv[1])

__addon_id__ = "plugin.video.fastshare"
__Addon__ = xbmcaddon.Addon(__addon_id__)
#__cwd__ = xbmcaddon.Addon().getAddonInfo('path').decode('utf-8')
__cwd__ = xbmcaddon.Addon().getAddonInfo('path')

language = xbmc.getLanguage()

addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_icon= addon.getAddonInfo('icon')

lang = addon.getLocalizedString

## SETTINGS ##
addon_username = addon.getSetting('username')
addon_password = addon.getSetting('password')
addon_dwnfolder = addon.getSetting('dwnfolder')
addon_remember_search = addon.getSetting('remember_search')
addon_show_adult = addon.getSetting('show_adult')

addon_devicename = addon.getSetting('devicename')

addon.setSetting('set_subs', 'false')

addon_credit = lang(30019) + ": ?"
addon_credit2 = 0
addon_hash = ""
memorized_search = ""

CATEGORIES = [
    'vyhledavani',
    'pravesestahuje',
    'nejcastejihledanevyrazy',
    'historie',
    'nastaveni'
    ]
CATEGORIES_LABELS = [
    lang(30053),
    lang(30054),
    lang(30055),
    lang(30056),
    lang(30057)
    ]

import xbmc

def Msg(message):
    xbmc.log(f"[Fastshare] {message}", level=xbmc.LOGINFO)

# def loadurl(url, retries=3):
    # for i in range(retries):
        # try:
            # Msg(f"[loadurl] Trying {url}, attempt {i+1}")
            # with urllib.request.urlopen(url, timeout=10) as response:
                # return response.read().decode()
        # except urllib.error.URLError as e:
            # Msg(f"[loadurl] URLError: {e}")
            # if isinstance(e.reason, socket.gaierror):
                # Msg("[loadurl] DNS resolution failed.")
            # time.sleep(1)
        # except Exception as e:
            # Msg(f"[loadurl] General exception: {e}")
            # time.sleep(1)
    # Msg("[loadurl] All attempts failed.")
    # return ""
    
import urllib.request

def loadurl(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Kodi; CoreELEC) AppleWebKit/537.36 (KHTML, like Gecko)',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
    }
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            data = response.read().decode()
            Msg(f"[Fastshare] Response1: {data[:200]}")  # log only first 200 chars
            return data
    except Exception as e:
        Msg(f"[Fastshare] Exception in load_url_with_headers: {e}")
        return ""


def printTime(seconds):
    orig = seconds    
    seconds = seconds % (24 * 3600) 
    hour = seconds // 3600
    seconds %= 3600
    minutes = seconds // 60
    seconds %= 60
    if orig<3600:
        return "%02d:%02d" % (minutes, seconds)
    else:
        return "%d:%02d:%02d" % (hour, minutes, seconds)

def notify(msg, timeout=3000):    
    #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(addon_name, msg.encode('utf-8'), timeout, addon_icon))
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(addon_name, msg, timeout, addon_icon))

def print_filesize(num, suffix='B'):    
    if num>0:
        for unit in ['','KB','MB','GB','TB','PB','EB','ZB']:
            if abs(num) < 1024.0:
                #return "%3.1f%s%s" % (num, unit, suffix)
                return "%3.1f %s" % (num, unit)
            num /= 1024.0
        return "%.1f%s%s" % (num, 'Yi', suffix)
    else:
        return "0 MB"

def isConnectionAvailable():
    try:
        with urllib.request.urlopen("https://fastshare.cz/api/api_kodi.php") as test:
            return True
    except IOError as err:
        Msg("Main Problem s pripojenim k internetu, Zkontrolujte pripojeni k internetu}")
        return False

def alertAndOpenSettings():
    ret = xbmcgui.Dialog().yesno(lang(30022), lang(30023), lang(30024), lang(30025))
    if ret:
        addon.openSettings()

def checkSettings():
    if addon_username and addon_password:        
        return True

def dialog(text):
    dialog = xbmcgui.Dialog()
    ok = dialog.ok(lang(30026), text)
    
Msg(f"HASH: {addon.getSetting('hash')}")
Msg(f"DEVICEID: {addon.getSetting('deviceid')}")

def hasValidLogin():
    try:
        url = "https://fastshare.cz/api/api_kodi.php?process=login&login=" + addon_username + "&password=" + addon_password
        response = loadurl(url)
        Msg(f"URL1: {url}")
        Msg(f"Response1: {response}")
        
        if response:
            try:
                r = json.loads(response)
            except Exception as json_err:
                Msg(f"Chyba při parsování JSON: {repr(json_err)}")
                notify("Neplatná odpověď serveru.")
                return False

            if r.get('user') and r['user'].get('hash'):
                addon_hash = r['user']['hash']
                addon.setSetting('hash', addon_hash)
                addon_credit = print_filesize(int(r['user']['data']['value']) * 1024 * 1024)
                addon_credit2 = r['user']['data']['value']
                if str(r['user']['unlimited']) == "True":
                    addon_credit = lang(30028)
                    addon_credit2 = "unlimited"
                addon.setSetting('kredit', addon_credit)
                addon.setSetting('kredit2', addon_credit2)
                Msg("LOGIN True")
                return True
            else:
                Msg("Neplatné přihlašovací údaje.")
                notify(lang(30027))  # "Neplatné přihlašovací údaje"
                return False
        else:
            Msg("Žádná odpověď od serveru.")
            notify("Chyba při komunikaci se serverem.")
            return False

    except Exception as e:
        Msg(f"LOGIN except type: {type(e)}")
        Msg(f"LOGIN except repr: {repr(e)}")
        Msg(f"LOGIN except str: {str(e)}")
        notify("Došlo k výjimce při přihlašování.")
        alertAndOpenSettings()
        return False



def downloadFile(url,filename):
    if addon_dwnfolder:
        try:
            dp = xbmcgui.DialogProgress()
            dp.create("Info",lang(30029), filename)
            urllib.urlretrieve(url,addon_dwnfolder + "//" + filename,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))        
        except:
            notify(lang(30030), 5000)
    else:
        dialog(lang(30031))
        addon.openSettings()
    return

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)        
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)        
        dp.close()
        notify(lang(30032), 5000)

    if dp.iscanceled():         
        notify(lang(30033), 5000)
        dp.close()

def get_url(**kwargs):    
    return '{0}?{1}'.format(_url, urllib.parse.urlencode(kwargs))

def get_categories():    
    return CATEGORIES

def get_categories_labels():
    return CATEGORIES_LABELS

def get_user_input():
    if addon.getSetting('remember_search') == "true":
        kb = xbmc.Keyboard(addon.getSetting('memorized_search'), lang(30034))
    else:
        kb = xbmc.Keyboard('', lang(30034))
        addon.setSetting('memorized_search', '')

    kb.doModal()
    if not kb.isConfirmed():
        return
    query = kb.getText()
    
    if addon.getSetting('remember_search') == "true":
        addon.setSetting('memorized_search', query)
        
    return query   

def list_categories():
    xbmcplugin.setContent(_handle, 'videos')    
    categories = get_categories()
    categories_labels = get_categories_labels()
    i = 0
    for key in categories:
        list_item = xbmcgui.ListItem(label=categories_labels[i])
        #xbmc.log(str(categories_labels[i]).encode('utf-8'),level=xbmc.LOGNOTICE)
        if key == 'stazenesoubory':
            list_item.setProperty('IsPlayable', 'True')
            url = get_url(action='listing', category=categories[i])
            is_folder = False
        else:
            url = get_url(action='listing', category=categories[i])
            is_folder = True
            #list_item.setLabel2(str(i))
            list_item.setInfo('video', {'plot': lang(30019) + ": " + addon.getSetting('kredit')})
        i+=1
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(_handle)

def list_videos2(data, addon_hash):    
    xbmcplugin.setPluginCategory(_handle, "video")
    xbmcplugin.setContent(_handle, 'videos')
    
    videos = data
    for video in videos:
        list_item = xbmcgui.ListItem(label=video['filename'])
        filename = video['filename']
        filename = filename.replace(" )", ")").replace("( ", "(").replace("=", "").replace(".", " ").replace("_", " ").replace(",,", ",").replace("+", "").replace("  ", " ").replace("  ", " ")

        plot = "[B]" + filename + "[/B][CR]"
        if video['data']['value']:
            plot += "[CR]" + lang(30036) + ": " + print_filesize(int(video['data']['value']))
        if video['duration']['value']:
            plot += "[CR]" + lang(30037) + ": " + printTime(int(video['duration']['value']))
        if video['resolution'] and video['resolution']!="x px":
            plot += "[CR]" + lang(30038) + ": " + video['resolution']

        list_item.setInfo('video', {'title': "[COLOR grey][" + print_filesize(int(video['data']['value'])) + "][/COLOR]" + " [B]" + filename + "[/B]",
                                    'duration': video['duration']['value'],
                                    'plot': plot,
                                    'size': video['data']['value'],
                                    'mediatype': 'video'})        
        list_item.setArt({'thumb': video['thumbnail'], 'icon': video['thumbnail'], 'fanart': video['thumbnail']})                
        list_item.setProperty('IsPlayable', 'true')                
        cookie = urllib.parse.quote_plus("FASTSHARE=" + addon_hash)
        vfinal = video['download_url'] + "|Cookie=" + cookie
        url = get_url(action='play', video=vfinal, filename=video['filename'], size=video['data']['value'])
        is_folder = False
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)    
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_UNSORTED)    
    xbmcplugin.endOfDirectory(_handle)

    xbmc.sleep(200)
    win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    if win:
        cid = win.getFocusId()
        if cid:
            ctl = win.getControl(cid)
            if ctl:
                ctl.selectItem(1)

def list_terms(data):    
    xbmcplugin.setContent(_handle, 'videos')        
    for query in data:        
        list_item = xbmcgui.ListItem(label=query)
        url = get_url(action='search', query=query)
        is_folder = True
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(_handle)    

def play_video(path, filename):
    if addon.getSetting('auto_set') == "true":
        addon.setSetting('set_subs', 'true')
    
    notify(lang(30039) + " ...")
    xbmc.sleep(500)

    if hasValidLogin() == True:
        if addon.getSetting('direct_play') == "true":
            play_item = xbmcgui.ListItem(path=path)
            xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)
        else:
            wheretodownload = lang(30040) + ' (' + addon_dwnfolder + ')'
            dialog = xbmcgui.Dialog()        
            call = dialog.select(lang(30041), [lang(30042) , wheretodownload])

            if call == 0:
                play_item = xbmcgui.ListItem(path=path)
                xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)

            elif call == 1:
                addon_hash = addon.getSetting('hash')
                if addon_hash:
                    if os.path.exists(addon_dwnfolder) == True:
                        downloadFile(path, filename)
                    else:
                        notify(lang(30031), 3000)
                        addon.openSettings()
                else:
                    notify(lang(30043), 3000)
                    return
    else:
        notify(lang(30044), 2000)
        return

def just_downloading():
    play_item = xbmcgui.ListItem(path=path)

def updatePinTimeout():    
    timestamp = int(time.time())
    addon.setSetting('pin_timeout', str(timestamp))

def checkPin():    
    if addon.getSetting('require_pin') == "true":
        now = int(time.time())
        entered_pin = addon.getSetting('entered_pin')
        if addon.getSetting('entered_pin') == addon.getSetting('pin') and int(addon.getSetting('pin_timeout'))>(now-(6*3600)):
            updatePinTimeout()
            return True
        else:
            pin = xbmc.Keyboard('', lang(30045))
            pin.setHiddenInput(True)
            pin.doModal()
            if not pin.isConfirmed():
                notify(lang(30046), 3000)
                return False
            query = pin.getText()
            if query == addon.getSetting('pin'):                
                addon.setSetting('entered_pin', query)
                updatePinTimeout()
                return True
            else:
                notify(lang(30046), 3000)
                return False
    else:        
        updatePinTimeout()
        return True

def router(paramstring):
    if checkPin() == False:
        return
    if checkSettings()==True:
            if hasValidLogin() == True:                
                if addon_devicename=="":
                    notify(lang(30047))
                    addon.openSettings()
                    return
                params = dict(urllib.parse.parse_qsl(paramstring))
                if params:                    
                    if params['action'] == 'listing':
                        addon_hash = addon.getSetting('hash')                        
                        if params['category'] == 'pravesestahuje':
                            if addon_hash:                                
                                url = "https://fastshare.cz/api/api_kodi.php?process=top&kodi=1"
                                response = loadurl(url)
                                jr = json.loads(response)
                                list_videos2(jr['search']['file'], addon_hash)                                
                        if params['category'] == 'nejcastejihledanevyrazy':
                            url = "https://fastshare.cz/api/api_kodi.php?process=gettopsearch&adult" + addon_show_adult
                            response = loadurl(url)
                            jr = json.loads(response)
                            list_terms(jr['words'])                            
                        if params['category'] == 'historie':
                            addon_hash = addon.getSetting('hash')
                            if addon_hash:            
                                url = "https://fastshare.cz/api/api_kodi.php?process=history&hash=" + addon_hash
                                Msg(f"Load historie: {url}")
                                response = loadurl(url)
                                jr = json.loads(response)
                                list_videos2(jr['search']['file'], addon_hash)                                
                            else:                                
                                notify(lang(30048), 5000)
                        if params['category'] == 'nastaveni':
                            addon.openSettings()                            
                        if params['category'] == 'vyhledavani' or params['category']=="gotosearch":
                            query = get_user_input()
                            if query:
                                addon_hash = addon.getSetting('hash')
                                if addon_hash:
                                    url = "https://fastshare.cz/api/api_kodi.php?process=search&pagination=200&term=" + urllib.parse.quote_plus(query) + "&adult=" + addon_show_adult
                                    Msg(f"Load vyhledávání: {url}")
                                    response = loadurl(url)
                                    jr = json.loads(response)
                                    data = jr['search']['file']
                                    Msg(f"URL: {url}")
                                    Msg(f"Response: {response}")
                                    Msg(f"Jr: {jr}")
                                    Msg(f"Data: {data}")
                                    if(len(data)):
                                        list_videos2(data, addon_hash)
                                    else:
                                        notify(lang(30049))
                    elif params['action'] == 'search':
                        addon_hash = addon.getSetting('hash')
                        if addon_hash:
                            url = "https://fastshare.cz/api/api_kodi.php?process=search&pagination=200&term=" + urllib.parse.quote_plus(params['query']) + "&adult=" + addon_show_adult
                            Msg(f"Load search: {url}")
                            response = loadurl(url)
                            jr = json.loads(response)
                            list_videos2(jr['search']['file'], addon_hash)
                    elif params['action'] == 'play':
                        valid = False
                        addon_credit2 = addon.getSetting('kredit2')
                        vsizemb = int(params['size'])/1024/1024

                        if addon_credit2 == "unlimited":
                            valid = True
                        elif int(addon_credit2) > vsizemb:
                            valid = True
                        elif int(addon_credit2) <= 0 or addon_credit2 == "":
                            valid = False

                        if valid == True:
                            play_video(params['video'], params['filename'])
                        else:
                            dialog(lang(30050) + " (" + addon.getSetting('kredit') + "). "+ lang(30051) + " " + lang(30052))    
                    else:
                        raise ValueError('Neplatný parametr: {0}!'.format(paramstring))
                else:
                    list_categories()
    else:
            alertAndOpenSettings()
            
if __name__ == '__main__':
    router(sys.argv[2][1:])
