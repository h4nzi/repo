#Git: https://github.com/jakubcizek/pojdmeprogramovatelektroniku/tree/master/SentinelDownloader
#Popis a návod: https://www.zive.cz/clanky/programujeme-v-pythonu-jak-uplne-zadarmo-stahnout-cerstve-druzicove-snimky-libovolneho-mista-v-cesku/sc-3-a-229892/default.aspx

import os
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import math
from oauthlib.oauth2 import BackendApplicationClient
from requests_oauthlib import OAuth2Session
#import datetime
from datetime import datetime, timezone, timedelta
import time as timemod
import datetime as dt


addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path')
output_dir = addon.getSetting('output_dir')
if not xbmcvfs.exists(output_dir):
    xbmcvfs.mkdir(output_dir)
output_file_path = os.path.join(output_dir, "snimek.jpg")

# Nastaveni API OAuth (musis se zaregistrovat)
# https://shapps.dataspace.copernicus.eu/dashboard/#/account/settings
#client_id = "sh-bd0f58d2-0500-4dac-bcb9-228d576198bb"
#client_secret = "JNnWwwUhBzbOEfNnZ6MfUQn06Nkk3FpJ"
client_id = addon.getSetting('client.key')
client_secret = addon.getSetting('secret.key')

if len(client_id) == 0 or len(client_secret) == 0:
    xbmc.log("[Copernicus] Vyplňte client_id a client_secret pro OAuth autentizaci!", xbmc.LOGERROR)
    xbmcgui.Dialog().notification("Sentinel", "Chyba: chybí client_id nebo client_secret!", xbmcgui.NOTIFICATION_ERROR, 5000)
    sys.exit()
else:
    if addon.getSetting('debug')=="true":
        xbmc.log("[Copernicus] OAuth údaje jsou v pořádku", xbmc.LOGINFO)

# Výchozí hodnoty
VYSKA = 512
SIRKA_MAX = 2500
FORMAT = "image/jpeg"
SOUBOR_NAZEV = "snimek.jpg"
KVALITA = 90
#Souřadnice  pro BOX nastavit na https://shapps.dataspace.copernicus.eu/requests-builder/ a překopírovat sem
BOX = [
  13.812588,
  49.851045,
  13.870106,
  49.875832
]
EVALSCRIPT = """
//VERSION=3
function setup() {
  return {
    input: ["B02", "B03", "B04"],
    output: { bands: 3 },
  }
}
function evaluatePixel(sample) {
  let expozice = 2;
  return [sample.B04 * expozice, sample.B03 * expozice, sample.B02 * expozice];
}
"""

# Vytvoření OAuth sezení
client = BackendApplicationClient(client_id=client_id)
oauth = OAuth2Session(client=client)
token = oauth.fetch_token(token_url='https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token', client_secret=client_secret, include_client_id=True)

# Vypocet pomeru stran pro obrazek v pixelech ze zemepisnych souradnic
rozdil_sirky = BOX[3] - BOX[1]
rozdil_delky = BOX[2] - BOX[0]
prumerna_sirka = (BOX[1] + BOX[3]) / 2
vzdalenost_sirky = rozdil_sirky * 111
vzdalenost_delky = rozdil_delky * 111 * math.cos(math.radians(prumerna_sirka))
pomer_stran = vzdalenost_delky / vzdalenost_sirky

# Vypocet sirky vystupniho obrazku podle nastavene vysky a poměru stran
sirka = int(VYSKA * pomer_stran)
vyska = VYSKA

# API umi vytvorit obrazek o sirce nejvyse 2500 pixelu
# Takze pokud jsme vypocitali vetsi sirku, zmensime vysku
if sirka > SIRKA_MAX:
    sirka = SIRKA_MAX
    vyska = int(sirka / pomer_stran)
if addon.getSetting('debug')=="true":
    xbmc.log(f"[Copernicus] Rozměry hotového obrázku: {sirka}x{vyska} pixelů", xbmc.LOGINFO)

# Druzice nad mistem/boxem v Evrope sice leti zpravidla kazde 2-3 dny,
# ale prodleva muze byt i delsi, a tak stanovime vyhledavaci rozsah na 7 dnu
# datum_konec = datetime.datetime.now(datetime.timezone.utc)
# datum_zacatek = (datum_konec - datetime.timedelta(days=7)).isoformat()
# datum_konec = datum_konec.isoformat()

# Funkce pro ruční zpracování data a odečítání dnů
def zpracuj_datum(datum_string):
    den, mesic, rok = map(int, datum_string.split('.'))
    datum = f"{rok:04d}-{mesic:02d}-{den:02d}T00:00:00+00:00"
    return datum

def odeber_dny(datum_string, dny_rozdil):
    rok, mesic, den = map(int, datum_string[:10].split('-'))
    den -= dny_rozdil
    if den <= 0:
        den = 1
    return f"{rok:04d}-{mesic:02d}-{den:02d}T00:00:00+00:00"

datum = addon.getSetting('datum')
datum_konec = zpracuj_datum(datum)
datum_zacatek = odeber_dny(datum_konec, 7)




#fix for datatetime.strptime returns None - Kodi Wiki
# class proxydt(datetime.datetime):
    # @classmethod
    # def strptime(cls, date_string, format):
        # return datetime.datetime(*(time.strptime(date_string, format)[0:6]))
# datetime.datetime = proxydt

# def zpracuj_datum(datum_string):
    # return datetime.datetime.strptime(datum_string, "%d.%m.%Y").replace(tzinfo=datetime.timezone.utc)

# datum = addon.getSetting('datum')
# datum_konec = zpracuj_datum(datum)
# datum_zacatek = (datum_konec - datetime.timedelta(days=7)).isoformat()
# datum_konec = datum_konec.isoformat()
if addon.getSetting('debug')=="true":
    xbmc.log(f"[Copernicus] Datum: začátek {datum_zacatek}, konec {datum_konec}", xbmc.LOGINFO)

# Priprava API dotazu ve forme JSON
# Budeme chit snimek z druzice Sentinel-2 L2A
# Pro dany box, pixelovou velikost, format atp.
# Pro dalsi mozne parametry kouknete na https://shapps.dataspace.copernicus.eu/requests-builder/
parametry_dotazu = {
    "input": {
        "bounds": {
            "bbox": BOX
        },
        "data": [
            {
                "type": "sentinel-2-l2a",
                "dataFilter": {
                    "timeRange": {
                        "from": datum_zacatek,
                        "to": datum_konec,
                    }
                },
                "processing": {
                    "upsampling": "BILINEAR",
                    "downsampling": "BILINEAR"
                },
            }
        ]
    },
    "output": {
        "width": sirka,
        "height": vyska,
        "responses": [
            {
                "identifier": "default",
                "format": {
                    "type": FORMAT,
                    "quality": KVALITA,
                }
            }
        ]
    },
    "evalscript": EVALSCRIPT
}

# Provedeme autentizovany HTTP dotaz skrze OAuth a server by mel odpovedet rovnou bajty obrazku
# V tomto API dotazu se (asi) nedozvime, z jakeho presneho casu ve vyberu obrazek pochazi

odpoved = oauth.post("https://sh.dataspace.copernicus.eu/api/v1/process", json=parametry_dotazu)
if addon.getSetting('debug')=="true":
    xbmc.log(f"[Copernicus] HTTP dotaz status code: {odpoved.status_code}", xbmc.LOGINFO)
    xbmc.log(f"[Copernicus] Parametry dotazu: {parametry_dotazu}", xbmc.LOGINFO)
    xbmc.log(f"[Copernicus] HTTP dotaz{odpoved}", xbmc.LOGINFO)
if odpoved.status_code == 200:
    xbmc.log(f"[Copernicus] Ukládám obrázek {output_file_path}", xbmc.LOGINFO)
    try:
        with xbmcvfs.File(output_file_path, "wb") as file:
            file.write(odpoved.content)
        xbmcgui.Dialog().notification("Sentinel", f"Obrázek {SOUBOR_NAZEV} byl úspěšně uložen.", xbmcgui.NOTIFICATION_INFO, 5000)
    except IOError as e:
        xbmc.log(f"[Copernicus] Chyba při ukládání souboru: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Sentinel", "Chyba při ukládání souboru!", xbmcgui.NOTIFICATION_ERROR, 5000)
else:
    if addon.getSetting('debug')=="true":
        xbmc.log(f"[Copernicus] Chyba při získávání obrázku! HTTP kód: {odpoved.status_code}, odpověď: {odpoved.text}", xbmc.LOGERROR)
    xbmcgui.Dialog().notification("Sentinel", "Chyba při získávání obrázku!", xbmcgui.NOTIFICATION_ERROR, 5000)

