import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import os
from xbmcvfs import translatePath

# Načtení cesty k addon adresáři
addon = xbmcaddon.Addon()
addon_path = translatePath(addon.getAddonInfo('path'))

# Načtení nastavení cesty k výstupnímu adresáři
output_dir = translatePath(addon.getSetting('output_dir'))
output_file_path = translatePath("%s/snimek.jpg" % output_dir)

# Cesta k souboru sentinel.py
sentinel_script = os.path.join(addon_path, 'resources', 'lib', 'sentinel.py')

# Funkce pro spuštění sentinel.py
def run_sentinel():
    try:
        xbmc.log(f"[Copernicus] Spouštím script", xbmc.LOGINFO)
        exec(open(sentinel_script).read())  # Spustí celý skript sentinel.py
    except Exception as e:
        if addon.getSetting('debug') == "true":
            xbmc.log(f"[Copernicus] Chyba při spuštění sentinel.py: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Sentinel", "Chyba při spouštění skriptu!", xbmcgui.NOTIFICATION_ERROR, 5000)

# Funkce pro zobrazení uloženého obrázku
def show_image():
    if os.path.exists(output_file_path):
        xbmc.log(f"[Copernicus] Zobrazuji obrázek: {output_file_path}", xbmc.LOGINFO)
        xbmc.executebuiltin(f'ShowPicture("{output_file_path}")')
    else:
        xbmc.log(f"[Copernicus] Obrázek nebyl nalezen: {output_file_path}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Sentinel", "Obrázek nebyl nalezen!", xbmcgui.NOTIFICATION_ERROR, 5000)

# Hlavní logika
if __name__ == '__main__':
    xbmc.log(f"[Copernicus] Skript je spuštěn jako hlavní skript", xbmc.LOGINFO)
    dialog = xbmcgui.Dialog()
    ret = dialog.yesno("Sentinel", "Chcete vygenerovat nový snímek?", yeslabel="Generovat", nolabel="Zobrazit uložený")
    
    xbmc.log(f"[Copernicus] Výběr uživatele: {'Generovat' if ret else 'Zobrazit'}", xbmc.LOGINFO)
    
    if ret:  # Uživatel zvolil "Generovat"
        run_sentinel()
    else:  # Uživatel zvolil "Zobrazit"
        show_image()
else:
    xbmc.log(f"[Copernicus] Skript byl importován jako modul, ne jako hlavní skript", xbmc.LOGINFO)
