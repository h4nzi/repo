import os
import xbmc
import subprocess
import xbmcgui
import xbmcaddon

def run_bash_script(script_path):
    try:
        result = subprocess.check_output(["bash", script_path], stderr=subprocess.STDOUT, text=True)
        return result
    except subprocess.CalledProcessError as e:
        return f"Error: {e.output}"

def show_text_viewer(title, text):
    viewer = xbmcgui.Dialog()
    viewer.textviewer(title, text)

def main():
    # Cesta k bash skriptu (resources/bin/ws.sh)
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    script_path = os.path.join(addon_path, "resources", "bin", "ws.sh")

    script_output = run_bash_script(script_path)

    show_text_viewer("Výsledky testování rychlosti", script_output)
    
    xbmc.log(f"Script output: {script_output}", level=xbmc.LOGINFO)

if __name__ == "__main__":
    main()
