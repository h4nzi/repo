import time
# import os
# import sys
import xbmc
import xbmcgui
# import xbmcaddon
import json
import requests
from requests.structures import CaseInsensitiveDict

monitor = xbmc.Monitor()

while not monitor.abortRequested():
    xbmc.log("*********Holidays Running*****************", 1)
    url = "https://svatky.vanio.cz/api/json"
    headers = CaseInsensitiveDict()
    headers["Accept"] = "application/json"
    resp = requests.get(url, headers=headers)
    date = resp.json()["date"]
    name_day = resp.json()["name"]
    public_holiday = resp.json()["isPublicHoliday"]
    xbmcgui.Window(10000).setProperty('public_holiday' , str(public_holiday))
    xbmcgui.Window(10000).setProperty('name_day' , name_day)
    if public_holiday == True:
        name_public_holiday = resp.json()["holidayName"]
        shopping = str(resp.json()["shopsClosed"])
        xbmcgui.Window(10000).setProperty('Státní svátek' , name_public_holiday)
        xbmcgui.Window(10000).setProperty('obchody' , shopping)
    else:
        print("Není státní svátek")    
    if monitor.waitForAbort(300):
        xbmc.log("********Holidays Abort Called*****************", 2)
        break