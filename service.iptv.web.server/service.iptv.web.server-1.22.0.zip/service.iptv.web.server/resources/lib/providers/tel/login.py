#-*-coding:utf8;-*-

import requests, xbmcaddon, xbmcgui, json, xbmc, os, xbmcvfs, uuid, re


addon = xbmcaddon.Addon()
code = addon.getSetting("tel_code")
icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'tel', 'icon.png')
addon_dir = xbmcvfs.translatePath( addon.getAddonInfo('path') )
addon_icon = os.path.join(addon_dir, "icon.png")
mac = ':'.join(re.findall('..', '%012x' % uuid.getnode()))
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
telly_token = os.path.join(profile, "telly_token.json")


def main():
    data = {"pairing_code": str(code), "brand_code": "telly"}
    req = requests.post("https://backoffice0-vip.tv.itself.cz/api/device/pairDeviceByPairingCode/", json = data, headers = {"Content-Type": "application/json"}).json()
    if req["success"] == True:
        token = req["token"]
        data = {"device_token": token, "device_type_code": "ANDROIDTV", "model": "XiaomiTVBox", "name": "STB", "serial_number": "unknown", "mac_address": mac}
        req = requests.post("https://backoffice0-vip.tv.itself.cz/api/device/completeDevicePairing/", json = data, headers = {"Content-Type": "application/json"}).json()
        if req["success"] == True:
            data = {"token": token}
            json_object = json.dumps(data, indent=4)
            with open(telly_token, "w") as outfile:
                outfile.write(json_object)
            xbmcgui.Dialog().notification("Telly", "Spárováno", icon = icon)
            xbmc.sleep(4000)
            xbmcgui.Dialog().notification("IPTV Web Server", "Restartujte KODI", icon = addon_icon)
        else:
            xbmcgui.Dialog().notification("Telly", req["message"], icon = icon)
    else:
        xbmcgui.Dialog().notification("Telly", req["message"], icon = icon)
