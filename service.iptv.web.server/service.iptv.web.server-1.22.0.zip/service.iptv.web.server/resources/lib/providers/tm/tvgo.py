import requests, xbmcaddon, xbmcgui, os, xbmcvfs, sys, xbmc, json, uuid
from urllib.parse import urlparse
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter
from datetime import datetime


UA = "okhttp/3.12.12"
addon = xbmcaddon.Addon()
user = addon.getSetting("tm_username")
password = addon.getSetting("tm_password")
icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'tm', 'icon.png')
addon_dir = xbmcvfs.translatePath( addon.getAddonInfo('path') )
addon_icon = os.path.join(addon_dir, "icon.png")
if addon.getSetting("tm_dev_id") == "":
    dev_id = str(uuid.uuid4())
    addon.setSetting(id='tm_dev_id', value= dev_id)
else:
    dev_id = addon.getSetting("tm_dev_id")
dev_name = "ANDROID-PHONE"
session = requests.Session()
session.mount('https://', HTTPAdapter(max_retries=Retry(total=5, backoff_factor=0.1, status_forcelist=[500, 502, 503, 504])))
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
tmobile_token = os.path.join(profile, "tmobile_token.json")


def get_data():
    try:
        with open(tmobile_token, 'r') as openfile:
            data = json.load(openfile)
        accesstoken = data["accesstoken"]
        refreshtoken = data["refreshtoken"]
    except:
        accesstoken = ""
        refreshtoken = ""
    return accesstoken, refreshtoken


def set_data(data):
    json_object = json.dumps(data, indent=4)
    with open(tmobile_token, "w") as outfile:
        outfile.write(json_object)


def login(dev_type):
    params={"dsid": dev_id, "deviceName": dev_name, "deviceType": dev_type, "osVersion": "0.0.0", "appVersion": "0.0.0", "language": "CZ"}
    headers={'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'User-Agent': UA, 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site'}
    req = session.post("https://czgo.magio.tv/v2/auth/init", params=params, headers=headers).json()
    accessToken = req["token"]["accessToken"]
    params = {"loginOrNickname": user, "password": password}
    headers = {"authorization": "Bearer " + accessToken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
    req = session.post("https://czgo.magio.tv/v2/auth/login", json = params, headers = headers).json()
    if req["success"] == True:
        return req["token"]["accessToken"], req["token"]["refreshToken"]
    else:
        xbmcgui.Dialog().notification("T-Mobile TV GO", str(req["errorMessage"]), icon = icon)
        return "", ""


def reg_device():
    accesstoken, refreshtoken = login("OTT_ANDROID")
    if accesstoken == "":
        return
    params={"list": "LIVE", "queryScope": "LIVE"}
    headers = {"authorization": "Bearer " + accesstoken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
    id = requests.get("https://czgo.magio.tv/v2/television/channels", params = params, headers = headers).json()["items"][0]["channel"]["channelId"]
    params={"service": "LIVE", "name": dev_name, "devtype": "OTT_ANDROID", "id": id, "prof": "p5", "ecid": "", "drm": "verimatrix"}
    headers = {"authorization": "Bearer " + accesstoken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
    req = session.get("https://czgo.magio.tv/v2/television/stream-url", params = params, headers = headers).json()
    if req["success"] == True:
        accesstoken, refreshtoken = login("OTT_LINUX_4302")
        set_data({"accesstoken": accesstoken, "refreshtoken": refreshtoken})
        xbmcgui.Dialog().notification("T-Mobile TV GO", "Přihlášení úspěšné", icon = icon)
    else:
        xbmcgui.Dialog().notification("T-Mobile TV GO", req["errorMessage"].replace("exceeded-max-device-count", "Překročen maximální počet zařízení"), icon = icon)


def get_stream(id):
    url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    accesstoken, refreshtoken = get_data()
    params={"refreshToken": refreshtoken}
    headers={'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'User-Agent': UA, 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site'}
    req = session.post("https://czgo.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken = req["token"]["accessToken"]
        refreshtoken = req["token"]["refreshToken"]
        set_data({"accesstoken": accesstoken, "refreshtoken": refreshtoken})
        params={"service": "LIVE", "name": dev_name, "devtype": "OTT_LINUX_4302", "id": int(id.split(".")[0]), "prof": "p5", "ecid": "", "drm": "verimatrix"}
        headers = {"authorization": "Bearer " + accesstoken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
        req = session.get("https://czgo.magio.tv/v2/television/stream-url", params = params, headers = headers).json()
        if req["success"] == True:
            url = req["url"]
            headers = {"Host": urlparse(url).netloc, "User-Agent": "ReactNativeVideo/3.13.2 (Linux;Android 10) ExoPlayerLib/2.10.3", "Connection": "Keep-Alive"}
            req = session.get(url, headers = headers, allow_redirects=False)
            url = req.headers["location"]
        else:
            url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    else:
        url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    return url


def get_channels():
    accesstoken, refreshtoken = get_data()
    dev_name = "ANDROID-PHONE"
    params={"refreshToken": refreshtoken}
    headers={'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'User-Agent': UA, 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site'}
    req = session.post("https://czgo.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken = req["token"]["accessToken"]
        refreshtoken = req["token"]["refreshToken"]
        set_data({"accesstoken": accesstoken, "refreshtoken": refreshtoken})
    params={"list": "LIVE", "queryScope": "LIVE"}
    headers = {"authorization": "Bearer " + accesstoken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
    ch = {}
    try:
        req = session.get("https://czgo.magio.tv/home/categories?language=cz", headers = headers).json()["categories"]
        categories = {}
        for cc in req:
            for c in cc["channels"]:
                categories[c["channelId"]] = cc["name"]
        req = session.get("https://czgo.magio.tv/v2/television/channels", params = params, headers = headers).json()["items"]
        for c in req:
            group = categories[c["channel"]["channelId"]]
            ch[str(c["channel"]["channelId"])] = {"name": c["channel"]["name"], "logo": c["channel"]["logoUrl"], "group": group}
    except:
        ch = {}
    return ch


def get_devices():
    accesstoken, refreshtoken = login("OTT_ANDROID")
    params={"refreshToken": refreshtoken}
    headers={'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'User-Agent': UA, 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site'}
    req = session.post("https://czgo.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken = req["token"]["accessToken"]
    else:
        xbmcgui.Dialog().notification("T-Mobile TV GO",req["errorMessage"], icon = icon)
        return
    headers = {"authorization": "Bearer " + accesstoken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
    req = session.get("https://czgo.magio.tv/v2/home/my-devices", headers = headers).json()
    devices = []
    try:
            devices.append((req["thisDevice"]["name"] + " (Toto zařízení)", req["thisDevice"]["id"]))
    except:
            pass
    try:
        for d in req["smallScreenDevices"]:
            devices.append((d["name"], d["id"]))
    except:
            pass
    try:
        for d in req["stbAndBigScreenDevices"]:
            devices.append((d["name"], d["id"]))
    except:
            pass
    choose = xbmcgui.Dialog().select("Odebrat zařízení", [i[0] for i in devices])

    if choose == -1: return
    else:
        dev_id = devices[choose][1]
    req = session.get("https://czgo.magio.tv/home/deleteDevice?id=" + str(dev_id), headers = headers).json()
    if req["success"] == True:
        xbmcgui.Dialog().notification("T-Mobile TV GO", "Odebráno", icon = icon)
        if choose == 0:
            set_data({"accesstoken": "", "refreshtoken": ""})
            addon.setSetting(id='tm_dev_id', value= "")
    else:
        xbmcgui.Dialog().notification("T-Mobile TV GO", req["errorMessage"], icon = icon)


def get_catchup(id, utc, utcend):
    id = int(id.split(".")[0])
    accesstoken, refreshtoken = get_data()
    params={"refreshToken": refreshtoken}
    headers={'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'User-Agent': UA, 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site'}
    req = session.post("https://czgo.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken = req["token"]["accessToken"]
        refreshtoken = req["token"]["refreshToken"]
        set_data({"accesstoken": accesstoken, "refreshtoken": refreshtoken})
        params={"service": "ARCHIVE", "name": dev_name, "devtype": "OTT_ANDROID", "id": int(id), "prof": "p5", "ecid": "", "drm": "verimatrix"}
        headers = {"authorization": "Bearer " + accesstoken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
        date_time_start = datetime.fromtimestamp(int(utc))
        d_start = date_time_start.strftime("%Y-%m-%dT%H:%M:%S")
        date_time_end = datetime.fromtimestamp(int(utcend) + 15)
        d_end = date_time_end.strftime("%Y-%m-%dT%H:%M:%S")
        req = session.get("https://czgo.magio.tv/v2/television/epg?filter=channel.id==" + str(id) + "%20and%20startTime=ge=" + d_start + ".000Z%20and%20endTime=le=" + d_end + ".000Z&limit=10&offset=0&lang=CZ", params = params, headers = headers).json()
        if req["success"] == True:
            scheduleId = str(req["items"][0]["programs"][0]["scheduleId"])
            params={"service": "ARCHIVE", "name": dev_name, "devtype": "OTT_LINUX_4302", "id": int(scheduleId), "prof": "p5", "ecid": "", "drm": "verimatrix"}
            headers = {"authorization": "Bearer " + accesstoken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
            req = session.get("https://czgo.magio.tv/v2/television/stream-url", params = params, headers = headers).json()
            if req["success"] == True:
                url = req["url"]
                headers = {"Host": urlparse(url).netloc, "User-Agent": "ReactNativeVideo/3.13.2 (Linux;Android 10) ExoPlayerLib/2.10.3", "Connection": "Keep-Alive"}
                req = session.get(url, headers = headers, allow_redirects=False)
                url = req.headers["location"]
            else:
                url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
        else:
            url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    else:
        url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    return url


def get_vod_stream(id):
    id = id.split(".")[0]
    url =  "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    accesstoken, refreshtoken = get_data()
    params={"refreshToken": refreshtoken}
    headers={'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'User-Agent': UA, 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site'}
    req = session.post("https://czgo.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken = req["token"]["accessToken"]
        refreshtoken = req["token"]["refreshToken"]
        set_data({"accesstoken": accesstoken, "refreshtoken": refreshtoken})
        params={"service": "ARCHIVE", "name": dev_name, "devtype": "OTT_LINUX_4302", "id": int(id), "prof": "p5", "ecid": "", "drm": "verimatrix", "contentId": int(id), "videoType": "archive"}
        headers = {"authorization": "Bearer " + accesstoken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
        req = session.get("https://czgo.magio.tv/v2/television/stream-url", params = params, headers = headers).json()
        if req["success"] == True:
            url = req["url"]
            headers = {"Host": urlparse(url).netloc, "User-Agent": "ReactNativeVideo/3.13.2 (Linux;Android 10) ExoPlayerLib/2.10.3", "Connection": "Keep-Alive"}
            req = session.get(url, headers = headers, allow_redirects=False)
            url = req.headers["location"]
        else:
            url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    else:
        url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    return url


def vod_favorites():
    records = {}
    accesstoken, refreshtoken = get_data()
    params={"refreshToken": refreshtoken}
    headers={'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'User-Agent': UA, 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site'}
    req = requests.post("https://czgo.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken = req["token"]["accessToken"]
        refreshtoken = req["token"]["refreshToken"]
        set_data({"accesstoken": accesstoken, "refreshtoken": refreshtoken})
        headers = {"authorization": "Bearer " + accesstoken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
        req = requests.get("https://czgo.magio.tv/v2/television/recordings?platform=iptv,go&limit=100&lang=CZ", headers = headers).json()
        if req["success"] == True:
            for r in req["items"]:
                try:
                    logo = r["schedule"]["program"]["images"][0]
                except:
                    logo = ""
                try:
                    episode = " (" + r["schedule"]["program"]["programValue"]["episodeId"] + ")"
                except:
                    episode = ""
                try:
                    t = str(r["startTime"])
                    date_time_start = datetime.fromtimestamp(int(t[:-3]))
                    d_start = date_time_start.strftime(" / %d.%m.%Y, %H:%M")
                except:
                    d_start = ""
                records[str(r["schedule"]["scheduleId"])] = {"name": r["title"] + episode + d_start, "logo": logo, "id": str(r["id"])}
    return records


def restart_pvr():
    try:
        xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":false}}}}'.format('pvr.iptvsimple'))
        xbmc.sleep(2000)
        xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":true}}}}'.format('pvr.iptvsimple'))
    except:
        pass


def add_record(id, utc, utcend):
    idd = ""
    for x, y in get_channels().items():
        if y["name"].replace(" HD", "") == id:
            idd = x
    if idd != "":
        accesstoken, refreshtoken = get_data()
        params={"refreshToken": refreshtoken}
        headers={'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'User-Agent': UA, 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site'}
        req = session.post("https://czgo.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
        if req["success"] == True:
            accesstoken = req["token"]["accessToken"]
            refreshtoken = req["token"]["refreshToken"]
            set_data({"accesstoken": accesstoken, "refreshtoken": refreshtoken})
            params={"service": "ARCHIVE", "name": dev_name, "devtype": "OTT_ANDROID", "id": int(idd), "prof": "p5", "ecid": "", "drm": "verimatrix"}
            headers = {"authorization": "Bearer " + accesstoken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
            date_time_start = datetime.fromtimestamp(int(utc))
            d_start = date_time_start.strftime("%Y-%m-%dT%H:%M:%S")
            date_time_end = datetime.fromtimestamp(int(utcend) + 15)
            d_end = date_time_end.strftime("%Y-%m-%dT%H:%M:%S")
            req = session.get("https://czgo.magio.tv/v2/television/epg?filter=channel.id==" + str(idd) + "%20and%20startTime=ge=" + d_start + ".000Z%20and%20endTime=le=" + d_end + ".000Z&limit=10&offset=0&lang=CZ", params = params, headers = headers).json()
            if req["success"] == True:
                scheduleId = str(req["items"][0]["programs"][0]["scheduleId"])
                req = requests.get("https://czgo.magio.tv/television/addProgramRecording?storage=go&type=SIMPLE&scheduleId=" + scheduleId + "&channelID=" + str(idd), headers = headers).json()
                if req["success"] == True:
                    restart_pvr()
                    xbmcgui.Dialog().notification("T-Mobile TV GO", "Přidáno", icon = icon)


def del_record(title):
    epgId = ""
    records = vod_favorites()
    for x,y in records.items():
        if y["name"] == title:
            epgId = y["id"]
    if epgId != "":
        accesstoken, refreshtoken = get_data()
        params={"refreshToken": refreshtoken}
        headers={'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'User-Agent': UA, 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site'}
        req = requests.post("https://czgo.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
        if req["success"] == True:
            accesstoken = req["token"]["accessToken"]
            refreshtoken = req["token"]["refreshToken"]
            set_data({"accesstoken": accesstoken, "refreshtoken": refreshtoken})
            headers = {"authorization": "Bearer " + accesstoken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
            req = requests.get("https://czgo.magio.tv/television/deleteRecording?recordingIds=" + str(epgId) + "&storage=go", headers = headers).json()
            if req["success"] == True:
                restart_pvr()
                xbmcgui.Dialog().notification("T-Mobile TV GO", "Odebráno", icon = icon)