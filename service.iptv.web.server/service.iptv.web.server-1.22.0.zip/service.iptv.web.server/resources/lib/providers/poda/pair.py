#-*-coding:utf8;-*-

import requests, xbmcaddon, xbmcgui, json, xbmc, os, xbmcvfs, uuid
from urllib.parse import quote


addon = xbmcaddon.Addon()
icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'poda', 'icon.png')
addon_dir = xbmcvfs.translatePath( addon.getAddonInfo('path') )
addon_icon = os.path.join(addon_dir, "icon.png")
headers = {"User-Agent": "okhttp/3.12.12"}
product_list = {"0": "ANDROID-PHONE", "1": "SAMSUNG-TV"}
dev_list = {"0": "androidportable", "1": "samsungtv"}
product = product_list[addon.getSetting("poda_device")]
dev = dev_list[addon.getSetting("poda_device")]
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
poda_data = os.path.join(profile, "poda_data.json")


def sec_to_min(seconds):
    h = seconds // 3600
    m = seconds % 3600 // 60
    s = seconds % 3600 % 60
    return "%02d:%02d" % (m, s)


def countDown(sec, pin, id, password):
    state = False
    secToWait = sec
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("Párování")
    for count in range(0, secToWait+1):
        if pDialog.iscanceled():
            state = False
            break
        pDialog.update(int((count)*100. /secToWait), 'Párovací kód ('+ str(sec_to_min(secToWait-count))+')\n\n' + "[B]" + pin + "[/B]")
        xbmc.sleep(1000)
        if str(count)[-1] == "0":
            req = requests.get("https://poda.moderntv.eu/api/pairing-state/?deviceId=" + id + "&password=" + password).json()["state"]
            if req == "paired":
                state = True
                break
    pDialog.close()
    return state


def pairing():
    mac_num = hex(uuid.getnode()).replace('0x', '').upper()
    mac = ':'.join(mac_num[i : i + 2] for i in range(0, 11, 2))
    data = requests.get("http://poda.moderntv.eu/api/start-pairing?type=" + dev + "&product=" + product + "&serial=" + mac).json()
    if data["status"] == 1:
        pairingPin = str(data["pairingPin"])
        expires = str(data["expires"])
        id = str(data["deviceId"])
        password = str(data["password"])
        json_object = json.dumps(data, indent=4)
        with open(poda_data, "w") as outfile:
            outfile.write(json_object)
        succeeded = countDown(600, pairingPin, id, password)
        if succeeded == False:
            xbmcvfs.delete(poda_data)
        else:
            xbmcgui.Dialog().notification("PODA.tv", "Spárováno", icon = icon)
            xbmc.sleep(4000)
            xbmcgui.Dialog().notification("IPTV Web Server", "Restartujte KODI", icon = addon_icon)
    else:
        xbmcgui.Dialog().notification("PODA.tv",data["error"], icon = icon)