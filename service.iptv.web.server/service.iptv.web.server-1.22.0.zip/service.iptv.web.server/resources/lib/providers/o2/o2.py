# -*- coding: utf-8 -*-


import requests, xbmcaddon, datetime, json, os, xbmcvfs, xbmcgui, xbmc
from urllib.parse import quote
from datetime import datetime


addon = xbmcaddon.Addon()
icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'o2', 'icon.png')
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
o2_token = os.path.join(profile, "o2_token.json")
try:
    with open(o2_token, 'r') as openfile:
        data = json.load(openfile)
    token = data["token"]
    subscription = data["subscription"]
except:
    token = ""
    subscription = ""


def get_stream(id):
    url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    headers = {'X-NanguTv-App-Version': 'Android#6.4.1', 'User-Agent': 'Dalvik/2.1.0', 'Connection': 'Keep-Alive', 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'X-NanguTv-Device-Id' : 'b7pzci54mrzbcvy', 'X-NanguTv-Device-Name': 'TV-BOX', 'X-NanguTv-Access-Token': token}
    try:
        data = requests.get('https://app.o2tv.cz/sws/server/streaming/uris.json?serviceType=LIVE_TV&deviceType=STB&streamingProtocol=HLS&subscriptionCode=' + str(subscription) + '&channelKey=' + quote(id.split(".")[0]) + '&encryptionType=NONE', headers = headers).json()
        for d in data["uris"]:
            if d["resolution"] == "HD":
                url = d["uri"]
    except:
        url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    return url


def get_catchup(id, utc, utcend):
    start = utc
    if utcend == "":
        end = int(utc) + 18000
        now =  int(datetime.datetime.now().timestamp())
        if end > now:
            end = now - 200
    else:
        end = utcend
    url =  "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    headers = {'X-NanguTv-App-Version': 'Android#6.4.1', 'User-Agent': 'Dalvik/2.1.0', 'Connection': 'Keep-Alive', 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'X-NanguTv-Device-Id' : 'b7pzci54mrzbcvy', 'X-NanguTv-Device-Name': 'TV-BOX', 'X-NanguTv-Access-Token': token}
    req = requests.get('https://app.o2tv.cz/sws/server/streaming/uris.json?serviceType=TIMESHIFT_TV&deviceType=STB&streamingProtocol=HLS&subscriptionCode=' + subscription +'&fromTimestamp=' + str(start) + '000&toTimestamp=' + str(end) + '000&channelKey=' + quote(id.split(".")[0]) + '&encryptionType=NONE', headers = headers)
    if req.status_code == 200:
        url = req.json()['uris'][0]['uri']
    return url


def get_vod_stream(id):
    id = id.split(".")[0]
    url =  "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    try:
        sdata = data["sdata"]
    except:
        sdata = ""
    headers = {'X-NanguTv-App-Version': 'Android#6.4.1', 'User-Agent': 'Dalvik/2.1.0', 'Connection': 'Keep-Alive', 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'X-NanguTv-Device-Id' : 'b7pzci54mrzbcvy', 'X-NanguTv-Device-Name': 'TV-BOX', 'X-NanguTv-Access-Token': token}
    post = {'serviceType': 'NPVR', 'deviceType': 'STB', 'streamingProtocol': 'HLS', 'subscriptionCode': subscription, 'contentId': str(id), 'encryptionType': 'NONE'}
    req = requests.post("https://app.o2tv.cz/sws/server/streaming/uris.json", data = post, headers = headers)
    if req.status_code == 200:
        url = req.json()['uris'][0]['uri']
    return url


def vod_favorites():
    try:
        sdata = data["sdata"]
    except:
        sdata = ""
    records = {}
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:75.0) Gecko/20100101 Firefox/75.0', 'Content-Type': 'application/json', 'x-o2tv-access-token': token, 'x-o2tv-sdata': sdata, 'x-o2tv-device-id': 'b7pzci54mrzbcvy', 'x-o2tv-device-name': 'TV-BOX'}
    req = requests.get('https://api.o2tv.cz/unity/api/v1/recordings/', headers = headers)
    if req.status_code == 200:
        for r in req.json()["result"]:
            try:
                t = str(r["program"]["start"])
                date_time_start = datetime.fromtimestamp(int(t[:-3]))
                d_start = date_time_start.strftime(" / %d.%m.%Y, %H:%M")
            except:
                d_start = ""
            try:
                logo = "https://img1.o2tv.cz" + r["program"]["images"][0]["cover"]
            except:
                try:
                    logo = "https://img1.o2tv.cz" + r["program"]["picture"]
                except:
                    logo = ""
            records[str(r["pvrProgramId"])] = {"name": r["program"]["name"] + d_start, "logo": logo, "channelKey": r["program"]["channelKey"]}
    return records


def restart_pvr():
    try:
        xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":false}}}}'.format('pvr.iptvsimple'))
        xbmc.sleep(2000)
        xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":true}}}}'.format('pvr.iptvsimple'))
    except:
        pass


def add_record(id, utc, utcend):
    url =  ""
    headers = {'X-NanguTv-App-Version': 'Android#6.4.1', 'User-Agent': 'Dalvik/2.1.0', 'Connection': 'Keep-Alive', 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'X-NanguTv-Device-Id' : 'b7pzci54mrzbcvy', 'X-NanguTv-Device-Name': 'TV-BOX'}
    cookies = { "access_token": token, "deviceId": "b7pzci54mrzbcvy"}
    params = {"language": "cze", "channelKey": id, "fromTimestamp": str(utc) + "000", "toTimestamp": str(utcend) + "000"}
    req = requests.get('http://app.o2tv.cz/sws/server/tv/channel-programs.json', params=params, headers=headers, cookies=cookies)
    if req.status_code == 200:
        post = {'epgId' : int(req.json()[0]["epgId"])}
        headers = {'X-NanguTv-App-Version': 'Android#6.4.1', 'User-Agent': 'Dalvik/2.1.0', 'Connection': 'Keep-Alive', 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'X-NanguTv-Device-Id' : 'b7pzci54mrzbcvy', 'X-NanguTv-Device-Name': 'TV-BOX', 'X-NanguTv-Access-Token': token}
        req = requests.post("https://app.o2tv.cz/sws/subscription/vod/pvr-add-program.json", data = post, headers = headers)
        if req.status_code == 200:
            restart_pvr()
            xbmcgui.Dialog().notification("O2 TV", "Přidáno", icon = icon)


def del_record(title):
    epgId = ""
    records = vod_favorites()
    for x,y in records.items():
        if y["name"] == title:
            epgId = x
    if epgId != "":
        post = {'pvrProgramId' : int(epgId)}
        headers = {'X-NanguTv-App-Version': 'Android#6.4.1', 'User-Agent': 'Dalvik/2.1.0', 'Connection': 'Keep-Alive', 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'X-NanguTv-Device-Id' : 'b7pzci54mrzbcvy', 'X-NanguTv-Device-Name': 'TV-BOX', 'X-NanguTv-Access-Token': token}
        req = requests.post("https://app.o2tv.cz/sws/subscription/vod/pvr-remove-program.json", data = post, headers = headers)
        if req.status_code == 200:
            restart_pvr()
            xbmcgui.Dialog().notification("O2 TV", "Odebráno", icon = icon)