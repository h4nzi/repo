# -*- coding: utf-8 -*-


import requests, xbmcaddon, datetime, json, os, xbmcvfs


addon = xbmcaddon.Addon()
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
sweet_token = os.path.join(profile, "sweet_token.json")
sweet_channels = os.path.join(profile, "sweet_channels.json")


try:
    with open(sweet_token, 'r') as openfile:
        data = json.load(openfile)
    refresh_token = data["refresh_token"]
    UUID = str(data["UUID"])
except:
    refresh_token = ""
    UUID = ""
try:
    with open(sweet_channels, 'r') as openfile:
        channels = json.load(openfile)
except:
    channels = {}
UA ='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:105.0) Gecko/20100101 Firefox/105.0'
headers = {'Host': 'api.sweet.tv', 'user-agent': UA, 'accept': 'application/json, text/plain, */*', 'accept-language': 'cs', 'x-device': '1;22;0;2;3.2.57', 'origin': 'https://sweet.tv', 'dnt': '1', 'referer': 'https://sweet.tv/'}
stream_id = ""


def get_token():
    data = {'device': {'type': 'DT_Web_Browser', 'application': {'type': 'AT_SWEET_TV_Player'}, 'model': UA, 'firmware': {'versionCode': 1, 'versionString': '3.2.57'}, 'uuid': UUID, 'supported_drm': {'widevine_modular': True}, 'screen_info': {'aspectRatio': 6, 'width': 1366, 'height': 768}}, 'refresh_token': refresh_token}
    req = requests.post("https://api.sweet.tv/AuthenticationService/Token.json", json = data, headers = headers).json()
    if req["result"] == "OK":
        return req["access_token"]
    else:
        return ""


def get_stream(id):
    global stream_id
    try:
        id = id.split(".")[0]
        access_token = get_token()
        headers["authorization"] = "Bearer " + access_token
        if stream_id != "":
            try:
                r = requests.post("https://api.sweet.tv/TvService/CloseStream.json", json = {"stream_id": int(stream_id)}, headers = headers).json()
            except:
                pass
        data = {'without_auth': True, 'channel_id': int(id), 'accept_scheme': ['HTTP_HLS'], 'multistream': True}
        req = requests.post("https://api.sweet.tv/TvService/OpenStream.json", json = data, headers = headers).json()
        if req["result"] == "OK":
            url = "https://" + req["http_stream"]["host"]["address"] + req["http_stream"]["url"]
            stream_id = str(req["stream_id"])
        else:
             url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    except:
         url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    return url


def get_catchup(id, utc):
    global stream_id
    try:
        id = int(id.split(".")[0])
        ids = []
        ids.append(id)
        access_token = get_token()
        headers["authorization"] = "Bearer " + access_token
        data = {"epg_limit_prev":0,"epg_limit_next":1,"epg_current_time":int(utc),"need_epg":True,"need_icons":False,"need_big_icons":False,"need_categories":False,"need_offsets":False,"need_list":True,"channels":ids}
        req = requests.post("https://api.sweet.tv/TvService/GetChannels.json", json = data, headers = headers).json()
        if req["status"] == "OK":
            if stream_id != "":
                try:
                    r = requests.post("https://api.sweet.tv/TvService/CloseStream.json", json = {"stream_id": int(stream_id)}, headers = headers).json()
                except:
                    pass
            epg_id = req["list"][0]["epg"][0]["id"]
            data = {'without_auth': True, 'channel_id': int(id), 'accept_scheme': ['HTTP_HLS'], 'multistream': True, 'epg_id': int(epg_id)}
            req = requests.post("https://api.sweet.tv/TvService/OpenStream.json", json = data, headers = headers).json()
            if req["result"] == "OK":
                url = "https://" + req["http_stream"]["host"]["address"] + req["http_stream"]["url"]
                stream_id = str(req["stream_id"])
            else:
                url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
        else:
            url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    except:
         url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    return url


def get_vod_stream(id, owner_id):
    url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    try:
        id = id.split(".")[0]
        access_token = get_token()
        headers["authorization"] = "Bearer " + access_token
        data = {"owner_id":int(owner_id),"movie_id": int(id),"audio_track":0,"preferred_link_type":0,"subtitle":"all"}
        req = requests.post("https://api.sweet.tv/MovieService/GetLink.json", json = data, headers = headers).json()
        if req["status"] == "OK":
            url = req["url"]
        else:
            url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    except:
        url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    return url


def vod_favorites():
    movies = {}
    try:
        access_token = get_token()
        headers["authorization"] = "Bearer " + access_token
        req = requests.post("https://api.sweet.tv/MovieService/GetFavoriteMovies.json", json = {}, headers = headers).json()
        if req["status"] == "OK" and "movies" in req:
            data = {"movies": req["movies"],"offset":0,"limit":100,"need_extended_info":False}
            req = requests.post("https://api.sweet.tv/MovieService/GetMovieInfo.json", json = data, headers = headers).json()
            if req["result"] == "OK":
                for r in req["movies"]:
                    movies[str(r["id"])] = {"name": r["title"] + " (" + str(r["year"]) + ")", "logo": r["poster_url"], "owner_id": str(r["external_id_pairs"][0]["owner_id"])}
    except:
        movies = {}
    return movies