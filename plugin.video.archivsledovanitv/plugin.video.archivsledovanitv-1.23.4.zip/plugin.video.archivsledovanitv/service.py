# -*- coding: utf-8 -*-

import xbmc, xbmcaddon, xbmcgui, os, xbmcvfs
from resources.lib import schedule


addon_dir = xbmcvfs.translatePath( xbmcaddon.Addon().getAddonInfo('path') )
addon_icon = os.path.join(addon_dir, "icon.png")
lng = xbmcaddon.Addon().getLocalizedString


def update_playlist():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.archivsledovanitv/?action=playlist&dlg=0)')


class MyMonitor(xbmc.Monitor):
    def __init__( self, *args, **kwargs ):
        xbmc.Monitor.__init__( self )
        self.action = kwargs['action']

    def onSettingsChanged( self ):
        self.action()

class Main:
    def __init__( self ):
        self.job = schedule.every(int(xbmcaddon.Addon().getSetting("interval_update"))).hours.do(update_playlist)
        if xbmcaddon.Addon().getSetting("auto_update") == "true":
            if xbmcaddon.Addon().getSetting("auto_update_start") == "true":
                update_playlist()
            self.update = True
        else:
            self.update = False
        self._service_setup()
        while (not self.Monitor.abortRequested()):
            if self.Monitor.waitForAbort(1):
                schedule.cancel_job(self.job)
                break
            if self.update == True:
                schedule.run_pending()

    def _service_setup( self ):
        self.Monitor = MyMonitor(action = self._get_settings)
        self._get_settings

    def _get_settings( self ):
        if xbmcaddon.Addon().getSetting("auto_update") == "true" and self.update == False:
            self.job = schedule.every(int(xbmcaddon.Addon().getSetting("interval_update"))).hours.do(update_playlist)
            self.update = True
            xbmcgui.Dialog().notification("Archiv SledovaniTV", lng(30143), sound = False, icon = addon_icon)
        if xbmcaddon.Addon().getSetting("auto_update") == "false" and self.update == True:
            self.update = False
            schedule.cancel_job(self.job)
            xbmcgui.Dialog().notification("Archiv SledovaniTV", lng(30144), sound = False, icon = addon_icon)


Main()