import requests
from resources.lib.browser import Firefox

api_key = "1f0150a5f78d4adc2407911989fdb66c" # Thanks saros :)
language = "cs-CS"

genres = {
    "movies":[{"id":28,"name":"Action"},{"id":12,"name":"Adventure"},{"id":16,"name":"Animation"},{"id":35,"name":"Comedy"},{"id":80,"name":"Crime"},{"id":99,"name":"Documentary"},{"id":18,"name":"Drama"},{"id":10751,"name":"Family"},{"id":14,"name":"Fantasy"},{"id":36,"name":"History"},{"id":27,"name":"Horror"},{"id":10402,"name":"Music"},{"id":9648,"name":"Mystery"},{"id":10749,"name":"Romance"},{"id":878,"name":"Science Fiction"},{"id":10770,"name":"TV Movie"},{"id":53,"name":"Thriller"},{"id":10752,"name":"War"},{"id":37,"name":"Western"}],
    "serials": [{"id":10759,"name":"Action & Adventure"},{"id":16,"name":"Animation"},{"id":35,"name":"Comedy"},{"id":80,"name":"Crime"},{"id":99,"name":"Documentary"},{"id":18,"name":"Drama"},{"id":10751,"name":"Family"},{"id":10762,"name":"Kids"},{"id":9648,"name":"Mystery"},{"id":10763,"name":"News"},{"id":10764,"name":"Reality"},{"id":10765,"name":"Sci-Fi & Fantasy"},{"id":10766,"name":"Soap"},{"id":10767,"name":"Talk"},{"id":10768,"name":"War & Politics"},{"id":37,"name":"Western"}]
}

def top_rated_movies(page=1):
    response = requests.get(f"https://api.themoviedb.org/3/movie/top_rated?api_key={api_key}&language={language}&page={page}", headers=Firefox().headers)
    return response.json()["results"], response.json()["total_pages"]

def popular_movies(page=1):
    response = requests.get(f"https://api.themoviedb.org/3/movie/popular?api_key={api_key}&language={language}&page={page}", headers=Firefox().headers)
    return response.json()["results"], response.json()["total_pages"]

def upcoming_movies(page=1):
    response = requests.get(f"https://api.themoviedb.org/3/movie/upcoming?api_key={api_key}&language={language}&page={page}", headers=Firefox().headers)
    return response.json()["results"], response.json()["total_pages"]

def get_by_genre_movies(genre, page=1):
    response = requests.get(f"https://api.themoviedb.org/3/discover/movie?api_key={api_key}&language={language}&sort_by=popularity.desc&include_video=false&page={page}&with_genres={genre}", headers=Firefox().headers)
    return response.json()["results"], response.json()["total_pages"]

def get_by_year_movies(year, page=1):
    response = requests.get(f"https://api.themoviedb.org/3/discover/movie?api_key={api_key}&language={language}&sort_by=popularity.desc&include_video=false&page={page}&year={year}", headers=Firefox().headers)
    return response.json()["results"], response.json()["total_pages"]


def get_serial_info(id):
    response = requests.get(f"https://api.themoviedb.org/3/tv/{id}?api_key={api_key}&language={language}", headers=Firefox().headers)
    return response.json()

def top_rated_serials(page=1):
    response = requests.get(f"https://api.themoviedb.org/3/tv/top_rated?api_key={api_key}&language={language}&page={page}", headers=Firefox().headers)
    return response.json()["results"], response.json()["total_pages"]

def popular_serials(page=1):
    response = requests.get(f"https://api.themoviedb.org/3/tv/popular?api_key={api_key}&language={language}&page={page}", headers=Firefox().headers)
    return response.json()["results"], response.json()["total_pages"]

def get_by_genre_serials(genre, page=1):
    response = requests.get(f"https://api.themoviedb.org/3/discover/tv?api_key={api_key}&language={language}&sort_by=popularity.desc&include_video=false&page={page}&with_genres={genre}", headers=Firefox().headers)
    return response.json()["results"], response.json()["total_pages"]

def get_by_year_serials(year, page=1):
    response = requests.get(f"https://api.themoviedb.org/3/discover/tv?api_key={api_key}&language=en-US&sort_by=popularity.desc&first_air_date_year={year}&page={page}&include_null_first_air_dates=false", headers=Firefox().headers)
    return response.json()["results"], response.json()["total_pages"]

