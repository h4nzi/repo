# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import re
import sys
import xbmcplugin
import xbmcaddon
import xbmcgui
import requests
import datetime
from bs4 import BeautifulSoup
from kodiez import KodiEZ
from routing import Plugin
from imgs import getIMG
from urllib.parse import parse_qs, quote, unquote, urlencode
from resources.lib.browser import Firefox
from resources.lib.tmdbapi import *

plugin = Plugin()
_ADDON = xbmcaddon.Addon()
_URL = "plugin://{}".format(_ADDON.getAddonInfo('id'))
_KODIEZ = KodiEZ(_ADDON, plugin.handle)
_ADDON_NAME = _ADDON.getAddonInfo('name')

def Msg(message):
    xbmc.log(f"[Prehraj to] {message}", level=xbmc.LOGINFO)

@plugin.route('/')
def root():
    xbmcplugin.setContent(plugin.handle, 'Home')
    xbmcplugin.setPluginCategory(plugin.handle, "Home")
    _KODIEZ.addItemToScreen("Search", "", getIMG("search", "white"), f"{_URL}/search", True)
    _KODIEZ.addItemToScreen("Movies", "", getIMG("movies", "white"), f"{_URL}/movies", True)
    _KODIEZ.addItemToScreen("Serials", "", getIMG("series", "white"), f"{_URL}/serials", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/search')
def search():
    xbmcplugin.setContent(plugin.handle, 'Search')
    xbmcplugin.setPluginCategory(plugin.handle, "Search")

    qs = parse_qs(sys.argv[2][1:])
    page = int(qs.get("page", ["1"])[0])
    query = qs.get("query", "")
    if type(query) == list: query = query[0]
    if not query: query = _KODIEZ.inpt("Enter search term:", hidden=False)
    if not query: exit()

    firefox = Firefox()
    firefox.addHeader("Referer", "https://prehraj.to")
    html = requests.get(f"https://prehraj.to/hledej/{query}?vp-page={page}", headers=firefox.headers).text
    soup = BeautifulSoup(html, features="html.parser")
    Msg(f"Soup: {soup}")
    videos = soup.find_all("div", {"class": "video__picture--container"})
    Msg(f"Videos: {videos}")
    
    names, images, urls = [], [], []

    for video in videos:
        a = video.find_all("a", {"class": "video video--small video--link"})[0]
        img = video.find_all("img", {"class": "thumb thumb1"})[0]

        try:
            time = a.find_all("div", {"class": "video__tag video__tag--time"})[0].text.replace("\n", "").replace("\r", "").replace(" ", "")
            size = a.find_all("div", {"class": "video__tag video__tag--size"})[0].text.replace("\n", "").replace("\r", "").replace(" ", "")
        except:
            time = "Unknown Length"
            size = "Unknown Size"

        name = a.get("title", "N/A")
        name = f"{name} | {time} | {size}"
        if name in names: continue

        names.append(name)
        urls.append("https://prehraj.to" + a.get("href", "N/A"))
        images.append(img.get("src", getIMG("not-found", "white")))
        what = urls.append("https://prehraj.to" + a.get("href", "N/A"))
        Msg(f"What: {what}")

    for name, url, img in zip(names, urls, images):
        _KODIEZ.addItemToScreen(name, "", img, f"{_URL}/play?url={quote(url, safe='')}", False)

    try:
        max_page = soup.find_all("span", {"class": "pagination-pages"})[0].find_all("a")[-1]["href"].split("?vp-page=")[1]
    except IndexError:
        max_page = 1

    if page != int(max_page):
        _KODIEZ.addItemToScreen(f"Next", "", getIMG("next", "white"), f"{_URL}/search?query={query}&page={page + 1}", True)

    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/movies')
def movies():
    #xbmcplugin.setContent(plugin.handle, 'Movies')
    xbmcplugin.setPluginCategory(plugin.handle, "Movies")
    _KODIEZ.addItemToScreen("Top Rated", "", getIMG("folder", "white"), f"{_URL}/topratedMovies", True)
    _KODIEZ.addItemToScreen("Popular", "", getIMG("folder", "white"), f"{_URL}/popularMovies", True)
    _KODIEZ.addItemToScreen("Upcoming", "", getIMG("folder", "white"), f"{_URL}/upcomingMovies", True)
    _KODIEZ.addItemToScreen("By Genres", "", getIMG("folder", "white"), f"{_URL}/bygenresMovies", True)
    _KODIEZ.addItemToScreen("By Year", "", getIMG("folder", "white"), f"{_URL}/byyearMovies", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/topratedMovies')
def topRated_Movies():
    xbmcplugin.setContent(plugin.handle, 'Movies')
    xbmcplugin.setPluginCategory(plugin.handle, "Top Rated Movies")
    qs = parse_qs(sys.argv[2][1:])
    page = int(qs.get("page", ["1"])[0])

    results, max_pages = top_rated_movies(page)
    for result in results:
        _KODIEZ.addItemToScreen(
            name=result['title'],
            icon=f'http://image.tmdb.org/t/p/w342{result["poster_path"]}',
            url=f"{_URL}/search?page=1&query={result['title']}",
            fanart=f'https://image.tmdb.org/t/p/w1280{result["backdrop_path"]}',
            plot=result['overview'],
            isFolder=True
        )

    if page != int(max_pages):
        _KODIEZ.addItemToScreen(f"Next", "", getIMG("next", "white"), f"{_URL}/topratedMovies?page={page + 1}", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/popularMovies')
def popular_Movies():
    xbmcplugin.setContent(plugin.handle, 'Movies')
    xbmcplugin.setPluginCategory(plugin.handle, "Popular Movies")
    qs = parse_qs(sys.argv[2][1:])
    page = int(qs.get("page", ["1"])[0])

    results, max_pages = popular_movies(page)
    for result in results:
        _KODIEZ.addItemToScreen(
            name=result['title'],
            icon=f'http://image.tmdb.org/t/p/w342{result["poster_path"]}',
            url=f"{_URL}/search?page=1&query={result['title']}",
            fanart=f'https://image.tmdb.org/t/p/w1280{result["backdrop_path"]}',
            plot=result['overview'],
            isFolder=True
        )

    if page != int(max_pages):
        _KODIEZ.addItemToScreen(f"Next", "", getIMG("next", "white"), f"{_URL}/popularMovies?page={page + 1}", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/upcomingMovies')
def upcoming_Movies():
    xbmcplugin.setContent(plugin.handle, 'Movies')
    xbmcplugin.setPluginCategory(plugin.handle, "Upcoming Movies")
    qs = parse_qs(sys.argv[2][1:])
    page = int(qs.get("page", ["1"])[0])

    results, max_pages = upcoming_movies(page)
    for result in results:
        _KODIEZ.addItemToScreen(
            name=result['title'],
            icon=f'http://image.tmdb.org/t/p/w342{result["poster_path"]}',
            url=f"{_URL}/search?page=1&query={result['title']}",
            fanart=f'https://image.tmdb.org/t/p/w1280{result["backdrop_path"]}',
            plot=result['overview'],
            isFolder=True
        )

    if page != int(max_pages):
        _KODIEZ.addItemToScreen(f"Next", "", getIMG("next", "white"), f"{_URL}/upcomingMovies?page={page + 1}", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/bygenresMovies')
def byGenres_Movies():
    xbmcplugin.setContent(plugin.handle, 'Genres')
    xbmcplugin.setPluginCategory(plugin.handle, "By Genres")
    for genre in genres["movies"]:
        _KODIEZ.addItemToScreen(genre["name"], "", getIMG("folder", "white"), f"{_URL}/genreMovies?page=1&id={genre['id']}&name={genre['name']}", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/genreMovies')
def genre_Movies():
    xbmcplugin.setContent(plugin.handle, 'Movies')
    qs = parse_qs(sys.argv[2][1:])
    name = qs.get("name", ["N/A"])[0]
    genre_id = qs.get("id", ["1"])[0]
    page = int(qs.get("page", ["1"])[0])
    xbmcplugin.setPluginCategory(plugin.handle, f"{name} Movies")

    results, max_pages = get_by_genre_movies(genre_id, page)
    for result in results:
        _KODIEZ.addItemToScreen(
            name=result['title'],
            icon=f'http://image.tmdb.org/t/p/w342{result["poster_path"]}',
            url=f"{_URL}/search?page=1&query={result['title']}",
            fanart=f'https://image.tmdb.org/t/p/w1280{result["backdrop_path"]}',
            plot=result['overview'],
            isFolder=True
        )

    if page != int(max_pages):
        _KODIEZ.addItemToScreen(f"Next", "", getIMG("next", "white"), f"{_URL}/genreMovies?page={page + 1}&name={name}&id={genre_id}", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/byyearMovies')
def byYear_Movies():
    xbmcplugin.setContent(plugin.handle, 'Years')
    xbmcplugin.setPluginCategory(plugin.handle, "By Year")
    now = datetime.datetime.now()
    currentYear = int(now.strftime("%Y"))
    years = list(range(1923, currentYear+1))
    years.reverse()
    for year in years:
        _KODIEZ.addItemToScreen(str(year), "", getIMG("folder", "white"), f"{_URL}/yearMovies?page=1&year={year}", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/yearMovies')
def year_Movies():
    xbmcplugin.setContent(plugin.handle, 'Movies')
    qs = parse_qs(sys.argv[2][1:])
    page = int(qs.get("page", ["1"])[0])
    selected_year = qs.get("year", ["2020"])[0]
    xbmcplugin.setPluginCategory(plugin.handle, f"{selected_year} Movies")

    results, max_pages = get_by_year_movies(selected_year, page)
    for result in results:
        _KODIEZ.addItemToScreen(
            name=result['title'],
            icon=f'http://image.tmdb.org/t/p/w342{result["poster_path"]}',
            url=f"{_URL}/search?page=1&query={result['title']}",
            fanart=f'https://image.tmdb.org/t/p/w1280{result["backdrop_path"]}',
            plot=result['overview'],
            isFolder=True
        )

    if page != int(max_pages):
        _KODIEZ.addItemToScreen(f"Next", "", getIMG("next", "white"), f"{_URL}/yearMovies?page={page + 1}&year={selected_year}", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route("/serials")
def serials():
    xbmcplugin.setPluginCategory(plugin.handle, "Serials")
    _KODIEZ.addItemToScreen("Top Rated", "", getIMG("folder", "white"), f"{_URL}/topratedSerials", True)
    _KODIEZ.addItemToScreen("Popular", "", getIMG("folder", "white"), f"{_URL}/popularSerials", True)
    _KODIEZ.addItemToScreen("By Genres", "", getIMG("folder", "white"), f"{_URL}/bygenresSerials", True)
    _KODIEZ.addItemToScreen("By Year", "", getIMG("folder", "white"), f"{_URL}/byyearSerials", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route("/seasons")
def seasons():
    xbmcplugin.setContent(plugin.handle, 'tvshows')
    qs = parse_qs(sys.argv[2][1:])
    name = qs.get("name", ["N/A"])[0]
    serialID = qs.get("id", ["1"])[0]
    xbmcplugin.setPluginCategory(plugin.handle, f"{name} Seasons")
    details = get_serial_info(serialID)

    for season in details["seasons"]:
        if season["season_number"] == 0: continue
        _KODIEZ.addItemToScreen(
            name=season["name"],
            icon=f'http://image.tmdb.org/t/p/w342{season["poster_path"]}',
            url=f"{_URL}/episodes?serialID={serialID}&seasonNumber={season['season_number']}&episodeCount={season['episode_count']}&poster={season['poster_path'][1:]}&serialName={name}",
            plot=season["overview"] or details["overview"],
            isFolder=True
        )
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route("/episodes")
def episodes():
    xbmcplugin.setContent(plugin.handle, 'episodes')
    qs = parse_qs(sys.argv[2][1:])
    episodeCount = qs.get("episodeCount", ["0"])[0]
    serialID = qs.get("serialID", ["1"])[0]
    serialName = qs.get("serialName", ["N/A"])[0]
    seasonNumber = qs.get("seasonNumber", ["N/A"])[0]
    poster = "http://image.tmdb.org/t/p/w342/" + qs.get("poster", ["1"])[0]
    xbmcplugin.setPluginCategory(plugin.handle, f"{serialName} Season {seasonNumber}: Episodes")
    details = get_serial_info(serialID)

    for episode in range(1, int(episodeCount) + 1):
        seasonS = int(seasonNumber)
        episodeS = int(episode)
        if seasonS < 10:
            seasonS = int(f"0{seasonS}")
        if episodeS < 10:
            episodeS = int(f"0{episodeS}")

        _KODIEZ.addItemToScreen(
            name=f"Episode {episode}",
            icon=poster,
            url=f"{_URL}/search?page=1&query={serialName} {seasonS}x{episodeS}",
            plot="N/A",
            isFolder=True
        )
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/topratedSerials')
def topRated_Serials():
    xbmcplugin.setContent(plugin.handle, 'tvshows')
    xbmcplugin.setPluginCategory(plugin.handle, "Top Rated Serials")
    qs = parse_qs(sys.argv[2][1:])
    page = int(qs.get("page", ["1"])[0])

    results, max_pages = top_rated_serials(page)
    for result in results:
        _KODIEZ.addItemToScreen(
            name=result['name'],
            icon=f'http://image.tmdb.org/t/p/w342{result["poster_path"]}',
            url=f"{_URL}/seasons?id={result['id']}&name={result['name']}",
            fanart=f'https://image.tmdb.org/t/p/w1280{result["backdrop_path"]}',
            plot=result['overview'],
            isFolder=True
        )

    if page != int(max_pages):
        _KODIEZ.addItemToScreen(f"Next", "", getIMG("next", "white"), f"{_URL}/topratedSerials?page={page + 1}", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/popularSerials')
def popular_Serials():
    xbmcplugin.setContent(plugin.handle, 'tvshows')
    xbmcplugin.setPluginCategory(plugin.handle, "Popular Serials")
    qs = parse_qs(sys.argv[2][1:])
    page = int(qs.get("page", ["1"])[0])

    results, max_pages = popular_serials(page)
    for result in results:
        _KODIEZ.addItemToScreen(
            name=result['name'],
            icon=f'http://image.tmdb.org/t/p/w342{result["poster_path"]}',
            url=f"{_URL}/seasons?id={result['id']}&name={result['name']}",
            fanart=f'https://image.tmdb.org/t/p/w1280{result["backdrop_path"]}',
            plot=result['overview'],
            isFolder=True
        )

    if page != int(max_pages):
        _KODIEZ.addItemToScreen(f"Next", "", getIMG("next", "white"), f"{_URL}/popularSerials?page={page + 1}", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/bygenresSerials')
def byGenres_Serials():
    xbmcplugin.setContent(plugin.handle, 'Genres')
    xbmcplugin.setPluginCategory(plugin.handle, "By Genres")
    for genre in genres["serials"]:
        _KODIEZ.addItemToScreen(genre["name"], "", getIMG("folder", "white"), f"{_URL}/genreSerials?page=1&id={genre['id']}&name={genre['name']}", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/genreSerials')
def genre_Serials():
    xbmcplugin.setContent(plugin.handle, 'tvshows')
    qs = parse_qs(sys.argv[2][1:])
    name = qs.get("name", ["N/A"])[0]
    genre_id = qs.get("id", ["1"])[0]
    page = int(qs.get("page", ["1"])[0])
    xbmcplugin.setPluginCategory(plugin.handle, f"{name} Serials")

    results, max_pages = get_by_genre_serials(genre_id, page)
    for result in results:
        _KODIEZ.addItemToScreen(
            name=result['name'],
            icon=f'http://image.tmdb.org/t/p/w342{result["poster_path"]}',
            url=f"{_URL}/seasons?id={result['id']}&name={result['name']}",
            fanart=f'https://image.tmdb.org/t/p/w1280{result["backdrop_path"]}',
            plot=result['overview'],
            isFolder=True
        )

    if page != int(max_pages):
        _KODIEZ.addItemToScreen(f"Next", "", getIMG("next", "white"), f"{_URL}/genreSerials?page={page + 1}&name={name}&id={genre_id}", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/byyearSerials')
def byYear_Serials():
    xbmcplugin.setContent(plugin.handle, 'Years')
    xbmcplugin.setPluginCategory(plugin.handle, "By Year")
    now = datetime.datetime.now()
    currentYear = int(now.strftime("%Y"))
    years = list(range(1923, currentYear+1))
    years.reverse()
    for year in years:
        _KODIEZ.addItemToScreen(str(year), "", getIMG("folder", "white"), f"{_URL}/yearSerials?page=1&year={year}", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/yearSerials')
def year_Serials():
    xbmcplugin.setContent(plugin.handle, 'tvshows')
    qs = parse_qs(sys.argv[2][1:])
    page = int(qs.get("page", ["1"])[0])
    selected_year = qs.get("year", ["2020"])[0]
    xbmcplugin.setPluginCategory(plugin.handle, f"{selected_year} Serials")

    results, max_pages = get_by_year_serials(selected_year, page)
    for result in results:
        _KODIEZ.addItemToScreen(
            name=result['name'],
            icon=f'http://image.tmdb.org/t/p/w342{result["poster_path"]}',
            url=f"{_URL}/seasons?id={result['id']}&name={result['name']}",
            fanart=f'https://image.tmdb.org/t/p/w1280{result["backdrop_path"]}',
            plot=result['overview'],
            isFolder=True
        )

    if page != int(max_pages):
        _KODIEZ.addItemToScreen(f"Next", "", getIMG("next", "white"), f"{_URL}/yearSerials?page={page + 1}&year={selected_year}", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route("/play")
def play():
    qs = parse_qs(sys.argv[2][1:])
    url = qs.get("url")
    Msg(f"URL: {url}")
    
    if not url:
        return

    firefox = Firefox()
    firefox.addHeader("Referer", "https://prehraj.to")
    html = requests.get(unquote(url[0]), headers=firefox.headers).text
    Msg(f"HTML: {html}")

    pattern = r'{\s*file:\s*"(?P<file>.*?)",\s*label:\s*\'(?P<label>.*?)\'.*}'
    matches = re.finditer(pattern, html)

    sources = tuple((match.group('file'), match.group('label')) for match in matches)

    if len(sources) == 0:
        xbmcgui.Dialog().ok(_ADDON_NAME, "No sources found")
        return

    selectedURL = ""

    if len(sources) == 1:
        selectedURL = sources[0][0]

    if len(sources) > 1:
        res, urls = [], []
        for url, resolution in sources:
            res.append(resolution)
            urls.append(url)
        select = xbmcgui.Dialog().select("Select source", res)
        if select == -1:
            return
        selectedURL = urls[select]

    li = xbmcgui.ListItem(path=selectedURL + '|' + urlencode(firefox.headers))
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(plugin.handle, True, li)

if __name__ == '__main__':
    plugin.run(sys.argv)