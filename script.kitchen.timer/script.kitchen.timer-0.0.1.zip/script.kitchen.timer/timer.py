import xbmcgui
import xbmc
import xbmcvfs
import xbmcaddon
import threading
import time
import os

addon = xbmcaddon.Addon()
player = xbmc.Player()
AP = xbmcvfs.translatePath(addon.getAddonInfo('path'))
JP = os.path.join(AP, 'resources', 'jingle.mp3')
dialog = xbmcgui.Dialog()

def play(JP):
    player.play(JP)

def counter(StartMin, JP):
    seconds = StartMin * 60
    while seconds >= 0:
        minutes_remaining = seconds // 60
        if minutes_remaining < 1:
            jingle_thread = threading.Thread(target=play, args=(JP,))
            jingle_thread.start()
            jingle_thread.join()
            dialog.notification("Minutka", "Čas vypršel", xbmcgui.NOTIFICATION_INFO)
        else:
            dialog.notification("Minutka", "Zbývající čas: " + str(minutes_remaining) + " minut", xbmcgui.NOTIFICATION_INFO, 10000)
        time.sleep(60)
        seconds -= 60

def main():
    StartMin = dialog.input("Minutka", type=xbmcgui.INPUT_NUMERIC)
    if not StartMin:
        return
    counter(int(StartMin), JP)

if __name__ == "__main__":
    main()

# xbmcgui.Window(10000).setProperty('Minutka' , time)
