import xbmcgui
import os
import xbmcaddon
import platform
import subprocess
try:
    from xbmc import translatePath
except ImportError:
    from xbmcvfs import translatePath

addon_id = 'script.advancedsettings.generator'
selfAddon = xbmcaddon.Addon(addon_id)
__version__ = selfAddon.getAddonInfo('version')

coeff = float(selfAddon.getSetting("coefficient"))
rf = selfAddon.getSetting("factor")
platform_name = platform.system()
dialog = xbmcgui.Dialog()
max_cache = 1000000000   # = 1 GB

def get_available_memory():
    if platform.system() == "Linux":
        meminfo_path = "/proc/meminfo"
        with open(meminfo_path, "r") as f:
            meminfo = f.read()
        available_memory = int(meminfo.split("MemAvailable:")[1].split()[0]) / 1024
    else:
        output = subprocess.check_output('wmic OS get FreePhysicalMemory /Value', shell=True).decode().strip()
        _, value = output.split('=')
        available_memory = int(value) / 1024
    return available_memory

def get_xml_file_path():
    if platform_name == "Android":
        return os.path.join(translatePath("special://userdata"), ".kodi", "userdata", "advancedsettings.xml")
    elif platform_name == "Linux":
        return translatePath("special://userdata/advancedsettings.xml")
    elif platform_name == "Windows":
        appdata_path = os.getenv("APPDATA")
        return os.path.join(appdata_path, "Kodi", "userdata", "advancedsettings.xml")
    else:
        return os.path.join(translatePath("special://userdata"), "advancedsettings.xml")

available_memory = get_available_memory()
calculated_cache = int(available_memory / 3 * 1024 * 1024 * coeff)
if calculated_cache > max_cache:
    calculated_cache = max_cache

xml_file_path = get_xml_file_path()

xml_str = f'<?xml version="1.0" encoding="utf-8"?><advancedsettings><cache><buffermode>1</buffermode><memorysize>{calculated_cache}</memorysize><readfactor>{rf}</readfactor></cache></advancedsettings>'

with open(xml_file_path, "w", encoding="utf-8") as xml_file:
    xml_file.write(xml_str)

dialog.ok("Generování a uložení advancedsettings.xml", f"Soubor uložen.[CR]Aktuálně volná paměť RAM: {int(available_memory)} MB. Velikost cache: {int(calculated_cache / 1024 /1024 )} MB.[CR]Cesta k souboru:[CR]{xml_file_path}")
