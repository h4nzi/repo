# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcgui
import requests
import json
import re
from requests.structures import CaseInsensitiveDict
import sys

addon_id = 'service.temperature'
selfAddon = xbmcaddon.Addon(addon_id)
__version__ = selfAddon.getAddonInfo('version')

URL1 = "http://192.168.1.20:9999/data?def"
INTERVAL = 360  # Interval v sekundách
WINDOW = xbmcgui.Window(10000)
monitor = xbmc.Monitor()

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)
def MsgWrn(message):
    xbmc.log(message, level=xbmc.LOGWARNING)
def MsgErr(message):
    xbmc.log(message, level=xbmc.LOGERROR)
def MsgDbg(message):
    xbmc.log(message, level=xbmc.LOGDEBUG)

def find_nested_value(data, keys):
    """
    Rekurzivně hledá hodnotu v zanořené JSON struktuře.
    :param data: Datová struktura (dict nebo list)
    :param keys: Seznam klíčů, které určují cestu
    :return: Hodnota, pokud je nalezena, jinak None
    """
    if not keys:
        return data
    if isinstance(data, dict) and keys[0] in data:
        return find_nested_value(data[keys[0]], keys[1:])
    return None

while not monitor.abortRequested():
    if selfAddon.getSetting('debug') == 'true':
        MsgDbg('[Teploměr] Running')
    try:
        headers = CaseInsensitiveDict()
        headers["Accept"] = "application/json"
        resp = requests.get(URL1, headers=headers)
        
        # Clean the response text by removing invalid characters
        clean_text = re.sub(r'[\x00-\x1F\x7F]', '', resp.text)
        try:
            data = json.loads(clean_text)
            
            # Definování cesty ke hledané hodnotě
            key_path = ["Broadcast", "messages", "Outsidetemp", "fields", "value", "value"]
            temp_value = find_nested_value(data, key_path)
            
            if isinstance(temp_value, (int, float)):
                temp_value = round(temp_value, 1)
                WINDOW.setProperty('outsidetemp', str(temp_value))
                Msg(f"[Teploměr]: {temp_value}°C")
            else:
                MsgWrn("[Teploměr] Hodnota není číselná nebo nebyla nalezena")
            if selfAddon.getSetting('debug') == 'true':        
                MsgDbg(f"[Teploměr] Parsed JSON data: {data}")

        except json.decoder.JSONDecodeError as json_err:
            error_message = "[Teploměr] JSON Decode Error: {} occurred at line {}".format(json_err, sys.exc_info()[-1].tb_lineno)
            MsgErr(error_message)

    except Exception as e:
        error_message = "[Teploměr] Error: {} occurred at line {}".format(e, sys.exc_info()[-1].tb_lineno)
        MsgErr(error_message)
        
    if monitor.waitForAbort(INTERVAL):
        MsgWrn('[Teploměr] Abort Called')
        break
