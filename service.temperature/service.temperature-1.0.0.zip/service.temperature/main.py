# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcgui
import requests
import json
import re
from requests.structures import CaseInsensitiveDict
import sys

addon_id = 'service.temperature'
selfAddon = xbmcaddon.Addon(addon_id)
__version__ = selfAddon.getAddonInfo('version')

URL1 = "http://192.168.1.20:9999/data?def"
URL2 = "http://192.168.1.23/json"
INTERVAL = 360  # Interval v sekundách
WINDOW = xbmcgui.Window(10000)
monitor = xbmc.Monitor()

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)
def MsgWrn(message):
    xbmc.log(message, level=xbmc.LOGWARNING)
def MsgErr(message):
    xbmc.log(message, level=xbmc.LOGERROR)
def MsgDbg(message):
    xbmc.log(message, level=xbmc.LOGDEBUG)

def find_temp2(data):
    """Find temp2 value in the nested data structure."""
    for key, value in data.items():
        if isinstance(value, dict):
            if "fields" in value:
                fields = value["fields"]
                if "temp2" in fields:
                    return fields["temp2"].get("value")
            else:
                result = find_temp2(value)
                if result is not None:
                    return result
    return None
    

while not monitor.abortRequested():
    if selfAddon.getSetting('debug') == 'true':
        MsgDbg('~Teploměr~ Running')
    try:
        headers = CaseInsensitiveDict()
        headers["Accept"] = "application/json"
        resp = requests.get(URL1, headers=headers)
        # Clean the response text by removing invalid characters
        clean_text = re.sub(r'[\x00-\x1F\x7F]', '', resp.text)
        try:
            data = json.loads(clean_text)
            broadcast = data.get("broadcast")
            if broadcast:
                temp2_value = round(find_temp2(broadcast),1)
                if temp2_value is not None:
                    WINDOW.setProperty('outsidetemp', str(temp2_value))
                    Msg(f"~Teploměr~: {temp2_value}")
                else:
                    MsgWrn("temp2 not found in broadcast fields")
            else:
                MsgWrn("Broadcast not found in data")
            if selfAddon.getSetting('debug') == 'true':        
                MsgDbg(f"Parsed JSON data: {data}")
                MsgDbg(f"Broadcast: {broadcast}")

        except json.decoder.JSONDecodeError as json_err:
            error_message = "~Teploměr~ JSON Decode Error: {} occurred at line {}".format(json_err, sys.exc_info()[-1].tb_lineno)
            MsgErr(error_message)

    except Exception as e:
        error_message = "~Teploměr~ Error: {} occurred at line {}".format(e, sys.exc_info()[-1].tb_lineno)
        MsgErr(error_message)
        
    if monitor.waitForAbort(INTERVAL):
        MsgWrn('~Teploměr~ Abort Called')
        break
