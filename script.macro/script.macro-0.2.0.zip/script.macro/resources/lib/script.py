# -*- coding: utf-8 -*-

import xbmc

import sys
import re

from resources.lib.command import executeCommand
from resources.lib.utils.logging import logger

def script():
    commands = sys.argv[1:]
    if len(commands) == 0:
        logger.warning(f'Nothing to do!')
    else:
        logger.info(f'Macro to execute: {commands}')
        for command in commands:
            if command[0] == '@':
                command = command[1:]
                logger.tracking(f'Internal command: {command}')
                executeCommand(command)
            else:
                logger.tracking(f'Builtin command: {command}')
                xbmc.executebuiltin(command)
        logger.info(f'Macro execute done!')
            