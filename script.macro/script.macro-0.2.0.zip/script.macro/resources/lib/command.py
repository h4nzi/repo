# -*- coding: utf-8 -*-

import xbmc

import re
import importlib

from resources.lib.utils.logging import logger
from resources.lib import functions

SYNTAX = {
    "delay": [("time", float, 0.5)],
    "stopanddelay": [("time", float, 0.5)],
    "test1": [("parametr1", int, 0), ("parametr2", str, ""), ("parametr3", float, 1.5)],
    "test2": [("parametr1", bool, True),("parametr2", list, [])],
}

def decodeSyntax(command):
    command = command.lower()
    pattern = r'(\w+)(?:\((.*?)\))?'
    match = re.match(pattern, command)
    
    if match:
        functionName = match.group(1)
        parametersString = match.group(2) if match.group(2) else ''
        functionInfo = SYNTAX.get(functionName)
        if functionInfo is None:
            logger.warning(f'Funkce {command} není definována!')
            return None, None

        parameters = [parameter.strip() for parameter in parametersString.split(',')] if parametersString else []
        
        decodedParameters = []
        parameterIndex = 0
        
        try:
            for parameterName, parameterType, defaultValue in functionInfo:
                if parameterIndex < len(parameters):
                    parameterValue = parameters[parameterIndex]
                    if parameterValue == "":
                        decodedParameters.append(defaultValue)
                    else:
                        decodedParameters.append(parameterType(parameterValue))
                else:
                    decodedParameters.append(defaultValue)
                parameterIndex += 1
            return functionName, decodedParameters
        except:
            logger.warning(f'Chybně zadané parametry v {command}!')
            return None, None
    else:
        logger.warning(f'Chyba syntaxe nebo parametrů v {command}!')
        return None, None

def executeCommand(command):
    functionName, parameters = decodeSyntax(command)
    if functionName == None:
        return
    function = getattr(functions, functionName, None)
    function(parameters)
