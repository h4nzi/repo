# -*- coding: utf-8 -*-

import xbmc

from resources.lib.utils.logging import logger

def delay(parameters):
    try:
        xbmc.Monitor().waitForAbort(parameters[0])
    except:
        logger.warning(f'Error by execute: delay')

def stopanddelay(parameters):
    try:
        if xbmc.getCondVisibility('Player.Hasmedia'):
            xbmc.executebuiltin('Action(Stop)')
            xbmc.Monitor().waitForAbort(parameters[0])
    except:
        logger.warning(f'Error by execute: stopanddelay')
