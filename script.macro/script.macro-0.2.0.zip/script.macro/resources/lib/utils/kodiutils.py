# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

import os

def addonPath(addon = xbmcaddon.Addon()):
    return xbmcvfs.translatePath(addon.getAddonInfo('path'))

def addonProfile(addon = xbmcaddon.Addon()):
    return xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    
def addonIcon(addon = xbmcaddon.Addon()):
    return xbmcvfs.translatePath(os.path.join(addonPath(addon), 'resources', 'icon.png'))

def getSettingBool(param, addon=xbmcaddon.Addon()):
    return True if addon.getSetting(param).upper() == 'TRUE' else False

def getSettingInt(param, addon=xbmcaddon.Addon()):
    return int(addon.getSetting(param))

def getSettingNumber(param, addon=xbmcaddon.Addon()):
    return float(addon.getSetting(param))

def getSettingStr(param, addon=xbmcaddon.Addon().getAddonInfo('id')):
    return addon.getSetting(param)
    
def getProperty(variable, window = 10000):
    return xbmcgui.Window(window).getProperty(variable)

def setProperty(variable, value, window = 10000):
    xbmcgui.Window(window).setProperty(variable, value)

def clearProperty(variable, window = 10000):
    xbmcgui.Window(window).clearProperty(variable)

def clearProperties(variables, window = 10000):
    for p in variables:
        clearProperty(p, window)

def encodeUTF(string):
    return string.encode('utf-8')

def decodeUTF(string):
    return string.decode('utf-8')
    