# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon

import inspect

from resources.lib.utils.kodiutils import getSettingBool

def logging(message, level=xbmc.LOGINFO):
    xbmc.log('[{}] {}'.format(xbmcaddon.Addon().getAddonInfo('name'), message), level)

class Logger:
    def __init__(self):
        pass

    def info(self, message):
        logging(message)

    def warning(self, message):
        logging(message, level=xbmc.LOGWARNING)

    def debug(self, message):
        logging(message, level=xbmc.LOGDEBUG)

    def error(self, message):
        logging(message, level=xbmc.LOGFATAL)
    
    def variable(self, variable):
        frame = inspect.currentframe().f_back
        for name, value in frame.f_locals.items():
            if value is variable:
                logging('VARIABLE {} = {}{}'.format(name, '\n' if len(str(value)) > 80 else '', value))
                break

    def tracking(self, message, variable = None, wrap = False):
        if getSettingBool('script_tracking'):
            logging('TRACKING {}{}{}'.format(message, '\n' if wrap and variable != None else '', variable if variable != None else ''))

logger = Logger()