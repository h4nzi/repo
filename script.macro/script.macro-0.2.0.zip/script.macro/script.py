# -*- coding: utf-8 -*-

from resources.lib.script import script

if __name__ == '__main__':
    script()
        