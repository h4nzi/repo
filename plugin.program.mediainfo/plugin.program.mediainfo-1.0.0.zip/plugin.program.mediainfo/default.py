import xbmc
import xbmcgui
import xbmcaddon
import subprocess
import json

addon = xbmcaddon.Addon()
player = xbmc.Player()
FFPROBE_PATH = "/storage/.kodi/addons/tools.ffmpeg-tools/bin/ffprobe"


def get_hdr_info(stream_url):
    cmd = [
        FFPROBE_PATH, "-v", "error",
        "-select_streams", "v:0",
        "-show_entries", "stream=color_transfer,color_primaries,color_space,side_data_list",
        "-of", "json", stream_url
    ]
    try:
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
        info = json.loads(result.stdout)

        hdr_type = "SDR"
        stream = info.get("streams", [{}])[0]
        color_transfer = stream.get("color_transfer", "")
        side_data = stream.get("side_data_list", [])

        if color_transfer == "smpte2084":
            hdr_type = "HDR10"
        if color_transfer == "arib-std-b67":
            hdr_type = "HLG"
        if any("HDR10+" in d.get("side_data_type", "") for d in side_data):
            hdr_type = "HDR10+"
        if any("DOVI configuration record" in d.get("side_data_type", "") for d in side_data):
            hdr_type = "Dolby Vision"

        return hdr_type
    except Exception as e:
        return "Neznámý (chyba nebo ffprobe není dostupné)"

def get_video_stream_info_ffprobe(stream_url):
    try:
        cmd = [
            FFPROBE_PATH, "-v", "error",
            "-select_streams", "v:0",
            "-show_entries", "stream=width,height,codec_name",
            "-of", "json", stream_url
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
        data = json.loads(result.stdout)
        stream = data.get("streams", [{}])[0]
        width = stream.get("width", "?")
        height = stream.get("height", "?")
        codec = stream.get("codec_name", "neznámý")
        return f"{width}x{height}", codec
    except:
        return "neznámé", "neznámý"

def get_audio_codec_ffprobe(stream_url):
    try:
        cmd = [
            FFPROBE_PATH, "-v", "error",
            "-select_streams", "a:0",
            "-show_entries", "stream=codec_name",
            "-of", "json", stream_url
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
        data = json.loads(result.stdout)
        stream = data.get("streams", [{}])[0]
        return stream.get("codec_name", "neznámý")
    except:
        return "neznámý"

def show_mediainfo():
    if not player.isPlaying():
        xbmcgui.Dialog().notification("MediaInfo", "Není aktivní přehrávání", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    file = player.getPlayingFile()
    info = player.getVideoInfoTag()

    resolution, codec = get_video_stream_info_ffprobe(file)
    audio = get_audio_codec_ffprobe(file)
    subtitles = ", ".join(player.getAvailableSubtitleStreams()) if hasattr(player, "getAvailableSubtitleStreams") else "neznámé"

    hdr_type = get_hdr_info(file)

    message = f"""
Název: {info.getTitle() or "neznámý"}
Soubor: {file}
Rozlišení: {resolution}
Video kodek: {codec}
Audio kodek: {audio}
Titulky: {subtitles}
HDR: {hdr_type}
    """.strip()

    xbmcgui.Dialog().textviewer("MediaInfo+", message)

show_mediainfo()
