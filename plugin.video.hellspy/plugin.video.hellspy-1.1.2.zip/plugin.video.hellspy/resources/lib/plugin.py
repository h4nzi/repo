import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib.parse
import json
import requests
import sys
import os
from xbmcvfs import translatePath

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]
profile_path = translatePath(addon.getAddonInfo('profile'))
history_file = os.path.join(profile_path, 'history.json')

if not os.path.exists(profile_path):
    os.makedirs(profile_path)


def Msg(message):
    xbmc.log(f"[Hellspy] {message}", level=xbmc.LOGINFO)


def show_search():
    kb = xbmc.Keyboard('', 'Zadej název videa')
    kb.doModal()
    if kb.isConfirmed():
        query = kb.getText()
        save_to_history(query)
        list(search(query))


def calculate_size(bits_size):
    mb_size = int(bits_size) / 1024 / 1024
    if mb_size > 1024:
        return f"{round(mb_size / 1024, 2)}  GB"
    return f"{round(mb_size, 2)} MB"


def load_history():
    if os.path.exists(history_file):
        with open(history_file, 'r', encoding='utf-8') as f:
            try:
                return json.load(f)
            except Exception:
                return []
    return []


def save_to_history(query):
    history = load_history()
    if query not in history:
        history.insert(0, query)
        history = history[:50]
        with open(history_file, 'w', encoding='utf-8') as f:
            json.dump(history, f, ensure_ascii=False, indent=2)


def search_direct(query):
    save_to_history(query)
    xbmc.executebuiltin(f'Notification(Vyhledávání, Hledám: {query}, 5000, info)')
    list(search(query))


def search(query):
    encoded_query = urllib.parse.quote_plus(query)
    limits = ['64', '128', '256', '512']
    index = int(addon.getSetting("search_limit"))  # napr. 2
    hodnota = limits[index]  # '256'
    # xbmc.log(f"Vybraná hodnota limitu: {hodnota}")
    api_url = f'https://api.hellspy.to/gw/search?query={encoded_query}&offset=0&limit={hodnota}'
    if addon.getSetting("debug") == "true":
        Msg(f"API: {api_url}")
    response = requests.get(api_url)
    response.raise_for_status()
    data = response.json()
    return data.get('items', [])


def list(items):
    if not items:
        xbmcgui.Dialog().notification('Výsledky', 'Nenalezeny žádné soubory.', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(addon_handle)
        return
    xbmcplugin.setContent(addon_handle, 'videos')

    videos_names = []

    for item in items:
        title = item.get('title', 'Bez názvu')

        file_id = item.get('id')
        file_hash = item.get('fileHash')
        size = item.get('size', 0)
        calculated_size = calculate_size(size)
        title = f"{title} ({calculated_size})"
        duration = item.get('duration', 0)
        thumbs = item.get('thumbs', [])

        if not file_id or not file_hash:
            continue

        url = f'{base_url}?action=select_stream&id={file_id}&hash={file_hash}'
        thumb = thumbs[0] if thumbs else ''

        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
        li.setInfo('video', {'title': title, 'duration': duration, 'size': size})
        li.setProperty('IsPlayable', 'true')
        li.setArt({'fanart': thumb, 'poster': thumb})
        if addon.getSetting('filter_container') == 'true':
            if title not in videos_names:
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        else:
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        videos_names.append(title)

    xbmcplugin.endOfDirectory(addon_handle)


def show_history():
    history = load_history()
    if not history:
        xbmcgui.Dialog().notification('Historie', 'Žádný záznam.', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(addon_handle)
        return
    xbmcplugin.setContent(addon_handle, 'videos')

    for query in history:
        url = f"{base_url}?action=direct&query={urllib.parse.quote_plus(query)}"
        li = xbmcgui.ListItem(label=query)
        li.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        li.setInfo('video', {'title': query})

        context_menu = [
            ('Hellspy Smazat z historie',
             f'RunPlugin({base_url}?action=delete_history_item&query={urllib.parse.quote_plus(query)})'),
            ('Hellspy Smazat celou historii', f'RunPlugin({base_url}?action=clear_history)')
        ]
        li.addContextMenuItems(context_menu)

        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def delete_history_item(query):
    history = load_history()
    if query in history:
        history.remove(query)
        with open(history_file, 'w', encoding='utf-8') as f:
            json.dump(history, f, ensure_ascii=False, indent=2)
        xbmcgui.Dialog().notification('Historie', f'Hledání "{query}" bylo smazáno.', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('Historie', 'Položka nenalezena.', xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin(f'Container.Refresh')
    
def clear_history():
    with open(history_file, 'w', encoding='utf-8') as f:
        json.dump([], f, ensure_ascii=False, indent=2)
    xbmcgui.Dialog().notification('Historie', 'Celá historie byla smazána.', xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin(f'Container.Refresh')

def select_stream(params):
    file_id = params.get('id')
    file_hash = params.get('hash')
    api_url = f"https://api.hellspy.to/gw/video/{file_id}/{file_hash}"
    if addon.getSetting("debug") == "true":
        Msg(f"Info o videu: {api_url}")
    try:
        response = requests.get(api_url)
        response.raise_for_status()
        data = response.json()
        conversions = data.get('conversions', {})
        if addon.getSetting("debug") == "true":
            Msg(f"Response: {response}")
            Msg(f"Data: {data}")
            Msg(f"Data1: {conversions}")

        if not conversions:
            xbmcgui.Dialog().notification('Chyba', 'Žádné streamy.', xbmcgui.NOTIFICATION_ERROR)
            return

        options = []
        for quality, url in conversions.items():
            options.append(quality)
        if addon.getSetting("debug") == "true":
            Msg(f"Možnosti: {options}")

        if not options:
            Msg("Žádné streamy.")
            xbmcgui.Dialog().notification('Chyba', 'Žádné streamy.', xbmcgui.NOTIFICATION_ERROR)
            return

        index = xbmcgui.Dialog().select('Vyber kvalitu', options)
        if index == -1:
            xbmcgui.Dialog().notification('Zrušeno uživatelem', xbmcgui.NOTIFICATION_ERROR)
            return

        selected_quality = options[index]
        stream_url = conversions[selected_quality]
        if addon.getSetting("debug") == "true":
            Msg(f"Vybraná kvalita: {selected_quality}, URL: {stream_url}")

        li = xbmcgui.ListItem(path=stream_url)
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(addon_handle, True, li)

    except Exception as e:
        Msg(f"Chyba při načítání streamu: {e}")
        xbmcgui.Dialog().notification('Chyba', str(e), xbmcgui.NOTIFICATION_ERROR)


def play_video(params):
    file_id = params.get('id')
    file_hash = params.get('hash')
    video_url = f"https://api.hellspy.to/gw/video/{file_id}/{file_hash}"

    if addon.getSetting("debug") == "true":
        Msg(f"file_id: {file_id}")
        Msg(f"file_hash: {file_hash}")
        Msg(f"URL videa: {video_url}")

    li = xbmcgui.ListItem(path=video_url)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(addon_handle, True, li)


def list_menu():
    name_list = [
        ("Vyhledat video", "DefaultAddonsSearch.png", "search", True),
        ("Historie hledání", "DefaultAddonInfo.png", "history", True),
        ("Nastavení", "DefaultAddonProgram.png", "settings", False)
    ]
    for label, icon, action_id, is_folder in name_list:
        url = f'{base_url}?action={action_id}'
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': icon, 'thumb': icon})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=is_folder)
    xbmcplugin.endOfDirectory(addon_handle)


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring.lstrip('?')))
    action = params.get('action')
    if action == 'search':
        show_search()
    elif action == 'history':
        show_history()
    elif action == 'settings':
        xbmcaddon.Addon().openSettings()
    elif action == 'direct':
        search_direct(params.get('query', ''))
    elif action == 'select_stream':
        select_stream(params)
    elif action == 'play':
        play_video(params)
    elif action == 'delete_history_item':
        delete_history_item(params.get('query', ''))
    elif action == 'clear_history':
        clear_history()
    else:
        list_menu()

