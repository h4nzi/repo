import sys
import urllib.parse
import xbmcplugin
import xbmcaddon

# Import plugin logic from resources/lib/plugin.py
from resources.lib import plugin

if __name__ == "__main__":
    plugin.router(sys.argv[2])
