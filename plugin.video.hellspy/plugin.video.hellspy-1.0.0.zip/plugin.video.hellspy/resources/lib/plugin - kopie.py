#funguje
#[Hellspy] Načítám info o videu: https://api.hellspy.to/gw/video/6589125/71c7dabf562e0e019e0dd3c330b3f2c7
#[Hellspy] Response: <Response [200]>
#[Hellspy] Data: {'structType': 'derivedObject', 'objectType': 'GWVideo', 'id': 6589125, 'title': 'Jízda smrti (2008) CZ dabing 1080p', 'fileHash': '71c7dabf562e0e019e0dd3c330b3f2c7', 'size': 2956045586, 'duration': 5265, 'thumbs': ['https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/1-416777.jpg', 'https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/2-909581.jpg', 'https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/3-1104808.jpg', 'https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/4-1635520.jpg', 'https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/5-2243943.jpg', 'https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/6-2624918.jpg', 'https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/7-3132886.jpg', 'https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/8-3688238.jpg', 'https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/9-3875882.jpg', 'https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/10-4495678.jpg'], 'filename': 'Jízda smrti (2008) CZ dabing 1080p.mp4', 'conversions': {'720': 'https://storage3.onecdn1.net/137265770/NyWhzkS2pUA6tq5tM1uGnC5rUNYHYRTwLu36TxJSo1uYaCd8sV5fZwsxAHkjuvZtGVsXqIaeSz6SEMcy8SL2uWySg9uEaSjvceviLNI8lTR5FdQsENSnLFMw.mp4?token=klOwZo9DdZdDGs2TF0gnlRlSSnxpLmJ7&expires=1747053062&sparams=token%2Cexpires%2Cpath&signature=4c51e01a9b7ac1d4c66384cc2b9195ef9b348851', '1080': 'https://storage3.onecdn1.net/137265770/gVMhK1S31UjWIdltp2SevsVJU1ECWdtjESavFMRFPZT1xHeaIYwcEeIJAf5zT5rC92iyDiDZhg8TZrIKlIGrS6nFQKh8ZIxdidpseGfz6hnlfDjI5VfDrtJj.mp4?token=BKPBiLKFfynGT06PU5B0QyTsPEdak9N3&expires=1747053062&sparams=token%2Cexpires%2Cpath&signature=6e96458e2d342ed3c7aa0ee4426e2f5debbe0583'}, 'subtitles': []}
#[Hellspy] Conversions: {'720': 'https://storage3.onecdn1.net/137265770/NyWhzkS2pUA6tq5tM1uGnC5rUNYHYRTwLu36TxJSo1uYaCd8sV5fZwsxAHkjuvZtGVsXqIaeSz6SEMcy8SL2uWySg9uEaSjvceviLNI8lTR5FdQsENSnLFMw.mp4?token=klOwZo9DdZdDGs2TF0gnlRlSSnxpLmJ7&expires=1747053062&sparams=token%2Cexpires%2Cpath&signature=4c51e01a9b7ac1d4c66384cc2b9195ef9b348851', '1080': 'https://storage3.onecdn1.net/137265770/gVMhK1S31UjWIdltp2SevsVJU1ECWdtjESavFMRFPZT1xHeaIYwcEeIJAf5zT5rC92iyDiDZhg8TZrIKlIGrS6nFQKh8ZIxdidpseGfz6hnlfDjI5VfDrtJj.mp4?token=BKPBiLKFfynGT06PU5B0QyTsPEdak9N3&expires=1747053062&sparams=token%2Cexpires%2Cpath&signature=6e96458e2d342ed3c7aa0ee4426e2f5debbe0583'}


# nefunguje
# [Hellspy] Načítám info o videu: https://api.hellspy.to/gw/video/6589125/71c7dabf562e0e019e0dd3c330b3f2c7
# [Hellspy] Response: <Response [200]>
# [Hellspy] Data: {'structType': 'derivedObject', 'objectType': 'GWVideo', 'id': 6589125, 'title': 'Jízda smrti (2008) CZ dabing 1080p', 'fileHash': '71c7dabf562e0e019e0dd3c330b3f2c7', 'size': 2956045586, 'duration': 5265, 'thumbs': ['https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/1-416777.jpg', 'https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/2-909581.jpg', 'https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/3-1104808.jpg', 'https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/4-1635520.jpg', 'https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/5-2243943.jpg', 'https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/6-2624918.jpg', 'https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/7-3132886.jpg', 'https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/8-3688238.jpg', 'https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/9-3875882.jpg', 'https://storage.hellspy.to/thumbs/d17564f6/595b9484/6589125/10-4495678.jpg'], 'filename': 'Jízda smrti (2008) CZ dabing 1080p.mp4', 'conversions': {'720': 'https://storage3.onecdn1.net/137265770/NyWhzkS2pUA6tq5tM1uGnC5rUNYHYRTwLu36TxJSo1uYaCd8sV5fZwsxAHkjuvZtGVsXqIaeSz6SEMcy8SL2uWySg9uEaSjvceviLNI8lTR5FdQsENSnLFMw.mp4?token=3y7nC08ZhrEsMrFioOQ6fpWEkKMmsPxz&expires=1747053279&sparams=token%2Cexpires%2Cpath&signature=94581a4e7d081924cfd40141bdaab8066513b7e0', '1080': 'https://storage3.onecdn1.net/137265770/gVMhK1S31UjWIdltp2SevsVJU1ECWdtjESavFMRFPZT1xHeaIYwcEeIJAf5zT5rC92iyDiDZhg8TZrIKlIGrS6nFQKh8ZIxdidpseGfz6hnlfDjI5VfDrtJj.mp4?token=OWxe8VNTYSCJQJFdmX2lpCq1hQCFbnDQ&expires=1747053279&sparams=token%2Cexpires%2Cpath&signature=9c4757061aa99c1d3dcd34a629a7eb93dfdac0f1'}, 'subtitles': []}
# [Hellspy] Conversions: {'720': 'https://storage3.onecdn1.net/137265770/NyWhzkS2pUA6tq5tM1uGnC5rUNYHYRTwLu36TxJSo1uYaCd8sV5fZwsxAHkjuvZtGVsXqIaeSz6SEMcy8SL2uWySg9uEaSjvceviLNI8lTR5FdQsENSnLFMw.mp4?token=3y7nC08ZhrEsMrFioOQ6fpWEkKMmsPxz&expires=1747053279&sparams=token%2Cexpires%2Cpath&signature=94581a4e7d081924cfd40141bdaab8066513b7e0', '1080': 'https://storage3.onecdn1.net/137265770/gVMhK1S31UjWIdltp2SevsVJU1ECWdtjESavFMRFPZT1xHeaIYwcEeIJAf5zT5rC92iyDiDZhg8TZrIKlIGrS6nFQKh8ZIxdidpseGfz6hnlfDjI5VfDrtJj.mp4?token=OWxe8VNTYSCJQJFdmX2lpCq1hQCFbnDQ&expires=1747053279&sparams=token%2Cexpires%2Cpath&signature=9c4757061aa99c1d3dcd34a629a7eb93dfdac0f1'}

import xbmc
import xbmcgui
import xbmcplugin
import urllib.parse
import json
import requests
import sys

addon_handle = int(sys.argv[1])
base_url = sys.argv[0]

def Msg(message):
    xbmc.log(f"[Hellspy] {message}", level=xbmc.LOGINFO)

def show_search():
    kb = xbmc.Keyboard('', 'Zadej název videa')
    kb.doModal()
    if kb.isConfirmed():
        query = kb.getText()
        search_hellspy(query)
        
def search_direct(query):
    xbmc.executebuiltin(f'Notification(Vyhledávání, Hledám: {query}, 2000, info)')
    search_hellspy(query)

def search_hellspy(search_str):
    query = urllib.parse.quote_plus(search_str)
    api_url = f'https://api.hellspy.to/gw/search?query={query}&offset=0&limit=64'

    try:
        response = requests.get(api_url)
        response.raise_for_status()

        Msg(f"Status kód: {response.status_code}")

        data = response.json()

        if 'items' not in data or not data['items']:
            Msg("Žádné výsledky v 'items'")
            xbmcgui.Dialog().notification('Výsledky', 'Nenalezeny žádné soubory.', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.endOfDirectory(addon_handle)
            return

        for item in data['items']:
            title = item.get('title', 'Bez názvu')
            file_id = item.get('id')
            file_hash = item.get('fileHash')
            size = item.get('size', 0)
            duration = item.get('duration', 0)
            thumbs = item.get('thumbs', [])

            if not file_id or not file_hash:
                Msg(f"Položka přeskočena (chybí id nebo hash): {title}")
                continue
                
            # Msg(f"Title: {title}")
            # Msg(f"File ID: {file_id}")
            # Msg(f"File Hash: {file_hash}")

            stream_select_url = f'{base_url}?action=select_stream&id={file_id}&hash={file_hash}'
            Msg(f"Stream select URL: {stream_select_url}")

            thumb = thumbs[0] if thumbs else ''

            li = xbmcgui.ListItem(label=title)
            li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
            li.setInfo('video', {
                'title': title,
                'duration': duration,
                'size': size
            })
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=stream_select_url, listitem=li, isFolder=False)

        xbmcplugin.endOfDirectory(addon_handle)

    except Exception as e:
        Msg(f"Chyba: {e}")
        xbmcgui.Dialog().notification('Chyba', str(e), xbmcgui.NOTIFICATION_ERROR)

def select_stream(params):
    file_id = params.get('id')
    file_hash = params.get('hash')
    api_url = f"https://api.hellspy.to/gw/video/{file_id}/{file_hash}"
    Msg(f"Načítám info o videu: {api_url}")

    try:
        response = requests.get(api_url)
        response.raise_for_status()
        data = response.json()
        conversions = data.get('conversions', {})

        if not conversions:
            xbmcgui.Dialog().notification('Chyba', 'Nenalezeny žádné streamy.', xbmcgui.NOTIFICATION_ERROR)
            return

        options = list(conversions.keys())
        index = xbmcgui.Dialog().select('Vyber kvalitu', options)

        if index == -1:
            Msg("Uživatel zrušil výběr kvality")
            return

        selected_quality = options[index]
        stream_url = conversions[selected_quality]

        Msg(f"Vybraná kvalita: {selected_quality}, URL: {stream_url}")

        li = xbmcgui.ListItem(path=stream_url)
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(addon_handle, True, li)

    except Exception as e:
        Msg(f"Chyba při načítání streamu: {e}")
        xbmcgui.Dialog().notification('Chyba', str(e), xbmcgui.NOTIFICATION_ERROR)

def play_video(params):
    file_id = params.get('id')
    file_hash = params.get('hash')
    video_url = f"https://api.hellspy.to/gw/video/{file_id}/{file_hash}"
    Msg(f"Play Kontrola: {video_url}")

    video_url = f"https://api.hellspy.to/gw/video/{file_id}/{file_hash}"
    Msg(f"Přehrávám video z: {video_url}")

    li = xbmcgui.ListItem(path=video_url)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(addon_handle, True, li)
    
def show_main_menu():
    url = f'{base_url}?action=search'
    li = xbmcgui.ListItem(label='Vyhledat video')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring.lstrip('?')))
    action = params.get('action')
    Msg(f"Parametry routeru: {params}")
    if action == 'search':
        show_search()
    elif action == 'direct':
        query = params.get('query')
        search_direct(query)
    elif action == 'play':
        play_video(params)
    elif action == 'select_stream':
        select_stream(params)
    else:
        show_main_menu()


