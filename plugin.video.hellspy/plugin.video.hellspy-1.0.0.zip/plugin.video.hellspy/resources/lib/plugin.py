import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib.parse
import json
import requests
import sys

addon_handle = int(sys.argv[1])
base_url = sys.argv[0]
addon = xbmcaddon.Addon()

def Msg(message):
    xbmc.log(f"[Hellspy] {message}", level=xbmc.LOGINFO)
            
def show_search():
    kb = xbmc.Keyboard('', 'Zadej název videa')
    kb.doModal()
    if kb.isConfirmed():
        list(search(kb.getText()))

def search_direct(query):
    xbmc.executebuiltin(f'Notification(Vyhledávání, Hledám: {query}, 2000, info)')
    list(search(query))

def search(query):
    encoded_query = urllib.parse.quote_plus(query)
    api_url = f'https://api.hellspy.to/gw/search?query={encoded_query}&offset=0&limit=64'
    Msg(f"API: {api_url}")
    
    response = requests.get(api_url)
    response.raise_for_status()
    data = response.json()
    return data.get('items', [])
    
def list(items):
    if not items:
        xbmcgui.Dialog().notification('Výsledky', 'Nenalezeny žádné soubory.', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(addon_handle)
        return

    xbmcplugin.setContent(addon_handle, 'videos')

    for item in items:
        title = item.get('title', 'Bez názvu')
        file_id = item.get('id')
        file_hash = item.get('fileHash')
        size = item.get('size', 0)
        duration = item.get('duration', 0)
        thumbs = item.get('thumbs', [])

        if not file_id or not file_hash:
            continue

        url = f'{base_url}?action=select_stream&id={file_id}&hash={file_hash}'
        thumb = thumbs[0] if thumbs else ''

        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
        li.setInfo('video', {'title': title, 'duration': duration, 'size': size})
        li.setProperty('IsPlayable', 'true')
        li.setArt({'fanart': thumb, 'poster': thumb})

        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)


def select_stream(params):
    file_id = params.get('id')
    file_hash = params.get('hash')
    api_url = f"https://api.hellspy.to/gw/video/{file_id}/{file_hash}"
    if addon.getSetting("debug") == "true":
        Msg(f"Info o videu: {api_url}")
    try:
        response = requests.get(api_url)
        response.raise_for_status()
        data = response.json()
        conversions = data.get('conversions', {})
        if addon.getSetting("debug") == "true":
            Msg(f"Response: {response}")
            Msg(f"Data: {data}")
            Msg(f"Data o konverzích: {conversions}")

        if not conversions:
            xbmcgui.Dialog().notification('Chyba', 'Nenalezeny žádné streamy.', xbmcgui.NOTIFICATION_ERROR)
            return

        options = []
        for quality, url in conversions.items():
            options.append(quality)
        if addon.getSetting("debug") == "true":
            Msg(f"Možnosti: {options}")

        if not options:
            Msg("Žádné streamy.")
            xbmcgui.Dialog().notification('Chyba', 'Žádné streamy.', xbmcgui.NOTIFICATION_ERROR)
            return

        index = xbmcgui.Dialog().select('Vyber kvalitu', options)
        if index == -1:
            Msg("Zrušeno.")
            return

        selected_quality = options[index]
        stream_url = conversions[selected_quality]
        if addon.getSetting("debug") == "true":
            Msg(f"Vybraná kvalita: {selected_quality}, URL: {stream_url}")

        li = xbmcgui.ListItem(path=stream_url)
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(addon_handle, True, li)

    except Exception as e:
        Msg(f"Chyba při načítání streamu: {e}")
        xbmcgui.Dialog().notification('Chyba', str(e), xbmcgui.NOTIFICATION_ERROR)

def play_video(params):
    file_id = params.get('id')
    file_hash = params.get('hash')
    video_url = f"https://api.hellspy.to/gw/video/{file_id}/{file_hash}"
    if addon.getSetting("debug") == "true":
        Msg(f"file_id: {file_id}")
        Msg(f"file_hash: {file_hash}")
        Msg(f"URL videa: {video_url}")

    li = xbmcgui.ListItem(path=video_url)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(addon_handle, True, li)
    
def list_menu():
    name_list = [
        ("Vyhledat video", "DefaultAddonsSearch.png", "search", True),
        ("Nastavení", "DefaultAddonProgram.png", "settings", False)
    ]
    for label, icon, action_id, is_folder in name_list:
        url = f'{base_url}?action={action_id}'
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': icon, 'thumb': icon})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=is_folder)
    xbmcplugin.endOfDirectory(addon_handle)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring.lstrip('?')))
    action = params.get('action')

    if action == 'search':
        show_search()
    elif action == 'settings':
        xbmcaddon.Addon().openSettings()
    elif action == 'direct':
        search_direct(params.get('query', ''))
    elif action == 'select_stream':
        select_stream(params)
    elif action == 'play':
        play_video(params)
    else:
        list_menu()

