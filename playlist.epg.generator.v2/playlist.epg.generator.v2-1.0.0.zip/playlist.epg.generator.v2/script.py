# -*-coding:utf8;-*-
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import requests
import json
import uuid
import os
import sys
from urllib.parse import quote
from datetime import datetime, timedelta
from resources.lib import xmltv

ADDON_ID = 'playlist.epg.generator.v2'
ADDON_NAME = 'Playlist EPG Generator verze 2'
addon = xbmcaddon.Addon(id=ADDON_ID)

product_list = ["Xiaomi Redmi Note 7", "iPhone Plus", "Samsung TV", "LG TV"]
dev_list = ["androidportable", "ios", "samsungtv", "lgtv"]
headers = {"User-Agent": "okhttp/3.12.12"}

username = addon.getSetting('username')
password = addon.getSetting('password')
days = int(addon.getSetting('num_days'))
days_back = int(addon.getSetting('num_days_back'))

data_file_path = "special://profile/addon_data/{}/data.json".format(ADDON_ID)
playlist_file_path = addon.getSetting("playlist_folder") + "playlist.m3u"
epg_file_path = addon.getSetting("playlist_folder") + "epg.xml" 


def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)

def MsgErr(message):
    xbmc.log(message, level=xbmc.LOGERROR)

def show_notification(title, message, icon=xbmcgui.NOTIFICATION_INFO, duration=5000):
    xbmcgui.Dialog().notification(title, message, icon, duration)

def save_json_to_file(filepath, data):
    with xbmcvfs.File(filepath, 'w') as file:
        file.write(json.dumps(data, indent=4))

def load_json_from_file(filepath):
    with xbmcvfs.File(filepath, 'r') as file:
        return json.load(file)
        
Msg("[Generátor playlistu a EPG verze 2] playlist: {}".format(playlist_file_path))

# Párování
if not xbmcvfs.exists(data_file_path):
    try:
        dialog = xbmcgui.Dialog()
        selected_index = dialog.select("Vyberte zařízení", product_list)
        if selected_index < 0:
            show_notification(ADDON_NAME, "Výběr zařízení zrušen.", xbmcgui.NOTIFICATION_WARNING)
            sys.exit(0)

        product = product_list[selected_index]
        dev = dev_list[selected_index]
        Msg("[Generátor playlistu a EPG verze 2] Zvoleno zařízení: {}".format(product))

        mac_num = hex(uuid.getnode()).replace('0x', '').upper()
        mac = ':'.join(mac_num[i:i + 2] for i in range(0, 11, 2))

        pairing_url = "https://sledovanitv.cz/api/create-pairing"
        params = {
            "username": username,
            "password": password,
            "type": dev,
            "product": product,
            "serial": mac
        }
        response = requests.get(pairing_url, params=params, headers=headers).json()
        Msg("[Generátor playlistu a EPG verze 2] response: {}".format(response))

        if response.get("status") == 1:
            deviceId = response["deviceId"]
            passwordId = response["password"]
            save_json_to_file(data_file_path, response)
            Msg("[Generátor playlistu a EPG verze 2] Párování úspěšné.")
            show_notification(ADDON_NAME, "Párování bylo úspěšné.", xbmcgui.NOTIFICATION_INFO)
        else:
            error_message = response.get("error", "Neznámá chyba.")
            MsgErr("[Generátor playlistu a EPG verze 2] Chyba při párování: {}".format(error_message))
            show_notification(ADDON_NAME, "Chyba při párování: {}".format(error_message), xbmcgui.NOTIFICATION_ERROR)
            sys.exit(1)

    except Exception as e:
        MsgErr("[Generátor playlistu a EPG verze 2] Neočekávaná chyba: {}".format(e))
        show_notification(ADDON_NAME, "Chyba: {}".format(e), xbmcgui.NOTIFICATION_ERROR)
        sys.exit(1)
else:
    data = load_json_from_file(data_file_path)
    deviceId = data["deviceId"]
    passwordId = data["password"]
    Msg("[Generátor playlistu a EPG verze 2] Načteny uložené údaje pro párování.")

# Přihlášení
login_url = "https://sledovanitv.cz/api/device-login"
login_params = {
    "deviceId": deviceId,
    "password": passwordId,
    "version": "2.44.16",
    "lang": "cs",
    "unit": "default",
    "capabilities": "clientvast,vast,adaptive2,webvtt"
}
login_response = requests.get(login_url, params=login_params, headers=headers).json()

if login_response.get("status") == 1:
    phpsessid = login_response["PHPSESSID"]
    Msg("[Generátor playlistu a EPG verze 2] Přihlášení úspěšné.")
else:
    error_message = login_response.get("error", "Neznámá chyba.")
    MsgErr("[Generátor playlistu a EPG verze 2] Chyba při přihlášení: {}".format(error_message))
    show_notification(ADDON_NAME, "Chyba při přihlášení: {}".format(error_message), xbmcgui.NOTIFICATION_ERROR)
    sys.exit(1)

ch = []

# Playlist
playlist_url = "https://sledovanitv.cz/api/playlist"
playlist_params = {
    "quality": "20",  # Defaultní kvalita (lze dynamicky nastavit)
    "capabilities": "h265,vast,clientvast,adaptive2,webvtt",
    "force": "true",
    "format": "m3u8",
    "logosize": "96",
    "whitelogo": "true",
    "drm": "",
    "subtitles": "1",
    "PHPSESSID": phpsessid
}
playlist_response = requests.get(playlist_url, params=playlist_params, headers=headers).json()
Msg("[Generátor playlistu a EPG verze 2] playlist response: {}".format(playlist_response))

if playlist_response.get("status") == 1:
    with xbmcvfs.File(playlist_file_path, 'w') as file:
        file.write("#EXTM3U\n")
        groups = playlist_response["groups"]
        channels = playlist_response["channels"]
        for channel in channels:
            group = groups.get(channel["group"], "Unknown")
            file.write(f'#EXTINF:-1 group-title="{group}" tvg-logo="{channel["logoUrl"]}" tvg-id="stv-{channel["id"]}",{channel["name"]}\n{channel["url"]}\n')
    Msg("[Generátor playlistu a EPG verze 2] Playlist vygenerován.")
    show_notification(ADDON_NAME, "Playlist vygenerován.", xbmcgui.NOTIFICATION_INFO)
else:
    error_message = playlist_response.get("error", "Neznámá chyba.")
    MsgErr("[Generátor playlistu a EPG verze 2] Chyba při generování playlistu: {}".format(error_message))
    show_notification(ADDON_NAME, "Chyba při generování playlistu: {}".format(error_message), xbmcgui.NOTIFICATION_ERROR)
    sys.exit(1)

# EPG
st = 1
programmes = []
now = datetime.now()
local_now = now.astimezone()
TS = " " + str(local_now)[-6:].replace(":", "")
for i in range(days_back*-1, days):
    next_day = now + timedelta(days = i)
    date_from = next_day.strftime("%Y-%m-%d")
    date_ = next_day.strftime("%d.%m.%Y")
    req = requests.get("https://sledovanitv.cz/api/epg?time=" + date_from + "+00%3A44&duration=1439&detail=description,poster,genres&posterSize=234&channels=" + ",".join(ch)&PHPSESSID=={phpsessid}, headers = headers).json()["channels"]
    if addon.getSetting('debug') == 'true': #mod
        Msg('[Archiv SledováníTV] req: {}'.format(req))
    for k in req.keys():
        for x in req[k]:
            programm = {
                'channel': k,
                'start': x["startTime"].replace("-", "").replace(" ", "").replace(":", "") + "00" + TS,
                'stop': x["endTime"].replace("-", "").replace(" ", "").replace(":", "") + "00" + TS,
                'title': [(x["title"], u'')],
                'desc': [(x["description"], u'')],
            }   
            try:
                icon = x["poster"]
            except:
                icon = None
            if icon != None:
                programm['icon'] = [{"src": icon}]
            try:
                genres = []
                for g in x["genres"]:
                    genres.append((g["name"], u''))
            except:
                genres = []
            if genres != []:
                programm['category'] = genres
            if programm not in programmes:
                programmes.append(programm)
    per = int(days_back) + int(days)
    percent = int((float(st*100) / per))
    if dlg == "1":
        dialog.update(percent, "Archiv SledovaniTV", date_)
    st += 1
w = xmltv.Writer(encoding="utf-8", source_info_url="http://www.funktronics.ca/python-xmltv", source_info_name="Funktronics", generator_info_name="python-xmltv", generator_info_url="http://www.funktronics.ca/python-xmltv")
for c in channels:
    w.addChannel(c)
for p in programmes:
    w.addProgramme(p)
w.write(path + "sledovanitv.xml", pretty_print=True)
if dlg == "1":
    dialog.update(100, "Archiv SledovaniTV", lng(30017))
    xbmc.sleep(1000)
    dialog.close()
    del dialog


        # Zpracování programu...
    Msg("[Generátor playlistu a EPG verze 2] EPG vygenerováno.")
    show_notification(ADDON_NAME, "EPG vygenerováno.", xbmcgui.NOTIFICATION_INFO)
