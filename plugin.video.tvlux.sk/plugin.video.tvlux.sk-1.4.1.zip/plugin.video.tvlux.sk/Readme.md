# KODI Doplnok Televízie LUX

Nový doplnok pre multimedialne centrum KODI slúžiaci na sledovanie archívu Televízie LUX


### Doplnok obsahuje
 - Relácie z archívu Televízie LUX
 - Živé vysielanie Televízie LUX

V prípade otázok / návrhov využite pull request na githube

#### Doležité informácie
Doplnok čerpá len z voľnedostuoných zdrojov a nevyužíva žiadne iné zdroje ako originálne zdroje z televízie LUX.
Samotný doplnok nemá žiaden obsah ktorý by nebol verejne prístupný

**Upozornenie**: Doplnok je funkčný na verziách KODI 19(matrix) alebo novšie

<div style="text-align:center">
	<img src="icon.png" width="25%">
</div>

License: [GPL v.3](http://www.gnu.org/copyleft/gpl.html)

