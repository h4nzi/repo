import sys
import urllib.parse
from urllib.parse import urlencode, parse_qsl
import xbmc
import xbmcgui
import xbmcplugin
import requests
import re
from bs4 import BeautifulSoup

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'videos')

headers = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate, br",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Connection": "keep-alive"
}

page_src = "http://nahnoji.cz"


def search(regex):
    url = regex
    response = requests.get(url, headers=headers)
    response.encoding = 'utf-8'
    return response.text


def get_url(action, **kwargs):
    params = urllib.parse.urlencode({'action': action, **kwargs})
    return f'{sys.argv[0]}?{params}'


def getRawDatas(search_str):
    soup = BeautifulSoup(search("http://nahnoji.cz/hledej?q=" + search_str), "html.parser")
    content_raw = soup.find("div", id="search_result")

    results = []
    print(content_raw.prettify())
    for video_raw in content_raw.find_all("div", class_="video"):
        name = video_raw.find("div", class_="name").text
        video_url = page_src + video_raw.find("a")["href"]
        video_img = page_src + video_raw.find("img")["src"]
        duration = video_raw.find("div", class_="duration").text
        print(name + " " + video_url + " " + video_img + " " + duration)
        results.append({
            "title": name,
            "url": video_url,
            "thumbnail": video_img
        })
    return results


def getVideo(video_url):
    match = re.search(r'var\s+videoPath\s*=\s*"([^"]+)"', search(video_url))
    return page_src + match.group(1)


def show_main_menu():
    li = xbmcgui.ListItem(label="Vyhľadávanie")
    li.setArt({'icon': 'DefaultFolder.png'})
    url = get_url(action='search')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)


def show_search_dialog():
    search_input = xbmcgui.Dialog().input('Zadaj hľadaný výraz', type=xbmcgui.INPUT_ALPHANUM)
    if search_input:
        xbmcgui.Dialog().notification(
            heading="Vyhľadávanie",
            message=f"Hľadám: {search_input}",
            icon=xbmcgui.NOTIFICATION_INFO,
            time=2000
        )
        list_results(search_input)
    else:
        xbmcgui.Dialog().notification(
            heading="Zrušené",
            message="Nebolo nič zadané",
            icon=xbmcgui.NOTIFICATION_WARNING,
            time=2000
        )
        xbmcplugin.endOfDirectory(addon_handle)


def list_results(search_input):
    get_url(action='listing', search_str=search_input)
    results = getRawDatas(search_input)
    for item in results:
        li = xbmcgui.ListItem(label=item['title'])
        li.setArt({'thumb': item['thumbnail'], 'icon': item['thumbnail'], 'poster': item['thumbnail']})
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': item['title']})
        video_url = getVideo(item['url'])
        play_url = get_url(action='play', video_url=video_url)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=play_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)


def play_video(video_url):
    li = xbmcgui.ListItem(path=video_url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=li)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action = params.get('action')

    if action == 'search':
        show_search_dialog()
    elif action == 'play':
        play_video(params['video_url'])
    elif action == 'listing':
        list_results(params['search_str'])
    else:
        show_main_menu()


if __name__ == '__main__':
    router(sys.argv[2][1:])
