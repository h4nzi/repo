# -*- coding: utf-8 -*-

import xbmcaddon
import xbmcgui
import socket
import struct
import time

addon_id = 'script.tools.box'
selfAddon = xbmcaddon.Addon(addon_id)
__version__ = selfAddon.getAddonInfo('version')

destination = selfAddon.getSetting("dest")
dialog = xbmcgui.Dialog()

dns_server = '8.8.8.8'

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)

def checksum(data):
    csum = sum((data[i] << 8) + data[i + 1] for i in range(0, len(data), 2))
    csum = (csum >> 16) + (csum & 0xffff)
    csum = csum + (csum >> 16)
    return (~csum) & 0xffff


def get_host_name(ip_address):
    try:
        host_name, _, _ = socket.gethostbyaddr(ip_address)
        return host_name
    except socket.herror as e:
        Msg(f"Error getting host name for {ip_address}: {e}")
        return None

def traceroute(destination, max_hops=40, measurements=3):
    port = 33434
    result = []
    for ttl in range(1, max_hops + 1):
        response_times = []
        for _ in range(measurements):
            icmp_socket = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_ICMP)
            icmp_socket.setsockopt(socket.IPPROTO_IP, socket.IP_TTL, struct.pack('I', ttl))
            try:
                # icmp_socket.setsockopt(socket.SOL_IP, socket.IP_RECVERR, 1)
                pass
            except AttributeError:
                Msg("IP_RECVERR not supported on this system")

            icmp_socket.settimeout(1)

            icmp_payload = b'abcdefghijklmnopqrstuvwabcdefghi'
            icmp_header = struct.pack('!BBHHH', 8, 0, 0, 0, 1)
            checksum_value = checksum(icmp_header + icmp_payload)
            icmp_header = struct.pack('!BBHHH', 8, 0, checksum_value, 0, 1)

            start = time.time()
            icmp_socket.sendto(icmp_header + icmp_payload, (destination, 1))
            try:
                data, address = icmp_socket.recvfrom(1024)
                end = time.time()
                response_time = round((end - start) * 1000, 2)
                response_times.append(response_time)
            except socket.timeout:
                pass
            except socket.error as e:
                Msg(f"Socket error: {e}")
            finally:
                icmp_socket.close()
        
        if address and response_times:
            host_name = get_host_name(address[0])
            result.append(f"{ttl:}. {', '.join(map(str, response_times))} ms       - {address[0]:} ({host_name})" if host_name else f"{ttl:}. {', '.join(map(str, response_times))} ms       - {address[0]:}")
        else:
            result.append(f"{ttl:<3}. * * *")

        if address and address[0] == destination:
            break

    result = "\n".join(result)
    dialog.textviewer(f"Traceroute IP: {destination}", result)
    Msg("Traceroute completed")

if __name__ == '__main__':
    Msg(f"Start traceroute IP: {destination}")
    dialog.ok("Cílová adresa", destination)
    traceroute(destination, measurements=3)
