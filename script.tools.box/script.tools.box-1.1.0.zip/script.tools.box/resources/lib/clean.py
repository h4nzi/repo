import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import os
import shutil

addon_id = 'script.tools.box'
selfAddon = xbmcaddon.Addon(addon_id)
__version__ = selfAddon.getAddonInfo('version')

tdb_path = xbmcvfs.translatePath("special://userdata/Database/Textures13.db")
thumb_path = xbmcvfs.translatePath("special://userdata/Thumbnails")
dialog = xbmcgui.Dialog()

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)

def dir_size():
    total = 0
    for dirpath, dirnames, filenames in os.walk(thumb_path):
        for filename in filenames:
            file_path = os.path.join(dirpath, filename)
            total += os.path.getsize(file_path)
    return total / 1024 / 1024

def del_dir():
    message = f"Celková velikost adresáře 'Thumbnails' je nyní {dir_size():.2f} MB.\nScript je připraven smazat adresář 'Thumbnails'.[CR]Tato akce je nevratná.[CR]Pokračovat?"
    is_confirmed = dialog.yesno("Mazání Thumbnails", message)
    if is_confirmed:
        try:
            os.remove(tdb_path)
            tdb_deleted = True
        except OSError:
            tdb_deleted = False

        try:
            shutil.rmtree(thumb_path)
            thumb_deleted = True
        except OSError:
            thumb_deleted = False

        if tdb_deleted and thumb_deleted:
            dialog.ok("Hotovo", "Soubor Textures13.db a adresář 'Thumbnails' byly úspěšně smazány.[CR]Pro dokončení akce nyní restartujte Kodi")
            return True
        elif tdb_deleted and not thumb_deleted:
            dialog.ok("Nezdařené smazání adresáře", "Soubor Textures13.db byl úspěšně smazán.[CR]Smazání adresáře 'Thumbnails' odmítnuto systémem.[CR]Zavřete Kodi a adresář smažte ručně. Cesta k adresáři:[CR]" + thumb_path)
            return True
        elif not tdb_deleted and thumb_deleted:
            dialog.ok("Nezdařené smazání souboru", "Adresář 'Thumbnails' byl úspěšně smazán.[CR]Smazání souboru Textures13.db odmítnuto systémem.[CR]Zavřete Kodi a soubor smažte ručně. Cesta k souboru:[CR]" + tdb_path)
            return True
        else:
            dialog.ok("Položky nesmazány", "Mazání souboru Textures13.db i adresáře 'Thumbnails' odmítnuto.[CR]Zavřete Kodi a smažte obě položky ručně. Cesty k položkám:[CR]" + tdb_path + "[CR]" + thumb_path)
            return False

    return False

del_dir()
