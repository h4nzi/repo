import xbmcaddon
import xbmcgui
import time
import subprocess
import threading

addon_id = 'script.tools.box'
selfAddon = xbmcaddon.Addon(addon_id)
__version__ = selfAddon.getAddonInfo('version')

server_address = selfAddon.getSetting("server_address")
home_address = selfAddon.getSetting("home_address")
mode = selfAddon.getSetting("mode")
# band = selfAddon.getSetting("band")

dialog = xbmcgui.Dialog()

def Msg(message):
    xbmc.log(message,level=xbmc.LOGINFO)

def run_bargraph():
    bargraph = xbmcgui.DialogProgressBG()
    bargraph.create("Iperf - probíhá měření", "Prosím čekejte...")
    d_b = 0
    d = 100
    per = int(d_b) + int(d)
    percent = 0

    while percent <= 100:
        bargraph.update(percent, "Iperf - probíhá měření {}%".format(percent))
        time.sleep(1)
        percent += 10
    bargraph.close()

def run_iperf():
    if mode == "0":
        address = server_address
    elif mode == "1":
        address = home_address
    else:
        address = ""

    if address:
        command = ["iperf3", "-c", address, "-R"]
        # command = ["iperf3", "-c", address, "-b", band, "-R"]
        try:
            output = subprocess.check_output(command)
            output_text = output.decode("utf-8")
            dialog.textviewer("Měřeno proti bodu:    {}".format(address), output_text)
        except subprocess.CalledProcessError as e:
            error_message = "Příkaz iperf3 se nezdařil: {}".format(e)
            dialog.notification("Chyba", error_message, xbmcgui.NOTIFICATION_ERROR)
    else:
        dialog.ok("Chyba", "IP adresa není nastavena nebo je nefunkční")

iperf_thread = threading.Thread(target=run_iperf)
bargraph_thread = threading.Thread(target=run_bargraph)

iperf_thread.start()
bargraph_thread.start()

iperf_thread.join()
bargraph_thread.join()

# Help pro případnou úpravu command

    # -c  client
    # -b  šířka pásma
    # -R  reverse - server posílá, client přijímá
    # 
