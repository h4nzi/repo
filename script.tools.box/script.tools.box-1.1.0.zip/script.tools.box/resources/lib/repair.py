# -*- coding: utf-8 -*-

import xbmcvfs
import xbmcgui

userpath = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.stream-cinema-2-release")
source = xbmcvfs.translatePath("%s/settings.xml" % userpath)
target = xbmcvfs.translatePath("%s/settings-scc.xml" % userpath)
dialog = xbmcgui.Dialog()
choice = dialog.select("Nabídka. Zálohujte JEN FUNKČNÍ soubor settings.xml", ["Vytvořit kopii souboru", "Opravit soubor"])

def Msg(message):
    xbmc.log(message,level=xbmc.LOGINFO)

if choice == 0:
    if xbmcvfs.exists(source):
        xbmcvfs.copy(source, target)
        dialog.ok("Záloha vytvořena", "Záložní soubor byl uložen pod názvem settings-scc.xml.")
    else:
        dialog.ok("Chyba", "Zálohu nelze vytvořit.[CR]Soubor settings.xml nebyl nalezen.")    
elif choice == 1:
    if xbmcvfs.exists(target):
        xbmcvfs.copy(target, source)
        dialog.ok("Soubor opraven", "Soubor opraven. Restartujte Kodi")
    else:
        dialog.ok("Chyba", "Soubor nelze opravit. Záložní soubor nebyl nalezen")


