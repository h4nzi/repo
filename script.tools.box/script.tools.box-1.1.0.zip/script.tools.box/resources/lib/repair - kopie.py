import xbmcvfs
import xbmcgui

dialog = xbmcgui.Dialog()

def Msg(message):
    xbmc.log(message,level=xbmc.LOGINFO)

def repair():
    userpath = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.stream-cinema-2-release")
    source = xbmcvfs.translatePath("%s/settings.xml" % userpath)
    target = xbmcvfs.translatePath("%s/settings-kopie.xml" % userpath)

    if xbmcvfs.exists(source):
        choice = dialog.select("Nabídka. Zálohujte JEN FUNKČNÍ soubor settings.xml", ["Vytvořit kopii souboru", "Opravit soubor"])

        if choice == 0:
            xbmcvfs.copy(source, target)
            dialog.notification("Záloha vytvořena", "Soubor settings-kopie.xml uložen.", xbmcgui.NOTIFICATION_INFO, 5000)
        elif choice == 1:
            if xbmcvfs.exists(target):
                xbmcvfs.rename(target, source)
                dialog.notification("Soubor opraven", "Soubor opraven. Restartujte Kodi", xbmcgui.NOTIFICATION_INFO, 5000)
            else:
                dialog.notification("Záloha nenalezena", "Soubor nelze opravit.", xbmcgui.NOTIFICATION_ERROR, 5000)
    else:
        dialog.notification("Soubor nenalezen", "Soubor settings.xml nebyl nalezen.", xbmcgui.NOTIFICATION_ERROR, 5000)

if __name__ == "__main__":
    repair()
