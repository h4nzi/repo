import xbmcgui
import xbmcvfs
import xbmcaddon
from xml.etree import ElementTree as ET
import re

addon_id = 'script.tools.box'
selfAddon = xbmcaddon.Addon(addon_id)
__version__ = selfAddon.getAddonInfo('version')

coeff = float(selfAddon.getSetting("coefficient"))
asg_path = xbmcvfs.translatePath("special://userdata/advancedsettings.xml")
dialog = xbmcgui.Dialog()

def Msg(message):
    xbmc.log(message,level=xbmc.LOGINFO)

def free_mem():
    memory_str = xbmc.getInfoLabel('System.Memory(free)')
    memory_value = re.search(r'\d+(\.\d+)?', memory_str)
    if memory_value:
        free_mem = float(memory_value.group())
    else:
        free_mem = 0.0
    return free_mem

free = free_mem()
calculated_value = int(free / 3 * 1024 * 1024 * coeff)

root = ET.Element("advancedsettings")

cache_element = ET.SubElement(root, "cache")
buffermode_element = ET.SubElement(cache_element, "buffermode")
buffermode_element.text = "1"
memorysize_element = ET.SubElement(cache_element, "memorysize")
memorysize_element.text = str(calculated_value)
readfactor_element = ET.SubElement(cache_element, "readfactor")
readfactor_element.text = "10"
curlclienttimeout_element = ET.SubElement(cache_element, "curlclienttimeout")
curlclienttimeout_element.text = "10"
curllowspeedtime_element = ET.SubElement(cache_element, "curllowspeedtime")
curllowspeedtime_element.text = "10"

xml_tree = ET.ElementTree(root)

xml_tree.write(asg_path, encoding="utf-8", xml_declaration=True)

dialog.ok("Generování a uložení advancedsettings.xml", "Soubor uložen. Volná RAM: " + str(int(free)) + " MB. Velikost cache: " + str(int(calculated_value / 1024 / 1024)) + " MB.[CR]Cesta k souboru:[CR] " + asg_path + "[CR]Pro načtení změny restartujte Kodi")
