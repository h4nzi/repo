# -*- coding: utf-8 -*-

import xbmcaddon
import xbmcgui
import time
import subprocess
import threading

addon_id = 'script.tools.box'
selfAddon = xbmcaddon.Addon(addon_id)
__version__ = selfAddon.getAddonInfo('version')

server_address = selfAddon.getSetting("server_address")
home_address = selfAddon.getSetting("home_address")
mode = selfAddon.getSetting("mode")
# band = selfAddon.getSetting("band")

dialog = xbmcgui.Dialog()

def Msg(message):
    xbmc.log(message,level=xbmc.LOGINFO)

def iperf():
    if not xbmc.getCondVisibility('System.HasAddon(virtual.network-tools)'):
        xbmc.executebuiltin('InstallAddon(virtual.network-tools)')
        time.sleep(5)
        if xbmc.getCondVisibility('System.HasAddon(virtual.network-tools)'):
            dialog.ok("Info", "Závislost nainstalována, před spuštěním je nutný restart Kodi")
        else:
            dialog.ok("Chyba", "Instalace závislosti selhala. Skript nemůže pokračovat.")
        return  # Skončí funkci, pokud addon není nainstalován

    if mode == "0":
        address = server_address
    elif mode == "1":
        address = home_address
    else:
        address = ""

    if address:
        command = ["iperf3", "-c", address, "-R"]
        # command = ["iperf3", "-c", address, "-b", band, "-R"]
        def ProgressBG():
            bargraph = xbmcgui.DialogProgressBG()
            bargraph.create("Iperf - probíhá měření", "Prosím čekejte...")
            d_b = 0
            d = 100
            per = int(d_b) + int(d)
            percent = 0
            while percent <= 100:
                bargraph.update(percent, "Iperf - probíhá měření {}%".format(percent))
                time.sleep(1)
                percent += 10
            bargraph.close()
        bargraph_thread = threading.Thread(target=ProgressBG)
        bargraph_thread.start()
        try:
            output = subprocess.check_output(command)
            output_text = output.decode("utf-8")
            dialog.textviewer("Měřící server:    {}".format(address), output_text)
        except subprocess.CalledProcessError as e:
            error = "Příkaz iperf3 se nezdařil: {}".format(e)
            dialog.notification("Chyba", error, xbmcgui.NOTIFICATION_ERROR)
        bargraph_thread.join()
    else:
        dialog.ok("Chyba", "IP adresa není nastavena nebo je nefunkční")

if __name__ == '__main__':
    iperf()
