# -*- coding: utf-8 -*-

import xbmcaddon
import xbmcgui

addon_id = 'script.tools.box'
selfAddon = xbmcaddon.Addon(addon_id)
__version__ = selfAddon.getAddonInfo('version')

dialog = xbmcgui.Dialog()

def Msg(text, addon=addon_id):
    xbmc.log('[{}] {}'.format(addon, text), xbmc.LOGINFO)

if __name__ == '__main__':
    Msg('Get User Agent (UA) string, version: {}'.format(__version__))
    userAgent = xbmc.getUserAgent()
    Msg('UA = {}'.format(userAgent))
    lg = Msg('UA = {}'.format(userAgent))
    xbmcgui.Window(10007).setProperty('UA', userAgent)

    index1 = userAgent.find("/32 ")
    if index1 != -1:
       index1 += len("/32 ")
    index2 = userAgent.find("2.0)")
    
    if index2 != -1:
       index2 += len("2.0)")
       
    line1 = userAgent[:index1]
    line2 = userAgent[index1:index2]
    line3 = userAgent[index2:]

    dialog.ok("Aktuální User Agent", line1 + "\n" + line2 + "\n" + line3)
    ver = xbmc.getInfoLabel('System.BuildVersionShort')
    dialog.ok("Verze Kodi", ver)


