# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon
import xbmcgui
import os
import shutil
import glob

try:
    from xbmc import translatePath
except ImportError:
    from xbmcvfs import translatePath

addon_id = 'script.tools.box'
selfAddon = xbmcaddon.Addon(addon_id)
__version__ = selfAddon.getAddonInfo('version')

dbPath = translatePath("special://userdata/Database/Textures13.db")
thumbPath = translatePath("special://userdata/Thumbnails")
addonsTempPath = translatePath("special://home/addons/temp")
tempPath = translatePath("special://temp/temp")
archiveCachePath = translatePath("special://temp/archive_cache")
packagesPath = translatePath("special://home/addons/packages")

dialog = xbmcgui.Dialog()

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)

def dirFileSize(path):
    size = 0
    for filePath in glob.glob(os.path.join(path, '**'), recursive=True):
        if os.path.isfile(filePath):
            size += os.path.getsize(filePath) / 1024 / 1024
    return size

def delTemp():
    if dialog.yesno("Vymazání dočasných adresářů Temp","Tento krok je nevratný.[CR][CR]Pokračovat?","Zrušit"):
        try:
            for root, dirs, files in os.walk(addonsTempPath):
                for file in files:
                    os.remove(os.path.join(root, file))
                for dir in dirs:
                    shutil.rmtree(os.path.join(root, dir))
            for root, dirs, files in os.walk(tempPath):
                for file in files:
                    os.remove(os.path.join(root, file))
                for dir in dirs:
                    shutil.rmtree(os.path.join(root, dir))
            for root, dirs, files in os.walk(archiveCachePath):
                for file in files:
                    os.remove(os.path.join(root, file))
                for dir in dirs:
                    shutil.rmtree(os.path.join(root, dir))
            # for root, dirs, files in os.walk(packagesPath):
                # for file in files:
                    # os.remove(os.path.join(root, file))
                # for dir in dirs:
                    # shutil.rmtree(os.path.join(root, dir))
            return True
        except OSError:
            dialog.ok("Info", "Nepodařilo se vymazat obsah dočasných adresářů.[CR]Zrušeno uživatelem nebo chyba systému")
            return False
    else:
        return False

def delThumb():
    if dialog.yesno("Smazání adresáře Thumbnails", "Tento krok je nevratný.[CR][CR]Pokračovat?", "Zrušit"):
        try:
            os.remove(dbPath)
            shutil.rmtree(thumbPath)
            dialog.ok("Upozornění", "Pro dokončení operace bude Kodi restartováno.")
            xbmc.executebuiltin('RestartApp')
            return True
        except OSError:
            dialog.ok("Chyba smazání souboru Textures13.db a adresáře Thumbnails", 
                      "Odmítnuto systémem. Zavřete Kodi a smažte soubor ručně.[CR]Cesta k souboru a adresáři:[CR]" 
                      + dbPath + "[CR]" + thumbPath)
            return False
    else:
        return False

def main():
    tempSize = dirFileSize(addonsTempPath) + dirFileSize(tempPath) + dirFileSize(archiveCachePath)
    thumbSize = dirFileSize(thumbPath) + dirFileSize(dbPath)
    choice = dialog.yesnocustom("Vyčištění Kodi", f"Zvolte další postup:[CR]Smazáním Thumbnails získáte celkem {thumbSize:.2f} MB volného místa.[CR]Vymazáním Temp získáte celkem {tempSize:.2f} MB volného místa", "Zpět", "Temp a Cache", "Thumbnails")
    if choice == 0:
        tempDel = delTemp()
        if tempDel:
            dialog.ok("Hotovo", "Dočasné soubory byly úspěšně smazány.")    
    if choice == 1:
        thumbDel = delThumb()
        if thumbDel:
            dialog.ok("Hotovo", "Adresář Thumbnails byl smazán.")
    if choice == 2:
        xbmc.executebuiltin("RunScript(script.tools.box)")

if __name__ == '__main__':
    main()
