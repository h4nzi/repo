import os
import xbmc
import subprocess
import xbmcgui
import xbmcaddon

script_path = "/storage/.kodi/addons/script.tools.box/resources/bin/ws.sh"
file_path = "/storage/.kodi/userdata/addon_data/script.tools.box/speedtest.xml"

def run_script(script_path):
    try:
        result = subprocess.check_output(["bash", script_path], stderr=subprocess.STDOUT, text=True)
        return result
    except subprocess.CalledProcessError as e:
        return f"Error: {e.output}"

def save_to_file(file_path, data):
    try:
        with open(file_path, "w", encoding="utf-8") as file:
            file.write(data)
        xbmc.log(f"Data uložena do {file_path}", level=xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"Chyba při ukládání: {str(e)}", level=xbmc.LOGERROR)

def show_result(title, text):
    viewer = xbmcgui.Dialog()
    viewer.textviewer(title, text)

script_output = run_script(script_path)

save_to_file(file_path, script_output)
show_result("Výsledky testování rychlosti", script_output)

xbmc.log(f"Script output: {script_output}", level=xbmc.LOGINFO)


