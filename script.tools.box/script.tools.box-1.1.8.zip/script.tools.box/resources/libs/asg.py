import xbmcgui
import os
import xbmcaddon
import platform
import subprocess
try:
    from xbmc import translatePath
except ImportError:
    from xbmcvfs import translatePath

# Inicializace
addon_id = 'script.tools.box'
selfAddon = xbmcaddon.Addon(addon_id)
__version__ = selfAddon.getAddonInfo('version')

coeff = float(selfAddon.getSetting("coefficient"))
rf = selfAddon.getSetting("factor")
platform_name = platform.system()
dialog = xbmcgui.Dialog()
max_cache = 1000000000   # = 1 GB

# Funkce pro získání dostupné paměti
def get_available_memory():
    if platform.system() == "Linux":
        meminfo_path = "/proc/meminfo"
        with open(meminfo_path, "r") as f:
            meminfo = f.read()
        available_memory = int(meminfo.split("MemAvailable:")[1].split()[0]) / 1024
    else:
        output = subprocess.check_output('wmic OS get FreePhysicalMemory /Value', shell=True).decode().strip()
        _, value = output.split('=')
        available_memory = int(value) / 1024
    return available_memory

# Funkce pro získání cesty k XML souboru
def get_xml_file_path():
    if platform_name == "Android":
        return os.path.join(translatePath("special://userdata"), ".kodi", "userdata", "advancedsettings.xml")
    elif platform_name == "Linux":
        return translatePath("special://userdata/advancedsettings.xml")
    elif platform_name == "Windows":
        appdata_path = os.getenv("APPDATA")
        return os.path.join(appdata_path, "Kodi", "userdata", "advancedsettings.xml")
    else:
        return os.path.join(translatePath("special://userdata"), "advancedsettings.xml")

# Kontrola verze Kodi
kodi_version = xbmc.getInfoLabel('System.BuildVersion')
if float(kodi_version[:2]) >= 21:
    dialog.ok("Nekompatibilní verze Kodi", "Toto nastavení lze použít jen pro Kodi 20 a nižší.[CR]Pro Kodi 21 a vyšší použijte nastavení v System/Služby/Caching")
    exit()

# Výpočet dostupné paměti a cache
available_memory = get_available_memory()
calculated_cache = int(available_memory / 3 * 1024 * 1024 * coeff)
if calculated_cache > max_cache:
    calculated_cache = max_cache

# Získání cesty k XML souboru
xml_file_path = get_xml_file_path()

# Vytvoření XML obsahu
xml_str = f'''<?xml version="1.0" encoding="utf-8"?>
<advancedsettings>
    <cache>
        <buffermode>1</buffermode>
        <memorysize>{calculated_cache}</memorysize>
        <readfactor>{rf}</readfactor>
    </cache>
</advancedsettings>'''

# Uložení XML souboru
with open(xml_file_path, "w", encoding="utf-8") as xml_file:
    xml_file.write(xml_str)

# Zobrazení dialogu s informací o uložení
dialog.ok("Generování a uložení advancedsettings.xml", f"Soubor uložen.\nAktuálně volná paměť RAM: {int(available_memory)} MB. Velikost cache: {int(calculated_cache / 1024 / 1024)} MB.\nCesta k souboru:\n{xml_file_path}")
