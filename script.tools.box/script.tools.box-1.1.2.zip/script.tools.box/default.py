# -*- coding: utf-8 -*-

import xbmcgui
import xbmc
import xbmcaddon
import os

try:
    from xbmc import translatePath
except ImportError:
    from xbmcvfs import translatePath

addon = xbmcaddon.Addon()
addon_path = translatePath(addon.getAddonInfo('path'))
path = os.path.join(addon_path, 'resources', 'libs')

asgs = translatePath(os.path.join(addon_path, 'resources', 'libs', 'asg.py'))
repairs = translatePath(os.path.join(addon_path, 'resources', 'libs', 'scc_repair.py'))
iperfs = translatePath(os.path.join(addon_path, 'resources', 'libs', 'iperf.py'))
cleans = translatePath(os.path.join(addon_path, 'resources', 'libs', 'clean.py'))
uas = translatePath(os.path.join(addon_path, 'resources', 'libs', 'ua.py'))


dialog = xbmcgui.Dialog()

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)

def asg():
    xbmc.executebuiltin('RunScript(' + asgs + ')')

def repair():
    xbmc.executebuiltin('RunScript(' + repairs + ')')

def clean():
    xbmc.executebuiltin('RunScript(' + cleans + ')')

def iperf():
    xbmc.executebuiltin('RunScript(' + iperfs + ')')

def ua():
    xbmc.executebuiltin('RunScript(' + uas + ')')
    
def setting():
    addon.openSettings()

def main():
    options = []
    functions_map = {
        'Advanced Settings Generator': asg,
        'Záloha/Oprava SCC souboru settings.xml': repair,
        'Čistící nástroje': clean,
        'Iperf3 Speedtest': iperf,
        'Info - váš Kodi User Agent': ua,
        'Nastavení Kodi Tools': setting
    }

    if addon.getSetting('asg_on') == 'true':
        options.append('Advanced Settings Generator')
    if addon.getSetting('repair_on') == 'true':
        options.append('Záloha/Oprava SCC souboru settings.xml')
    if addon.getSetting('clean_on') == 'true':
        options.append('Čistící nástroje')
    if addon.getSetting('iperf_on') == 'true':
        options.append('Iperf3 Speedtest')
    if addon.getSetting('ua_on') == 'true':
        options.append('Info - váš Kodi User Agent')
    if addon.getSetting('set_on') == 'true':
        options.append('Nastavení Kodi Tools')
    

    options.append('Odejít')

    choice = dialog.select('Kodi Tools Box', options)

    if choice != -1 and choice < len(options) - 1:
        selected_option = options[choice]
        selected_function = functions_map.get(selected_option)
        if selected_function:
            selected_function()
    elif choice == len(options) - 1:
        dialog.notification('Kodi Tools', 'Exiting Kodi Tools', xbmcgui.NOTIFICATION_INFO, 2000)

if __name__ == '__main__':
    main()
