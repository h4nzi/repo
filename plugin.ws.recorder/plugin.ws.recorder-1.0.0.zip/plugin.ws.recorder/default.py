# -*- coding: utf-8 -*-
import os
import threading
import requests
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
from resources.lib.ws_source import setProperty, clearProperties, logInfo

addon = xbmcaddon.Addon()
output_dir = addon.getSetting('output_dir')

# Zajistíme, že adresář pro stahování existuje (pouze jednou při spuštění)
if not xbmcvfs.exists(output_dir):
    xbmcvfs.mkdirs(output_dir)

# Event pro sledování zrušení stahování
cancel_event = threading.Event()

def download_file(url, destination):
    """Stáhne soubor pomocí requests a uloží ho na disk."""
    dialog = xbmcgui.DialogProgressBG()
    dialog.create("Stahování", f"Stahuji soubor z: {url}")

    try:
        response = requests.get(url, stream=True)
        response.raise_for_status()  # Zkontroluje HTTP chyby

        with open(destination, 'wb') as f:
            total_length = int(response.headers.get('content-length', 0))
            downloaded = 0

            for chunk in response.iter_content(chunk_size=8192):
                if cancel_event.is_set():  # Kontrola, zda bylo stahování zrušeno
                    raise Exception("Stahování zrušeno uživatelem")
                
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    percent = int(downloaded * 100 / total_length)
                    dialog.update(percent, f"Stahování: {percent}%")

        dialog.close()
        xbmcgui.Dialog().notification("Stahování dokončeno", destination, xbmcgui.NOTIFICATION_INFO, 3000)
    except Exception as e:
        dialog.close()
        xbmcgui.Dialog().notification("Chyba při stahování", str(e), xbmcgui.NOTIFICATION_ERROR, 5000)

def start_download(stream):
    """Spustí stahování v novém vlákně."""
    file_name = os.path.basename(stream)
    destination = os.path.join(output_dir, file_name)

    # Vyčištění předchozího eventu pro případ nového stahování
    cancel_event.clear()

    # Vytvoření vlákna pro stahování
    download_thread = threading.Thread(target=download_file, args=(stream, destination))
    download_thread.start()

    # Nabídka pro uživatele se zrušením stahování
    if xbmcgui.Dialog().yesno("Stahování", "Chcete zrušit stahování?"):
        cancel_event.set()  # Nastavení eventu pro zrušení

def main():
    logInfo('Spouštím hlavní funkci pluginu')

    # Získání odkazu na stream z ws_source.py
    stream = xbmcgui.Window(10000).getProperty('PLAYED')

    if not stream:
        xbmcgui.Dialog().notification("Chyba", "Stream nebyl nalezen", xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    logInfo(f'Stream nalezen: {stream}')
    
    start_download(stream)  # Spustí stahování na pozadí

    logInfo('Hlavní funkce pluginu dokončena')

if __name__ == '__main__':
    main()
