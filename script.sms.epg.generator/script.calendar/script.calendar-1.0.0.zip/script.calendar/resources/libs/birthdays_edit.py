# -*- coding: utf-8 -*-

import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

addon = xbmcaddon.Addon(id='script.calendar')
userpath = addon.getAddonInfo('profile')
names = xbmcvfs.translatePath("%s/names.txt" % userpath)

if not xbmcvfs.exists(userpath):
    xbmcvfs.mkdir(userpath)

    # Vytvoření souboru names.txt, pokud neexistuje
    with open(names, 'w'):
        pass

if not xbmcgui.Dialog().yesno('Chcete vložit nový záznam?', 'Vkládejte ve tvaru: ddmm jméno, např.: 0101 Emil'):
    xbmcgui.Dialog().notification('Operace zrušena', '')
else:
    # Získání textu, který se má vložit
    text_to_insert = xbmcgui.Dialog().input('Vložte nový záznam')

    # Otevření souboru names.txt v režimu append (přidávání)
    with open(names, 'a') as file:
        # Přidání nového textu na konec souboru s novým řádkem
        file.write(text_to_insert + '\n')

    xbmcgui.Dialog().notification('Nový záznam uložen', '')
