#1.1.2

# -*- coding: utf-8 -*-
import os
import routing
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import requests
import re
from resources.libs.selenium_driver import load_page
from resources.libs.utils import check_kodi_version

import time
import urllib.parse
import json


addon = xbmcaddon.Addon()
plugin = routing.Plugin()
player = xbmc.Player()
dialog = xbmcgui.Dialog()

kodi_version = check_kodi_version()


BASE_URL = "https://tv.idnes.cz/"
#KINO_URL = "https://kino.idnes.cz/"


def Msg(message):
        xbmc.log(message, level=xbmc.LOGINFO)
        
def MsgErr(message):
        xbmc.log(message, level=xbmc.LOGERROR)


@plugin.route('/')
def main_menu():
    """Vytvoří hlavní menu v Kodi."""
    xbmcplugin.setContent(plugin.handle, 'directories')
    listing = []

    sections = {
        "iDnes>TV": BASE_URL,
        "Technika": BASE_URL + "technika",
        "Slow": BASE_URL + "slow",
        "Pořady": BASE_URL + "porady",
        "Archiv": BASE_URL + "archiv",
        "Rozstřel": BASE_URL + "rozstrel",
        "Živě": BASE_URL + "zive",
        #"iDnes Kino": KINO_URL + "serialy"
    }

    for label, url in sections.items():
        encoded_url = urllib.parse.quote(url, safe='')
        if addon.getSetting("debug") == "true":
            decoded = urllib.parse.unquote(encoded_url)
            if addon.getSetting("debug") == "true":
                Msg(f"[iDnes] Main menu: {label} -> {decoded}")

        list_item = xbmcgui.ListItem(label=label)
        list_item.setArt({'icon': 'DefaultTVShows.png'})
        listing.append((plugin.url_for(list_submenu, menu_url=encoded_url), list_item, True))

    xbmcplugin.addDirectoryItems(plugin.handle, listing, len(listing))
    xbmcplugin.endOfDirectory(plugin.handle)


@plugin.route('/submenu/<menu_url>/')
def list_submenu(menu_url):
    """Načte a zobrazí všechny stránky submenu podle dané kategorie."""
    decoded_url = urllib.parse.unquote(menu_url)
    if addon.getSetting("debug") == "true":
        Msg(f"[iDnes] Navigating to submenu URL: {decoded_url}")
        
    xbmcplugin.setContent(plugin.handle, 'videos')

    submenu_listing = []
    video_listing = []
    current_url = decoded_url
    last_valid_url = None

    while current_url:
        soup, real_loaded_url = load_page(current_url)
        if not soup:
            return

        if last_valid_url and real_loaded_url == last_valid_url:
            Msg("[iDnes] Další strana není k dispozici.\n")
            break

        last_valid_url = real_loaded_url  

        entries = soup.find_all('div', class_='entry-in')
        url_pattern = re.compile(r'.*\.(aspx|K\d+)$')

        for entry in entries:
            title_tag = entry.find('h3')
            link_tag = entry.find('a')
            length_tag = entry.find('span', class_='length')
            fanart_tag = entry.find('div', class_='art-img')
            
            title = title_tag.get_text(strip=True)
            url = link_tag['href']
            data_id = link_tag.get('data-id', 'N/A')
            
            if fanart_tag:
                style = fanart_tag.get("style", "")
                url_start = style.find("url('") + 5
                url_end = style.find("')", url_start)
                image_url = style[url_start:url_end] if url_start > 4 and url_end > url_start else None
                if image_url:
                    image_url = "https:" + image_url

            if length_tag:
                duration_text = length_tag.get_text(strip=True).lower()
                try:
                    parts = list(map(int, duration_text.split(':')))
                    if len(parts) == 3:  # HH:MM:SS
                        hours, minutes, seconds = parts
                    elif len(parts) == 2:  # MM:SS
                        hours, minutes, seconds = 0, *parts
                    else:
                        raise ValueError("Neznámý formát času")
                    duration = hours * 3600 + minutes * 60 + seconds
                except ValueError:
                    duration = 0
            else:
                duration = 0

            if addon.getSetting("debug") == "true":
                Msg(f"[iDnes] submenu title: {title}")
                Msg(f"[iDnes] submenu url: {url}")
                Msg(f"[iDnes] submenu data-id: {data_id}")
                Msg(f"[iDnes] submenu stream length: {duration} sec\n")

            full_url = urllib.parse.urljoin(BASE_URL, url) if not url.startswith('http') else url
            encoded_full_url = urllib.parse.quote(full_url, safe='')

            if kodi_version >= 20:
                # Kodi 20+
                if url_pattern.match(url):
                    list_item = xbmcgui.ListItem(label=title)
                    list_item.setArt({'fanart': image_url, 'poster': image_url})
                    info_tag = list_item.getVideoInfoTag()
                    info_tag.setTitle(title)
                    info_tag.setPlot(title)
                    info_tag.setDuration(duration)
                    submenu_listing.append((plugin.url_for(list_submenu, menu_url=encoded_full_url), list_item, True))
                else:
                    list_item = xbmcgui.ListItem(label=title)
                    list_item.setArt({'fanart': image_url, 'poster': image_url})
                    info_tag = list_item.getVideoInfoTag()
                    info_tag.setTitle(title)
                    info_tag.setPlot(title)
                    info_tag.setDuration(duration)

            else:
                # Kodi 19
                if url_pattern.match(url):
                    list_item = xbmcgui.ListItem(label=title)
                    list_item.setArt({'fanart': image_url})
                    submenu_listing.append((plugin.url_for(list_submenu, menu_url=encoded_full_url), list_item, True))
                else:
                    list_item = xbmcgui.ListItem(label=title)
                    list_item.setArt({'fanart': image_url})
                    list_item.setInfo('video', {'title': title, 'duration': duration})

            if data_id and data_id != "N/A":
                video_listing.append((plugin.url_for(list_videos, data_id=data_id), list_item, False))



        next_page_number = check_next_page(real_loaded_url)

        if addon.getSetting('auto_load') == 'Ručně':
            if next_page_number is not None:
                next_page_url = re.sub(r'/\d+$', f"/{next_page_number}", real_loaded_url) if re.search(r'/\d+$', real_loaded_url) else f"{real_loaded_url}/{next_page_number}"
                encoded_next_page_url = urllib.parse.quote(next_page_url, safe='')
                list_item = xbmcgui.ListItem(label="Další strana")
                submenu_listing.append((plugin.url_for(list_submenu, menu_url=encoded_next_page_url), list_item, True))
            break

        if addon.getSetting('auto_load') == 'Automaticky':
            if next_page_number is not None:
                current_url = re.sub(r'/\d+$', f"/{next_page_number}", real_loaded_url) if re.search(r'/\d+$', real_loaded_url) else f"{real_loaded_url}/{next_page_number}"
            else:
                current_url = None

    xbmcplugin.addDirectoryItems(plugin.handle, submenu_listing + video_listing, len(submenu_listing) + len(video_listing))
    xbmcplugin.endOfDirectory(plugin.handle)


def check_next_page(current_url):
    """Zjistí, zda existuje další stránka."""
    base_match = re.match(r'(.*?K\d+)(/\d+)?$', current_url)
    if base_match:
        base_url = base_match.group(1)
        current_page = int(base_match.group(2)[1:]) if base_match.group(2) else 1
        next_page = current_page + 1
        Msg(f"[iDnes] Next page: {next_page}")
        dialog.notification('iDnes TV', f'Načítám {next_page}. stránku', xbmcgui.NOTIFICATION_INFO, 2000)
        
        test_url = f"{base_url}/{next_page}"
        if addon.getSetting("debug") == "true":
            Msg(f"[iDnes] Checking next page: {test_url}")
        
        soup, real_loaded_url = load_page(current_url)
        if not soup:
            return
        
        if soup.find('div', class_='entry-in'):
            return next_page
    return None


@plugin.route('/video/<data_id>/')
def list_videos(data_id):
    """Najde streamy videa, zobrazí dialog a přehraje vybraný stream."""
    if not data_id or data_id == "N/A":
        MsgErr("[iDnes] Chybí data-id pro video")
        return

    video_url = f"https://tv.idnes.cz/_servix/media/video.aspx?idvideo={data_id}&reklama=0&idnestv=1&type=js"

    if addon.getSetting("debug") == "true":
        Msg(f"[iDnes] Video URL: {video_url}")
        
    request = video_url
    response = requests.get(video_url)
    if addon.getSetting("debug") == "true":
        Msg(f"[iDnes] Video URL Request:\n{request}")
        response_text = response.text
        json_match = re.search(r"(\{.*\})", response_text, re.DOTALL)
        if json_match:
            try:
                extracted_json = json.loads(json_match.group(1))
                if "items" in extracted_json:
                    items_data = extracted_json["items"]
                    formatted_response = json.dumps(items_data, indent=4, ensure_ascii=False)
                else:
                    formatted_response = "Položka 'items' nebyla nalezena v odpovědi."
            except ValueError:
                formatted_response = "Nepodařilo se správně převést JSON."
        else:
            formatted_response = "JSON nebyl nalezen v odpovědi."
        if addon.getSetting("debug") == "true":
            Msg(f"[iDnes] Video Response:\n{formatted_response}")

    try:
        response = requests.get(video_url, timeout=5)
        response.raise_for_status()
        json_data = response.text
    except requests.RequestException as e:
        MsgErr(f"[iDnes] Chyba při stahování JSON: {str(e)}")
        return

    mp4_links = re.findall(r'"file":"(https://vod\.idnes\.cz/.*?\.mp4)"', json_data)
    m3u8_links = re.findall(r'"file"\s*:\s*"(https://live\.idnes\.cz/[^"]*\.m3u8)"', json_data)

    stream_urls = mp4_links + m3u8_links
    Msg(f"[iDnes] Stream URLs:{stream_urls}")
    
    def m3u8_resolution(url):
        if addon.getSetting("auto_play_best_stream") == "true":
            links = m3u8_links
            match = re.search(r'(\d{3,4})p', url)
            return int(match.group(1)) if match else 0
        return none

    def extract_resolution(url):
        if addon.getSetting("auto_play_best_stream") == "true":
            links = mp4_links
            if 'high' in url:
                return 2
            elif 'middle' in url:
                return 1
            else:
                return 0
        return none

    def select_stream():
        if addon.getSetting("auto_play_best_stream") == "true":
            if m3u8_links:
                best_m3u8 = max(m3u8_links, key=m3u8_resolution)
                Msg(f"[iDnes] Best m3u8: {best_m3u8}")
                stream_url = best_m3u8
            elif mp4_links:
                best_mp4 = max(mp4_links, key=extract_resolution)
                Msg(f"[iDnes] Best mp4: {best_mp4}")
                stream_url = best_mp4
            else:
                return None
        else:
            stream_urls = m3u8_links + mp4_links
            if not stream_urls:
                return None
            vyber = xbmcgui.Dialog().select("Vyber stream", stream_urls)
            Msg(f"[iDnes] vyber: {vyber}")
            if vyber < 0:
                return None
            
            stream_url = stream_urls[vyber]
        
        return stream_url

    stream_url = select_stream()

    title = xbmc.getInfoLabel('ListItem.Label')
    duration = xbmc.getInfoLabel('ListItem.Duration')
    play_video(stream_url, title=title)

    
def play_video(stream_url, title="Neznámý název"):
    if not stream_url:
        if addon.getSetting("debug") == "true":
            MsgErr("[iDnes] Žádný stream URL pro přehrání")
        return
    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setLabel(title)
    list_item.setProperty("title", title)
    list_item.setProperty("genre", "Live")

    player.play(stream_url, list_item)



def run():
    plugin.run()

