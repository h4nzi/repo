#Upravena aktualitece z povinné na nepovinnou
#přehled verzí chromedriver https://googlechromelabs.github.io/chrome-for-testing/known-good-versions-with-downloads.json

import os
import json
import shutil
import platform
from urllib.request import urlopen, Request
from zipfile import ZipFile
from io import BytesIO
import xbmc
import xbmcgui
import xbmcaddon

addon = xbmcaddon.Addon("plugin.video.idnes.tv")
user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)


def check_kodi_version():
    kodi_version = int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0])
    Msg(f'[iDnes] Instalovaná verze Kodi: {kodi_version}')
    return kodi_version



def check_chromedriver(path):
    data = None
    split_path = path.split(os.sep)
    
    if len(split_path) > 2:
        platform = split_path[-2]
        driverpath = os.path.dirname(path)
        
        # Pokud cesta neexistuje, vytvoříme ji
        if not os.path.exists(driverpath):
            os.makedirs(driverpath)
            xbmc.log(f'[iDnes] Vytvořena cesta: {driverpath}')
        
        filename = os.path.join(driverpath, 'version.json')
        version = None
        
        try:
            with open(filename, "r") as f:
                for row in f:
                    version = row.strip()
        except IOError:
            pass
        
        request = Request(url = 'https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json', method = 'GET', headers = {'User-Agent' : user_agent, 'Accept': 'application/json', 'Content-Type' : 'application/json'})
        
        try:
            response = urlopen(request).read()
            data = json.loads(response)
        except HTTPError as e:
            xbmc.log('[iDnes] Chyba při kontrole verze chromedriver: ' + e.reason)
            return {'err': e.reason}
        
        if data and 'channels' in data and 'Stable' in data['channels'] and 'downloads' in data['channels']['Stable']:
            if version is None or version != data['channels']['Stable']['version']:
                should_update = xbmcgui.Dialog().yesno('[iDnes]', 'Je dostupná nová verze chromedriveru. Aktualizovat?')
                
                if should_update:
                    for platforms in data['channels']['Stable']['downloads']['chromedriver']:
                        if platform == platforms['platform']:
                            response = urlopen(platforms['url'])
                            zip = ZipFile(BytesIO(response.read()))
                            
                            for file in zip.namelist():
                                zipfile = os.path.basename(file)
                                if zipfile:
                                    source = zip.open(file)
                                    target_path = os.path.join(driverpath, zipfile)
                                    
                                    with source, open(target_path, "wb") as target:
                                        shutil.copyfileobj(source, target)
                            
                            xbmcgui.Dialog().notification('[iDnes]', 'Chromedriver byl aktualizovaný!', xbmcgui.NOTIFICATION_INFO, 5000)
                            
                            try:
                                with open(filename, "w") as f:
                                    f.write(f'{data["channels"]["Stable"]["version"]}\n')
                            except IOError:
                                pass


