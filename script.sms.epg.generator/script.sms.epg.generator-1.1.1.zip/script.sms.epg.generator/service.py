import xbmc
import xbmcaddon
import xbmcgui
import time

addon = xbmcaddon.Addon(id='script.sms.epg.generator')

def update():
    if addon.getSetting("start_enabled") == "true":
        xbmcgui.Dialog().notification("SMS EPG Generator","Připravuji aktualizaci", xbmcgui.NOTIFICATION_INFO, 4000, sound = True)
        time.sleep(120)
        xbmc.executebuiltin('RunScript("special://home/addons/script.sms.epg.generator/resources/lib/start.py")')

if __name__ == '__main__':
    update()

