import plug_in

if __name__ == '__main__':
    plug_in.generator()
    
# import test

# if __name__ == '__main__':
    # test()
    
# import subprocess

# if __name__ == '__main__':
    # subprocess.run(['python', 'test.py'])
