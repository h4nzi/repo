# -*- coding: utf-8 -*-

import sys
import os
import xbmcaddon
import xbmcgui
import xbmc
import xbmcvfs
from datetime import datetime, timedelta
import xml.etree.ElementTree as ET
import unicodedata
import time
import requests
try:
    from resources.lib import xmltv
except:
    import xmltv

addon = xbmcaddon.Addon(id='script.sms.epg.generator')
download_path = addon.getSetting("folder")
userpath = addon.getAddonInfo('profile')
temp_epg = xbmcvfs.translatePath("%s/epg.xml" % userpath)
custom_names_path = xbmcvfs.translatePath("%s/custom_names.txt" % userpath)
now = datetime.now()
local_now = now.astimezone()
TimeShift = " " + str(local_now)[-6:].replace(":", "")
TimeShift1 = TimeShift[:3] + str(int(TimeShift[3]) - 1) + TimeShift[4:]
W = xmltv.Writer(encoding="utf-8", source_info_url="http://www.funktronics.ca/python-xmltv", source_info_name="Funktronics", generator_info_name="python-xmltv", generator_info_url="http://www.funktronics.ca/python-xmltv")

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)
    
custom_names = []
if addon.getSetting("notice") == "true" and addon.getSetting("dialog") == "true":
    DLG = True
else:
    DLG = False
    
    
try:
    f = open(custom_names_path, "r", encoding="utf-8").read().splitlines()
    for x in f:
        x = x.split("=")
        custom_names.append((x[0], x[1]))
except:
    pass
    

if addon.getSetting("custom_names") == "true":
    CN = True
else:
    CN = False
if addon.getSetting("diacritics") == "false":
    DC = False
else:
    DC = True
    

def replace_names(value):
    if CN == True:
        for v in custom_names:
            if v[0] == value:
                value = v[1]
    return value

def encode(string):
    if DC == False:
        string = str(unicodedata.normalize('NFKD', string).encode('ascii', 'ignore'), "utf-8")
    return string
    

def replace_names(value):
    if CN == True:
        for v in custom_names:
            if v[0] == value:
                value = v[1]
    return value

class Get_channels_sms:
    def __init__(self):
        self.channels = []
        self.dialog = xbmcgui.DialogProgressBG()
        if DLG == True:
            self.dialog.create("TV.SMS.cz", "")
            self.dialog.update(0, "TV.SMS.cz","Stahování dat...")
        headers = {"user-agent": "SMSTVP/1.7.3 (242;cs_CZ) ID/ef284441-c1cd-4f9e-8e30-f5d8b1ac170c HW/Redmi Note 7 Android/10 (QKQ1.190910.002)"}
        if addon.getSetting("debug") == "true":
            Msg(f"[SMS EPG] headers: {headers}")
        try:
            self.html = requests.get("http://programandroid.365dni.cz/android/v6-tv.php?locale=cs_CZ", headers=headers).text #http volá loga, id, názvy
            if addon.getSetting("debug") == "true":
                Msg(f"[SMS EPG] HTML content1: {self.html[:500]}")  # Ukáže prvních 500 znaků
        except:
            if DLG == True:
                self.dialog.close()
            xbmcgui.Dialog().notification("TV.SMS.cz","Nedostupné", xbmcgui.NOTIFICATION_ERROR, 5000, sound = False)
        if DLG == True:
            self.dialog.close()
        self.ch = {}

    def all_channels(self):
        if addon.getSetting("debug") == "true":
            Msg("[SMS EPG] Entered all_channels")
        try:
            root = ET.fromstring(self.html)
            if addon.getSetting("debug") == "true":
                Msg(f"[SMS EPG] HTML content2: {self.html[:500]}")  # Ukáže prvních 500 znaků HTML
                Msg(f"[SMS EPG] Parsed XML root: {root}")
            for i in root.iter("a"):
                channel_id = encode((i.attrib["id"] + "-" + i.find("n").text).replace(" ", "-").lower())
                if addon.getSetting("debug") == "true":
                    Msg(f"[SMS EPG] channel id: {channel_id}")
                self.ch[i.attrib["id"]] = channel_id
                try:
                    icon = "http://sms.cz/kategorie/televize/bmp/loga/velka/" + i.find("o").text
                except:
                    icon = ""
                W.addChannel({
                    "display-name": [(replace_names(i.find("n").text), u"cs")],
                    "id": channel_id,
                    "icon": [{"src": icon}]
                })
                if addon.getSetting("debug") == "true":
                    Msg(f"[SMS EPG] Added channel: {channel_id}")#vypíše seznam nalezených programů
        except Exception as e:
            Msg(f"[SMS EPG] Error in all_channels: {e}")
            return {}
        return self.ch


class Get_programmes_sms:

    def __init__(self, days_back, days):
        self.programmes_sms = []
        self.days_back = days_back
        self.days = days
        self.dialog = xbmcgui.DialogProgressBG()
        self.dialog.create("TV.SMS.cz", "")
        self.dialog.update(0, "TV.SMS.cz", "Stahování dat...")

    def data_programmes(self, ch):
        try:
            if ch:
                chl = ",".join(ch.keys())
                now = datetime.now()
                st = 1
                for i in range(self.days_back * -1, self.days):
                    next_day = now + timedelta(days=i)
                    date = next_day.strftime("%Y-%m-%d")
                    date_ = next_day.strftime("%d.%m.%Y")
                    headers = {"user-agent": "SMSTVP/1.7.3 (242;cs_CZ) ID/ef284441-c1cd-4f9e-8e30-f5d8b1ac170c HW/Redmi Note 7 Android/10 (QKQ1.190910.002)"}
                    html = requests.get(f"http://programandroid.365dni.cz/android/v6-program.php?datum={date}&id_tv={chl}", headers=headers).text
                    if addon.getSetting("debug") == "true":
                        Msg(f"[SMS EPG] html: {html}") #vypíše surová data pro EPG
                    root = ET.fromstring(html)
                    root[:] = sorted(root, key=lambda child: (child.tag, child.get("o")))
                    for i in root.iter("p"):
                        n = i.find("n").text
                        try:
                            k = i.find("k").text
                        except:
                            k = ""
                        if i.attrib["id_tv"] in ch:
                            TS = TimeShift1 if ch[i.attrib["id_tv"]] == "1455-nova-+1" else TimeShift
                            W.addProgramme({
                                "channel": ch[i.attrib["id_tv"]].replace("804-ct-art", "805-ct-:d"),
                                "start": i.attrib["o"].replace("-", "").replace(":", "").replace(" ", "") + TS,
                                "stop": i.attrib["d"].replace("-", "").replace(":", "").replace(" ", "") + TS,
                                "title": [(n, "")],
                                "desc": [(k, "")]
                            })
                    percent = int((float(st * 100) / (self.days + abs(self.days_back))))
                    self.dialog.update(percent, "TV.SMS.cz", date_)
                    st += 1
                self.dialog.update(100, "TV.SMS.cz", date_)
                time.sleep(0.5)
                self.dialog.close()
        except Exception as e:
            Msg(f"[SMS EPG] {e}")
            self.dialog.close()
            xbmcgui.Dialog().notification("TV.SMS.cz", "Nedostupné", xbmcgui.NOTIFICATION_ERROR, 5000, sound=False)

def generator():
    Msg(f"[SMS EPG] Generator spuštěn")
    try:
        days = int(addon.getSetting("num_days"))
        days_back = int(addon.getSetting("num_days_back"))
        
        g = Get_channels_sms()
        ch = g.all_channels()
        gg = Get_programmes_sms(days_back, days)
        gg.data_programmes(ch)

        if isinstance(W.get_channels, dict):
            channels = W.get_channels
            if addon.getSetting("debug") == "true":
                Msg(f"[SMS EPG] Retrieved Channels: {channels}")
            if not channels:
                xbmcgui.Dialog().notification("TV.SMS.cz", "Žádné kanály", xbmcgui.NOTIFICATION_ERROR, 4000, sound=True)
                return
        else:
            xbmcgui.Dialog().notification("TV.SMS.cz", "Chyba při načítání kanálů", xbmcgui.NOTIFICATION_ERROR, 4000, sound=True)
            return

        try:
            W.write(temp_epg, pretty_print=True)
            xbmcvfs.copy(temp_epg, download_path + addon.getSetting("file_name"))
            xbmcvfs.delete(temp_epg)
            xbmcgui.Dialog().notification("TV.SMS.cz", "Hotovo, uloženo", xbmcgui.NOTIFICATION_INFO, 4000, sound=False)
        except Exception as e:
            xbmcgui.Dialog().notification("TV.SMS.cz", "Chyba při ukládání", xbmcgui.NOTIFICATION_ERROR, 4000, sound=True)

    except Exception as e:
        xbmcgui.Dialog().notification("TV.SMS.cz", "Obecná chyba", xbmcgui.NOTIFICATION_ERROR, 4000, sound=True)





