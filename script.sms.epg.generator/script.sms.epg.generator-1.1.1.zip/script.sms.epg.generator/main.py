from resources.lib import plug_in

if __name__ == '__main__':
    plug_in.generator()