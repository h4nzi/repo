
import xbmc
import xbmcgui
import xbmcaddon

import requests
from bs4 import BeautifulSoup

addon = xbmcaddon.Addon("plugin.video.idnes.tv")
user_agent = {'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:129.0) Gecko/20100101 Firefox/129.0"}
cookies = "_webid=3.bfaeb97b52.1741517544.1741517544; _mmid=lq8fe729cbc43c14; sso=id=---&_v=q7qx97gvhi&e=1773010800; __pat=3600000; _webid2=89451952.1742110678177.I; dCMP=mafra=1111,all=1,reklama=1,part=0,cpex=1,google=1,gemius=1,id5=1,next=0000,onlajny=0000,jenzeny=0000,databazeknih=0000,autojournal=0000,skodahome=0000,skodaklasik=0000,groupm=1,piano=1,seznam=1,geozo=0,czaid=1,click=1,vendors=full,verze=2,; playtvak_log=arts=A170421_162637A180419_111038A190517_103534; TS019301af=01942f2c3099b4f20b43f1b9ee3076e0fd7aaa31ef720b86a5e9dc859f3c4beb5f01d7eafbc95dfb185b1a242a2a86f95914b0308229572d2855bd6ca7fc7fe1edc9c2ea45a0da46a91cd2744b3d640a8e56862213; personalizace=setver=full&sp=3214471440178444&lidskost=AsgaYYySqoR7DyZa54eBTew&lS=za-oponou; didomi_token=eyJ1c2VyX2lkIjoiMTk1N2E1MjMtMjUxNi02NjhkLWFjZjctNGQ3ZWIzY2RhODQ2IiwiY3JlYXRlZCI6IjIwMjUtMDMtMDlUMDk6NTI6NDIuMDY1WiIsInVwZGF0ZWQiOiIyMDI1LTAzLTE5VDE1OjA0OjU0LjY1OVoiLCJ2ZXJzaW9uIjoyLCJwdXJwb3NlcyI6eyJlbmFibGVkIjpbInB1Ymxpc2hlcnMtalJRRjJGNFUiLCJwdWJsaXNoZXJzLUtxcTNpUGdlIiwicHVibGlzaGVycy1VUHF0Y2dhRSIsInB1Ymxpc2hlcnMtWFdaMmIzQUsiLCJzb3VobGFzcy02RUM3aDRkSiJdfSwidmVuZG9ycyI6eyJlbmFibGVkIjpbImdvb2dsZSIsImM6bWFmcmFhcy1YZDZwMm1HQSJdfSwicHVycG9zZXNfbGkiOnsiZW5hYmxlZCI6WyJwdWJsaXNoZXJzLWpSUUYyRjRVIiwicHVibGlzaGVycy1LcXEzaVBnZSIsInB1Ymxpc2hlcnMtVVBxdGNnYUUiLCJwdWJsaXNoZXJzLVhXWjJiM0FLIiwic291aGxhc3MtNkVDN2g0ZEoiXX0sInZlbmRvcnNfbGkiOnsiZW5hYmxlZCI6WyJnb29nbGUiLCJjOm1hZnJhYXMtWGQ2cDJtR0EiXX19; euconsent-v2=CQOAIQAQOhFoAAHABBENBhFgAP_gAEPgAAAAJpwMgAFAAQAArABwAHQAQAAqABaADIAGkARABFACSAEwALcAXgBfADEAH4AQEAgwCEAEQAIoAToAywB3ADxAH6ARYAkoBOACkAFmALqAXwAzgCFgEdAJpATaAnQBP4CpAFZALUAXmAxkBkgDUwHfgRsAlWBNMDU4DAAFQAOAAgABUADIAGgARAAmABiAD8AIQARAAywB3AD9AIsASUBNoCpAFZALUAXmAyQBqYAwSADAAEFdh0AGAAIK7EoAMAAQV2KQAYAAgrsQgAwABBXYtABgACCuwAAA.f_wAH_wAAAAA; lastAdSyncDate=1742634660187; sso_sync=idnes=1742634660094; xbc=%7Bkpex%7DGgBCPbT-PxzYZ8J_8i6V1Q; euctmp=CQOAIQAQOhFoAAHABBENBhFgAP_gAEPgAAAAJpwMgAFAAQAArABwAHQAQAAqABaADIAGkARABFACSAEwALcAXgBfADEAH4AQEAgwCEAEQAIoAToAywB3ADxAH6ARYAkoBOACkAFmALqAXwAzgCFgEdAJpATaAnQBP4CpAFZALUAXmAxkBkgDUwHfgRsAlWBNMDU4DAAFQAOAAgABUADIAGgARAAmABiAD8AIQARAAywB3AD9AIsASUBNoCpAFZALUAXmAyQBqYAwSADAAEFdh0AGAAIK7EoAMAAQV2KQAYAAgrsQgAwABBXYtABgACCuwAAA.f_wAH_wAAAAA"
#cookies = xbmcplugin.getSetting('cookies') Nefunguje!. Nutno nalézt řešení

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)
def MsgErr(message):
        xbmc.log(message, level=xbmc.LOGERROR)


def check_kodi_version():
    kodi_version = int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0])
    if addon.getSetting("debug") == "true":
        Msg(f'[iDnes] Instalovaná verze Kodi: {kodi_version}')
    return kodi_version
    
def load_page(url):
    """Načte HTML stránku bez použití Selenium."""
    try:
        response = requests.get(url, headers=user_agent, cookies={'Cookie': cookies}, timeout=5)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        if addon.getSetting("response") == "true":
            Msg(f'[iDnes] Response Soup: {soup}')
        return soup, response.url
    except requests.RequestException as e:
        MsgErr(f"[iDnes] Chyba při načítání stránky: {str(e)}")
        return None, None



