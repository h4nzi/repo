# -*- coding: utf-8 -*-

import os
import subprocess
import xbmc
import xbmcaddon

addon = xbmcaddon.Addon()
log_path = addon.getSetting("log_path") or "/storage/logfiles/journalctl.log"

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)

Msg("[Autoexec] Journal Logger started")

try:
    with open(log_path, "w") as log_file:
        subprocess.run(["journalctl", "-b"], stdout=log_file, check=True)
    Msg(f"[Autoexec] Journal log saved to {log_path}")
except Exception as e:
    Msg(f"[Autoexec] Error saving journal log: {e}")
    

