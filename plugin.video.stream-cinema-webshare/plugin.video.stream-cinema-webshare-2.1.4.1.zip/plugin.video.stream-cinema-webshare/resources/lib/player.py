import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import uuid
import xml.etree.ElementTree as ET
from urllib.parse import urlencode
import requests  # ← TOTO JE TO, CO TI CHYBĚLO

from resources.lib.login import login, revalidate, api, is_ok, HEADERS, REALM

addon = xbmcaddon.Addon()
_handle = int(sys.argv[1])
_session = requests.Session()
_session.headers.update(HEADERS)


def Info(message, heading=addon.getAddonInfo('name'), icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)
    
def Msg(message):
    xbmc.log("[Stream Cinema Webshare - Player] " + message, level=xbmc.LOGINFO)

def getlink(ident, wst, dtype='video_stream'):
    duuid = addon.getSetting('duuid')
    if not duuid:
        duuid = str(uuid.uuid4())
        addon.setSetting('duuid', duuid)
    data = {'ident': ident, 'wst': wst, 'download_type': dtype, 'device_uuid': duuid}
    #TODO password protect
    #response = api('file_protected',data) #protected
    #xml = ET.fromstring(response.content)
    #if is_ok(xml) and xml.find('protected').text != 0:
    #    pass #ask for password

    response = api('file_link', data)
    xml = ET.fromstring(response.content)
    if is_ok(xml):
        return xml.find('link').text

def play(params):
    Msg(f"Spouštím přehrání, ident={params.get('ident')}, name={params.get('name')}")
    token = revalidate()
    link = getlink(params['ident'], token)
    Msg(f"Link: {link}")

    if link and link.startswith("http"):
        headers = _session.headers.copy()
        headers.update({'Cookie': 'wst=' + token})
        link = link + '|' + urlencode(headers)
        listitem = xbmcgui.ListItem(label=params['name'], path=link)
        # listitem.setProperty('mimetype', 'application/octet-stream')
        listitem.setMimeType('video/x-matroska')  # nebo jiný typ podle formátu
        xbmcplugin.setResolvedUrl(_handle, True, listitem)
    else:
        Msg("Nepodařilo se získat platný stream link")
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem("Chyba přehrání"))

