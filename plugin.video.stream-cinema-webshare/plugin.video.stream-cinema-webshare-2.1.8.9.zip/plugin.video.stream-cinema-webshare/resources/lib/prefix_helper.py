# import sqlite3
# import unicodedata
# import xbmcgui
# import xbmcplugin
# from collections import defaultdict
# import xbmcaddon

# from resources.lib.metadata import fetch_tmdb_metadata
# from resources.lib.logger import Msg, Info

# addon = xbmcaddon.Addon()

# PageLimit = int(addon.getSetting("page_limit"))# počet položek na stránku


# def normalize_text(text):
    # replacements = {
        # 'ß': 'ss',
        # 'ł': 'l',
        # # Přidejte další speciální případy podle potřeby
    # }
    # text = text.lower()
    # text = ''.join(
        # c for c in unicodedata.normalize('NFKD', text)
        # if not unicodedata.combining(c)
    # )
    # for src, tgt in replacements.items():
        # text = text.replace(src, tgt)
    # return text


# def show_letter_selector(_handle, get_url):
    # xbmcplugin.setPluginCategory(_handle, "Filmy - A-Z")
    # xbmcplugin.setContent(_handle, "files")

    # for char in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        # url = get_url(action="movies_by_prefix_menu", prefix=char)
        # li = xbmcgui.ListItem(label=char)
        # li.setArt({'icon': 'DefaultFolder.png'})
        # xbmcplugin.addDirectoryItem(_handle, url, li, isFolder=True)

    # # Přidáme číslice 0-9 jako jedna volba
    # url = get_url(action="movies_by_prefix_menu", prefix="0-9")
    # li = xbmcgui.ListItem(label="0-9")
    # li.setArt({'icon': 'DefaultFolder.png'})
    # xbmcplugin.addDirectoryItem(_handle, url, li, isFolder=True)

    # # Přidáme speciální znaky jako jedna volba (třeba #)
    # url = get_url(action="movies_by_prefix_menu", prefix="other")
    # li = xbmcgui.ListItem(label="#")
    # li.setArt({'icon': 'DefaultFolder.png'})
    # xbmcplugin.addDirectoryItem(_handle, url, li, isFolder=True)

    # xbmcplugin.endOfDirectory(_handle)

# def show_prefix_menu(_handle, get_url, DB_MOVIES, prefix=""):
    # next_len = len(prefix) + 1
    # xbmcplugin.setPluginCategory(_handle, f"Filmy - {prefix.upper() or 'A-Z'}")
    # xbmcplugin.setContent(_handle, "files")

    # conn = sqlite3.connect(DB_MOVIES)
    # cursor = conn.cursor()

    # cursor.execute("""
        # SELECT
            # COALESCE(
                # NULLIF(TRIM(m.CzTitle), ''),
                # NULLIF(TRIM(m.OriginalTitle), ''),
                # NULLIF(TRIM(m.Title), '')
            # ) AS Title
        # FROM Movies m
    # """)

    # rows = cursor.fetchall()
    # conn.close()

    # prefix_counts = defaultdict(int)
    # prefix_titles = defaultdict(list)
    # norm_prefix = normalize_text(prefix)
    # if addon.getSetting("debug") == "true":
        # Msg(f"[PREFIX HELPER] norm_prefix: {norm_prefix}")

    # for (title,) in rows:
        # if not title:
            # continue
        # norm_title = normalize_text(title)
        # if norm_title.startswith(norm_prefix):
            # next_key = norm_title[:next_len]
            # prefix_counts[next_key] += 1
            # prefix_titles[next_key].append(title)

    # for next_key in sorted(prefix_counts.keys()):
        # count = prefix_counts[next_key]
        # titles = prefix_titles[next_key]
        # if addon.getSetting("debug") == "true":
            # Msg(f"[PREFIX HELPER] Prefix '{next_key}' má {count} filmů:")
            # for t in titles:
                # Msg(f" - {t}")

        # visible_label = next_key.upper().replace(" ", "␣")
        # label = f"{visible_label} ({count})"

        # url = get_url(
            # action="movies_by_prefix" if len(next_key) >= 2 else "movies_by_letter_menu",
            # prefix=next_key
        # )
        # li = xbmcgui.ListItem(label=label)
        # li.setArt({'icon': 'DefaultFolder.png'})
        # xbmcplugin.addDirectoryItem(_handle, url, li, isFolder=True)

    # xbmcplugin.endOfDirectory(_handle)


# def show_movies_by_prefix(_handle, get_url, DB_MOVIES, prefix, page=1, page_size=PageLimit):
    # conn = sqlite3.connect(DB_MOVIES)
    # cursor = conn.cursor()

    # cursor.execute("""
        # SELECT m.Movie_ID,
               # COALESCE(
                   # NULLIF(TRIM(COALESCE(m.CzTitle, '')), ''),
                   # NULLIF(TRIM(COALESCE(m.OriginalTitle, '')), ''),
                   # NULLIF(TRIM(COALESCE(m.Title, '')), '')
               # ) AS FinalTitle,
               # s.Provider_Ident AS stream_url
        # FROM Movies m
        # JOIN Streams s ON s.Movie_ID = m.Movie_ID
        # WHERE s.Provider_Ident IS NOT NULL AND s.Provider_Ident != ''
        # GROUP BY m.Movie_ID
        # ORDER BY FinalTitle COLLATE NOCASE
    # """)

    # rows = cursor.fetchall()
    # conn.close()

    # prefix_norm = normalize_text(prefix)
    # Msg(f"[PREFIX HELPER] prefix_norm: {prefix_norm}")
    # filtered = [
        # (movie_id, title, url)
        # for movie_id, title, url in rows
        # if title and normalize_text(title).startswith(prefix_norm)
    # ]
    # Msg(f"[PREFIX HELPER] filtered: {filtered}")
    # total_items = len(filtered)
    # Msg(f"[PREFIX HELPER] total_items: {total_items}")
    # start = (page - 1) * page_size
    # end = start + page_size
    # paged = filtered[start:end]

    # xbmcplugin.setPluginCategory(_handle, f"Filmy - {prefix} ({total_items})")
    # xbmcplugin.setContent(_handle, "movies")

    # total_pages = (total_items + page_size - 1) // page_size

    # if page > 1:
        # prev_page_url = get_url(action="movies_by_prefix", prefix=prefix, page=page - 1)
        # li = xbmcgui.ListItem(label="« Předchozí strana")
        # li.setArt({'icon': 'DefaultFolder.png'})
        # xbmcplugin.addDirectoryItem(_handle, prev_page_url, li, isFolder=True)

    # for movie_id, title, stream_url in paged:
        # li = xbmcgui.ListItem(label=title)
        # li.setPath(stream_url)
        # li.setProperty("IsPlayable", "true")

        # metadata = fetch_tmdb_metadata(title, DB_MOVIES)
        # if metadata:
            # info = li.getVideoInfoTag()
            # info.setTitle(metadata.get("title", title))
            # info.setPlot(metadata.get("overview", ""))
            # if metadata.get("release_date"):
                # info.setYear(int(metadata["release_date"][:4]))
            # info.setRating(float(metadata.get("vote_average", 0.0)))
            # info.setDuration(int(metadata.get("runtime", 0)))
            # info.setMediaType("movie")

            # genres = [g["name"] for g in metadata.get("genres", [])]
            # if genres:
                # info.setGenres(genres)

            # poster = metadata.get("poster_path")
            # if poster:
                # img = f"https://image.tmdb.org/t/p/w500{poster}"
                # li.setArt({"poster": img, "fanart": img, "icon": img})
            # else:
                # li.setArt({"icon": "DefaultVideo.png"})
        # else:
            # li.setArt({"icon": "DefaultVideo.png"})

        # play_url = get_url(action="play", ident=stream_url, name=title)
        # xbmcplugin.addDirectoryItem(_handle, play_url, li, isFolder=False)

    # if page < total_pages:
        # next_page_url = get_url(action="movies_by_prefix", prefix=prefix, page=page + 1)
        # li = xbmcgui.ListItem(label="Další strana »")
        # li.setArt({'icon': 'DefaultFolder.png'})
        # xbmcplugin.addDirectoryItem(_handle, next_page_url, li, isFolder=True)

    # xbmcplugin.endOfDirectory(_handle, updateListing=(page != 1), cacheToDisc=False)
    
import sqlite3
import unicodedata
import xbmcgui
import xbmcplugin
from collections import defaultdict
import xbmcaddon

from resources.lib.metadata import fetch_tmdb_metadata
from resources.lib.logger import Msg, Info

addon = xbmcaddon.Addon()

PageLimit = int(addon.getSetting("page_limit"))


def normalize_text(text):
    replacements = {
        'ß': 'ss',
        'ł': 'l',
    }
    text = text.lower()
    text = ''.join(
        c for c in unicodedata.normalize('NFKD', text)
        if not unicodedata.combining(c)
    )
    for src, tgt in replacements.items():
        text = text.replace(src, tgt)
    return text


def show_letter_selector(_handle, get_url):
    xbmcplugin.setPluginCategory(_handle, "Filmy - A-Z")
    xbmcplugin.setContent(_handle, "files")

    for char in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        url = get_url(action="movies_by_prefix_menu", prefix=char)
        li = xbmcgui.ListItem(label=char)
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(_handle, url, li, isFolder=True)

    url = get_url(action="movies_by_prefix_menu", prefix="0-9")
    li = xbmcgui.ListItem(label="0-9")
    li.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(_handle, url, li, isFolder=True)

    url = get_url(action="movies_by_prefix_menu", prefix="other")
    li = xbmcgui.ListItem(label="#")
    li.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(_handle, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(_handle)


def show_prefix_menu(_handle, get_url, DB_MOVIES, prefix=""):
    next_len = len(prefix) + 1
    xbmcplugin.setPluginCategory(_handle, f"Filmy - {prefix.upper() or 'A-Z'}")
    xbmcplugin.setContent(_handle, "files")

    conn = sqlite3.connect(DB_MOVIES)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            COALESCE(
                NULLIF(TRIM(m.CzTitle), ''),
                NULLIF(TRIM(m.OriginalTitle), ''),
                NULLIF(TRIM(m.Title), '')
            ) AS Title
        FROM Movies m
    """)
    rows = cursor.fetchall()
    conn.close()

    prefix_counts = defaultdict(int)
    prefix_titles = defaultdict(list)
    norm_prefix = normalize_text(prefix)
    if addon.getSetting("debug") == "true":
        Msg(f"[PREFIX HELPER] norm_prefix: {norm_prefix}")

    for (title,) in rows:
        if not title:
            continue
        norm_title = normalize_text(title)
        if not norm_title:
            continue

        # Speciální režim pro "0-9"
        if prefix == "0-9":
            if not norm_title[0].isdigit():
                continue
            next_key = norm_title[0]
        elif prefix == "other":
            if norm_title[0].isalnum():
                continue
            next_key = norm_title[0]
        else:
            if not norm_title.startswith(norm_prefix):
                continue
            next_key = norm_title[:next_len]

        prefix_counts[next_key] += 1
        prefix_titles[next_key].append(title)

    for next_key in sorted(prefix_counts.keys()):
        count = prefix_counts[next_key]
        titles = prefix_titles[next_key]
        if addon.getSetting("debug") == "true":
            Msg(f"[PREFIX HELPER] Prefix '{next_key}' má {count} filmů:")
            for t in titles:
                Msg(f" - {t}")

        visible_label = next_key.upper().replace(" ", "␣")
        label = f"{visible_label} ({count})"

        url = get_url(
            action="movies_by_prefix" if len(next_key) >= 1 else "movies_by_letter_menu",
            prefix=next_key
        )
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(_handle, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(_handle)


def show_movies_by_prefix(_handle, get_url, DB_MOVIES, prefix, page=1, page_size=PageLimit):
    conn = sqlite3.connect(DB_MOVIES)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT m.Movie_ID,
               COALESCE(
                   NULLIF(TRIM(COALESCE(m.CzTitle, '')), ''),
                   NULLIF(TRIM(COALESCE(m.OriginalTitle, '')), ''),
                   NULLIF(TRIM(COALESCE(m.Title, '')), '')
               ) AS FinalTitle,
               s.Provider_Ident AS stream_url
        FROM Movies m
        JOIN Streams s ON s.Movie_ID = m.Movie_ID
        WHERE s.Provider_Ident != ''
        GROUP BY m.Movie_ID
        ORDER BY FinalTitle COLLATE NOCASE
    """)

    rows = cursor.fetchall()
    conn.close()

    prefix_norm = normalize_text(prefix)
    Msg(f"[PREFIX HELPER] prefix_norm: {prefix_norm}")

    if prefix == "0-9":
        filtered = [
            (movie_id, title, url)
            for movie_id, title, url in rows
            if title and normalize_text(title)[0].isdigit()
        ]
    elif prefix == "other":
        filtered = [
            (movie_id, title, url)
            for movie_id, title, url in rows
            if title and not normalize_text(title)[0].isalnum()
        ]
    else:
        filtered = [
            (movie_id, title, url)
            for movie_id, title, url in rows
            if title and normalize_text(title).startswith(prefix_norm)
        ]

    Msg(f"[PREFIX HELPER] filtered: {filtered}")
    total_items = len(filtered)
    Msg(f"[PREFIX HELPER] total_items: {total_items}")
    start = (page - 1) * page_size
    end = start + page_size
    paged = filtered[start:end]

    xbmcplugin.setPluginCategory(_handle, f"Filmy - {prefix} ({total_items})")
    xbmcplugin.setContent(_handle, "movies")

    total_pages = (total_items + page_size - 1) // page_size

    if page > 1:
        prev_page_url = get_url(action="movies_by_prefix", prefix=prefix, page=page - 1)
        li = xbmcgui.ListItem(label="« Předchozí strana")
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(_handle, prev_page_url, li, isFolder=True)

    for movie_id, title, stream_url in paged:
        li = xbmcgui.ListItem(label=title)
        li.setPath(stream_url)
        li.setProperty("IsPlayable", "true")

        metadata = fetch_tmdb_metadata(title, DB_MOVIES)
        if metadata:
            info = li.getVideoInfoTag()
            info.setTitle(metadata.get("title", title))
            info.setPlot(metadata.get("overview", ""))
            if metadata.get("release_date"):
                info.setYear(int(metadata["release_date"][:4]))
            info.setRating(float(metadata.get("vote_average", 0.0)))
            info.setDuration(int(metadata.get("runtime", 0)))
            info.setMediaType("movie")

            genres = [g["name"] for g in metadata.get("genres", [])]
            if genres:
                info.setGenres(genres)

            poster = metadata.get("poster_path")
            if poster:
                img = f"https://image.tmdb.org/t/p/w500{poster}"
                li.setArt({"poster": img, "fanart": img, "icon": img})
            else:
                li.setArt({"icon": "DefaultVideo.png"})
        else:
            li.setArt({"icon": "DefaultVideo.png"})

        play_url = get_url(action="play", ident=stream_url, name=title)
        xbmcplugin.addDirectoryItem(_handle, play_url, li, isFolder=False)

    if page < total_pages:
        next_page_url = get_url(action="movies_by_prefix", prefix=prefix, page=page + 1)
        li = xbmcgui.ListItem(label="Další strana »")
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(_handle, next_page_url, li, isFolder=True)

    xbmcplugin.endOfDirectory(_handle, updateListing=(page != 1), cacheToDisc=False)

