import os
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import json
import sqlite3
import requests
from xml.etree import ElementTree
from resources.lib.logger import Msg, Info
from resources.lib.login import revalidate

addon = xbmcaddon.Addon()
history_path = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.stream-cinema-webshare/search_history.json")
ADDON_DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.stream-cinema-webshare")
DB_VIDEOS = os.path.join(ADDON_DATA_DIR, "videos.db")
TOKEN = 'DGr4w5qjcH0w1c8d'
API_URL = 'https://webshare.cz/api/search/'

def delete_history_item(query):
    with xbmcvfs.File(history_path, 'r') as f:
        history = json.loads(f.read())

    if query in history:
        history.remove(query)
        with xbmcvfs.File(history_path, 'w') as f:
            f.write(json.dumps(history, ensure_ascii=False, indent=2))

        xbmcgui.Dialog().notification('Historie', f'„{query}“ bylo smazáno.', xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Refresh')
    
def clear_history():
    if xbmcvfs.exists(history_path):
        xbmcvfs.delete(history_path)
        xbmc.executebuiltin(f'Container.Refresh')
        Info("Historie hledání byla smazána.")
        
def clear_db():
    conn = sqlite3.connect(DB_VIDEOS)
    c = conn.cursor()
    c.execute('DELETE FROM videos')
    conn.commit()
    conn.close()
    
def find():
    Msg(f"Spouštím find")
    revalidate()
    HEADERS = {
        'Authorization': f'Token {TOKEN}',
        'Accept': 'text/xml; charset=UTF-8',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
    }

    MIN_SIZE = 1 * 1024**3  # 1 GB
    NEEDLE = ['1080', '1080p']

    offset = 0
    limit = 200

    while True:
        data = {
            'what': 'ostrava',
            'sort': 'largest',
            'limit': str(limit),
            'offset': str(offset),
            'category': 'video'
        }

        resp = requests.post(API_URL, headers=HEADERS, data=data)
        if resp.status_code != 200:
            Msg(f"[Utils] Chyba: {resp.status_code}")
            break

        root = ElementTree.fromstring(resp.content)
        files = root.findall('.//file')
        if not files:
            Msg("[Utils] Konec výsledků.")
            Info("Konec. Více informací v protokolu.")
            break

        for file in files:
            name = file.findtext('name') or ''
            size = int(file.findtext('size') or 0)
            ident = file.findtext('ident') or ''
            if size >= MIN_SIZE and any(keyword in name.lower() for keyword in NEEDLE):
                Msg(f"[Utils] {name} ({size / 1024**3:.1f} GB): https://webshare.cz/file/{ident}")

        offset += limit
        
def utilities():
    options = [
        "1. Prozkoumat WS",
        "2. Smazat nalezené",
        "3. Smazat celou historii hledání"
    ]
    choice = xbmcgui.Dialog().select("Vyber akci", options)

    if choice == 0:
        find()
    elif choice == 1:
        clear_db()
    elif choice == 2:
        clear_history()
    else:
        Msg("[Filler] Akce zrušena uživatelem.")
        
        
