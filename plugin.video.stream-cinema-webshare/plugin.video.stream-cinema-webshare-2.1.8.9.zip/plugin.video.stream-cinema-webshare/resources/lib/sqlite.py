import os
import sys
import sqlite3
import xbmcvfs
import requests
import xbmc
import xbmcgui
import xbmcaddon
import unicodedata
import re
from resources.lib.logger import Msg, Info

addon_lib_path = os.path.abspath(os.path.dirname(__file__))
if addon_lib_path not in sys.path:
    sys.path.insert(0, addon_lib_path)
try:
    from fuzzywuzzy import fuzz
except ImportError as e:
    xbmcgui.Dialog().notification("Chyba", "Nepodařilo se importovat fuzzywuzzy!", xbmcgui.NOTIFICATION_ERROR, 5000)
    xbmc.log("Import fuzzywuzzy selhal: {}".format(e), xbmc.LOGERROR)

addon = xbmcaddon.Addon()

ADDON_DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.stream-cinema-webshare")
DB_VIDEOS = os.path.join(ADDON_DATA_DIR, "videos.db")
DB_CONTINUE = os.path.join(ADDON_DATA_DIR, "continue.db")

if not xbmcvfs.exists(ADDON_DATA_DIR):
    xbmcvfs.mkdirs(ADDON_DATA_DIR)
threshold = int(addon.getSetting("fuzz_threshold"))

TMDB_API_KEY = "3c6301e382a803d9c9b52adad044a45a"
TMDB_API_URL = "https://api.themoviedb.org/3"

def init_db(): #pro hledání filmů a novinek
    conn = sqlite3.connect(DB_VIDEOS)
    cur = conn.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS videos (
            ident TEXT PRIMARY KEY,
            title TEXT,
            size INTEGER,
            tmdb_id INTEGER,
            year INTEGER,
            overview TEXT,
            rating REAL,
            poster_url TEXT,
            runtime INTEGER,
            genre TEXT
        )
    ''')

    conn.commit()
    conn.close()

def insert_video(ident, title, size, tmdb_id=None, year=None, overview=None, rating=None, poster_url=None, runtime=None, genre=None):
    conn = sqlite3.connect(DB_VIDEOS)
    cur = conn.cursor()
    if tmdb_id is not None:
        cur.execute('''
            REPLACE INTO videos 
            (ident, title, size, tmdb_id, year, overview, rating, poster_url, runtime, genre)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (ident, title, size, tmdb_id, year, overview, rating, poster_url, runtime, genre))
    else:
        cur.execute('''
            REPLACE INTO videos (ident, title, size) VALUES (?, ?, ?)
        ''', (ident, title, size))
    conn.commit()
    conn.close()

def get_all_videos():
    conn = sqlite3.connect(DB_VIDEOS)
    cur = conn.cursor()
    cur.execute('SELECT ident, title, size, tmdb_id, year, overview, rating, poster_url, runtime, genre FROM videos')
    rows = cur.fetchall()
    conn.close()
    return rows


def normalize(text):
    text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('ascii')
    text = text.lower()
    text = re.sub(r'[^a-z0-9 ]+', ' ', text)
    return re.sub(r'\s+', ' ', text).strip()

def search_tmdb(title, year=None):
    Msg(f"[TMDb] Titul: '{title}' rok: {year}")

    params = {
        "api_key": TMDB_API_KEY,
        "query": title,
        "language": "cs-CZ",
        "include_adult": False,
        "page": 1
    }

    if year:
        params["year"] = year

    headers = {
        "accept": "application/json"
    }

    r = requests.get(f"{TMDB_API_URL}/search/movie", params=params, headers=headers, timeout=10)
    r.raise_for_status()
    data = r.json()
    media_type = "movie"

    if not data.get("results"):
        r = requests.get(f"{TMDB_API_URL}/search/tv", params=params, headers=headers, timeout=10)
        r.raise_for_status()
        data = r.json()
        media_type = "tv"

    results = data.get("results", [])

    if addon.getSetting("debug") == "true":
        Msg(f"[TMDb] Data: {data}")
        Msg(f"[TMDb] Celkem výsledků: {len(results)}")

    # 3. Vypiš skóre pro každý výsledek
    scored = []
    norm_title = normalize(title)

    for result in results:
        name = result.get("title") or result.get("name")
        norm_name = normalize(name)
        score = fuzz.token_set_ratio(norm_title, norm_name)
        if score < threshold:
            if addon.getSetting("debug") == "true":
                Msg(f"[TMDb] '{norm_name}' vs '{norm_title}' → skóre: {score} (nevyhovuje)")
                continue
        Msg(f"[TMDb] Kandidát: '{name}' - Skóre: {score}")
        scored.append((score, result))
    
    if not scored:
        Msg(f"[TMDb] Nenalezen žádný výsledek pro '{title}'\n")
        return {}

    scored.sort(reverse=True)
    best_score, item = scored[0]
    tmdb_id = item.get("id")

    title = item.get("title") if media_type == "movie" else item.get("name")
    release = item.get("release_date") if media_type == "movie" else item.get("first_air_date")

    Msg(f"[TMDb] Nalezeno '{title}' jako {media_type.upper()}, TMDb ID {tmdb_id}")

    # Detailní dotaz
    detail_url = f"{TMDB_API_URL}/{media_type}/{tmdb_id}"
    detail_params = {
        "api_key": TMDB_API_KEY,
        "language": "cs-CZ"
    }
    detail_response = requests.get(detail_url, params=detail_params, headers=headers, timeout=10)
    detail_data = detail_response.json()

    if addon.getSetting("debug") == "true":
        Msg(f"[TMDb] Detail_data: '{detail_data}'\n")

    genres = detail_data.get("genres", [])
    genre_list = [g["name"] for g in genres if "name" in g]

    return {
        "tmdb_id": tmdb_id,
        "title": title,
        "year": int(release[:4]) if release else None,
        "overview": item.get("overview"),
        "rating": item.get("vote_average"),
        "poster_url": f"https://image.tmdb.org/t/p/w500{item['poster_path']}" if item.get("poster_path") else None,
        "runtime": (
            detail_data.get("runtime") if media_type == "movie"
            else detail_data.get("episode_run_time", [None])[0]
        ),
        "genre": genre_list
    }

def init_continue_watching_db():
    DB_VIDEOS = os.path.abspath(DB_CONTINUE)
    xbmc.log(f"[DEBUG] Vytvářím continue_watching v: {DB_VIDEOS}", level=xbmc.LOGINFO)

    conn = sqlite3.connect(DB_CONTINUE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS continue_watching (
            movie_id TEXT PRIMARY KEY,
            stream_id TEXT,
            season INTEGER,
            episode INTEGER,
            last_position INTEGER,
            finished INTEGER DEFAULT 0,
            last_played TEXT
        )
    ''')
    conn.commit()
    conn.close()

def save_continue_watching(movie_id, stream_id, media_path, season=None, episode=None, last_position=0, finished=0):
    import datetime
    conn = sqlite3.connect(DB_CONTINUE)
    cursor = conn.cursor()
    last_played = datetime.datetime.utcnow().isoformat()

    cursor.execute('''
    INSERT OR REPLACE INTO continue_watching
    (movie_id, stream_id, media_path, season, episode, last_position, finished, last_played)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (movie_id, stream_id, media_path, season, episode, last_position, finished, last_played))

    conn.commit()
    conn.close()


