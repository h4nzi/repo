
import sys
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import xbmcvfs
import requests
import time
import re
import unicodedata
import os
import xml.etree.ElementTree as ET
import sys
import json
from urllib.parse import unquote_plus, quote_plus, urlparse, parse_qs
from resources.lib.login import login, api
from resources.lib.sqlite import init_db, insert_video, search_tmdb
from resources.lib.utils import clear_db
from resources.lib.logger import Msg, Info

addon_lib_path = os.path.abspath(os.path.dirname(__file__))

if addon_lib_path not in sys.path:
    sys.path.insert(0, addon_lib_path)

try:
    from fuzzywuzzy import fuzz, process
except ImportError as e:
    xbmcgui.Dialog().notification("Chyba", "Nepodařilo se importovat fuzzywuzzy!", xbmcgui.NOTIFICATION_ERROR, 5000)
    xbmc.log("Import fuzzywuzzy selhal: {}".format(e), xbmc.LOGERROR)


addon = xbmcaddon.Addon()
profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
history_path = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.stream-cinema-webshare/search_history.json")

limit = int(addon.getSetting("page_limit"))
MinSize = float(addon.getSetting("min"))
MinSizeNews = float(addon.getSetting("min_news"))
ShowSize = addon.getSetting("show_size") == "true"
threshold = int(addon.getSetting("fuzz_threshold"))

NewsLimit = int(addon.getSetting("news_limit"))

category = addon.getSetting('scategory')
sort = addon.getSetting('ssort')
sort_news = addon.getSetting('ssort_news')

MAX_TMDB_FETCH = int(addon.getSetting("sfetch"))
MAX_NEWS_FETCH = int(addon.getSetting("sfetch_news"))
        
def auto_search_by_name(_handle, limit=60):
    Msg(f"[AutoSearch] Hledám alternativy")
    time.sleep(0.5)

    try:
        plugin_url = sys.argv[0] + '?' + sys.argv[2][1:]
        query = urlparse(plugin_url).query
        params = parse_qs(query)
        name = unquote_plus(params.get("name", [""])[0])

        if not name:
            Msg("[AutoSearch] Název nebyl nalezen.")
            return

        Msg(f"[AutoSearch] Hledám alternativy pro: {name}")

        token = login()
        data = {
            "what": name,
            "limit": limit,
            "offset": 0,
            "category": "video",
            "wst": token
        }

        response = api("search", data)
        response.raise_for_status()
        xml = ET.fromstring(response.text)

        options = []
        idents = []

        files = xml.findall('file')
        files.sort(key=lambda f: int(f.findtext("size", "0")), reverse=True)

        for file in files:
            fname = file.findtext("name", "Neznámý")
            fid = file.findtext("ident", "")
            fsize = int(file.findtext("size", "0"))
            size_gb = round(fsize / (1024**3), 2)
            label = f"{fname} ({size_gb} GB)"
            options.append(label)
            idents.append((fname, fid))

        if not options:
            xbmcgui.Dialog().notification("AutoSearch", "Nenalezeny žádné alternativy.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        choice = xbmcgui.Dialog().select("Vyber alternativu", options)

        if choice >= 0:
            fname, fid = idents[choice]
            url = f"plugin://plugin.video.stream-cinema-webshare/?action=play&ident={fid}&name={quote_plus(fname)}"
            Msg(f"[AutoSearch] Spouštím alternativu: {fname}")
            xbmc.executebuiltin(f'PlayMedia({url})')

    except Exception as e:
        Msg(f"[AutoSearch] Chyba: {e}")

def get_news():
    news_items = []
    min_size = MinSizeNews * 1024**3
    init_db()
    token = login()
    offset = 0
    news_fetch_count = 0

    try:
        while True:
            data = {
                "what": " dab 2025 mkv",
                "sort": sort_news,
                "limit": NewsLimit,
                "offset": offset,
                "category": "video",
                "wst": token
            }

            if addon.getSetting("debug") == "true":
                Msg(f"[Search]Data (novinky): {data}")

            response = api("search", data)
            response.raise_for_status()

            root = ET.fromstring(response.text)
            files = root.findall("file")
            if not files:
                break

            for file in files:
                try:
                    name = file.findtext("name", "Neznámý")
                    ident = file.findtext("ident", "")
                    size = int(file.findtext("size", "0"))
                    date = file.findtext("upload_date", "")
                    if addon.getSetting("debug") == "true":
                        Msg(f"[Search]Size (novinky): {round(size / (1024**3), 2)}GB")
                        Msg(f"[Search]Limit (novinky): {NewsLimit}")

                    if size >= min_size:

                        cleaned_name, year = clean_title(name)
                        tmdb_data = search_tmdb(cleaned_name, year=year)
                        if tmdb_data and tmdb_data.get("title"):
                            if news_fetch_count >= MAX_NEWS_FETCH:
                                Msg(f"[Search]Překročen limit {MAX_NEWS_FETCH} záznamů, ukončuji zpracování\n")
                                Info(f"Novinky načteny", sound=True)
                                return news_items
                            news_fetch_count += 1
                            Msg(f"[Search]Count {news_fetch_count} záznamů\n")

                            news_items.append({
                                "title": (f"[{round(size / (1024**3), 2)} GB] " if ShowSize else "") + (tmdb_data.get("title") or ""),
                                "ident": ident,
                                "overview": tmdb_data.get("overview", ""),
                                "poster_url": tmdb_data.get("poster_url", ""),
                                "date": date,
                                "year": tmdb_data.get("year"),
                                "rating": tmdb_data.get("rating"),
                                "runtime": tmdb_data.get("runtime"),
                                "genre": tmdb_data.get("genre")
                            })
                        else:
                            Msg(f"[Search]Chybí TMDB data: {name}\n")

                except Exception as e:
                    Msg(f"[Search]Chyba při zpracování novinky: {e}")

            offset += NewsLimit
            

            time.sleep(0.5)

    except Exception as e:
        Msg(f"[Search]Chyba při načítání novinek: {e}")

    return news_items

def clean_title(title):
    # demo: The.Ghost.Of.An.Andromeda.2023.UHD.1080p.BluRay.x264.CZ.mkv
    # Krok 1: Odstranění přípony
    title = re.sub(r'\.\w{2,4}$', '', title)
    # The.Ghost.Of.An.Andromeda.2023.UHD.1080p.BluRay.x264.CZ

    # Krok 2: Najdi rok v textu
    year_match = re.search(r'\b(19\d{2}|20\d{2})\b', title)
    year = year_match.group(0) if year_match else None
    # year = "2023"

    # Krok 3: Pokud se rok nenachází na začátku, usekni string na rok
    if year:
        if not title.startswith(year):
            title = title.split(year)[0]
        else:
            year = None
    # Výsledek: "The.Ghost.Of.An.Andromeda."

    # Krok 4: Nahraď tečky, pomlčky, podtržítka mezerami
    title = re.sub(r'[._\-]+', ' ', title)
    # Výsledek: "The Ghost Of An Andromeda "

    # Krok 5: Odstraň běžné tagy (rozlišení, jazyk, formáty apod.)
    title = re.sub(
        r'\b(uhd|1080p|720p|bluray|dvdrip|x264|web[-]?dl|cz|eng|vykonavatel|s\d{2}e\d{2})\b',
        '', title, flags=re.I)
    # Výsledek: "The Ghost Of An Andromeda "

    # Krok 6: Odstraň vícenásobné mezery a ořízni okraje
    title = re.sub(r'\s+', ' ', title).strip()
    # Výsledek: "The Ghost Of An Andromeda"

    # Krok 7: Odstraň stop slova jako 'of', 'the', 'an', 'and', 'ghost'
    stop_words = {'of', 'the', 'an', 'and', 'ghost'}
    parts = [w for w in title.split() if w.lower() not in stop_words]
    # Výsledek: ["Andromeda"]

    # Krok 8: Omez název na maximálně 4 slova
    if len(parts) > 4:
        parts = parts[:4]

    # Krok 9: Spoj zpět do jednoho názvu
    title = ' '.join(parts)
    # Výsledek: "Andromeda"

    return title, year

def ask(default=""):
    return xbmcgui.Dialog().input("Zadejte hledaný výraz:", defaultt=default)

def save_search_query(query):
    if not query:
        return

    xbmcvfs.mkdirs(profile_path)

    history = []
    if xbmcvfs.exists(history_path):
        try:
            with xbmcvfs.File(history_path, 'r') as f:
                content = f.read()
                if content:
                    history = json.loads(content)
        except Exception:
            history = []
    if query not in history:
        history.insert(0, query)  # přidá na začátek

    history = history[:20]

    with xbmcvfs.File(history_path, 'w') as f:
        f.write(json.dumps(history, ensure_ascii=False, indent=2))

def list_history():
    handle = int(sys.argv[1])
    if not xbmcvfs.exists(history_path):
        Info("Žádná historie hledání.")
        xbmcplugin.endOfDirectory(handle)
        return

    with open(history_path, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()]
        lines = list(dict.fromkeys(reversed(lines)))

    for query in lines[:30]:
        url = f"{sys.argv[0]}?action=search&query={quote_plus(query)}"
        li = xbmcgui.ListItem(label=query)
        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(query)
        info_tag.setMediaType('video')

        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

    clear_url = f"{sys.argv[0]}?action=clear_history"
    li = xbmcgui.ListItem(label="[Smazat historii]")
    li.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle, clear_url, li, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

def search_videos():
    query = ask("")
    if query:
        search_query(query, interactive=False)
    else:
        Msg("Nebyl zadán žádný hledaný výraz.")

def normalize(text):
    text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode()
    text = text.lower()
    # Nahradíme vše, co není písmeno nebo číslo, mezerou (tedy odstraníme i podtržítka)
    text = re.sub(r'[^a-z0-9\s]', ' ', text)
    return text.split()

def search_query(query, interactive=True):
    original_query = query

    if interactive:
        new_query = xbmcgui.Dialog().input("Zadejte hledaný výraz:", defaultt=query)
        if not new_query:
            Msg("Hledání bylo zrušeno uživatelem.")
            return
        query = new_query
        original_query = query

        resolution = {
            "Bez filtru": "",
            "4K (2160p)": "2160p|4k",
            "1080p": "1080p",
            "720p": "720p",
            "2020-2025":"2020-2025"
        }

        index = xbmcgui.Dialog().select("Vyberte rozlišení (volitelné):", list(resolution.keys()))
        extra = resolution[list(resolution.keys())[index]] if index >= 0 else ""

        if extra:
            query += " " + extra

    save_search_query(original_query)

    min_size = MinSize * 1024**3
    init_db()
    clear_db()
    token = login()
    Msg(f"[Search]\n\nHledám soubory s výrazem: {query}\n")
    Info(f"Hledám soubory {query}.")

    offset = 0
    all_files = []
    tmdb_fetch_count = 0
    query_str = query.lower()
    threshold = float(addon.getSetting("fuzz_threshold"))

    while True:
        data = {
            "what": query,
            "sort": sort,
            "limit": limit,
            "offset": offset,
            "category": category,
            "wst": token
        }
        if addon.getSetting("debug") == "true":
            Msg(f"[Search]Data: {data}")

        try:
            response = api("search", data)
            response.raise_for_status()

            xml = ET.fromstring(response.text)
            files = xml.findall('file')
            files = [f for f in files if isinstance(f, ET.Element) and f.findtext("size", "").isdigit()]
            files.sort(key=lambda f: int(f.findtext("size", "0")), reverse=True)

            if not files:
                Msg(f"[Search]Nalezeno jen {len(all_files)} z {MAX_TMDB_FETCH} videí.")
                Info(f"Nalezeno jen {len(all_files)} z {MAX_TMDB_FETCH} videí.", sound=True)
                break

            for file in files:
                try:
                    name = file.findtext("name", "Neznámý")
                    ident = file.findtext("ident", "")
                    size = int(file.findtext("size", "0"))
                    date = file.findtext("upload_date", "")

                    if size >= min_size:
                        score = fuzz.token_set_ratio(query_str, name)

                        if score < threshold:
                            #if addon.getSetting("debug") == "true":
                            Msg(f"[Fuzzy] '{query_str}' vs '{name}' → skóre: {score} (nevyhovuje)")
                            continue

                        if addon.getSetting("debug") == "true":
                            Msg(f"[Search]RAW soubor: {name}, ident: {ident}, velikost: {size}")

                        cleaned_name, year = clean_title(name)
                        if addon.getSetting("debug") == "true":
                            Msg(f"[Search]Čistím název '{name}' na '{cleaned_name}', rok: {year}")

                        tmdb_data = search_tmdb(cleaned_name, year=year)

                        if tmdb_fetch_count >= MAX_TMDB_FETCH:
                            Msg(f"[Search]Celkem nalezeno a uloženo: {len(all_files)} souborů.")
                            Info(f"Celkem nalezeno a uloženo {len(all_files)} nových videí.", sound=True)
                            Msg(f"[Search]Překročen limit {MAX_TMDB_FETCH} záznamů, ukončuji zpracování\n")
                            return

                        tmdb_fetch_count += 1
                        Msg(f"[Search]Count {tmdb_fetch_count} záznamů\n")
                        
                        genre = tmdb_data.get("genre")
                        if isinstance(genre, list):
                            genre = ", ".join(genre)
                        elif genre is None:
                            genre = ""

                        insert_video(
                            ident,
                            (f"[{round(size / (1024**3), 2)} GB] " if ShowSize else "") + (tmdb_data.get("title") or name or "Neznámý název"),
                            size,
                            tmdb_data.get("tmdb_id"),
                            tmdb_data.get("year"),
                            tmdb_data.get("overview", ""),
                            tmdb_data.get("rating"),
                            tmdb_data.get("poster_url", ""),
                            tmdb_data.get("runtime"),
                            genre
                        )

                        all_files.append((name, ident))
                except Exception as e:
                    Msg(f"[Search]Chyba při zpracování položky '{name}': {e}")

            offset += limit
            time.sleep(0.5)

        except Exception as e:
            Msg(f"[Search]Chyba při volání API: {e}")
            break

    xbmc.executebuiltin("Container.Refresh")

