
import sqlite3
import os
import xbmcvfs
import requests
import xbmc
import xbmcgui
import xbmcaddon

addon = xbmcaddon.Addon()

ADDON_DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.stream-cinema-webshare")
DB_PATH = os.path.join(ADDON_DATA_DIR, "videos.db")

if not xbmcvfs.exists(ADDON_DATA_DIR):
    xbmcvfs.mkdirs(ADDON_DATA_DIR)

TMDB_API_KEY = "3c6301e382a803d9c9b52adad044a45a"
TMDB_API_URL = "https://api.themoviedb.org/3"

def Msg(message):
    xbmc.log("[Stream Cinema Webshare - DB] " + message, level=xbmc.LOGINFO)
    
def Info(message, heading=None, icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    if heading is None:
        heading = addon.getAddonInfo('name')
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS videos (
            ident TEXT PRIMARY KEY,
            title TEXT,
            size INTEGER,
            tmdb_id INTEGER,
            year INTEGER,
            overview TEXT,
            rating REAL,
            poster_url TEXT,
            runtime INTEGER,
            genre TEXT
        )
    ''')

    conn.commit()
    conn.close()

def insert_video(ident, title, size, tmdb_id=None, year=None, overview=None, rating=None, poster_url=None, runtime=None, genre=None):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    if tmdb_id is not None:
        cur.execute('''
            REPLACE INTO videos 
            (ident, title, size, tmdb_id, year, overview, rating, poster_url, runtime, genre)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (ident, title, size, tmdb_id, year, overview, rating, poster_url, runtime, genre))
    else:
        cur.execute('''
            REPLACE INTO videos (ident, title, size) VALUES (?, ?, ?)
        ''', (ident, title, size))
    conn.commit()
    conn.close()

def clear_db():
    Info("Mažu databázi", sound=True)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('DELETE FROM videos')
    conn.commit()
    conn.close()

def get_all_videos():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute('SELECT ident, title, size, tmdb_id, year, overview, rating, poster_url, runtime, genre FROM videos')
    rows = cur.fetchall()
    conn.close()
    return rows

def search_tmdb(title, year=None):
    Msg(f"[TMDb] Volám API pro titul: '{title}' rok: {year}")
    
    params = {
        "api_key": TMDB_API_KEY,
        "query": title,
        "language": "cs-CZ",
        "include_adult": False,
        "page": 1
    }

    # Pokud máme rok, přidáme ho do parametrů
    if year:
        params["year"] = year

    headers = {
        "accept": "application/json"
    }

    r = requests.get(f"{TMDB_API_URL}/search/movie", params=params, headers=headers, timeout=10)
    r.raise_for_status()
    data = r.json()
    Msg(f"[TMDb] Odpověď: {data}")
    
    if data.get("results"):
        movie = data["results"][0]
        tmdb_id = movie.get("id")
        Msg(f"[TMDb] Nalezeno '{movie}'")
        Msg(f"[TMDb] Nalezeno '{title}': TMDb ID {tmdb_id}")

        detail_url = f"{TMDB_API_URL}/movie/{tmdb_id}"
        detail_params = {
            "api_key": TMDB_API_KEY,
            "language": "cs-CZ"
        }
        detail_response = requests.get(detail_url, params=detail_params, headers=headers, timeout=10)
        detail_data = detail_response.json()
        Msg(f"[TMDb] Detail_data: '{detail_data}'\n")

        genres = detail_data.get("genres", [])
        genre_names = ", ".join([g["name"] for g in genres]) if genres else None

        return {
            "tmdb_id": tmdb_id,
            "title": movie.get("title"),
            "year": int(movie["release_date"][:4]) if movie.get("release_date") else None,
            "overview": movie.get("overview"),
            "rating": movie.get("vote_average"),
            "poster_url": f"https://image.tmdb.org/t/p/w500{movie['poster_path']}" if movie.get("poster_path") else None,
            "runtime": detail_data.get("runtime"),
            "genre": genre_names
        }
    else:
        Msg(f"[TMDb] Nenalezen žádný výsledek pro '{title}'\n")
        return {}

