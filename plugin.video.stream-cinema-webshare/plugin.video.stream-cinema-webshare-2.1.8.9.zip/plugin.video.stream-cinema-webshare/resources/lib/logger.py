# logger.py
import xbmc
import xbmcgui
import xbmcaddon

addon = xbmcaddon.Addon()

def Msg(message):
    xbmc.log("[Stream Cinema Webshare] " + message, level=xbmc.LOGINFO)

def Info(message, heading=addon.getAddonInfo('name'), icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)
