import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import uuid
import requests
import xml.etree.ElementTree as ET
from urllib.parse import urlencode
from resources.lib.login import login, revalidate, api, is_ok, HEADERS, REALM
#from resources.lib.search import auto_search_by_name
from urllib.parse import quote_plus
import threading
import time
import sqlite3
import datetime


addon = xbmcaddon.Addon()
_handle = int(sys.argv[1])
_session = requests.Session()
_session.headers.update(HEADERS)


def Info(message, heading=addon.getAddonInfo('name'), icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)
    
def Msg(message):
    xbmc.log("[Stream Cinema Webshare - Player] " + message, level=xbmc.LOGINFO)

def getlink(ident, wst, dtype='video_stream'):
    duuid = addon.getSetting('duuid')
    if not duuid:
        duuid = str(uuid.uuid4())
        addon.setSetting('duuid', duuid)
    data = {'ident': ident, 'wst': wst, 'download_type': dtype, 'device_uuid': duuid}

    response = api('file_link', data)
    xml = ET.fromstring(response.content)
    if is_ok(xml):
        return xml.find('link').text

DB_CONTINUE = "/storage/.kodi/userdata/addon_data/plugin.video.stream-cinema-webshare/continue.db"

_continue_watching_saver_running = False

def save_continue_watching(movie_id, stream_id, season=None, episode=None, last_position=0, finished=0):
    conn = sqlite3.connect(DB_CONTINUE)
    cursor = conn.cursor()

    cursor.execute('''
    INSERT OR REPLACE INTO continue_watching
    (movie_id, stream_id, season, episode, last_position, finished)
    VALUES (?, ?, ?, ?, ?, ?)
    ''', (movie_id, stream_id, season, episode, last_position, finished))
    conn.commit()
    conn.close()
    
# def save_continue_watching(movie_id, stream_id, season=None, episode=None, last_position=0, finished=0):
    # conn = sqlite3.connect(DB_CONTINUE)
    # cursor = conn.cursor()
    # last_played = datetime.datetime.utcnow().isoformat()

    # cursor.execute('''
    # INSERT OR REPLACE INTO continue_watching
    # (movie_id, stream_id, season, episode, last_position, finished, last_played)
    # VALUES (?, ?, ?, ?, ?, ?, ?)
    # ''', (movie_id, stream_id, season, episode, last_position, finished, last_played))

    # conn.commit()
    # conn.close()

# def start_continue_watching_saver(movie_id, stream_id, season=None, episode=None, interval=10):
    # global _continue_watching_saver_running
    # if _continue_watching_saver_running:
        # return
    # _continue_watching_saver_running = True

    # def saver_loop():
        # player = xbmc.Player()
        # while _continue_watching_saver_running and player.isPlaying():
            # pos = player.getTime()
            # save_continue_watching(movie_id, stream_id, season, episode, last_position=pos, finished=0)
            # time.sleep(interval)
        # # Po skončení přehrávání označit jako dokončené
        # save_continue_watching(movie_id, stream_id, season, episode, last_position=0, finished=1)

    # thread = threading.Thread(target=saver_loop)
    # thread.daemon = True
    # thread.start()

def stop_continue_watching_saver():
    global _continue_watching_saver_running
    _continue_watching_saver_running = False

def play(params):
    Msg(f"Spouštím přehrání, ident={params.get('ident')}, name={params.get('name')}, movie_id={params.get('movie_id')}")
    token = revalidate()

    try:
        api('clear_history', {'wst': token})
    except Exception as e:
        Msg(f"Zkontrolujte historii WS: {e}")

    link = getlink(params['ident'], token)

    if not link:
        search_url = (
            f'plugin://plugin.video.stream-cinema-webshare/?action=autosearch'
            f'&name={quote_plus(params.get("name", ""))}'
        )
        xbmc.executebuiltin(f'RunPlugin("{search_url}")')
        return

    Msg(f"Link: {link}")

    if link.startswith("http"):
        headers = _session.headers.copy()
        headers.update({'Cookie': 'wst=' + token})
        link = link + '|' + urlencode(headers)
        Msg(f"Link1: {link}")

        # Ulož start videa do DB s pozicí 0, finished=0
        save_continue_watching(
            movie_id=params.get('movie_id'),
            stream_id=params.get('stream_id'),
            season=params.get('season'),
            episode=params.get('episode'),
            last_position=0,
            finished=0
        )
        # Spusť průběžné ukládání pozice
        # start_continue_watching_saver(
            # movie_id=params.get('movie_id'),
            # stream_id=params.get('stream_id'),
            # season=params.get('season'),
            # episode=params.get('episode'),
            # interval=10
        # )

        listitem = xbmcgui.ListItem(label=params['name'], path=link)
        listitem.setMimeType('video/x-matroska')
        xbmcplugin.setResolvedUrl(_handle, True, listitem)

        


