import os
import sqlite3
import requests
import xbmcaddon
import xbmcgui
import xbmcvfs
import time
from resources.lib.logger import Msg, Info

addon = xbmcaddon.Addon()
folder_path = addon.getSetting("folder_path")
db_path = xbmcvfs.translatePath(folder_path)
DB_MOVIES = os.path.join(db_path, 'movies.sqlite')
DB_TVSHOWS = os.path.join(db_path, 'tvshows.sqlite')
TMDB_API_KEY = "3c6301e382a803d9c9b52adad044a45a"
TMDB_API_URL = "https://api.themoviedb.org/3"

def search_tmdb(title):
    url = f"{TMDB_API_URL}/search/movie"
    params = {
        "api_key": TMDB_API_KEY,
        "query": title,
        "language": "en-US",
        "include_adult": True
    }
    response = requests.get(url, params=params)
    if response.status_code == 200:
        results = response.json().get("results", [])
        if results:
            return results[0]["id"]
    return None

def update_missing_tmdb_ids():
    Msg("[Filler] Spouštím hledání TMDB ID")
    Info("Spouštím hledání TMDB ID", sound=True)
    conn = sqlite3.connect(DB_MOVIES)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT rowid, Title, OriginalTitle, TMDB_ID FROM Movies
        WHERE TMDB_ID IS NULL OR TMDB_ID = ''
    """)
    movies = cursor.fetchall()

    count = 0
    for index, row in enumerate(movies, start=1):
        rowid, title, original_title, tmdb_id = row
        search_title = (
            original_title.removesuffix(';;')
            if original_title and original_title.strip() != ""
            else title.removesuffix(';;')
        )

        if addon.getSetting("debug") == "true":
            Msg(f"Hledám TMDB ID pro: {search_title}")

        found_tmdb_id = search_tmdb(search_title)
        if found_tmdb_id:
            Msg(f" - Nalezeno TMDB ID: {found_tmdb_id}")
            cursor.execute("""
                UPDATE Movies SET TMDB_ID = ? WHERE rowid = ?
            """, (str(found_tmdb_id), rowid))
            count += 1

            if count % 100 == 0:
                conn.commit()
                Msg(f" -- Průběžné uložení po {count} aktualizacích")
        else:
            Msg(f" - Nenalezeno TMDB ID pro: {search_title}")

    conn.commit()
    conn.close()
    Msg(f"[Filler] Aktualizace TMDB ID dokončena. Počet doplněných položek: {count}")
    Info(f"Aktualizace TMDB ID dokončena. Počet doplněných položek: {count}", sound=True)

def update_czech_titles_from_tmdb():
    Msg("[Filler] Spouštím doplňování českých názvů")
    Info("Spouštím doplňování českých názvů", sound=True)
    conn = sqlite3.connect(DB_MOVIES)
    cursor = conn.cursor()
    MAX = 6000

    cursor.execute("""
        SELECT rowid, TMDB_ID FROM Movies
        WHERE TMDB_ID IS NOT NULL AND TMDB_ID != ''
          AND (CzTitle IS NULL OR CzTitle = '')
    """)

    movies = cursor.fetchall()

    count = 0
    for index, row in enumerate(movies, start=1):
        if count >= MAX:
            Msg(f"[Filler] Dosáhl limitu {MAX} dotazů, ukončuji.")
            break

        rowid, tmdb_id = row
        url = f"{TMDB_API_URL}/movie/{tmdb_id}"
        params = {
            "api_key": TMDB_API_KEY,
            "language": "cs-CZ"
        }

        response = requests.get(url, params=params)
        if response.status_code == 200:
            data = response.json()
            cz_title = data.get("title")
            if cz_title:
                cursor.execute("""
                    UPDATE Movies SET CzTitle = ? WHERE rowid = ?
                """, (cz_title, rowid))
                count += 1
                time.sleep(0.5)
                if addon.getSetting("debug") == "true":
                    Msg(f"[Filler] Doplněn český název: {cz_title} (TMDB_ID: {tmdb_id})")

                if count % 500 == 0:
                    conn.commit()
                    Msg(f"[Filler] Průběžné uložení po {count} aktualizacích")
            else:
                Msg(f"[Filler] Nenalezen český název pro TMDB_ID: {tmdb_id}")
        else:
            Msg(f"[Filler] Chyba při dotazu na TMDB_ID {tmdb_id}: HTTP {response.status_code}")

    conn.commit()
    conn.close()
    Msg(f"[Filler] Doplňování českých názvů dokončeno. Počet doplněných položek: {count}")
    Info(f"Doplňování českých názvů dokončeno. Počet doplněných položek: {count}", sound=True)

def update_czech_tvshow_titles_from_tmdb():
    Msg("[Filler] Spouštím doplňování českých názvů pro TV pořady")
    Info("Spouštím doplňování českých názvů pro TV pořady", sound=True)
    conn = sqlite3.connect(DB_TVSHOWS)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT rowid, TMDB_ID FROM TVShows
        WHERE TMDB_ID IS NOT NULL AND TMDB_ID != ''
    """)
    shows = cursor.fetchall()

    count = 0
    for index, row in enumerate(shows, start=1):
        rowid, tmdb_id = row
        url = f"{TMDB_API_URL}/tv/{tmdb_id}"
        params = {
            "api_key": TMDB_API_KEY,
            "language": "cs-CZ"
        }

        response = requests.get(url, params=params)
        if response.status_code == 200:
            data = response.json()
            cz_title = data.get("name")
            if cz_title:
                cursor.execute("""
                    UPDATE TVShows SET CzTitle = ? WHERE rowid = ?
                """, (cz_title, rowid))
                count += 1
                if addon.getSetting("debug") == "true":
                    Msg(f"[Filler] Doplněn český název: {cz_title} (TMDB_ID: {tmdb_id})")

                if count % 500 == 0:
                    conn.commit()
                    Msg(f"[Filler] Průběžné uložení po {count} aktualizacích")
            else:
                Msg(f"[Filler] Nenalezen český název pro TMDB_ID: {tmdb_id}")
        else:
            Msg(f"[Filler] Chyba při dotazu na TMDB_ID {tmdb_id}: HTTP {response.status_code}")

    conn.commit()
    conn.close()
    Msg(f"[Filler] Doplňování českých názvů dokončeno. Počet doplněných položek: {count}")
    Info(f"Doplňování českých názvů dokončeno. Počet doplněných položek: {count}", sound=True)

def db_fill():
    options = [
        "1. Doplnit chybějící TMDB ID",
        "2. Doplnit české názvy filmů (CzTitle)",
        "3. Doplnit české názvy seriálů (CzTitle)"
    ]
    choice = xbmcgui.Dialog().select("Vyber akci", options)

    if choice == 0:
        update_missing_tmdb_ids()
    elif choice == 1:
        update_czech_titles_from_tmdb()
    elif choice == 2:
        update_czech_tvshow_titles_from_tmdb()
    else:
        Msg("[Filler] Akce zrušena uživatelem.")
