import os
import re
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import difflib
import requests
import time
import random
import sqlite3
import xml.etree.ElementTree as ET

from resources.lib.logger import Msg, Info
from resources.lib.login import login, revalidate, api, is_ok, HEADERS, REALM

addon = xbmcaddon.Addon()

folder_path = addon.getSetting("folder_path")
db_path = xbmcvfs.translatePath(folder_path)
DB_MOVIES = os.path.join(db_path, 'movies.sqlite')
DB_TVSHOWS = os.path.join(db_path, 'tvshows.sqlite')

API_URL = 'https://webshare.cz/api/file_exists/'
HEADERS = {
    'Accept': 'text/xml; charset=UTF-8',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
}

def get_link(ident, token):
    device_uuid = addon.getSetting('duuid')
    data = {'ident': ident, 'wst': token, 'device_uuid': device_uuid}
    response = api('file_link', data)
    
    try:
        Msg(f"[get_link] Odpověď z API:\n{response.content.decode('utf-8')}")
        xml = ET.fromstring(response.content)
        status = xml.findtext("status")
        Msg(f"[get_link] Status: {status}")
        
        if is_ok(xml):
            link = xml.findtext('link')
            Msg(f"[get_link] VIP link: {link}")
            return link
        else:
            Msg(f"[get_link] API odpověď není OK. Status: {status}")
    except ET.ParseError as e:
        Msg(f"[get_link] Chyba při zpracování XML: {e}")
    
    return None

def get_file_info(ident, password=None, maybe_removed=None):
    data = {
        "ident": ident
    }
    if password:
        data["password"] = password
    if maybe_removed is not None:
        data["maybe_removed"] = maybe_removed

    try:
        response = api("file_info", data)
        #Msg(f"[Test]response: {response}")
        response.raise_for_status()
        #Msg(f"[Test]Response text:\n{response.text}")
        return response.text
        
    except Exception as e:
        Msg(f"[Test]Chyba při volání file_info API: {e}")
        return None
       
def test():
    revalidate()
    ident = "TEunbOfOTb"  # správný ident

    if addon.getSetting("debug") == "true":
        Msg(f"[Test]Získávám info o souboru : {ident}")

    token = login()
    if not token:
        Msg("[Test]Autentizace selhala.")
        Info("Autentizace selhala.", icon=xbmcgui.NOTIFICATION_ERROR)
        return

    info_xml = get_file_info(ident, token)
    Msg(f"[Test]Získávám info o souboru : {info_xml}")
    if not info_xml:
        Msg("[Test]Nepodařilo se získat info o souboru.")
        Info("Nepodařilo se získat info o souboru.", icon=xbmcgui.NOTIFICATION_ERROR)
        return
    root = ET.fromstring(info_xml)

    status = root.findtext("status")
    if status != "OK":
        message = root.findtext("message") or "Neznámá chyba"
        Msg(f"[Test]Chyba API: {message}")
        Info(f"Chyba API: {message}", icon=xbmcgui.NOTIFICATION_ERROR)
        return

    size = root.findtext("size")
    name = root.findtext("name")
    available = root.findtext("available")

    Msg(f"Název souboru: {name}")
    if size and size.isdigit():
        size_gb = round(int(size) / (1024*1024*1024), 2)
        Info(f"Velikost souboru: {size_gb} GB")
    else:
        Info("Velikost souboru není k dispozici.", icon=xbmcgui.NOTIFICATION_WARNING)

    if available == "1":
        link = get_link(ident, token)
        if link:
            Msg(f"[Test]VIP link: {link}")
            xbmc.executebuiltin(f'PlayMedia({link})')
        else:
            Info("Soubor je dočasně nedostupný. Zkuste to později.", icon=xbmcgui.NOTIFICATION_WARNING)
            Info("Soubor je dočasně nedostupný.", icon=xbmcgui.NOTIFICATION_ERROR)
    else:
        Msg("[Test]Soubor není dostupný.")
        Info("Soubor není dostupný.", icon=xbmcgui.NOTIFICATION_WARNING)

def search_files(min_size=0.5 * 1024**3, max_size=2 * 1024**3, extensions=["Zdivocela zeme S01E01"], limit=100):
    token = login()
    all_files = []

    for ext in extensions:
        Msg(f"[Test]Hledám soubory s příponou {ext}")
        data = {
            "what": ext,
            "limit": limit,
            "offset": 0,
            "category": "video",
            "wst": token
        }

        try:
            response = api("search", data)
            response.raise_for_status()
            xml = ET.fromstring(response.text)
            for file in xml.findall('file'):
                try:
                    name = file.findtext("name", "Neznámý")
                    ident = file.findtext("ident", "")
                    size = int(file.findtext("size", "0"))
                    if min_size <= size <= max_size:
                        Msg(f"Nalezený soubor: {name}, ident: {ident}, velikost: {size}")
                        all_files.append((name, ident, size))

                except Exception as e:
                    Msg(f"Chyba při zpracování položky: {e}")
        except Exception as e:
            Msg(f"[Test]Chyba při vyhledávání {ext}: {e}")

    names = [f[0] for f in all_files]
    groups = {}

    for name in names:
        matches = difflib.get_close_matches(name, names, n=10, cutoff=0.8)
        if len(matches) > 1:
            key = tuple(sorted(matches))
            groups[key] = groups.get(key, set()).union(matches)

    if groups:
        Msg("Nalezené možné seriály:")
        for group in groups.values():
            Msg(f"Skupina: {', '.join(group)}")
    else:
        Msg("Nebyly nalezeny žádné podobné názvy.")
    
    if not all_files:
        Info("Nebyly nalezeny žádné odpovídající soubory.", icon=xbmcgui.NOTIFICATION_WARNING)
       
def availability_test(ident):
    revalidate()
    token = login()
    if not token:
        Msg("[Test]Autentizace selhala při kontrolování dostupnosti.")
        return False

    info_xml = get_file_info(ident, token)
    if not info_xml:
        Msg(f"[TEST] info_xml není dostupné pro ident: {ident}")
        return False

    try:
        root = ET.fromstring(info_xml)
        status = root.findtext("status")
        available = root.findtext("available")
        if status == "OK" and available == "1":
            return True
        else:
            # Msg(f"Soubor nedostupný nebo status != OK ({status})")
            return False
    except Exception as e:
        Msg(f"[TEST] Chyba parsování XML pro ident {ident}: {e}")
        return False
        
def generate_object_id():
    timestamp = int(time.time())
    timestamp_hex = f'{timestamp:08x}'

    random_hex = ''.join(random.choices('0123456789abcdef', k=16))

    object_id = timestamp_hex + random_hex
    Msg(f"[TEST] Vygenerované ID {object_id}")
    Info(f"Vygenerované ID {object_id}", sound=True)
    return object_id

def validate_movies_idents_preview():
    MAX_CHECKS = 10000

    Info("Spouštím validaci Ident_ID")
    if not xbmcvfs.exists(DB_MOVIES):
        Msg(f"[Stream] Databáze nenalezena: {DB_MOVIES}")
        return

    conn = sqlite3.connect(DB_MOVIES)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT s.Movie_ID, m.CzTitle, s.Provider_Ident, s.DOWNLOAD_AVAILABLE
        FROM Streams s
        JOIN Movies m ON s.Movie_ID = m.Movie_ID
        WHERE s.DOWNLOAD_AVAILABLE IS NOT NULL AND s.DOWNLOAD_AVAILABLE != ''
    """)
    
    rows = cursor.fetchall()
    dead_idents = []
    valid = 0
    checked = 0

    for i, (movie_id, cz_title, provider_ident, url) in enumerate(rows):
        if i >= MAX_CHECKS:
            Msg(f"[Stream] Dosažen maximální počet dotazů: {MAX_CHECKS}")
            break
        if i % 1000 == 0:
            Msg(f"[Stream] Zpracováno {i} záznamů...")

        match = re.search(r'ident=([a-zA-Z0-9]+)', url)
        ident = match.group(1) if match else None
        if not ident:
            continue

        try:
            response = requests.post(API_URL, data={'ident': ident}, headers=HEADERS)
            exists = response.text.strip() == '1'
        except Exception as e:
            Msg(f"[Stream] Chyba při ověřování identu {ident}: {e}")
            exists = False

        checked += 1
        if exists:
            valid += 1
        else:
            Msg(f"[Stream] NEPLATNÝ ident: {ident} (Movie_ID: {movie_id}, Název: '{cz_title}')")
            dead_idents.append(ident)

        time.sleep(0.3)  # respekt k API

    conn.close()

    Msg(f"[Stream] Validace hotova. Ověřeno: {checked}, platné: {valid}, neplatné: {len(dead_idents)}")
    Info(f"Nalezeno {len(dead_idents)} neplatných záznamů", sound=True)
    
def validate_tvshows_idents_preview():
    MAX_CHECKS = 10000

    Info("Spouštím validaci Ident_ID pro seriály")
    if not xbmcvfs.exists(DB_TVSHOWS):
        Msg(f"[Stream] Databáze nenalezena: {DB_TVSHOWS}")
        return

    conn = sqlite3.connect(DB_TVSHOWS)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT t.TVShow_ID, t.CzTitle, s.Provider_Ident
        FROM Streams s
        JOIN Episodes e ON s.Episode_ID = e.Episode_ID
        JOIN Seasons se ON e.Season_ID = se.Season_ID
        JOIN TVShows t ON se.TVShow_ID = t.TVShow_ID
        WHERE s.Provider_Ident != ''
    """)

    rows = cursor.fetchall()
    dead_idents = []
    valid = 0
    checked = 0

    for i, (tvshow_id, cz_title, provider_ident) in enumerate(rows):
        if i >= MAX_CHECKS:
            Msg(f"[Stream] Dosažen maximální počet dotazů: {MAX_CHECKS}")
            break
        if i % 1000 == 0:
            Msg(f"[Stream] Zpracováno {i} záznamů...")

        match = re.search(r'ident=([a-zA-Z0-9]+)', provider_ident)
        ident = match.group(1) if match else None
        if not ident:
            continue

        try:
            response = requests.post(API_URL, data={'ident': ident}, headers=HEADERS)
            exists = response.text.strip() == '1'
        except Exception as e:
            Msg(f"[Stream] Chyba při ověřování identu {ident}: {e}")
            exists = False

        checked += 1
        if exists:
            valid += 1
        else:
            Msg(f"[Stream] NEPLATNÝ ident: {ident} (TVShow_ID: {tvshow_id}, Název: '{cz_title}')")
            dead_idents.append(ident)

        time.sleep(0.3)

    conn.close()

    Msg(f"[Stream] Validace hotova. Ověřeno: {checked}, platné: {valid}, neplatné: {len(dead_idents)}")
    Info(f"Nalezeno {len(dead_idents)} neplatných záznamů", sound=True)


    
       
def tests():
    options = [
        "1. Hledej soubory podle ident",
        "2. Hledej soubory podle řetězce",
        "3. Generátor ID řetězce",
        "4. Validace TMDb Ident_ID filmů",
        "5. Validace TMDb Ident_ID seriálů"
    ]
    choice = xbmcgui.Dialog().select("Vyber akci", options)
    if choice == 0:
        test()
    elif choice == 1:
        search_files()
    elif choice == 2:
        generate_object_id()
    elif choice == 3:
        validate_movies_idents_preview()
    elif choice == 4:
        validate_tvshows_idents_preview()
    else:
        Msg("[Filler] Akce zrušena uživatelem.")
        
# https://api.themoviedb.org/3/tv/10283/season/1/episode/12?api_key=3c6301e382a803d9c9b52adad044a45a&language=cs-CZ
# https://api.themoviedb.org/3/tv/66075/season/1?api_key=3c6301e382a803d9c9b52adad044a45a&language=cs-CZ

# https://api.themoviedb.org/3/movie/138034?api_key=3c6301e382a803d9c9b52adad044a45a&language=cs-CZ
# https://webshare.cz/file/YCbbySnkuQ 

