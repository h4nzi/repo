# importování metadat z TMDB na základě TMDB_ID
# dodělat! generovat metadata u názvu seriálu jen jednou -> nyní 10 epizod = 10 stejných dotazů
import os
import json
import time
import sqlite3
import requests
import xbmcaddon
import xbmcvfs
import xbmc
import xbmcgui
from resources.lib.logger import Msg, Info
from simplecache import SimpleCache
import datetime

addon = xbmcaddon.Addon()

# folder_path = addon.getSetting("folder_path")
# db_movies = os.path.join(folder_path, "movies.sqlite")
# db_tvshows = os.path.join(folder_path, "tvshows.sqlite")

# output_folder_movies = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.stream-cinema-webshare/strm_movies/")
# output_folder_tvshows = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.stream-cinema-webshare/strm_tvshows/")
TMDB_API_KEY = "3c6301e382a803d9c9b52adad044a45a"
TMDB_API_URL = "https://api.themoviedb.org/3"
TMDB_LANG = "cs-CZ"
MAX_TMDB_FETCH = int(addon.getSetting("sfetch"))
commit_interval = 100
cache = SimpleCache()

# vyzkoušet script.module.metadatautils

########################################################
##################      FILMY      ###################
########################################################
def fetch_tmdb_metadata(title, db_file):
    try:
        cache_key = f"tmdb_metadata_{title.strip().lower()}"
        cached = cache.get(cache_key)
        if cached:
            Msg(f"[Stream] Cache hit pro {title}")
            return cached

        movie_id = None

        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT TMDB_ID FROM Movies
            WHERE COALESCE(
                NULLIF(TRIM(CzTitle), ''),
                NULLIF(TRIM(OriginalTitle), ''),
                NULLIF(TRIM(Title), '')
            ) = ?
            LIMIT 1
        """, (title.strip(),))

        result = cursor.fetchone()
        conn.close()

        if result and result[0]:
            movie_id = result[0]
            Msg(f"[Stream] ID z DB: {movie_id}")

        if not movie_id:
            search_url = f"{TMDB_API_URL}/search/movie"
            Msg(f"[Stream] ID není v DB, hledám podle názvu v TMDB: {title}")

            search_params = {
                "api_key": TMDB_API_KEY,
                "query": title,
                "language": "cs-CZ"
            }

            search_response = requests.get(search_url, params=search_params)
            search_data = search_response.json()

            if search_data.get("results"):
                movie_id = search_data["results"][0]["id"]
                Msg(f"[Stream] TMDB nalezeno: {title} ID {movie_id}")
            else:
                Msg(f"[Stream] TMDB nenalezeno: {title}")
                return None

        details_url = f"{TMDB_API_URL}/movie/{movie_id}"
        details_params = {"api_key": TMDB_API_KEY, "language": "cs-CZ"}
        details_response = requests.get(details_url, params=details_params)

        if details_response.status_code != 200:
            Msg(f"[Stream] Chyba při načítání detailů z TMDB {details_url}")
            Msg(f"[Stream] Chyba při načítání detailů z TMDB")
            return None

        metadata = details_response.json()
        cache.set(cache_key, metadata, expiration=datetime.timedelta(days=14))  # např. 2 týdny
        Msg(f"[Stream] Metadata uložena do cache: {title}")

        return metadata

    except Exception as e:
        xbmc.log(f"Chyba při načítání z TMDB: {e}", xbmc.LOGWARNING)
        return None

########################################################
##################      SERIÁLY      ###################
########################################################
def fetch_tmdb_tv_data(tmdb_id):
    url_tv = f"https://api.themoviedb.org/3/tv/{tmdb_id}?api_key={TMDB_API_KEY}&language={TMDB_LANG}"
    try:
        response = requests.get(url_tv)
        if response.status_code == 200:
            data = response.json()
            if addon.getSetting("debug") == "true":
                Msg(f"[Metadata][DEBUG] TMDb data: {json.dumps(data, indent=2, ensure_ascii=False)}")
            return data
        else:
            Msg(f"[Metadata][TMDB-TV] Chyba HTTP {response.status_code} pro ID {tmdb_id}")
    except Exception as e:
        Msg(f"[Metadata][TMDB-TV] Výjimka: {e}")
    return {}

def fetch_tmdb_tv_metadata(title, db_file):
    try:
        cache_key = f"tmdb_tv_metadata_{title.strip().lower()}"
        cached = cache.get(cache_key)
        if cached:
            Msg(f"[TV] Cache hit pro {title}")
            return cached

        tv_id = None

        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT TMDB_ID FROM TVShows
            WHERE COALESCE(
                NULLIF(TRIM(CzTitle), ''),
                NULLIF(TRIM(Originaltitle), ''),
                NULLIF(TRIM(Alternativetitles), '')
            ) = ?
            LIMIT 1
        """, (title.strip(),))
        result = cursor.fetchone()
        conn.close()

        if result and result[0]:
            tv_id = result[0]
            Msg(f"[TV] TMDB_ID nalezeno v DB: {tv_id}")
        else:
            Msg(f"[TV] TMDB_ID nenalezeno v DB pro {title}")
            return None

        details_url = f"{TMDB_API_URL}/tv/{tv_id}"
        details_params = {
            "api_key": TMDB_API_KEY,
            "language": "cs-CZ"
        }
        details_response = requests.get(details_url, params=details_params)

        if details_response.status_code != 200:
            Msg(f"[TV] Chyba při načítání detailů z TMDB: {title} ({tv_id})")
            return None

        metadata = details_response.json()
        cache.set(cache_key, metadata, expiration=datetime.timedelta(days=14))
        Msg(f"[TV] Metadata uložena do cache: {title}")

        return metadata

    except Exception as e:
        xbmc.log(f"Chyba při načítání seriálových metadat z TMDB: {e}", xbmc.LOGWARNING)
        return None

def find_existing_folder_case_insensitive(base_path, target_name):
    try:
        target_name_lower = target_name.lower().replace(":", "").strip()
        for entry in os.scandir(base_path):
            if entry.is_dir():
                entry_name_lower = entry.name.lower().replace(":", " ").strip()
                #Msg(f"[Metadata][DEBUG] target_name_lower: '{target_name_lower}'")
                #Msg(f"[Metadata][DEBUG] entry_name_lower: '{entry_name_lower}'")

                if entry_name_lower == target_name_lower:
                    Msg(f"[Metadata][DEBUG] Shoda: '{entry.name}'")
                    #Msg(f"[Metadata][DEBUG] target_name_lower 1: '{target_name_lower}'")
                    #Msg(f"[Metadata][DEBUG] entry_name_lower 1: '{entry_name_lower}'")
                    return entry.path
    except Exception as e:
        Msg(f"[Metadata][Chyba při hledání složky] {e}")
    return None

def metadata_tvshows():
    Msg("Spouštím hledání metadat pro seriály")
    Info("Spouštím generování metadat pro seriály", sound=True)
    tmdb_fetch_count = 0

    output_folder_tvshows = xbmcvfs.translatePath(
        "special://userdata/addon_data/plugin.video.stream-cinema-webshare/strm_tvshows/"
    )
    if not xbmcvfs.exists(output_folder_tvshows):
        xbmcvfs.mkdirs(output_folder_tvshows)

    conn = sqlite3.connect(db_tvshows)
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT DISTINCT TMDB_ID,
               CASE
                 WHEN OriginalTitle IS NULL OR TRIM(OriginalTitle) = '' THEN AlternativeTitles
                 ELSE OriginalTitle
               END AS Title
        FROM TVshows
        WHERE TMDB_ID IS NOT NULL
          AND TRIM(TMDB_ID) != ''
    """)

    rows = cursor.fetchall()

    for tmdb_id, Title in rows:
        if tmdb_fetch_count >= MAX_TMDB_FETCH:
            Msg(f"[Metadata]Překročen limit {MAX_TMDB_FETCH} záznamů, ukončuji zpracování\n")
            break

        if addon.getSetting("debug") == "true":
            Msg(f"[Metadata][DEBUG] Zpracovávám TMDB_ID={tmdb_id}, název='{Title}'")

        raw_data = fetch_tmdb_tv_data(tmdb_id)
        if not raw_data:
            Msg(f"[Metadata]  ! Nenalezena data pro TMDB_ID={tmdb_id}")
            continue

        tmdb_fetch_count += 1
        if tmdb_fetch_count % commit_interval == 0:
             Msg(f"[Metadata]Count {tmdb_fetch_count} záznamů")

        data = {
            "tmdb_id": raw_data.get("id"),
            "title": raw_data.get("name"),
            "year": int(raw_data.get("first_air_date", "0000")[:4]) if raw_data.get("first_air_date") else 0,
            "plot": raw_data.get("overview"),
            "poster": f"https://image.tmdb.org/t/p/w500{raw_data['poster_path']}" if raw_data.get("poster_path") else None,
            "runtime": raw_data["episode_run_time"][0] * 60 if raw_data.get("episode_run_time") else 0,
            "rating": raw_data.get("vote_average"),
            "genres": [genre["name"] for genre in raw_data.get("genres", [])],
        }

        try:
            original_folder = find_existing_folder_case_insensitive(output_folder_tvshows, Title)
            if not original_folder:
                Msg(f"[Metadata][Upozornění] Adresář '{Title}' neexistuje, přeskočeno.")
                continue

            if addon.getSetting("debug") == "true":
                Msg(f"[Metadata][DEBUG] Hledaný název: '{Title}', nalezený adresář: '{original_folder}'")

            json_path = os.path.join(original_folder, "series.json")
            with open(json_path, "w", encoding="utf-8") as jf:
                json.dump(data, jf, ensure_ascii=False, indent=2)

            localized_name = data["title"]
            localized_folder = os.path.join(output_folder_tvshows, localized_name)

            if localized_name != Title and not xbmcvfs.exists(localized_folder):
                xbmcvfs.rename(original_folder, localized_folder)
                if addon.getSetting("debug") == "true":
                    Msg(f"[Metadata]Přejmenováno: '{Title}' → '{localized_name}'")

            time.sleep(0.5)

        except Exception as e:
            Msg(f"[Metadata][Chyba zápisu JSON / přejmenování] {Title} – {e}")

    Msg(f"[Metadata]Count {tmdb_fetch_count} záznamů\n")
    conn.close()
    Msg(f"[Metadata]Metadata doplněna pro {tmdb_fetch_count} seriálů.")
    Info("Metadata hotovo.", sound=True)

##################################################################
##################      DOPLNĚNÍ DATABÁZE      ###################
##################################################################
def get_episode_info(tmdb_id, season_num, episode_num):
    url = f"https://api.themoviedb.org/3/tv/{tmdb_id}/season/{season_num}/episode/{episode_num}"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANG
    }
    response = requests.get(url, params=params)
    if response.status_code == 200:
        data = response.json()
        episode_title = data.get("name", None)
        season_url = f"https://api.themoviedb.org/3/tv/{tmdb_id}/season/{season_num}"
        season_resp = requests.get(season_url, params=params)
        if season_resp.status_code == 200:
            season_data = season_resp.json()
            season_name = season_data.get("name", None)
        else:
            season_name = None
        return episode_title, season_name
    else:
        Msg(f"[Metadata]Chyba API: {response.status_code} pro TV show {tmdb_id}, sezónu {season_num}, epizodu {episode_num}")
        return None, None

def update_episodes_from_tmdb(limit=2000, delay=0.3):
    Msg("Spouštím doplnění DB pro seriály")
    Info("Spouštím doplnění DB pro seriály", sound=True)
    conn = sqlite3.connect(db_tvshows)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT TMDB_ID, Season_number, Episode_number FROM Live
        WHERE Episode_Originaltitle IS NULL OR Episode_Originaltitle = ''
    """)
    
    rows = cursor.fetchall()

    if limit is not None:
        rows = rows[:limit]

    for tmdb_id, season_num, episode_num in rows:
        if not tmdb_id or not season_num or not episode_num:
            Msg(f"[Metadata]Přeskakuji neúplný záznam: TMDB_ID={tmdb_id}, sezóna={season_num}, epizoda={episode_num}")
            continue
        if addon.getSetting("debug") == "true":
            Msg(f"[Metadata]Načítám info pro TMDB_ID={tmdb_id}, sezóna={season_num}, epizoda={episode_num} ...")
        episode_title, season_name = get_episode_info(tmdb_id, season_num, episode_num)

        if episode_title:
            cursor.execute("""
                            UPDATE Live
                            SET Episode_Originaltitle = ?, Season_name = ?
                            WHERE TMDB_ID = ? AND Season_number = ? AND Episode_number = ?
            """, (episode_title, season_name, tmdb_id, season_num, episode_num))

            if addon.getSetting("debug") == "true":
                Msg(f"[Metadata]Upraveno: Epizoda='{episode_title}', Sezóna='{season_name}'")
        else:
            Msg("Nenalezeny údaje o epizodě/sezóně.")
        time.sleep(delay)  # prodleva mezi dotazy

    conn.close()
    Msg("Hotovo!")
    Info("Hotovo", sound=True)
    
def search_tmdb_id_by_title(title):
    url = "https://api.themoviedb.org/3/search/tv"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANG,
        "query": title
    }
    response = requests.get(url, params=params)
    if response.status_code == 200:
        results = response.json().get("results", [])
        if results:
            return results[0].get("id")
    else:
        Msg(f"[Metadata]Chyba API při hledání názvu '{title}': {response.status_code}")
    return None

def update_missing_tmdb_ids(limit=2000, delay=0.3):
    Msg("Spouštím dohledání TMDB_ID pro záznamy bez ID")
    Info("Dohledávám TMDB_ID z názvů", sound=True)

    conn = sqlite3.connect(db_tvshows)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT rowid, Originaltitle, Alternativetitles FROM Live
        WHERE TMDB_ID IS NULL OR TMDB_ID = ''
    """)
    rows = cursor.fetchall()

    if limit is not None:
        rows = rows[:limit]

    for rowid, original_title, alt_titles in rows:
        if original_title:
            search_titles = [original_title]
        elif alt_titles:
            search_titles = alt_titles.split(";;")
        else:
            Msg(f"[Metadata]Chybí název u záznamu ID={rowid}, přeskakuji.")
            continue

        tmdb_id = None
        for title in search_titles:
            tmdb_id = search_tmdb_id_by_title(title.strip())
            if tmdb_id:
                break

        if tmdb_id:
            cursor.execute("""
                UPDATE Live SET TMDB_ID = ?
                WHERE rowid = ?
            """, (str(tmdb_id), rowid))
            if addon.getSetting("debug") == "true":
                Msg(f"[Metadata]Uloženo TMDB_ID={tmdb_id} pro název '{title}' (rowid={rowid})")
        else:
            Msg(f"[Metadata]Nenalezeno TMDB_ID pro žádný název (rowid={rowid})")

        time.sleep(delay)

    conn.close()
    Msg("Hotovo (TMDB_ID doplněna)!")
    Info("Dohledání ID dokončeno", sound=True)

    
# https://api.themoviedb.org/3/tv/10283/season/1/episode/12?api_key=3c6301e382a803d9c9b52adad044a45a&language=cs-CZ
# https://api.themoviedb.org/3/tv/66075/season/1?api_key=3c6301e382a803d9c9b52adad044a45a&language=cs-CZ
# https://api.themoviedb.org/3/movie/682810?api_key=3c6301e382a803d9c9b52adad044a45a&language=cs-CZ

#xxxxxxxxxxxxxxxxxx            SQL Query             xxxxxxxxxxxxxxxxxx
# Smazání tabulky:    DROP TABLE IF EXISTS Live;
# Počet unikátních záznamů:    SELECT COUNT(DISTINCT TVShow_ID) FROM TVShows;
# Počet neprázdných záznamů:    SELECT COUNT(TVShow_ID) FROM TVShows;
# Smazat v konkrétní tabulce knkrétní text:   DELETE FROM Streams WHERE DOWNLOAD_AVAILABLE LIKE '%//free%';
# Přidat sloupec do tabulky:    ALTER TABLE Movies ADD COLUMN CzTitle TEXT;


