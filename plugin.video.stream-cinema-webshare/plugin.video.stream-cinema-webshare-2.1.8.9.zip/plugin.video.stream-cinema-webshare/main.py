# default.py
import sys
import os
import urllib.parse
import xbmcaddon
import xbmcplugin
import xbmcgui
import xbmcvfs
import json
import requests
from urllib.parse import quote_plus, urlencode
import xml.etree.ElementTree as ET

import sqlite3
from urllib.parse import quote

# from resources.lib.repairer import repair
# from resources.lib.generator import LiveStreams_generate
from resources.lib.stream import generate_strm_movies,generate_strm_tvshows
from resources.lib.test import tests
from resources.lib.metadata import metadata_tvshows, fetch_tmdb_metadata, fetch_tmdb_tv_metadata
from resources.lib.metadata import update_episodes_from_tmdb, update_missing_tmdb_ids
from resources.lib.player import play
from resources.lib.search import search_videos, search_query, list_history, get_news
from resources.lib.sqlite import get_all_videos, init_continue_watching_db
from resources.lib.login import login, api, revalidate, check_vip_status
from resources.lib.utils import delete_history_item, clear_history, clear_db, utilities
from resources.lib.logger import Msg, Info
from resources.lib.filler import db_fill
from resources.lib.prefix_helper import show_letter_selector, show_prefix_menu, show_movies_by_prefix
from resources.lib.search import auto_search_by_name

addon = xbmcaddon.Addon()
_handle = int(sys.argv[1])
_base_url = sys.argv[0]

PageLimit = int(addon.getSetting("page_limit"))# počet položek na stránku

history_path = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.stream-cinema-webshare/search_history.json")
icons_dir = os.path.join(addon.getAddonInfo('path'), 'resources','skins','images','icons')
folder_path = addon.getSetting("folder_path")
db_path = xbmcvfs.translatePath(folder_path)
DB_MOVIES = os.path.join(db_path, 'movies.sqlite')
DB_TVSHOWS = os.path.join(db_path, 'tvshows.sqlite')
DB_CONTINUE = "/storage/.kodi/userdata/addon_data/plugin.video.stream-cinema-webshare/continue.db"


vip_days = check_vip_status()
init_continue_watching_db()

def get_url(**kwargs):
    url = _base_url + '?' + urllib.parse.urlencode(kwargs)
    if addon.getSetting("debug") == "true":
        Msg(f"[MAIN] Vygenerované URL: {url}")
    return url
 
def show_news():
    xbmcplugin.setContent(_handle, "videos")

    news_items = get_news()
    if not news_items:
        Info("Nepodařilo se načíst novinky.", icon=xbmcgui.NOTIFICATION_ERROR)
        return

    for data in news_items:
        listitem = xbmcgui.ListItem(label=data.get("title", "Neznámý titul"))
        listitem.setProperty('IsPlayable', 'true')

        info_tag = listitem.getVideoInfoTag()
        info_tag.setTitle(data.get("title", ""))
        info_tag.setPlot(data.get('overview', ''))
        info_tag.setMediaType("video")
        
        year = data.get("year")
        if year is not None:
            info_tag.setYear(int(year))
            
        rating = data.get("rating")
        if rating is not None:
            info_tag.setRating(float(rating))
            
        runtime = data.get("runtime")
        if runtime is not None:
            info_tag.setDuration(int(runtime))

        genres = data.get("genre", [])
        if isinstance(genres, str):
            genres = [genres]
        if isinstance(genres, list):
            info_tag.setGenres(genres)

        poster = data.get("poster_url")
        if poster:
            listitem.setArt({
                "thumb": poster,
                "fanart": poster,
                "icon": poster,
                "poster": poster
            })

        url = get_url(action="play", ident=data.get("ident"), name=data.get("title"))
        xbmcplugin.addDirectoryItem(handle=_handle, url=url, listitem=listitem, isFolder=False)

    xbmcplugin.endOfDirectory(_handle, cacheToDisc=False)
    
def show_movies(page=1, page_size=PageLimit):
    xbmcplugin.setPluginCategory(_handle, "Filmy")
    xbmcplugin.setContent(_handle, "movies")
    
    conn = sqlite3.connect(DB_MOVIES)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT m.Movie_ID,
               COALESCE(
                   NULLIF(TRIM(COALESCE(m.CzTitle, '')), ''),
                   NULLIF(TRIM(COALESCE(m.OriginalTitle, '')), ''),
                   NULLIF(TRIM(COALESCE(m.Title, '')), '')
               ) AS FinalTitle,
               s.Provider_Ident AS stream_url
        FROM Movies m
        JOIN Streams s ON s.Movie_ID = m.Movie_ID
        WHERE s.Provider_Ident != ''
        GROUP BY m.Movie_ID
        ORDER BY FinalTitle COLLATE NOCASE
        LIMIT ? OFFSET ?
    """, (page_size, (page - 1) * page_size))

    rows = cursor.fetchall()

    cursor.execute("""
        SELECT COUNT(DISTINCT m.Movie_ID)
        FROM Movies m
        JOIN Streams s ON s.Movie_ID = m.Movie_ID
        WHERE s.DOWNLOAD_AVAILABLE IS NOT NULL AND s.DOWNLOAD_AVAILABLE != ''
    """)
    total_items = cursor.fetchone()[0]
    conn.close()

    total_pages = (total_items + page_size - 1) // page_size

    if page > 1:
        prev_page_url = get_url(action="movies", page=page - 1)
        li = xbmcgui.ListItem(label="« Předchozí strana")
        li.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(_handle, prev_page_url, li, isFolder=True)

    for movie_id, title, stream_url in rows:
        li = xbmcgui.ListItem(label=title)
        li.setPath(stream_url)
        li.setProperty("IsPlayable", "true")

        metadata = fetch_tmdb_metadata(title, DB_MOVIES)
        if metadata:
            info_tag = li.getVideoInfoTag()
            info_tag.setTitle(metadata.get("title", title))
            info_tag.setPlot(metadata.get("overview", ""))
            release_date = metadata.get("release_date")
            if release_date:
                info_tag.setYear(int(release_date[:4]))
            info_tag.setRating(float(metadata.get("vote_average", 0.0)))
            info_tag.setDuration(int(metadata.get("runtime", 0)))
            info_tag.setMediaType("movie")

            genres = [g["name"] for g in metadata.get("genres", [])]
            if genres:
                info_tag.setGenres(genres)

            li.setProperty("title", title)
            li.setProperty("DBTYPE", "movie")

            poster_path = metadata.get("poster_path")
            if poster_path:
                full_url = f"https://image.tmdb.org/t/p/w500{poster_path}"
                li.setArt({
                    "poster": full_url,
                    "fanart": full_url,
                    "icon": full_url
                })
            else:
                li.setArt({
                    "icon": "DefaultVideo.png",
                    "poster": "DefaultVideo.png"
                })

        play_url = get_url(action="play", ident=stream_url, name=title, movie_id = movie_id)
        xbmcplugin.addDirectoryItem(_handle, play_url, li, isFolder=False)

    if page < total_pages:
        next_page_url = get_url(action="movies", page=page + 1)
        li = xbmcgui.ListItem(label="Další strana »")
        li.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(_handle, next_page_url, li, isFolder=True)

    xbmcplugin.endOfDirectory(_handle, updateListing=(page != 1), cacheToDisc=False)
  
def show_movies_by_letter(_handle, get_url, DB_MOVIES, prefix):
    xbmcplugin.setPluginCategory(_handle, f"Filmy – {prefix}")
    xbmcplugin.setContent(_handle, "movies")

    conn = sqlite3.connect(DB_MOVIES)
    cursor = conn.cursor()

    if prefix == "0-9":
        cursor.execute("""
            SELECT DISTINCT UPPER(SUBSTR(
                COALESCE(
                    NULLIF(TRIM(COALESCE(CzTitle, '')), ''),
                    NULLIF(TRIM(COALESCE(OriginalTitle, '')), ''),
                    NULLIF(TRIM(COALESCE(Title, '')), '')
                ), 1, 2)) AS prefix
            FROM Movies m
            JOIN Streams s ON s.Movie_ID = m.Movie_ID
            WHERE s.Provider_Ident IS NOT NULL AND s.Provider_Ident != ''
              AND prefix GLOB '[0-9]*'
            ORDER BY prefix
        """)
    elif prefix == "other":
        cursor.execute("""
            SELECT DISTINCT UPPER(SUBSTR(
                COALESCE(
                    NULLIF(TRIM(COALESCE(CzTitle, '')), ''),
                    NULLIF(TRIM(COALESCE(OriginalTitle, '')), ''),
                    NULLIF(TRIM(COALESCE(Title, '')), '')
                ), 1, 2)) AS prefix
            FROM Movies m
            JOIN Streams s ON s.Movie_ID = m.Movie_ID
            WHERE s.Provider_Ident IS NOT NULL AND s.Provider_Ident != ''
              AND prefix GLOB '[^A-Z0-9]*'
            ORDER BY prefix
        """)
    else:
        cursor.execute("""
            SELECT DISTINCT UPPER(SUBSTR(
                COALESCE(
                    NULLIF(TRIM(COALESCE(CzTitle, '')), ''),
                    NULLIF(TRIM(COALESCE(OriginalTitle, '')), ''),
                    NULLIF(TRIM(COALESCE(Title, '')), '')
                ), 1, 2)) AS prefix
            FROM Movies m
            JOIN Streams s ON s.Movie_ID = m.Movie_ID
            WHERE s.Provider_Ident IS NOT NULL AND s.Provider_Ident != ''
              AND prefix LIKE ?
            ORDER BY prefix
        """, (prefix + '%',))

    prefixes = cursor.fetchall()
    conn.close()

    for (prefix2,) in prefixes:
        li = xbmcgui.ListItem(label=prefix2)
        url = get_url(action="movies_by_prefix", prefix=prefix2)
        xbmcplugin.addDirectoryItem(_handle, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(_handle)

def show_tvshows(tvshow_id=None, season_id=None, page=1, page_size=PageLimit):
    if addon.getSetting("debug") == "true":
        Msg(f"[DEBUG] show_tvshows vstup: tvshow_id={tvshow_id}, season_id={season_id}, page={page}")
    conn = sqlite3.connect(DB_TVSHOWS)
    cursor = conn.cursor()
    
    if season_id:
        xbmcplugin.setPluginCategory(_handle, "Epizody")
        xbmcplugin.setContent(_handle, "tvshows")

        cursor.execute("""
            SELECT e.Episode_ID,
                   e.Episode_Number,
                   COALESCE(NULLIF(TRIM(e.Episode_Originaltitle), ''),
                            NULLIF(TRIM(e.Episode_Alternativetitles), '')) AS Title,
                   s.Provider_Ident
            FROM Episodes e
            LEFT JOIN Streams s ON s.Episode_ID = e.Episode_ID
            WHERE e.Season_ID = ?
              AND s.Provider_Ident IS NOT NULL AND s.Provider_Ident != ''
            ORDER BY CAST(Episode_Number AS INTEGER) ASC
        """, (season_id,))

        rows = cursor.fetchall()
        Msg(f"[DEBUG] Načteno {len(rows)} epizod pro Season_ID={season_id}")

        for episode_id, number, title, stream_url in rows:
            title = title.strip() if title else ""
            full_title = f"{number}. díl – {title}" if title else f"{number}. díl"

            li = xbmcgui.ListItem(label=full_title)
            li.setProperty("IsPlayable", "true")
            if stream_url:
                url = get_url(action="play", ident=stream_url, name=full_title)
            else:
                url = get_url(action="tvshows", season_id=season_id, tvshow_id=tvshow_id)  # fallback, nepřehraje nic
            if addon.getSetting("debug") == "true":
                Msg(f"[DEBUG] Vygenerované URL epizody: {url}")
            xbmcplugin.addDirectoryItem(_handle, url, li, isFolder=False)

    elif tvshow_id:
        xbmcplugin.setPluginCategory(_handle, "Sezóny")
        xbmcplugin.setContent(_handle, "tvshows")

        cursor.execute("""
            SELECT s.Season_ID,
                   s.Season_Number,
                   s.Season_Name
            FROM Seasons s
            WHERE s.TVShow_ID = ?
            ORDER BY CAST(Season_number AS INTEGER) ASC
        """, (tvshow_id,))

        rows = cursor.fetchall()
        Msg(f"[DEBUG] Načteno {len(rows)} sezón pro TVShow_ID={tvshow_id}")

        for season_id, number, name in rows:
            if name and name.strip():
                title = f"Sezóna {number} – {name.strip()}"
            else:
                title = f"Sezóna {number}"

            li = xbmcgui.ListItem(label=title)
            url = get_url(action="tvshows", tvshow_id=tvshow_id, season_id=season_id)
            if addon.getSetting("debug") == "true":
                Msg(f"[DEBUG] Vygenerované URL sezóny: {url}")
            xbmcplugin.addDirectoryItem(_handle, url, li, isFolder=True)

    else:
        xbmcplugin.setPluginCategory(_handle, "Seriály")
        xbmcplugin.setContent(_handle, "tvshows")

        cursor.execute("SELECT COUNT(*) FROM TVShows")
        total_items = cursor.fetchone()[0]
        total_pages = (total_items + page_size - 1) // page_size
        Msg(f"[MAIN] Celkem {total_items} seriálů, {total_pages} stran")

        if page > 1:
            prev_url = get_url(action="tvshows", page=page - 1)
            li = xbmcgui.ListItem(label="« Předchozí strana")
            li.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
            xbmcplugin.addDirectoryItem(_handle, prev_url, li, isFolder=True)
            if addon.getSetting("debug") == "true":
                Msg(f"[MAIN] Přidána předchozí strana: page={page - 1}")

        cursor.execute("""
            SELECT t.TVShow_ID,
                   COALESCE(NULLIF(TRIM(t.CzTitle), ''),
                            NULLIF(TRIM(t.Originaltitle), ''),
                            NULLIF(TRIM(t.Alternativetitles), '')) AS FinalTitle
            FROM TVShows t
            ORDER BY FinalTitle COLLATE NOCASE
            LIMIT ? OFFSET ?
        """, (page_size, (page - 1) * page_size))
        Msg("[MAIN] query executed, čekám na výsledky")

        rows = cursor.fetchall()
        Msg(f"[MAIN] Načteno {len(rows)} seriálů")

        for tvshow_id, title in rows:
            final_title = title or "[Neznámý název]"
            li = xbmcgui.ListItem(label=final_title)
            
            metadata = fetch_tmdb_tv_metadata(final_title, DB_TVSHOWS)
            if metadata:
                info_tag = li.getVideoInfoTag()
                info_tag.setTitle(metadata.get("name", final_title))
                info_tag.setPlot(metadata.get("overview", ""))
                info_tag.setDuration(int(metadata.get("runtime", 0)))
                first_air_date = metadata.get("first_air_date")
                if first_air_date:
                    info_tag.setYear(int(first_air_date[:4]))
                info_tag.setRating(float(metadata.get("vote_average", 0.0)))
                info_tag.setMediaType("tvshow")

                genres = [g["name"] for g in metadata.get("genres", [])]
                if genres:
                    info_tag.setGenres(genres)

                poster_path = metadata.get("poster_path")
                if poster_path:
                    full_url = f"https://image.tmdb.org/t/p/w500{poster_path}"
                    li.setArt({
                        "poster": full_url,
                        "fanart": full_url,
                        "icon": full_url
                    })
                else:
                    li.setArt({
                        "icon": "DefaultVideo.png",
                        "poster": "DefaultVideo.png"
                    })

            url = get_url(action="tvshows", tvshow_id=tvshow_id)
            xbmcplugin.addDirectoryItem(_handle, url, li, isFolder=True)


        if page < total_pages:
            next_url = get_url(action="tvshows", page=page + 1)
            li = xbmcgui.ListItem(label="Další strana »")
            li.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
            xbmcplugin.addDirectoryItem(_handle, next_url, li, isFolder=True)
            if addon.getSetting("debug") == "true":
                Msg(f"[MAIN] Přidána další strana: page={page + 1}")


    conn.close()
    xbmcplugin.endOfDirectory(_handle, updateListing=(page != 1), cacheToDisc=False)


def list_videos():
    videos = get_all_videos()
    xbmcplugin.setContent(_handle, "movies")

    for ident, title, size, tmdb_id, year, overview, rating, poster_url, runtime, genre in videos:

        url = get_url(action='play', ident=ident, name=title)

        li = xbmcgui.ListItem(label=title)
        li.setProperty('IsPlayable', 'true')

        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(title)
        info_tag.setPlot(overview or "")
        info_tag.setMediaType('movie')
        info_tag.setDuration(int(runtime * 60) if runtime else 0)
        
        if year is not None:
            info_tag.setYear(year)
            
        if rating is not None:
            info_tag.setRating(float(rating))
            
        if runtime is not None:
            info_tag.setDuration(int(runtime))
            
        if genre:
            info_tag.setGenres(genre if isinstance(genre, (list, tuple)) else [genre])

        li.setArt({
            'poster': poster_url,
            'thumb': poster_url,
            'fanart': poster_url,
            'icon': poster_url
        })

        xbmcplugin.addDirectoryItem(handle=_handle, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(_handle)
    
def list_history():
    xbmcplugin.setPluginCategory(_handle, "Historie hledání")
    xbmcplugin.setContent(_handle, "files")

    if not xbmcvfs.exists(history_path):
        xbmcgui.Dialog().notification("Historie", "Žádná historie není k dispozici", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    with xbmcvfs.File(history_path, 'r') as f:
        history = json.loads(f.read())

    for query in history:
        url = f"{_base_url}?action=search&query={urllib.parse.quote_plus(query)}"
        li = xbmcgui.ListItem(label=query)
        context_menu = [
            ('WST Smazat z historie',
             f'RunPlugin({_base_url}?action=delete_history_item&query={urllib.parse.quote_plus(query)})'),
            ('WST Smazat celou historii',
             f'RunPlugin({_base_url}?action=clear_history)')
        ]
        li.addContextMenuItems(context_menu)

        xbmcplugin.addDirectoryItem(_handle, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(_handle)
    
def show_continue_watching():
    xbmcplugin.setPluginCategory(_handle, "Pokračovat ve sledování")
    xbmcplugin.setContent(_handle, "movies")

    conn_continue = sqlite3.connect(DB_CONTINUE)
    cursor_continue = conn_continue.cursor()

    conn_movies = sqlite3.connect(DB_MOVIES)
    cursor_movies = conn_movies.cursor()

    cursor_continue.execute('''
        SELECT movie_id, season, episode, last_position
        FROM continue_watching
        WHERE finished = 0
        ORDER BY datetime(last_played) DESC
    ''')

    rows = cursor_continue.fetchall()

    for movie_id, season, episode, last_position in rows:
        label = movie_id
        provider_ident = None

        cursor_movies.execute("SELECT CzTitle FROM Movies WHERE Movie_ID = ?", (movie_id,))
        result = cursor_movies.fetchone()
        Msg(f"[MAIN] movie_id: {movie_id} - Movies.CzTitle: {result}")

        if result and result[0]:
            label = result[0]

        cursor_movies.execute("SELECT Provider_Ident FROM Streams WHERE Movie_ID = ? LIMIT 1", (movie_id,))
        stream_result = cursor_movies.fetchone()
        if addon.getSetting("debug") == "true":
            Msg(f"[MAIN] movie_id: {movie_id} - Streams.Provider_Ident: {stream_result}")

        if stream_result and stream_result[0]:
            provider_ident = stream_result[0]
        else:
            Msg(f"[MAIN] SKIP – chybí Provider_Ident pro movie_id {movie_id}")
            continue

        if season and episode:
            label += f" S{int(season):02d}E{int(episode):02d}"

        li = xbmcgui.ListItem(label=label)
        li.setProperty("IsPlayable", "true")

        play_url = get_url(action="play", ident=provider_ident, name=label)
        xbmcplugin.addDirectoryItem(_handle, play_url, li, isFolder=False)

    conn_continue.close()
    conn_movies.close()

    xbmcplugin.endOfDirectory(_handle)

def menu_search():
    xbmcplugin.setPluginCategory(_handle, "Vyhledávání")

    search_items = [
        ("Naposledy hledané", "list", 'icon_video.png', True),
        ("Nové hledání", "search", 'icon_search.png', False),
        ("Historie hledání", "history", 'history.png', True),
    ]

    for label, action, icon, is_folder in search_items:
        listitem = xbmcgui.ListItem(label=label)
        listitem.setArt({'icon': icon, 'thumb': icon})
        url = get_url(action=action)
        xbmcplugin.addDirectoryItem(_handle, url, listitem, isFolder=is_folder)

    xbmcplugin.endOfDirectory(_handle)
    
def menu_utils():
    xbmcplugin.setPluginCategory(_handle, "Utils")

    utils_items = [
        ("Filmy - Generovat streamy", "strm_movies", 'DefaultMovies.png', False),
        ("Seriály - Generovat streamy", "strm_tvshows", 'DefaultTVShows.png', False),
        ("Hledat podle ident/podle řetězce", "tests", 'DefaultAddonsSearch.png', False),
        ("Doplnění databází", "db_fill", 'DefaultFolder.png', False), 
        ("Testy", "utilities", 'DefaultFolder.png', False),         
    ]

    for label, action, icon, is_folder in utils_items:
        listitem = xbmcgui.ListItem(label=label)
        listitem.setArt({'icon': icon, 'thumb': icon})
        url = get_url(action=action)
        xbmcplugin.addDirectoryItem(_handle, url, listitem, isFolder=is_folder)

    xbmcplugin.endOfDirectory(_handle)
    
def menu_movies():
    items = [
        ("Všechny filmy", "movies", 'DefaultMovies.png', True),
        ("Podle abecedy", "movies_by_letter_menu", 'DefaultMovies.png', True),
    ]

    for label, action, icon, is_folder in items:
        listitem = xbmcgui.ListItem(label=label)
        listitem.setArt({'icon': icon, 'thumb': icon})
        url = get_url(action=action)
        xbmcplugin.addDirectoryItem(_handle, url, listitem, isFolder=is_folder)

    xbmcplugin.endOfDirectory(_handle)

def menu():
    xbmcplugin.setPluginCategory(_handle, addon.getAddonInfo('name'))
    xbmcplugin.setContent(_handle, "files")

    items = [
        ("Hledat", "menu_search", 'icon_search.png', True),
        ("Novinky", "show_news", 'DefaultVideoPlaylists.png', True),
        ("Filmy", "menu_movies", 'DefaultMovies.png', True),
        ("Seriály", "tvshows", 'DefaultTVShows.png', True),
        ("Pokračovat ve sledování", "continue_watching", 'DefaultVideo.png', True),
        ("Utility", "utils", 'DefaultFolder.png', True),
        ("Nastavení", "settings", 'DefaultFolder.png', False),
    ]

    for label, action, icon, is_folder in items:
        listitem = xbmcgui.ListItem(label=label)
        listitem.setArt({'icon': icon, 'thumb': icon})
        url = get_url(action=action)
        xbmcplugin.addDirectoryItem(_handle, url, listitem, isFolder=is_folder)

    xbmcplugin.endOfDirectory(_handle)

def router(params):
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    if addon.getSetting("debug") == "true":
        Msg(f"[DEBUG params] Přijaté parametry: {params}")

    action = params.get('action')
    if action == 'movies':
        page = int(params.get('page', 1))
        show_movies(page=page)
    elif action == 'menu_movies':
        menu_movies()
    elif action == 'continue_watching':
        show_continue_watching()
    elif action == "movies_by_letter_menu":
        show_letter_selector(_handle, get_url)
    elif action == "movies_by_prefix_menu":
        prefix = params.get("prefix", "")
        show_prefix_menu(_handle, get_url, DB_MOVIES, prefix=prefix)
    elif action == "movies_by_prefix":
        prefix = params.get("prefix", "")
        page = int(params.get("page", 1))
        show_movies_by_prefix(_handle, get_url, DB_MOVIES, prefix, page=page)
    elif action == 'tvshows':
        show_tvshows(
            tvshow_id=params.get('tvshow_id'),
            season_id=params.get('season_id'),
            page=int(params.get('page', 1))
        )
    elif action == 'menu_search':
        menu_search()
    elif action == 'utils':
        menu_utils()
    elif action == 'strm_movies':
        generate_strm_movies()
    elif action == 'strm_tvshows':
        generate_strm_tvshows()
    elif action == 'metadata_movies':
        metadata_movies()
    elif action == 'metadata_tvshows':
        metadata_tvshows()
        #update_episodes_from_tmdb()# doplňuje názvy episod
        #update_missing_tmdb_ids()# doplňuje ID
    elif action == 'list':
        list_videos()
    elif action == 'search':
        query = params.get('query')
        search_query(query) if query else search_videos()
    elif action == 'history':
        list_history()
    elif action == 'clear_history':
        clear_history()
    elif action == "delete_history_item":
        query = params.get("query")
        delete_history_item(query)
    elif action == 'settings':
        addon.openSettings()
    elif action == 'play':
        play(params)
    elif action == 'clear_db':
        clear_db()
    elif action == "show_news":
        show_news()
    elif action == "utilities":
        utilities()
    elif action == "tests":
        tests()
    elif action == "db_fill":
        db_fill()
    elif action == 'autosearch':
        name = params.get('name', '').lower()
        if any(keyword in name for keyword in ['díl', 'episode', 's01e', 'e01', 'epizoda']):
            return
        auto_search_by_name(_handle)
    else:
        menu()

if __name__ == "__main__":
    if addon.getSetting("debug") == "true":
        Msg(f"[DEBUG main] sys.argv: {sys.argv}")
    raw_params = sys.argv[2][1:]
    args = dict(urllib.parse.parse_qsl(raw_params))
    if addon.getSetting("debug") == "true":
        Msg(f"[DEBUG main] Parsed args: {args}")
    router(args)

