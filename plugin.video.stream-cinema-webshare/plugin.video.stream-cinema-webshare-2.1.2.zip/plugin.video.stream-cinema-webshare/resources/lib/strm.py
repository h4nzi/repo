#Generuje stmr soubory z db
import os
import xbmc
import sqlite3
import xbmcgui
import xbmcaddon
import xbmcvfs
import traceback
import re
import urllib.parse

addon = xbmcaddon.Addon()

folder_path = addon.getSetting('path')
db_path = xbmcvfs.translatePath(folder_path)

def Info(message, heading=addon.getAddonInfo('name'), icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)
    
def Msg(message):
    xbmc.log("[Stream Cinema Webshare] " + message, level=xbmc.LOGINFO)

def generate_strm_movies(): #JiRo
    Msg("[SQL] Spouštím generování strm souborů")
    Info("Spouštím generování strm souborů", sound=True)
    db_file = os.path.join(db_path, 'movies.sqlite')
    output_folder = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.stream-cinema-webshare/strm_movies/")
    if not xbmcvfs.exists(output_folder):
        xbmcvfs.mkdirs(output_folder)
    try:
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                COALESCE(NULLIF(TRIM(OriginalTitle), ''), Title) AS FinalTitle,
                DOWNLOAD_AVAILABLE,
                Video_Height,
                Provider_Ident,
                OriginalTitle
            FROM Live
            WHERE Video_Height >= 1080
        """)

        rows = cursor.fetchall()
        count = 0

        for title, url, height, provider_ident, originaltitle in rows:
            if not title or not url:
                continue

            safe_title = "".join(c for c in title if c.isalnum() or c in " _-.").strip()
            filename = os.path.join(output_folder, f"{safe_title}.strm")

            with open(filename, "w", encoding="utf-8") as f:
                url = f"plugin://plugin.video.stream-cinema-webshare/?action=play&ident={provider_ident}&name={originaltitle}"
                #Msg(f"URL strm: {url}")
                f.write(url)
            count += 1

        conn.close()
        xbmcgui.Dialog().notification(addon.getAddonInfo('name'), f"Vytvořeno {count} .strm souborů", xbmcgui.NOTIFICATION_INFO, 3000)

    except Exception as e:
        xbmcgui.Dialog().notification("Chyba", str(e), xbmcgui.NOTIFICATION_ERROR, 5000)
        import traceback
        traceback.print_exc()

# def generate_strm_tvshows():  # JiRo
    # Msg("[SQL] Spouštím generování strm souborů")
    # Info("Spouštím generování strm souborů", sound=True)
    # db_file = os.path.join(db_path, 'tvshows.sqlite')
    # output_folder = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.stream-cinema-webshare/strm_tvshows/")
    # try:
        # conn = sqlite3.connect(db_file)
        # cursor = conn.cursor()

        # cursor.execute("""
            # SELECT
                # COALESCE(NULLIF(TRIM(OriginalTitle), ''), AlternativeTitles) AS ShowTitle,
                # Season_ID,
                # Season_number,
                # Season_name,
                # Episode_ID,
                # Episode_number,
                # Episode_AlternativeTitles,
                # DOWNLOAD_AVAILABLE,
                # Provider_Ident,
                # Video_Height,
                # OriginalTitle
            # FROM Live
            # WHERE Video_Height >= 1080
        # """)

        # rows = cursor.fetchall()
        # count = 0

        # for (show_title, season_id, season_number, season_name,
             # episode_id, episode_number, episode_alt_title,
             # download_available, provider_ident, video_height, episode_alternativetitles) in rows:

            # if not show_title or not download_available:
                # continue

            ## Čisté názvy
            # clean = lambda s: "".join(c for c in s if c.isalnum() or c in " _-.").strip()
            # safe_show = clean(show_title)
            # safe_season_name = clean(season_name or "")
            # safe_episode_title = clean(episode_alt_title or "")

            ## Formát season_number
            # try:
                # season_number_fmt = f"{int(season_number):02d}"
            # except (ValueError, TypeError):
                # season_number_fmt = clean(str(season_number or "Unknown"))

            ## Formát episode_number
            # try:
                # episode_number_fmt = f"{int(episode_number):02d}"
            # except (ValueError, TypeError):
                # episode_number_fmt = clean(str(episode_number or "Unknown"))

            ## Cesty
            # show_folder = os.path.join(output_folder, safe_show)
            # season_folder = os.path.join(show_folder, f"{season_number_fmt} - {safe_season_name}")
            # file_name = f"{episode_number_fmt} - {safe_episode_title}.strm"
            # file_path = os.path.join(season_folder, file_name)

            ## Vytvoření složek
            # if not xbmcvfs.exists(show_folder):
                # xbmcvfs.mkdirs(show_folder)
            # if not xbmcvfs.exists(season_folder):
                # xbmcvfs.mkdirs(season_folder)

            ## Zápis .strm souboru
            # if not xbmcvfs.exists(file_path):
                # with xbmcvfs.File(file_path, "w") as f:
                    # url = f"plugin://plugin.video.stream-cinema-webshare/?action=play&ident={provider_ident}&name={episode_alternativetitles}"
                    # f.write(url)
                    # count += 1

        # conn.close()
        # xbmcgui.Dialog().notification(
            # addon.getAddonInfo('name'),
            # f"Vytvořeno {count} .strm souborů",
            # xbmcgui.NOTIFICATION_INFO, 3000
        # )

    # except Exception as e:
        # xbmcgui.Dialog().notification("Chyba", str(e), xbmcgui.NOTIFICATION_ERROR, 5000)
        # import traceback
        # traceback.print_exc()
        
def generate_strm_tvshows():
    Msg("[SQL] Spouštím generování strm souborů")
    Info("Spouštím generování strm souborů", sound=True)

    db_file = os.path.join(db_path, 'tvshows.sqlite')
    output_folder = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.stream-cinema-webshare/strm_tvshows/")

    try:
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                COALESCE(NULLIF(TRIM(OriginalTitle), ''), AlternativeTitles) AS ShowTitle,
                Season_ID,
                Season_number,
                Season_name,
                Episode_ID,
                Episode_number,
                COALESCE(NULLIF(TRIM(Episode_AlternativeTitles), ''), 'Neznámá epizoda') AS EpisodeTitle,
                DOWNLOAD_AVAILABLE,
                Provider_Ident,
                Video_Height
            FROM Live
            WHERE Video_Height >= 1080
        """)

        rows = cursor.fetchall()
        count = 0

        for (
            show_title, season_id, season_number, season_name,
            episode_id, episode_number, episode_title,
            download_available, provider_ident, video_height
        ) in rows:

            if not show_title or not download_available:
                continue

            # Čisté názvy
            clean = lambda s: "".join(c for c in s if c.isalnum() or c in " _-.").strip()

            safe_show = clean(show_title)
            safe_season_name = clean(season_name or "")
            safe_episode_title = clean(episode_title or "")

            # Formát season_number
            try:
                season_number_fmt = f"{int(season_number):02d}"
            except (ValueError, TypeError):
                season_number_fmt = clean(str(season_number or "Unknown"))

            # Formát episode_number
            try:
                episode_number_fmt = f"{int(episode_number):02d}"
            except (ValueError, TypeError):
                episode_number_fmt = clean(str(episode_number or "Unknown"))

            # Cesty
            show_folder = os.path.join(output_folder, safe_show)
            season_folder = os.path.join(show_folder, f"{season_number_fmt} - {safe_season_name}")
            file_name = f"{episode_number_fmt} - {safe_episode_title}.strm"
            file_path = os.path.join(season_folder, file_name)

            # Vytvoření složek
            if not xbmcvfs.exists(show_folder):
                xbmcvfs.mkdirs(show_folder)
            if not xbmcvfs.exists(season_folder):
                xbmcvfs.mkdirs(season_folder)

            # Zápis .strm souboru
            if not xbmcvfs.exists(file_path):
                with xbmcvfs.File(file_path, "w") as f:
                    # DŮLEŽITÉ: Vkládáme EpisodeTitle do URL parametru name
                    url = f"plugin://plugin.video.stream-cinema-webshare/?action=play&ident={provider_ident}&name={urllib.parse.quote(episode_title)}"
                    f.write(url)
                    count += 1

        conn.close()
        xbmcgui.Dialog().notification(
            addon.getAddonInfo('name'),
            f"Vytvořeno {count} .strm souborů",
            xbmcgui.NOTIFICATION_INFO, 3000
        )

    except Exception as e:
        xbmcgui.Dialog().notification("Chyba", str(e), xbmcgui.NOTIFICATION_ERROR, 5000)
        import traceback
        traceback.print_exc()


