# default.py
import sys
import os
import urllib.parse
import xbmcaddon
import xbmcplugin
import xbmcgui
import xbmcvfs
import json
import requests
from urllib.parse import quote_plus, urlencode
import xml.etree.ElementTree as ET

from resources.lib.repairer import repair
from resources.lib.generator import LiveStreams_generate
from resources.lib.strm import generate_strm_movies,generate_strm_tvshows
from resources.lib.test import test, search_files
from resources.lib.metadata import metadata_movies, metadata_tvshows
from resources.lib.metadata import update_episodes_from_tmdb
from resources.lib.player import play
from resources.lib.search import search_videos, search_query, list_history, clear_history, get_news
from resources.lib.db import get_all_videos, clear_db
from resources.lib.login import login, api, revalidate, check_vip_status

addon = xbmcaddon.Addon()
_handle = int(sys.argv[1])
_base_url = sys.argv[0]

movies_path = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.stream-cinema-webshare/strm_movies/")
tvshows_path = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.stream-cinema-webshare/strm_tvshows/")
history_path = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.stream-cinema-webshare/search_history.json")
icons_dir = os.path.join(addon.getAddonInfo('path'), 'resources','skins','images','icons')

vip_days = check_vip_status()

def Msg(message):
    xbmc.log("[Stream Cinema Webshare - Main] " + message, level=xbmc.LOGINFO)

def Info(message, heading=None, icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    if heading is None:
        heading = addon.getAddonInfo('name')
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)
    


def get_url(**kwargs):
    return _base_url + '?' + urllib.parse.urlencode(kwargs)

def show_news():
    xbmcplugin.setContent(_handle, "videos")

    news_items = get_news()
    if not news_items:
        Info("Nepodařilo se načíst novinky.", icon=xbmcgui.NOTIFICATION_ERROR)
        return

    for item in news_items:
        plot = f"{item['overview']}\n\nDatum nahrání: {item['date']}"
        li = xbmcgui.ListItem(label=item["title"])
        li.setProperty('IsPlayable', 'true')
        li.setInfo("video", {
            "title": item["title"],
            "plot": plot,
            "year": item["year"],
            "rating": item["rating"],
            "genre": item["genre"],
            "duration": item["runtime"],
            "mediatype": "video"
        })
        li.setArt({
            'poster': item["poster_url"],
            'thumb': item["poster_url"],
            'fanart': item["poster_url"],
            'icon': item["poster_url"]
        })

        params = {
            'action': 'play',
            'ident': item['ident'],
            'name': item['title']
        }
        url = get_url(**params)
    
        xbmcplugin.addDirectoryItem(handle=_handle, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(_handle, cacheToDisc = False)

def show_movies():
    xbmcplugin.setPluginCategory(_handle, "Filmy")
    xbmcplugin.setContent(_handle, "movies")

    for filename in os.listdir(movies_path):
        if filename.endswith(".strm"):
            title = os.path.splitext(filename)[0]
            file_path = os.path.join(movies_path, filename)
            li = xbmcgui.ListItem(label=title)
            li.setPath(file_path)
            li.setProperty("IsPlayable", "true")

            json_path = os.path.join(movies_path, f"{title}.json")
            if os.path.exists(json_path):
                try:
                    with open(json_path, "r", encoding="utf-8") as f:
                        data = json.load(f)

                        li.setProperty("title", data.get("title", title))
                        if "size" in data:
                            li.setProperty("Size", data["size"])

                        li.setInfo("video", {
                            "title": data.get("title", title),
                            "plot": data.get("plot", ""),
                            "year": data.get("year", 0),
                            "genre": ", ".join(data.get("genres", [])),
                            "duration": data.get("runtime", 0),
                            "rating": data.get("rating", 0.0),
                            "mediatype": "movie",
                        })

                        info_tag = li.getVideoInfoTag()
                        info_tag.setTitle(data.get("title", title))
                        info_tag.setPlot(data.get("plot", ""))
                        info_tag.setDuration(data.get("runtime", 0))
                        if data.get("year"):
                            info_tag.setYear(int(data.get("year")))
                        if data.get("rating"):
                            info_tag.setRating(float(data.get("rating")))

                        if data.get("poster"):
                            li.setArt({
                                "poster": data["poster"],
                                "fanart": data["poster"],
                                "icon": data["poster"]
                            })

                except Exception as e:
                    xbmc.log(f"Chyba při čtení JSON: {e}", xbmc.LOGWARNING)

            xbmcplugin.addDirectoryItem(_handle, file_path, li, isFolder=False)
            xbmcplugin.addSortMethod(_handle, 21)  # SORT_METHOD_VIDEO_YEAR
            xbmcplugin.addSortMethod(_handle, 9)   # SORT_METHOD_TITLE
            xbmcplugin.addSortMethod(_handle, 23)  # SORT_METHOD_VIDEO_RATING

    xbmcplugin.endOfDirectory(_handle, updateListing = True, cacheToDisc = False)

def show_tvshows(base_path=None):
    if base_path is None:
        base_path = tvshows_path

    rel_path = os.path.relpath(base_path, tvshows_path)
    Msg(f"Browsing: {rel_path}")

    dirs = []
    files = []

    for item in sorted(os.listdir(base_path)):
        full_path = os.path.join(base_path, item)
        if os.path.isdir(full_path):
            dirs.append((item, full_path))
        elif item.endswith(".strm"):
            files.append((item, full_path))

    if dirs:
        xbmcplugin.setPluginCategory(_handle, "Seriály")
        xbmcplugin.setContent(_handle, "tvshows")

        for folder_name, folder_path in dirs:
            listitem = xbmcgui.ListItem(label=folder_name)
            listitem.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
            url = get_url(action="tvshows", folder=urllib.parse.quote(folder_path))
            xbmcplugin.addDirectoryItem(_handle, url, listitem, isFolder=True)

    elif files:
        xbmcplugin.setPluginCategory(_handle, "Epizody")
        xbmcplugin.setContent(_handle, "tvshows")

        for filename, file_path in files:
            title = os.path.splitext(filename)[0]
            li = xbmcgui.ListItem(label=title)
            li.setPath(file_path)
            li.setProperty("IsPlayable", "true")

            json_path = os.path.join(os.path.dirname(file_path), f"{title}.json")
            if os.path.exists(json_path):
                try:
                    with open(json_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        li.setLabel(data.get("title", title))
                        li.setProperty("title", data.get("title", title))
                        li.setInfo("video", {
                            "title": data.get("title", title),
                            "plot": data.get("plot", ""),
                            "season": data.get("season", 1),
                            "episode": data.get("episode", 1),
                            "year": data.get("year", 0),
                            "genre": ", ".join(data.get("genres", [])),
                            "duration": data.get("runtime", 0),
                            "rating": data.get("rating", 0.0),
                            "mediatype": "episode",
                        })
                        if data.get("poster"):
                            li.setArt({
                                "poster": data["poster"],
                                "fanart": data["poster"],
                                "icon": data["poster"]
                            })
                except Exception as e:
                    xbmc.log(f"Chyba při čtení JSON: {e}", xbmc.LOGWARNING)

            xbmcplugin.addDirectoryItem(_handle, file_path, li, isFolder=False)

    xbmcplugin.endOfDirectory(_handle)

def list_videos():
    videos = get_all_videos()
    xbmcplugin.setContent(_handle, "movies")

    for ident, title, size, tmdb_id, year, overview, rating, poster_url, runtime, genre in videos:

        url = get_url(action='play', ident=ident, name=title)

        li = xbmcgui.ListItem(label=title)
        li.setProperty('IsPlayable', 'true')

        li.setInfo('video', {
            'title': title,
            'mediatype': 'movie',
            'size': size,
            'year': year,
            'plot': overview or "",
            'rating': float(rating) if rating else 0,
            "duration": runtime,
            "genre": genre
        })

        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(title)
        info_tag.setPlot(overview or "")
        info_tag.setDuration(int(runtime * 60) if runtime else 0)

        li.setArt({
            'poster': poster_url,
            'thumb': poster_url,
            'fanart': poster_url,
            'icon': poster_url
        })

        xbmcplugin.addDirectoryItem(handle=_handle, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(_handle)
    
def list_history():
    xbmcplugin.setPluginCategory(_handle, "Historie hledání")
    xbmcplugin.setContent(_handle, "files")

    if not xbmcvfs.exists(history_path):
        xbmcgui.Dialog().notification("Historie", "Žádná historie není k dispozici", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    with xbmcvfs.File(history_path, 'r') as f:
        history = json.loads(f.read())

    for query in history:
        li = xbmcgui.ListItem(label=query)
        url = f"{_base_url}?action=search&query={urllib.parse.quote(query)}"
        xbmcplugin.addDirectoryItem(_handle, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(_handle)

def show_search():
    xbmcplugin.setPluginCategory(_handle, "Vyhledávání")

    search_items = [
        ("Nalezeno na Webshare", "list", 'icon_video.png', True),
        ("Nové hledání", "search", 'icon_search.png', False),
        ("Historie", "history", 'history.png', True),
        ("Smazat historii", "clear_history", 'DefaultAddonsSearch.png', False),
        ("Smazat databázi", "clear_db", 'DefaultAddonsSearch.png', False),
    ]

    for label, action, icon, is_folder in search_items:
        listitem = xbmcgui.ListItem(label=label)
        listitem.setArt({'icon': icon, 'thumb': icon})
        url = get_url(action=action)
        xbmcplugin.addDirectoryItem(_handle, url, listitem, isFolder=is_folder)

    xbmcplugin.endOfDirectory(_handle)
    
def show_utils():
    xbmcplugin.setPluginCategory(_handle, "Utils")

    utils_items = [
        ("Filmy - Generovat strm", "strm_movies", 'DefaultMovies.png', False),
        ("Filmy - Generovat metadata", "metadata_movies", 'DefaultMovies.png', False),
        ("Seriály - Generovat strm", "strm_tvshows", 'DefaultTVShows.png', False),
        ("Seriály - Generovat metadata", "metadata_tvshows", 'DefaultTVShows.png', False),
        ("Opravit odkazy", "repair", 'DefaultScript.png', False),
        ("Generovat tabulku", "generate", 'DefaultFolder.png', False),
        ("Test / hledání", "test", 'DefaultAddonsSearch.png', False),  
    ]

    for label, action, icon, is_folder in utils_items:
        listitem = xbmcgui.ListItem(label=label)
        listitem.setArt({'icon': icon, 'thumb': icon})
        url = get_url(action=action)
        xbmcplugin.addDirectoryItem(_handle, url, listitem, isFolder=is_folder)

    xbmcplugin.endOfDirectory(_handle)
    
def menu():
    xbmcplugin.setPluginCategory(_handle, addon.getAddonInfo('name'))
    xbmcplugin.setContent(_handle, "files")

    items = [
        ("Novinky", "show_news", 'DefaultVideoPlaylists.png', True),
        ("Filmy", "movies", 'DefaultMovies.png', True),
        ("Seriály", "tvshows", 'DefaultTVShows.png', True),
        ("Vyhledávání", "show_search",'icon_search.png', True),
        ("Utility", "utils", 'DefaultFolder.png', True),
        ("Nastavení", "settings", 'DefaultFolder.png', False),
    ]
    
    for label, action, icon, is_folder in items:
        listitem = xbmcgui.ListItem(label=label)
        listitem.setArt({'icon': icon, 'thumb': icon})
        url = get_url(action=action)
        xbmcplugin.addDirectoryItem(_handle, url, listitem, isFolder=is_folder)

    xbmcplugin.endOfDirectory(_handle)

def router(params):
    action = params.get('action')
    if action == 'movies':
        show_movies()
    elif action == 'tvshows':
        folder = params.get('folder')
        if folder:
            folder = urllib.parse.unquote(folder)
            show_tvshows(folder)
        else:
            show_tvshows()
    elif action == 'show_search':
        show_search()
    elif action == 'utils':
        show_utils()
    elif action == 'strm_movies':
        generate_strm_movies()
    elif action == 'strm_tvshows':
        generate_strm_tvshows()
    elif action == 'metadata_movies':
        metadata_movies()
    elif action == 'metadata_tvshows':
        metadata_tvshows()
    elif action == 'repair':
        repair()
    elif action == 'generate':
        LiveStreams_generate()
    elif action == 'test':
        test()
    elif action == 'list':
        list_videos()
    elif action == 'search':
        query = params.get('query')
        if query:
            search_query(query)
        else:
            search_videos()
    elif action == 'history':
        list_history()
    elif action == 'clear_history':
        clear_history()
    elif action == 'settings':
        addon.openSettings()
    elif action == 'play':
        play(params)
    elif action == 'clear_db':
        clear_db()
    elif action == "show_news":
        show_news()
    else:
        menu()
        
if __name__ == "__main__":
    args = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    router(args)
