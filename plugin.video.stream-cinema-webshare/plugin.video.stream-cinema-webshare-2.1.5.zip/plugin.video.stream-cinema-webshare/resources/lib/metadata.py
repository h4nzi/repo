# importování metadat z TMDB na základě TNDB_ID
import os
import json
import time
import sqlite3
import requests
import xbmcaddon
import xbmcvfs
import xbmc
import xbmcgui

addon = xbmcaddon.Addon()
folder_path = addon.getSetting('path')
db_path = xbmcvfs.translatePath(folder_path)
db_movies = os.path.join(db_path, 'movies.sqlite')
db_tvshows = os.path.join(db_path, 'tvshows.sqlite')

output_folder_movies = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.stream-cinema-webshare/strm_movies/")
output_folder_tvshows = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.stream-cinema-webshare/strm_tvshows/")
TMDB_API_KEY = "3c6301e382a803d9c9b52adad044a45a"
TMDB_LANG = "cs-CZ"
MAX_TMDB_FETCH = 10000
# MAX_TMDB_FETCH = int(addon.getSetting("sfetch"))

def Msg(message):
    xbmc.log("[Stream Cinema Webshare - Metadata] " + message, level=xbmc.LOGINFO)

def Info(message, heading=addon.getAddonInfo('name'), icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)

def fetch_tmdb_data(tmdb_id):
    try:
        url_movies = f"https://api.themoviedb.org/3/movie/{tmdb_id}?api_key={TMDB_API_KEY}&language={TMDB_LANG}"
        response = requests.get(url_movies)
        if response.status_code == 200:
            return response.json()
    except Exception as e:
        Msg(f"[TMDB] Chyba: {e}")
    return {}
    
def fetch_tmdb_tv_data(tmdb_id):
    try:
        url_tv = f"https://api.themoviedb.org/3/tv/{tmdb_id}?api_key={TMDB_API_KEY}&language={TMDB_LANG}"
        response = requests.get(url_tv)
        if response.status_code == 200:
            return response.json()
    except Exception as e:
        Msg(f"[TMDB-TV] Chyba: {e}")
    return {}

#xxxxxxxxxxxxxxxxxx      FILMY     xxxxxxxxxxxxxxxxxxxxx

def metadata_movies():
    Msg("[Spouštím doplnění metadat pro .strm soubory")
    Info("Spouštím generování metadat", sound=True)
    try:
        conn = sqlite3.connect(db_movies)
        cursor = conn.cursor()
        tmdb_fetch_count = 0

        for filename in os.listdir(output_folder_movies):
            if filename.endswith(".strm"):
                title = os.path.splitext(filename)[0]
                if addon.getSetting("debug") == "true":
                    Msg(f"[TMDB] Zpracovávám title: '{title}'")
                json_path = os.path.join(output_folder_movies, f"{title}.json")
                if os.path.exists(json_path):
                    Msg(f"[TMDB] JSON pro '{title}' už existuje, přeskakuji.")
                    continue

                cursor.execute("""
                    SELECT
                        TMDB_ID,
                        Audio_Codec,
                        Video_Codec
                    FROM Live
                    WHERE TRIM(OriginalTitle) = ? OR TRIM(Title) = ?
                    LIMIT 1
                """, (title, title))
                result = cursor.fetchone()
                if addon.getSetting("debug") == "true":
                    Msg(f"Result '{title}': {result}")

                if not result:
                    Msg(f"[TMDB] Nebyl nalezen odpovídající záznam v DB pro '{title}'")
                    continue

                tmdb_id, audio_codec, video_codec = result

                if not tmdb_id:
                    if addon.getSetting("debug") == "true":
                        Msg(f"Záznam nalezen, ale chybí TMDB_ID pro '{title}'")
                    continue

                if tmdb_fetch_count >= MAX_TMDB_FETCH:
                    Msg(f"Překročen limit {MAX_TMDB_FETCH} záznamů, ukončuji zpracování\n")
                    break

                metadata = fetch_tmdb_data(tmdb_id)
                if not metadata:
                    if addon.getSetting("debug") == "true":
                        Msg(f"API nevrátilo metadata pro TMDB_ID={tmdb_id}, název '{title}'")
                    continue

                genres = [g["name"] for g in metadata.get("genres", [])]

                json_data = {
                    "tmdb_id": tmdb_id,
                    "title": metadata.get("title", title),
                    "year": int(metadata.get("release_date", "0")[:4]) if metadata.get("release_date") else 0,
                    "plot": metadata.get("overview", ""),
                    "poster": f"https://image.tmdb.org/t/p/w500{metadata['poster_path']}" if metadata.get("poster_path") else "",
                    "audio_codec": audio_codec,
                    "video_codec": video_codec,
                    "runtime": metadata.get("runtime", 0) * 60,  # převod minut na sekundy
                    "rating": round(float(metadata.get("vote_average", 0.0)), 1),
                    "genres": genres
                }

                if addon.getSetting("debug") == "true":
                    Msg(f"Ukládám metadata JSON pro '{title}'\n")
                with open(json_path, "w", encoding="utf-8") as jf:
                    json.dump(json_data, jf, ensure_ascii=False, indent=2)

                tmdb_fetch_count += 1
                time.sleep(0.1)

        conn.close()
        Msg(f"Doplněno {tmdb_fetch_count} metadata záznamů")
        Info("Metadata hotovo", sound=True)
    except Exception as e:
        xbmc.log(f"[TMDB] Chyba při doplňování metadat: {str(e)}", xbmc.LOGERROR)



#xxxxxxxxxxxxxxxxxx      SERIÁLY     xxxxxxxxxxxxxxxxxxxxx
        
def metadata_tvshows():
    Msg("Spouštím hledání metadat pro seriály")
    Info("Spouštím generování metadat pro seriály", sound=True)
    try:
        conn = sqlite3.connect(db_tvshows)
        cursor = conn.cursor()
        tmdb_fetch_count = 0
        # if tmdb_fetch_count % 100 == 0:
            # Msg(f"[TMDB-TV] Zpracováno {tmdb_fetch_count} seriálových záznamů...")

        # Debug: vypiš všechny tituly v databázi
        cursor.execute("SELECT DISTINCT TRIM(Originaltitle) FROM Live")
        titles_in_db = [row[0] for row in cursor.fetchall()]
        if addon.getSetting("debug") == "true":
            Msg(f"[DEBUG] Original titles v databázi: {titles_in_db}")

        for dirpath, _, filenames in os.walk(output_folder_tvshows):
            for filename in filenames:
                if not filename.endswith(".strm"):
                    continue

                title = os.path.splitext(filename)[0]
                if addon.getSetting("debug") == "true":
                    Msg(f"Zpracovávám title: '{title}'")

                json_path = os.path.join(dirpath, f"{title}.json")
                if os.path.exists(json_path):
                    continue

                # Hlavní dotaz – hledá i sezonu a epizodu
                cursor.execute("""
                    SELECT
                        TMDB_ID,
                        Audio_Codec,
                        Video_Codec,
                        Season_number,
                        Episode_Number
                    FROM Live
                    WHERE TRIM(Originaltitle) = ? OR TRIM(Alternativetitles) = ?
                    LIMIT 1
                """, ('%' + title + '%', '%' + title + '%'))
                result = cursor.fetchone()

                if addon.getSetting("debug") == "true":
                    Msg(f"Výsledek dotazu pro '{title}': {result}")
                if not result:
                    continue

                tmdb_id, audio_codec, video_codec, season, episode = result
                if not tmdb_id or tmdb_fetch_count >= MAX_TMDB_FETCH:
                    continue

                metadata = fetch_tmdb_tv_data(tmdb_id)
                time.sleep(0.1)

                genres = [g["name"] for g in metadata.get("genres", [])]

                json_data = {
                    "tmdb_id": tmdb_id,
                    "title": metadata.get("name", title),
                    "year": int(metadata.get("first_air_date", "0")[:4]) if metadata.get("first_air_date") else 0,
                    "plot": metadata.get("overview", ""),
                    "poster": f"https://image.tmdb.org/t/p/w500{metadata['poster_path']}" if metadata.get("poster_path") else "",
                    "audio_codec": audio_codec,
                    "video_codec": video_codec,
                    "season": season or 1,
                    "episode": episode or 1,
                    "runtime": 0,
                    "rating": round(float(metadata.get("vote_average", 0.0)), 1),
                    "genres": genres
                }

                with open(json_path, "w", encoding="utf-8") as jf:
                    json.dump(json_data, jf, ensure_ascii=False, indent=2)

                tmdb_fetch_count += 1

        conn.close()
        Msg(f"Doplněno {tmdb_fetch_count} metadata záznamů")
        Info("Metadata pro seriály hotovo", sound=True)
    except Exception as e:
        xbmc.log(f"[TMDB-TV] Chyba při doplňování metadat: {str(e)}", xbmc.LOGERROR)
        

#xxxxxxxxxxxxxxxxxx      DOPLNĚNÍ DATABÁZE     xxxxxxxxxxxxxxxxxxxxx

def get_episode_info(tmdb_id, season_num, episode_num):
    url = f"https://api.themoviedb.org/3/tv/{tmdb_id}/season/{season_num}/episode/{episode_num}"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANG
    }
    response = requests.get(url, params=params)
    if response.status_code == 200:
        data = response.json()
        episode_title = data.get("name", None)
        season_url = f"https://api.themoviedb.org/3/tv/{tmdb_id}/season/{season_num}"
        season_resp = requests.get(season_url, params=params)
        if season_resp.status_code == 200:
            season_data = season_resp.json()
            season_name = season_data.get("name", None)
        else:
            season_name = None
        return episode_title, season_name
    else:
        Msg(f"Chyba API: {response.status_code} pro TV show {tmdb_id}, sezónu {season_num}, epizodu {episode_num}")
        return None, None

import time

def update_episodes_from_tmdb(limit=2000, delay=0.3):
    Msg("Spouštím doplnění DB pro seriály")
    Info("Spouštím doplnění DB pro seriály", sound=True)
    conn = sqlite3.connect(db_tvshows)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT TMDB_ID, Season_number, Episode_number FROM Live
        WHERE Episode_Originaltitle IS NULL OR Episode_Originaltitle = ''
    """)
    
    rows = cursor.fetchall()

    if limit is not None:
        rows = rows[:limit]

    for tmdb_id, season_num, episode_num in rows:
        if not tmdb_id or not season_num or not episode_num:
            Msg(f"Přeskakuji neúplný záznam: TMDB_ID={tmdb_id}, sezóna={season_num}, epizoda={episode_num}")
            continue
        if addon.getSetting("debug") == "true":
            Msg(f"Načítám info pro TMDB_ID={tmdb_id}, sezóna={season_num}, epizoda={episode_num} ...")
        episode_title, season_name = get_episode_info(tmdb_id, season_num, episode_num)

        if episode_title:
            cursor.execute("""
                            UPDATE Live
                            SET Episode_Originaltitle = ?, Season_name = ?
                            WHERE TMDB_ID = ? AND Season_number = ? AND Episode_number = ?
            """, (episode_title, season_name, tmdb_id, season_num, episode_num))
                      
            # cursor.execute("""
                            # UPDATE Live
                            # SET Episode_Originaltitle = ?, Season_name = ?
                            # WHERE TMDB_ID = ? AND Season_number = ? AND Episode_number = ?
                            # AND (Episode_Originaltitle IS NULL OR Episode_Originaltitle = '')
            # """, (episode_title, season_name, tmdb_id, season_num, episode_num))
            if addon.getSetting("debug") == "true":
                Msg(f"Upraveno: Epizoda='{episode_title}', Sezóna='{season_name}'")
        else:
            Msg("Nenalezeny údaje o epizodě/sezóně.")
        time.sleep(delay)  # prodleva mezi dotazy

    conn.commit()
    conn.close()
    Msg("Hotovo!")
    Info("Hotovo", sound=True)
    
# https://api.themoviedb.org/3/tv/27902/season/1/episode/1?api_key=3c6301e382a803d9c9b52adad044a45a&language=cs-CZ
# https://api.themoviedb.org/3/movie/138034?api_key=3c6301e382a803d9c9b52adad044a45a&language=cs-CZ

#xxxxxxxxxxxxxxxxxx            SQL Query             xxxxxxxxxxxxxxxxxx
# Smazání tabulky DROP TABLE IF EXISTS Live;
# Počet unikátních záznamů SELECT COUNT(DISTINCT TVShow_ID) FROM TVShows;
#Počet neprázdných záznamů SELECT COUNT(TVShow_ID) FROM TVShows;