# Upravuje db
# Mít očištěnou tabulku, kde jsou jen „funkční“ streamy připravené k přehrání nebo zobrazení
# v uživatelském rozhraní — rychlejší a přehlednější načítání dat v addonu.

import os
import sqlite3
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

addon = xbmcaddon.Addon()

folder_path = addon.getSetting('path')
db_path = xbmcvfs.translatePath(folder_path)

db_file = os.path.join(db_path, 'movies.sqlite')

def Info(message, heading=None, icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    if heading is None:
        heading = addon.getAddonInfo('name')
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)

def Msg(message):
    xbmc.log("[Stream Cinema Webshare - Generator] " + message, level=xbmc.LOGINFO)

def LiveStreams_generate():
    Msg("\nSpouštím generování LiveStreams.")
    Info("Spouštím generování", sound=True)

    if not os.path.isfile(db_file):
        Msg(f"[CHYBA] Databázový soubor neexistuje: {db_file}")
        Info("Databáze nenalezena!", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
        return

    try:
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()

        cursor.execute("DROP TABLE IF EXISTS LiveStreams;")
        conn.commit()
        if addon.getSetting("debug") == "true":
            Msg("Příkaz DROP TABLE IF EXISTS LiveStreams proveden.")

        cursor.execute("""
        CREATE TABLE LiveStreams AS
        SELECT Movies.*, Streams.*
        FROM Movies
        INNER JOIN Streams ON Movies.Movie_ID = Streams.Movie_ID
        WHERE Streams.DOWNLOAD_AVAILABLE IS NOT NULL
          AND TRIM(Streams.DOWNLOAD_AVAILABLE) <> ''
        ORDER BY Movies.Year ASC;
        """)
        conn.commit()
        if addon.getSetting("debug") == "true":
            Msg("Tabulka LiveStreams byla vytvořena.")

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='LiveStreams';")
        if addon.getSetting("debug") == "true":
            Msg(f"Existuje tabulka LiveStreams? {cursor.fetchone()}")
        if addon.getSetting("debug") == "true":
            Msg("Struktura tabulky LiveStreams:")
        cursor.execute("PRAGMA table_info(LiveStreams);")
        for row in cursor.fetchall():
            if addon.getSetting("debug") == "true":
                Msg(f"Row: {row}")

        cursor.execute("SELECT COUNT(*) FROM LiveStreams;")
        Msg(f"[SQL] Počet záznamů v LiveStreams: {cursor.fetchone()[0]}")

        conn.close()
        Msg("Hotovo.\n")
        Info("Hotovo", sound=True)

    except Exception as e:
        Msg(f"[CHYBA] {e}")
        Info("Chyba při práci s databází", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
        
        
#Potřebuji na zkoušky ponechat v db jen položky s Movie_ID 5ee203f5c934502b9c4abc95, 659d3cb1b478fca0543fee26, 5f690381296b3c3a9c804f69, 627dff29f6dc6c987791497e, 65a10dd1b478fca05423587a, 604540b7c441b87819a52010. Db má dvě tabulky Movies a Streams
