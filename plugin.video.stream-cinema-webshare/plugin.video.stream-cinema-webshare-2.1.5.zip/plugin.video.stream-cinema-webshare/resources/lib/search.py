
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import xbmcvfs
import requests
import time
import re
import os
import xml.etree.ElementTree as ET
import sys
import json
from urllib.parse import quote_plus
from resources.lib.login import login, api
from resources.lib.db import init_db, insert_video, search_tmdb, clear_db

addon = xbmcaddon.Addon()
profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
history_path = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.stream-cinema-webshare/search_history.json")

limit = int(addon.getSetting("slimit"))
MinSize = float(addon.getSetting("min"))
category = addon.getSetting('scategory')
sort = addon.getSetting('ssort')

MAX_TMDB_FETCH = float(addon.getSetting("sfetch"))

def Msg(message):
    xbmc.log("[Stream Cinema Webshare - Search] " + message, level=xbmc.LOGINFO)

def Info(message, heading=addon.getAddonInfo('name'), icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)
    
def get_news():
    news_items = []
    min_size = MinSize * 1024**3
    init_db()
    token = login()
    offset = 0
    tmdb_fetch_count = 0

    try:
        while True:
            data = {
                "what": "2025 mkv",
                "sort": "recent",
                "limit": limit,
                "offset": offset,
                "category": "video",
                "wst": token
            }

            if addon.getSetting("debug") == "true":
                Msg(f"Data (novinky): {data}")

            response = api("search", data)
            response.raise_for_status()

            root = ET.fromstring(response.text)
            files = root.findall("file")
            if not files:
                break

            for file in files:
                try:
                    name = file.findtext("name", "Neznámý")
                    ident = file.findtext("ident", "")
                    size = int(file.findtext("size", "0"))
                    date = file.findtext("upload_date", "")

                    if size >= min_size:
                        cleaned_name, year = clean_title(name)
                        tmdb_data = search_tmdb(cleaned_name, year=year)
                        tmdb_fetch_count += 1

                        news_items.append({
                            "title": tmdb_data.get("title") or name,
                            "ident": ident,
                            "overview": tmdb_data.get("overview", ""),
                            "poster_url": tmdb_data.get("poster_url", ""),
                            "date": date,
                            "year": tmdb_data.get("year"),
                            "rating": tmdb_data.get("rating"),
                            "runtime": tmdb_data.get("runtime"),
                            "genre": tmdb_data.get("genre")
                        })
                except Exception as e:
                    Msg(f"Chyba při zpracování novinky: {e}")

            offset += limit
            
            Msg(f"Count {tmdb_fetch_count} záznamů\n")
            time.sleep(0.5)
            if tmdb_fetch_count >= MAX_TMDB_FETCH:
                Msg(f"Překročen limit {MAX_TMDB_FETCH} záznamů, ukončuji zpracování\n")
                Info(f"Hotovo", sound=True)
                break

    except Exception as e:
        Msg(f"Chyba při načítání novinek: {e}")

    return news_items

def clean_title(title):
    
    title = re.sub(r'\.\w{2,4}$', '', title) # Odstranit příponu souboru 
    year_match = re.search(r'\b(19\d{2}|20\d{2})\b', title) # Najít rok (1900-2099) 
    year = year_match.group(0) if year_match else None

    if year: # Pokud je rok, vezmeme část nalevo od roku
        title = title.split(year)[0]

    title = re.sub(r'[._\-]+', ' ', title) # Nahradit tečky, podtržítka, pomlčky mezerou 
    title = re.sub(r'\b(uhd|1080p|720p|bluray|dvdrip|x264|web[-]?dl|cz|eng|vykonavatel|s\d{2}e\d{2})\b', '', title, flags=re.I) # Odstranit metadata (kvalita, jazyk, release tagy, epizody)
    title = re.sub(r'\s+', ' ', title).strip() # Odstranit vícenásobné mezery a oříznout
    parts = title.split() # Rozdělit na části a omezit na 3 slova (pokud je víc)
    if len(parts) > 3:
        title = ' '.join(parts[:3])
    else:
        title = ' '.join(parts)

    return title, year

def ask(default=""):
    return xbmcgui.Dialog().input("Zadejte hledaný výraz:", defaultt=default)

def save_search_query(query):
    if not query:
        return

    xbmcvfs.mkdirs(profile_path)

    history = []
    if xbmcvfs.exists(history_path):
        try:
            with xbmcvfs.File(history_path, 'r') as f:
                content = f.read()
                if content:
                    history = json.loads(content)
        except Exception:
            history = []
    if query not in history:
        history.insert(0, query)  # přidá na začátek

    history = history[:20]

    with xbmcvfs.File(history_path, 'w') as f:
        f.write(json.dumps(history, ensure_ascii=False, indent=2))

def clear_history():
    if xbmcvfs.exists(history_path):
        xbmcvfs.delete(history_path)
        Info("Historie hledání byla smazána.")

def list_history():
    handle = int(sys.argv[1])
    if not xbmcvfs.exists(history_path):
        Info("Žádná historie hledání.")
        xbmcplugin.endOfDirectory(handle)
        return

    with open(history_path, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()]
        lines = list(dict.fromkeys(reversed(lines)))

    for query in lines[:30]:
        url = f"{sys.argv[0]}?action=search&query={quote_plus(query)}"
        li = xbmcgui.ListItem(label=query)
        li.setInfo('video', {'title': query})
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

    clear_url = f"{sys.argv[0]}?action=clear_history"
    li = xbmcgui.ListItem(label="[Smazat historii]")
    li.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle, clear_url, li, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

def search_videos():
    query = ask("")
    if query:
        search_query(query, interactive=False)
    else:
        Msg("Nebyl zadán žádný hledaný výraz.")

def search_query(query, interactive=True):
    if interactive:
        new_query = xbmcgui.Dialog().input("Zadejte hledaný výraz:", defaultt=query)
        if not new_query:
            Msg("Hledání bylo zrušeno uživatelem.")
            return
        query = new_query

    save_search_query(query)
    min_size = MinSize * 1024**3
    init_db()
    clear_db()
    token = login()
    Msg(f"Hledám soubory s výrazem: {query}\n")
    Info(f"Hledám soubory {query}.")

    offset = 0
    all_files = []
    tmdb_fetch_count = 0

    while True:
        data = {
            "what": query,
            "sort": sort,
            "limit": limit,
            "offset": offset,
            "category": category,
            "wst": token
        }
        if addon.getSetting("debug") == "true":
            Msg(f"Data: {data}")

        try:
            response = api("search", data)
            response.raise_for_status()

            xml = ET.fromstring(response.text)
            files = xml.findall('file')
            if not files:
                break

            for file in files:
                try:
                    name = file.findtext("name", "Neznámý")
                    ident = file.findtext("ident", "")
                    size = int(file.findtext("size", "0"))

                    # Přeskoč, pokud název neobsahuje hledané slovo
                    Msg(f"Hledám '{query.lower()}' v '{name.lower()}'")
                    if query.lower() not in name.lower():
                        Msg(f"Přeskakuji '{name}', protože neobsahuje '{query}'")
                        continue
                        
                    if size >= min_size:
                        if addon.getSetting("debug") == "true":
                            Msg(f"Nalezený soubor: {name}, ident: {ident}, velikost: {size}")

                        cleaned_name, year = clean_title(name)
                        if addon.getSetting("debug") == "true":
                            Msg(f"Čistím název '{name}' na '{cleaned_name}', rok: {year}")

                        tmdb_data = search_tmdb(cleaned_name, year=year)
                        tmdb_fetch_count += 1

                        insert_video(
                            ident,
                            tmdb_data.get("title") or name,
                            size,
                            tmdb_data.get("tmdb_id"),
                            tmdb_data.get("year"),
                            tmdb_data.get("overview"),
                            tmdb_data.get("rating"),
                            tmdb_data.get("poster_url"),
                            tmdb_data.get("runtime"),
                            tmdb_data.get("genre")
                        )
                        all_files.append((name, ident))
                except Exception as e:
                    Msg(f"Chyba při zpracování položky '{name}': {e}")

            offset += limit
            
            Msg(f"Count {tmdb_fetch_count} záznamů\n")
            time.sleep(0.5)
            if tmdb_fetch_count >= MAX_TMDB_FETCH:
                Msg(f"Překročen limit {MAX_TMDB_FETCH} záznamů, ukončuji zpracování\n")
                Info(f"Hotovo.")
                break

        except Exception as e:
            Msg(f"Chyba při volání API: {e}")
            break

    Msg(f"Celkem nalezeno a uloženo: {len(all_files)} souborů.")
    Info(f"Celkem nalezeno a uloženo {len(all_files)} nových videí.", sound=True)
    xbmc.executebuiltin("Container.Refresh")



