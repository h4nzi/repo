#se současným pluginem nesouvisí, jen příprava

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import re
import xml.etree.ElementTree as ET

from resources.lib.login import login, api
from resources.lib.db import init_db, insert_video, search_tmdb

addon = xbmcaddon.Addon()
extensions = addon.getSetting("ext").split(",")
limit = addon.getSetting("limit")
MinSize = float(addon.getSetting("min"))

def Msg(message):
    xbmc.log("[Stream Cinema Webshare] " + message, level=xbmc.LOGINFO)

def Info(message, heading=addon.getAddonInfo('name'), icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)

def clean_title(title):
    # Odstranit příponu souboru (.mkv, .mp4, .avi, ...)
    title = re.sub(r'\.\w{2,4}$', '', title)
    
    # Nahradit tečky, podtržítka a pomlčky mezerami
    title = re.sub(r'[._-]+', ' ', title)
    
    # Odstranit nadbytečné mezery
    title = title.strip()
    
    # Odstranit kvalitu a další běžné tagy
    title = re.sub(r'\b(uhd|1080p|720p|bluray|dvdrip|x264|web[-]?dl)\b', '', title, flags=re.I)
    
    # Opět odstranit nadbytečné mezery po odstranění tagů
    title = re.sub(r'\s+', ' ', title).strip()
    
    # Rozdělit podle mezer a vzít jen první tři části
    parts = title.split()
    if len(parts) > 3:
        title = ' '.join(parts[:3])
    
    return title

   
def search_videos():
    """Hledá videa na Webshare a ukládá je do databáze s integrací TMDb."""
    min_size = MinSize * 1024**3
    init_db()
    token = login()
    all_files = []
    for ext in extensions:
        Msg(f"Hledám soubory s výrazem: {ext}")
        data = {
            "what": ext,
            "sort": "largest",
            "limit": limit,
            "offset": 0,
            "category": "video",
            "wst": token
        }
            
        response = api("search", data)
        response.raise_for_status()
        xml = ET.fromstring(response.text)
        for file in xml.findall('file'):
            try:
                name = file.findtext("name", "Neznámý")
                ident = file.findtext("ident", "")
                size = int(file.findtext("size", "0"))
                if size >= min_size:
                    if addon.getSetting("debug") == "true":
                        Msg(f"Nalezený soubor: {name}, ident: {ident}, velikost: {size}")

                    cleaned_name = clean_title(name)
                    Msg(f"Čistím název '{name}' na '{cleaned_name}' před vyhledáním TMDb")
                    tmdb_data = search_tmdb(cleaned_name)
                    if addon.getSetting("debug") == "true":
                        if tmdb_data:
                            Msg(f"Search TMDb data pro '{name}': ID={tmdb_data.get('tmdb_id')}, rok={tmdb_data.get('year')}\n")
                        else:
                            Msg(f"Search TMDb data pro '{name}' nebyla nalezena.\n")
                    insert_video(
                            ident,
                            name,
                            size,
                            tmdb_data.get("tmdb_id"),
                            tmdb_data.get("year"),
                            tmdb_data.get("overview"),
                            tmdb_data.get("rating"),
                            tmdb_data.get("poster_url"),
                            tmdb_data.get("runtime")
                        )
                    all_files.append((name, ident, size))
            except Exception as e:
                Msg(f"Chyba při zpracování položky '{name}': {e}")                    
                    
    Msg(f"Celkem nalezeno a uloženo: {len(all_files)} souborů.")
    Info(f"Nalezeno {len(all_files)} nových videí.")
    xbmc.executebuiltin("Container.Refresh")

    return all_files
