import os
import sys
import time
import sqlite3
import requests
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import xml.etree.ElementTree as ET

from resources.lib.login import login, revalidate, api, is_ok, HEADERS, REALM

try:
    from xbmc import translatePath
except ImportError:
    from xbmcvfs import translatePath

addon = xbmcaddon.Addon()

_profile = translatePath(addon.getAddonInfo('profile'))
folder_path = addon.getSetting('path')
db_path = xbmcvfs.translatePath(folder_path)
db_file = os.path.join(db_path, 'movies.sqlite')

def Info(message, heading=addon.getAddonInfo('name'), icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)

def Msg(message):
    xbmc.log("[Stream Cinema Webshare] " + message, level=xbmc.LOGINFO)

def repair():
    Info("Spouštím opravy", sound=True)
    Msg(f"\n[Repair] Spouštím Repair")

    token = login()
    if not token:
        Info("Nelze získat token (WST)", icon=xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()

        # Vytvoření tabulky Live, pokud neexistuje
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='Live'")
        if not cursor.fetchone():
            cursor.execute("CREATE TABLE Live AS SELECT * FROM LiveStreams WHERE 0")

        cursor.execute("SELECT * FROM LiveStreams WHERE Provider_Ident IS NOT NULL")
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()

        ok, fail, skipped = 0, 0, 0
        Msg(f"[Repair] Ke zpracování: {len(rows)}")

        for row in rows:
            row_dict = dict(zip(columns, row))
            ident = row_dict.get("Provider_Ident")

            if not ident:
                Msg(f"[Repair] PŘESKOČENO: ident chybí")
                skipped += 1
                continue

            if (ok + fail) % 250 == 0 and (ok + fail) > 0:
                conn.commit()
                Msg(f"[Repair] Commit po {ok + fail} záznamech")

            data = {'ident': ident, 'wst': token, 'device_uuid': addon.getSetting('duuid')}
            xml = None
            for attempt in range(3):
                try:
                    response = api('file_link', data)
                    if addon.getSetting("debug") == "true":
                        Msg(f"[Repair] API odpověď pro {ident} (pokus {attempt+1}): {response.text[:200]}")
                    xml = ET.fromstring(response.content)
                    if is_ok(xml):
                        break
                except Exception as e:
                    Msg(f"[Repair] Pokus {attempt+1} selhal: {e}")
                    time.sleep(1.0)

            if not xml or not is_ok(xml):
                Msg(f"[Repair] Chyba nebo neplatný status pro ident {ident}")
                fail += 1
                continue

            new_link = xml.findtext('link')
            Msg(f"[Repair] Nalezený link {new_link}")
            if not new_link:
                Msg(f"[Repair] <link> chybí pro ident {ident}")
                fail += 1
                continue

            row_dict['DOWNLOAD_AVAILABLE'] = new_link
            valid_columns = [col for col in columns if ':' not in col]
            placeholders = ','.join(['?'] * len(valid_columns))
            insert_sql = f"INSERT INTO Live ({','.join(valid_columns)}) VALUES ({placeholders})"

            try:
                cursor.execute(insert_sql, [row_dict[col] for col in valid_columns])
                ok += 1
                Msg(f"[Repair] OK: {ident}\n")
            except Exception as e:
                Msg(f"[Repair] CHYBA při vkládání {ident}: {str(e)}")
                fail += 1

        conn.commit()
        conn.close()

        Info(f"OK: {ok}, Fail: {fail}, Skip: {skipped}", icon=xbmcgui.NOTIFICATION_INFO)
        Msg(f"[Repair] Výsledek: OK: {ok}, Fail: {fail}, Skip: {skipped}")

    except Exception as e:
        import traceback
        traceback.print_exc()
        Info(f"Chyba: {str(e)}", icon=xbmcgui.NOTIFICATION_ERROR)
        Msg(f"[Repair] Chyba: {str(e)}")
