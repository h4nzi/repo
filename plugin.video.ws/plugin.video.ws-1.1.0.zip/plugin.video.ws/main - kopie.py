# default.py
import sys
import os
import urllib.parse
import xbmcaddon
import xbmcplugin
import xbmcgui
import xbmcvfs

from resources.lib.repairer import repair
from resources.lib.generator import LiveStreams_generate
from resources.lib.strm import generate_strm_movies
from resources.lib.test import test, search_files

_addon = xbmcaddon.Addon()
_handle = int(sys.argv[1])
_base_url = sys.argv[0]


def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)
    
Msg(f"[DEBUG] Handle: {_handle}")

def Info(message, heading=None, icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    if heading is None:
        heading = _addon.getAddonInfo('name')
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)

def get_url(**kwargs):
    return _base_url + '?' + urllib.parse.urlencode(kwargs)
    
# def show_movies():
    # # Cesta ke složce s .strm soubory
    # strm_path = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.ws/strm_movies/")
    # Info("Načítám data", icon=xbmcgui.NOTIFICATION_INFO, sound=True)
    # for filename in sorted(os.listdir(strm_path)):
        # if filename.endswith(".strm"):
            # title = os.path.splitext(filename)[0]
            # file_path = os.path.join(strm_path, filename)
            # Msg(f"File path: {file_path}")

            # listitem = xbmcgui.ListItem(label=title)
            # listitem.setPath(file_path)
            # listitem.setProperty("IsPlayable", "true")

            # xbmcplugin.addDirectoryItem(_handle, file_path, listitem, isFolder=False)

    # xbmcplugin.endOfDirectory(_handle)
    

import os

def show_movies():
    Info("Načítám data", icon=xbmcgui.NOTIFICATION_INFO, sound=True)

    listitem = xbmcgui.ListItem(label="Testovací Film")
    listitem.setPath("plugin://plugin.video.yawsp/?action=play&ident=test&name=Testovací Film")
    listitem.setProperty("IsPlayable", "true")

    xbmcplugin.addDirectoryItem(_handle, 
                                "plugin://plugin.video.yawsp/?action=play&ident=test&name=Testovací Film", 
                                listitem, 
                                isFolder=True)

    xbmcplugin.endOfDirectory(_handle)








def menu():
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name'))

    items = [
        ("Filmy", "movies", 'DefaultMovies.png'),
        ("Generovat .strm", "strm", 'DefaultVideo.png'),
        # ("Opravit odkazy", "repair", 'DefaultScript.png'),
        # ("Generovat tabulku", "generate", 'DefaultFolder.png'),
        # ("Test / hledání", "test", 'DefaultAddonsSearch.png'),
        ("Nastavení", "settings", 'DefaultAddonSettings.png'),
    ]
    
    for label, action, icon in items:
        listitem = xbmcgui.ListItem(label=label)
        listitem.setArt({'icon': icon, 'thumb': icon})
        url = get_url(action=action)
        xbmcplugin.addDirectoryItem(_handle, url, listitem, isFolder=False)

    xbmcplugin.endOfDirectory(_handle)
    
# def menu():
    # revalidate()
    # xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name'))

    # # 1. History
    # listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30203))
    # listitem.setArt({'icon': 'DefaultAddonsUpdates.png'})
    # xbmcplugin.addDirectoryItem(_handle, get_url(action='history'), listitem, True)

    # # 2. Search
    # listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30201))
    # listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
    # xbmcplugin.addDirectoryItem(_handle, get_url(action='search'), listitem, True)

    # # 3. Queue
    # listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30202))
    # listitem.setArt({'icon': 'DefaultPlaylist.png'})
    # xbmcplugin.addDirectoryItem(_handle, get_url(action='queue'), listitem, True)

    # # 4. Backup DB (jen pokud experimental = true)
    # if 'true' == _addon.getSetting('experimental'):
        # listitem = xbmcgui.ListItem(label='Backup DB')
        # listitem.setArt({'icon': 'DefaultAddonsZip.png'})
        # xbmcplugin.addDirectoryItem(_handle, get_url(action='db'), listitem, True)

    # # 5. Settings
    # listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30204))
    # listitem.setArt({'icon': 'DefaultAddonService.png'})
    # xbmcplugin.addDirectoryItem(_handle, get_url(action='settings'), listitem, False)

    # xbmcplugin.endOfDirectory(_handle)


    
def router(params):
    action = params.get('action')
    # if action == 'generate':
        # LiveStreams_generate()
    if action == 'movies':
        show_movies()
    # elif action == 'repair':
        # repair()
    elif action == 'strm':
        generate_strm_movies()
    # elif action == 'test':
        # search_files()
    elif action == 'settings':
        _addon.openSettings()
    else:
        menu()

if __name__ == "__main__":
    args = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    router(args)

