# default.py
import sys
import os
import urllib.parse
import xbmcaddon
import xbmcplugin
import xbmcgui
import xbmcvfs

from resources.lib.repairer import repair
from resources.lib.generator import LiveStreams_generate
from resources.lib.strm import generate_strm_movies
from resources.lib.test import test, search_files

_addon = xbmcaddon.Addon()
_handle = int(sys.argv[1])
_base_url = sys.argv[0]

strm_path = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.ws/strm_movies/")


def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)

def Info(message, heading=None, icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    if heading is None:
        heading = _addon.getAddonInfo('name')
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)

def get_url(**kwargs):
    return _base_url + '?' + urllib.parse.urlencode(kwargs)

def show_movies():
    xbmcplugin.setPluginCategory(_handle, "Filmy")
    xbmcplugin.setContent(_handle, "movies")

    for filename in os.listdir(strm_path):
        if filename.endswith(".strm"):
            title = os.path.splitext(filename)[0]
            file_path = os.path.join(strm_path, filename)
            li = xbmcgui.ListItem(label=title)
            li.setPath(file_path)
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(_handle, file_path, li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle)
    
def menu():
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name'))

    items = [
        ("Filmy", "movies", 'DefaultMovies.png', True),
        ("Generovat strm soubory", "strm", 'DefaultVideo.png', False),
        ("Opravit odkazy", "repair", 'DefaultScript.png', False),
        ("Generovat tabulku", "generate", 'DefaultFolder.png', False),
        ("Test / hledání", "test", 'DefaultAddonsSearch.png', False),
        ("Nastavení", "settings", 'DefaultAddonSettings.png', False),
        # Přidej další položky:
        # ("Historie", "history", 'DefaultHistory.png', True),
        # ("Nastavení zálohy", "backup", 'DefaultAddonService.png', False),
    ]
    
    for label, action, icon, is_folder in items:
        listitem = xbmcgui.ListItem(label=label)
        listitem.setArt({'icon': icon, 'thumb': icon})
        url = get_url(action=action)
        xbmcplugin.addDirectoryItem(_handle, url, listitem, isFolder=is_folder)

    xbmcplugin.endOfDirectory(_handle)

def router(params):
    action = params.get('action')
    if action == 'movies':
        show_movies()
    elif action == 'strm':
        generate_strm_movies()
    elif action == 'repair':
        repair()
    elif action == 'generate':
        LiveStreams_generate()
    elif action == 'test':
        search_files()
    elif action == 'settings':
        _addon.openSettings()
    elif action == 'history':
        show_history()
    elif action == 'backup':
        backup_settings()
    else:
        menu()


if __name__ == "__main__":
    args = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    router(args)

