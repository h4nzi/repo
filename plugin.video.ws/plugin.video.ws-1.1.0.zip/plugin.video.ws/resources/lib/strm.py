import os
import xbmc
import sqlite3
import xbmcgui
import xbmcaddon
import xbmcvfs
import traceback

addon = xbmcaddon.Addon()

folder_path = addon.getSetting('path')
db_path = xbmcvfs.translatePath(folder_path)

strm_path = addon.getSetting('output_folder')
output = xbmcvfs.translatePath(strm_path)

db_file = os.path.join(db_path, 'movies.sqlite')
output_folder = os.path.join(output, "strm_movies")

if not xbmcvfs.exists(output_folder):
    xbmcvfs.mkdirs(output_folder)

def Info(message, heading=addon.getAddonInfo('name'), icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)
    
def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)

def generate_strm_movies(): #JiRo
    Msg("[SQL] Spouštím generování strm souborů")
    Info("Spouštím generování strm souborů", sound=True)
    try:
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                COALESCE(NULLIF(TRIM(OriginalTitle), ''), Title) AS FinalTitle,
                DOWNLOAD_AVAILABLE,
                Video_Height,
                Provider_Ident
            FROM Live
            WHERE Video_Height >= 720
        """)

        rows = cursor.fetchall()
        count = 0

        for title, url, height, provider_ident in rows:
            if not title or not url:
                continue

            safe_title = "".join(c for c in title if c.isalnum() or c in " _-.").strip()
            filename = os.path.join(output_folder, f"{safe_title}.strm")

            with open(filename, "w", encoding="utf-8") as f:
                url = 'plugin://plugin.video.yawsp/?action=play&ident={0}&name={0}'.format(provider_ident)
                Msg(f"URL strm: {url}")
                f.write(url)
            count += 1

        conn.close()
        xbmcgui.Dialog().notification(addon.getAddonInfo('name'), f"Vytvořeno {count} .strm souborů", xbmcgui.NOTIFICATION_INFO, 3000)

    except Exception as e:
        xbmcgui.Dialog().notification("Chyba", str(e), xbmcgui.NOTIFICATION_ERROR, 5000)
        import traceback
        traceback.print_exc()
