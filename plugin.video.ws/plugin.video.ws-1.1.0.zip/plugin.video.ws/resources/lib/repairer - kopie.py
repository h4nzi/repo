import os
import sys
import time
import sqlite3
import hashlib
import requests
import xbmc
import xbmcgui
import xbmcaddon
import xml.etree.ElementTree as ET
import xbmcvfs
from resources.lib.md5crypt import md5crypt

# Import funkce pro převod cesty (pro různé verze Kodi)
try:
    from xbmc import translatePath
except ImportError:
    from xbmcvfs import translatePath

# Nastavení konstant pro API a hlaviček
BASE = 'https://webshare.cz'
API = BASE + '/api/'
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36"
HEADERS = {'User-Agent': UA, 'Referer': BASE}
REALM = ':Webshare:'

# Inicializace doplňku a session
addon = xbmcaddon.Addon()
_session = requests.Session()
_session.headers.update(HEADERS)

# Překlad cesty k databázovému souboru
_profile = translatePath(addon.getAddonInfo('profile'))
folder_path = addon.getSetting('path')
db_path = xbmcvfs.translatePath(folder_path)
db_file = os.path.join(db_path, 'movies.sqlite')

# Funkce pro volání Webshare API
def api(fnct, data):
    return _session.post(API + fnct + "/", data=data)

# Zobrazení notifikace v Kodi
def Info(message, heading=addon.getAddonInfo('name'), icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)

# Zápis zprávy do Kodi logu
def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)

# Kontrola, jestli odpověď API obsahuje status OK
def is_ok(xml):
    return xml is not None and xml.findtext('status') == 'OK'

# Přihlášení k Webshare a získání tokenu
def login():
    # Načte přihlašovací údaje z nastavení
    username = addon.getSetting('wsuser')
    password = addon.getSetting('wspass')

    # Pokud nejsou vyplněné, otevře nastavení
    if not username or not password:
        Info("Nejdříve si musíte na Webshare založit účet.", sound=True)
        addon.openSettings()
        return

    # Zde žádá API o salt podle uživatelského jména (zde hledá ident)
    response = api('salt', {'username_or_email': username})
    xml = ET.fromstring(response.content)

    # Pokud API vrátí OK, pokračuje
    if is_ok(xml):
        new_link = xml.findtext('link')
        if new_link:
            # Zde vypisuje nově nalezený link (debug)
            Msg(f"[Repair] ident={ident} | Link: {new_link}")
            # Zde se nalezený link ukládá do struktury (zde se neukládá do DB!)
            row_dict['DOWNLOAD_AVAILABLE'] = new_link
            try:
                # Zde vkládá nový záznam do tabulky Live (pokud by to bylo relevantní)
                cursor.execute(insert_sql, [row_dict[col] for col in valid_columns])
                ok_free += 1
            except Exception as e:
                Msg(f"[Repair] CHYBA při vkládání FREE {ident}: {str(e)}")
                fail += 1
        else:
            Msg(f"[Repair] API OK, ale chybí <link> pro ident {ident}")
            fail += 1

        # Zde se z odpovědi znovu vytahuje token
        xml = ET.fromstring(response.content)
        if is_ok(xml):
            token = xml.find('token').text
            # Uloží token do nastavení
            if addon.getSetting("debug") == "true":
                Msg(f"[Repair] Token: {token}")
            addon.setSetting('token', token)
            return token
        else:
            Info("Neplatné přihlašovací údaje!", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
            addon.openSettings()
    else:
        Info("Chyba přihlašování (salt)!", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
        addon.openSettings()

# Funkce pro ověření, případně obnovu tokenu
def revalidate():
    token = addon.getSetting('token')
    if addon.getSetting("debug") == "true":
        Msg(f"[Repair] Renew Token: {token}")

    # Pokud token chybí, spustí přihlášení
    if not token:
        if login():
            return revalidate()
    else:
        # Zde se podle tokenu ptá API na data uživatele
        response = api('user_data', { 'wst': token })
        if addon.getSetting("debug") == "true":
            Msg(f"[Repair] Renew Response: {response}")
        xml = ET.fromstring(response.content)

        if is_ok(xml):
            # Kontrola, zda má uživatel VIP status
            if xml.findtext('vip') != '1':
                Info("Neplatné VIP.", icon=xbmcgui.NOTIFICATION_WARNING)
            return token
        else:
            # Pokud token expiroval, zkusí se přihlásit znovu
            if login():
                return revalidate()

# Hlavní funkce opravující záznamy v databázi
def repair():
    Info("Spouštím opravy", sound=True)
    Msg(f"\n[Repair] Spouštím Repair")

    # Ověření nebo získání tokenu
    token = revalidate()
    if not token:
        Info("Nelze získat token (WST)", icon=xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        # Otevření SQLite databáze
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()

        # Pokud tabulka Live neexistuje, vytvoří ji
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='Live'")
        if not cursor.fetchone():
            cursor.execute("CREATE TABLE Live AS SELECT * FROM LiveStreams WHERE 0")

        # Načtení všech záznamů s vyplněným identem
        cursor.execute("SELECT * FROM LiveStreams WHERE Provider_Ident IS NOT NULL")
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()

        ok, fail, skipped = 0, 0, 0
        Msg(f"[Repair] Ke zpracování: {len(rows)}")

        # Pro každý řádek v tabulce
        for row in rows:
            row_dict = dict(zip(columns, row))
            ident = row_dict.get("Provider_Ident")  # Zde hledá ident

            # Pokud ident chybí, přeskočí
            if not ident:
                Msg(f"[Repair] PŘESKOČENO: ident chybí")
                skipped += 1
                continue

            # Každých 250 záznamů commitne
            if (ok + fail) % 250 == 0 and (ok + fail) > 0:
                conn.commit()
                Msg(f"[Repair] Commit po {ok + fail} záznamech")

            # Zde se podle identu ptá na link
            data = {'ident': ident, 'wst': token, 'device_uuid': addon.getSetting('duuid')}
            xml = None
            for attempt in range(3):  # Retry mechanismus
                try:
                    response = api('file_link', data)
                    if addon.getSetting("debug") == "true":
                        Msg(f"[Repair] API odpověď pro {ident} (pokus {attempt+1}): {response.text[:200]}")
                    xml = ET.fromstring(response.content)
                    if is_ok(xml):
                        break
                except Exception as e:
                    Msg(f"[Repair] Pokus {attempt+1} selhal: {e}")
                    time.sleep(1.0)

            # Pokud odpověď není OK, přeskočí
            if not xml or not is_ok(xml):
                Msg(f"[Repair] Chyba nebo neplatný status pro ident {ident}")
                fail += 1
                continue

            # Zde získává link z odpovědi
            new_link = xml.findtext('link')
            Msg(f"[Repair] Nalezený link {new_link}")
            if not new_link:
                Msg(f"[Repair] <link> chybí pro ident {ident}")
                fail += 1
                continue

            # Zde nalezený link ukládá do Live
            row_dict['DOWNLOAD_AVAILABLE'] = new_link
            valid_columns = [col for col in columns if ':' not in col]
            placeholders = ','.join(['?'] * len(valid_columns))
            insert_sql = f"INSERT INTO Live ({','.join(valid_columns)}) VALUES ({placeholders})"

            try:
                # Uložení záznamu do tabulky Live
                cursor.execute(insert_sql, [row_dict[col] for col in valid_columns])
                ok += 1
                Msg(f"[Repair] OK: {ident}\n")
            except Exception as e:
                Msg(f"[Repair] CHYBA při vkládání {ident}: {str(e)}")
                fail += 1

        # Uložení změn a uzavření spojení s databází
        conn.commit()
        conn.close()

        # Výpis výsledků
        Info(f"OK: {ok}, Fail: {fail}, Skip: {skipped}", icon=xbmcgui.NOTIFICATION_INFO)
        Msg(f"[Repair] Výsledek: OK: {ok}, Fail: {fail}, Skip: {skipped}")

    except Exception as e:
        import traceback
        traceback.print_exc()
        Info(f"Chyba: {str(e)}", icon=xbmcgui.NOTIFICATION_ERROR)
        Msg(f"[Repair] Chyba: {str(e)}")
