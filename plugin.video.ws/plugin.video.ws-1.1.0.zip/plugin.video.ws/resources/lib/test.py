import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import difflib
import requests
import xml.etree.ElementTree as ET

from resources.lib.login import login, revalidate, api, is_ok, HEADERS, REALM

addon = xbmcaddon.Addon()

def Msg(message):
    xbmc.log("[Webshare] " + message, level=xbmc.LOGINFO)
    
def Info(message, heading=addon.getAddonInfo('name'), icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)

def get_vip_link(ident, token):
    device_uuid = addon.getSetting('duuid')
    data = {'ident': ident, 'wst': token, 'device_uuid': device_uuid}
    response = api('file_link', data)
    try:
        xml = ET.fromstring(response.content)
        if is_ok(xml):
            return xml.findtext('link')
        else:
            Msg("API odpověď není OK.")
    except ET.ParseError as e:
        Msg(f"Chyba při zpracování XML: {e}")
    return None

def get_file_size(url):
    try:
        r = requests.head(url, allow_redirects=True, timeout=10)
        size = r.headers.get('Content-Length')
        if size:
            return int(size)
        else:
            Msg("Content-Length nebyl nalezen v hlavičce.")
    except Exception as e:
        Msg(f"Chyba při získávání velikosti: {e}")
    return None

def test():
    ident = "6QriyUcqy2"  # zadej svůj ident
    Msg(f"Získávám VIP odkaz pro ident: {ident}")
    token = login()
    if token:
        link = get_vip_link(ident, token)
        if link:
            Msg(f"VIP link: {link}")
            size = get_file_size(link)
            if size:
                Info(f"Velikost souboru: {round(size / (1024*1024*1024), 2)} GB")
            else:
                Info("Velikost souboru není k dispozici.", icon=xbmcgui.NOTIFICATION_WARNING)

            xbmc.executebuiltin(f'PlayMedia({link})')
        else:
            Msg("Nepodařilo se získat VIP link.")
            Info("Nepodařilo se získat VIP link.", icon=xbmcgui.NOTIFICATION_ERROR)
    else:
        Msg("Autentizace selhala.")
        Info("Autentizace selhala.", icon=xbmcgui.NOTIFICATION_ERROR)

def search_files(min_size=0.5 * 1024**3, max_size=2 * 1024**3, extensions=["Babičky"], limit=1000):
    token = login()
    all_files = []

    for ext in extensions:
        Msg(f"Hledám soubory s příponou {ext}")
        data = {
            "what": ext,
            "limit": limit,
            "offset": 0,
            "category": "video",
            "wst": token
        }

        try:
            response = api("search", data)
            response.raise_for_status()
            xml = ET.fromstring(response.text)
            for file in xml.findall('file'):
                try:
                    name = file.findtext("name", "Neznámý")
                    ident = file.findtext("ident", "")
                    size = int(file.findtext("size", "0"))
                    if min_size <= size <= max_size:
                        Msg(f"Nalezený soubor: {name}, ident: {ident}, velikost: {size}")
                        all_files.append((name, ident, size))

                except Exception as e:
                    Msg(f"Chyba při zpracování položky: {e}")
        except Exception as e:
            Msg(f"Chyba při vyhledávání {ext}: {e}")

    # Skupiny podobných názvů podle difflib
    names = [f[0] for f in all_files]
    groups = {}

    for name in names:
        matches = difflib.get_close_matches(name, names, n=10, cutoff=0.8)
        if len(matches) > 1:
            key = tuple(sorted(matches))
            groups[key] = groups.get(key, set()).union(matches)

    if groups:
        Msg("Nalezené možné seriály:")
        for group in groups.values():
            Msg(f"  ➤ Skupina: {', '.join(group)}")
    else:
        Msg("Nebyly nalezeny žádné podobné názvy.")
    
    if not all_files:
        Info("Nebyly nalezeny žádné odpovídající soubory.", icon=xbmcgui.NOTIFICATION_WARNING)
