import sys
import xbmc
import xbmcgui
import xbmcplugin
from urllib.parse import parse_qsl, urlencode

ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

# Streamy
STREAMS = {
    "Noe Plus": "https://n106.quickmedia.tv/noetvplus/live/noetvplus/Shz3_1_1/playlist.m3u8",
    "Noe": "https://n106.quickmedia.tv/noetv/live/noetv/Ifd4_1_4/playlist.m3u8"
}

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)
def MsgWrn(message):
    xbmc.log(message, level=xbmc.LOGWARNING)
def MsgErr(message):
    xbmc.log(message, level=xbmc.LOGERROR)
def MsgDbg(message):
    xbmc.log(message, level=xbmc.LOGDEBUG)

def build_url(query):
    return BASE_URL + "?" + urlencode(query)

def list_videos():
    for name, url in STREAMS.items():
        stream_url = build_url({'action': 'play', 'video': url})
        li = xbmcgui.ListItem(label=name)
        li.setInfo('video', {'title': name, 'genre': 'Live TV'})
        li.setArt({'thumb': 'icon.png', 'icon': 'icon.png', 'fanart': 'icon.png'})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=stream_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_video(path):
    play_item = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=play_item)
    player = xbmc.Player()
    while not player.isPlayingVideo():
        xbmc.sleep(100)

    while player.isPlayingVideo():
        xbmc.sleep(500)  # Kontrola běhu přehrávače kařdých 500 ms

    dialog = xbmcgui.Dialog()
    choice = dialog.select("Jak pokračovat?", ["Výběr Noe kanálů", "Domů"])
    
    if choice == 0:
        xbmc.executebuiltin(f"ActivateWindow(Videos,{BASE_URL})")
    elif choice == 1:
        xbmc.executebuiltin("ActivateWindow(Home)")

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params['action'] == 'play':
            play_video(params['video'])
    else:
        list_videos()

if __name__ == '__main__':
    router(sys.argv[2][1:])
