__NOTICE__

__This addon is no longer maintained by me, if you are interested in taking it over then please contact me via the Issues section. (You are welcome to submit it to the official Kodi Repo - just make sure you remove my name from it before you do it)__


![AudioBooks](icon.png)

AudioBooks is an addon that allows you to list and play your m4b AudioBooks using Kodi. (As well as an improved interface for mp3/flac audiobooks)

Please read the wiki for details on how to get the best out of the AudioBooks addon, including m4b chapter support:

[Add-on:AudioBooks](https://github.com/robwebset/script.audiobooks/wiki)

_Note:_ It is strongly recommended, if you are not running on Windows, that you also install the script.module.ffmpeg addon as detailed in the Wiki.

