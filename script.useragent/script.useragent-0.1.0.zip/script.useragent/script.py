# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon

addon = xbmcaddon.Addon()
addonName = addon.getAddonInfo('name')
addonVersion = addon.getAddonInfo('version')

def logInfo(text, addon = addonName):
    xbmc.log('[{}] {}'.format(addon,text), xbmc.LOGINFO)

if __name__ == '__main__':
    logInfo('Get User Agent (UA) string, version: {}'.format(addonVersion))
    userAgent = xbmc.getUserAgent()
    logInfo('UA = {}'.format(userAgent))
        