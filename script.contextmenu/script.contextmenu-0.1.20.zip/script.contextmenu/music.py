# -*- coding: utf-8 -*-

import xbmc

xbmc.executebuiltin('Addon.OpenSettings(script.backgroundmusic)')
