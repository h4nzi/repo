# -*- coding: utf-8 -*-

import xbmc
import sys
from urllib.parse import quote

from resources.lib.utils import getParam, getSettingBool, localizedStr, logNot, logErr

# Společná šablona pro spuštění pluginu
COMMON_BUILTIN = 'ActivateWindow(videos,"plugin://{}{}",return)'

# YAWSP (výchozí)
YAWSP_ADDON = 'plugin.video.yawsp'
YAWSP_ENABLE = 'enable_search_yawsp'
YAWSP_COMMAND = '{}'
YAWSP_URL = '/?action=search&what={}'

# SKT Online
SKT_ADDON = 'plugin.video.sktonline'
SKT_ENABLE = 'enable_search_sktonline'
SKT_COMMAND = '{}'
SKT_URL = '/?action=search&query={}'

# Hellspy
HELLSPY_ADDON = 'plugin.video.hellspy'
HELLSPY_ENABLE = 'enable_search_hellspy'
HELLSPY_COMMAND = '{}'
HELLSPY_URL = '/?action=direct&query={}'

def nothingToDo():
    logNot('Search - Nothing to do')

def setUrl(value, url=None, addon=None):
    if url is None:
        url = COMMON_BUILTIN
    if addon is None:
        return url.format(value)
    else:
        return url.format(addon, value)

def getSearchString():
    dbType = xbmc.getInfoLabel('ListItem.DBTYPE')
    logNot('DBTYPE: {}'.format(dbType))
    if dbType == 'movie':
        return xbmc.getInfoLabel('ListItem.Title')
    elif dbType == 'tvshow':
        return xbmc.getInfoLabel('ListItem.TVShowTitle')
    elif dbType == 'season':
        return '{0} S{1:02d}'.format(
            xbmc.getInfoLabel('ListItem.TVShowTitle'),
            int(xbmc.getInfoLabel('ListItem.Season'))
        )
    elif dbType == 'episode':
        return '{0} S{1:02d}E{2:02d}'.format(
            xbmc.getInfoLabel('ListItem.TVShowTitle'),
            int(xbmc.getInfoLabel('ListItem.Season')),
            int(xbmc.getInfoLabel('ListItem.Episode'))
        )
    else:
        return None

if __name__ == '__main__':
    howToSearch = getParam(1)
    logNot('howToSearch: {}'.format(howToSearch))

    searchString = getSearchString()
    if not searchString:
        nothingToDo()
    else:
        encoded = quote(searchString)

        if howToSearch == 'default':
            searchUrl = setUrl(encoded, YAWSP_URL)
            addonCommand = setUrl(searchUrl, YAWSP_COMMAND)
            builtinCommand = setUrl(addonCommand, COMMON_BUILTIN, YAWSP_ADDON)
            logNot('YAWSP search command: {}'.format(builtinCommand))
            xbmc.executebuiltin(builtinCommand)

        elif howToSearch == 'sktonline':
            searchUrl = setUrl(encoded, SKT_URL)
            addonCommand = setUrl(searchUrl, SKT_COMMAND)
            builtinCommand = setUrl(addonCommand, COMMON_BUILTIN, SKT_ADDON)
            logNot('SKT search command: {}'.format(builtinCommand))
            xbmc.executebuiltin(builtinCommand)

        elif howToSearch == 'hellspy':
            searchUrl = setUrl(encoded, HELLSPY_URL)
            addonCommand = setUrl(searchUrl, HELLSPY_COMMAND)
            builtinCommand = setUrl(addonCommand, COMMON_BUILTIN, HELLSPY_ADDON)
            logNot('HELLSPY search command: {}'.format(builtinCommand))
            xbmc.executebuiltin(builtinCommand)

        else:
            nothingToDo()
