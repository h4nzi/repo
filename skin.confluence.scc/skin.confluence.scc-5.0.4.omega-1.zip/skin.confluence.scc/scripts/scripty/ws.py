# -*- coding: utf-8 -*-

import subprocess
import socket
import xbmcgui

dialog = xbmcgui.Dialog()

output = subprocess.check_output(['netstat', '-tulan']).decode('utf-8')
dns_names = []

for line in output.splitlines():
    parts = line.split()
    if len(parts) >= 6 and parts[4].startswith('185.201'):
        ip = parts[4].split(':')[0]
        try:
            hostname = socket.gethostbyaddr(ip)
            dns_names.append(f"{hostname[0]}")
        except socket.herror:
            pass
dns_name = ', '.join(dns_names)
xbmcgui.Window(10000).setProperty('WS', dns_name)
dialog.notification("Check DNS Name", dns_name,  xbmcgui.NOTIFICATION_INFO, 2000)






