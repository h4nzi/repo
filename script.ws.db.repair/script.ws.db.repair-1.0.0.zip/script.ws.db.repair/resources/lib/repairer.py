import sys
import time
import sqlite3
import hashlib
import requests
import xbmc
import xbmcgui
import xbmcaddon
import xml.etree.ElementTree as ET
from xbmcvfs import translatePath
from resources.lib.md5crypt import md5crypt


try:
    from xbmc import translatePath
except ImportError:
    from xbmcvfs import translatePath

BASE = 'https://webshare.cz'
API = BASE + '/api/'
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36"
HEADERS = {'User-Agent': UA, 'Referer':BASE}
REALM = ':Webshare:'

addon = xbmcaddon.Addon()

_session = requests.Session()
_session.headers.update(HEADERS)
_profile = translatePath(addon.getAddonInfo('profile'))

def api(fnct, data):
    response = _session.post(API + fnct + "/", data=data)
    return response

def Info(message, heading=addon.getAddonInfo('name'), icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)
    
def is_ok(xml):
    status = xml.find('status').text
    return status == 'OK'

def login():
    username = addon.getSetting('wsuser')
    password = addon.getSetting('wspass')
    if username == '' or password == '':
        Info("Nejdříve si musíte na Webshare založit účet.", sound=True)
        addon.openSettings()
        return
    response = api('salt', {'username_or_email': username})
    xml = ET.fromstring(response.content)
    if is_ok(xml):
        salt = xml.find('salt').text
        try:
            encrypted_pass = hashlib.sha1(md5crypt(password.encode('utf-8'), salt.encode('utf-8'))).hexdigest()
            pass_digest = hashlib.md5(username.encode('utf-8') + REALM + encrypted_pass.encode('utf-8')).hexdigest()
        except TypeError:
            encrypted_pass = hashlib.sha1(md5crypt(password.encode('utf-8'), salt.encode('utf-8')).encode('utf-8')).hexdigest()
            pass_digest = hashlib.md5(username.encode('utf-8') + REALM.encode('utf-8') + encrypted_pass.encode('utf-8')).hexdigest()
        response = api('login', {'username_or_email': username, 'password': encrypted_pass, 'digest': pass_digest, 'keep_logged_in': 1})
        xml = ET.fromstring(response.content)
        if is_ok(xml):
            token = xml.find('token').text
            if addon.getSetting("debug") == "true":
                Msg(f"[Repair] Token: {token}")
            addon.setSetting('token', token)
            return token
        else:
            Info("Neplatné přihlašovací údaje!", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)

            addon.openSettings()
    else:
        Info("Neplatné přihlašovací údaje!", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
        addon.openSettings()

def revalidate():
    token = addon.getSetting('token')
    if addon.getSetting("debug") == "true":
        Msg(f"[Repair] Renew Token: {token}")
    if len(token) == 0:
        if login():
            return revalidate()
    else:
        response = api('user_data', { 'wst': token })
        if addon.getSetting("debug") == "true":
            Msg(f"[Repair] Renew Response: {response}")
        xml = ET.fromstring(response.content)
        if is_ok(xml):
            vip = xml.find('vip').text
            if vip != '1':
                Info("Neplatné VIP.", icon=xbmcgui.NOTIFICATION_WARNING)
            return token
        else:
            if login():
                return revalidate()
                
                
def repair():
    Info("Spouštím opravy", sound=True)
    Msg(f"\n[Repair] Spouštím Repair")
    db_path = "/storage/data/test/movies.sqlite"
    token = revalidate()

    if not token:
        Info("Nelze získat token (WST)", icon=xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='Live'")
        if not cursor.fetchone():
            cursor.execute("CREATE TABLE Live AS SELECT * FROM LiveStreams WHERE 0")

        cursor.execute("""
            SELECT * FROM LiveStreams
            WHERE DOWNLOAD_AVAILABLE LIKE '%://free.%'
               OR DOWNLOAD_AVAILABLE LIKE '%://vip.%'
        """)
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()

        ok_vip, ok_free, fail, skipped = 0, 0, 0, 0

        if addon.getSetting("debug") == "true":
            Msg(f"[Repair] Ke zpracování: {len(rows)}")

        for row in rows:
            if ok_vip + ok_free > 0 and (ok_vip + ok_free) % 250 == 0:
                conn.commit()
                Msg(f"[Repair] Commit proveden po {ok_vip + ok_free} záznamech")
            row_dict = dict(zip(columns, row))
            ident = row_dict.get("Provider_Ident")
            url = row_dict.get("DOWNLOAD_AVAILABLE", "")

            if not url or not ident:
                Msg(f"[Repair] PŘESKOČENO: ident={ident}, url={url}")
                skipped += 1
                continue

            valid_columns = [col for col in columns if ':' not in col] #normalizuje bez :
            placeholders = ','.join(['?'] * len(valid_columns))
            insert_sql = f"INSERT INTO Live ({','.join(valid_columns)}) VALUES ({placeholders})"

            if "://vip." in url:  #vip jen překopíruje
                try:
                    cursor.execute(insert_sql, [row_dict[col] for col in valid_columns])
                    ok_vip += 1
                except Exception as e:
                    Msg(f"[Repair] CHYBA při vkládání VIP: {ident} → {str(e)}")
                    fail += 1
                continue

            elif "://free." in url:  # získání vip odkazu pro free
                data = {'ident': ident, 'wst': token, 'device_uuid': addon.getSetting('duuid')}
                response = api('file_link', data)
                time.sleep(0.3)

                if addon.getSetting("debug") == "true":
                    Msg(f"[Repair] API odpověď pro {ident}: {response.text[:200]}\n")

                try:
                    xml = ET.fromstring(response.content)
                except ET.ParseError as e:
                    Msg(f"[Repair] XML ParseError pro ident {ident}: {str(e)}")
                    fail += 1
                    continue

                if is_ok(xml):
                    new_link = xml.findtext('link')
                    if new_link:
                        # if addon.getSetting("debug") == "true":
                        Msg(f"[Repair] ident={ident} | FREE={url}")
                        Msg(f"[Repair] ident={ident} | VIP={new_link}\n")
                        row_dict['DOWNLOAD_AVAILABLE'] = new_link
                        try:
                            cursor.execute(insert_sql, [row_dict[col] for col in valid_columns])
                            ok_free += 1
                        except Exception as e:
                            Msg(f"[Repair] CHYBA při vkládání FREE {ident}: {str(e)}")
                            fail += 1

                    else:
                        Msg(f"[Repair] API OK, ale chybí <link> pro ident {ident}")
                        fail += 1
                else:
                    Msg(f"[Repair] API status != OK pro ident {ident}")
                    fail += 1
            else:
                Msg(f"[Repair] ➖ PŘESKOČENO (ne VIP/Free): ident={ident}, url={url}")
                skipped += 1


        conn.commit()
        conn.close()

        Info(f"VIP: {ok_vip}, FREE: {ok_free}, Fail: {fail}, Skip: {skipped}", icon=xbmcgui.NOTIFICATION_INFO)
        Msg(f"[Repair] Result: VIP: {ok_vip}, FREE: {ok_free}, Fail: {fail}, ➖ Skip: {skipped}")

    except Exception as e:
        import traceback
        traceback.print_exc()
        Info(f"Chyba: {str(e)}", icon=xbmcgui.NOTIFICATION_ERROR)
        Msg(f"[Repair] Chyba: {str(e)}")
