import sqlite3
import xbmc
import xbmcgui
import xbmcaddon

addon = xbmcaddon.Addon()

path = addon.getSetting('path')

def Info(message, heading=None, icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    if heading is None:
        heading = addon.getAddonInfo('name')
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)

def LiveStreams_generate():
    Msg("\n[SQL] Spouštím generování LiveStreams.")
    Info("Spouštím generování", sound=True)

    conn = sqlite3.connect('/storage/data/test/movies.sqlite')
    cursor = conn.cursor()

    cursor.execute("DROP TABLE IF EXISTS LiveStreams;")
    conn.commit()
    if addon.getSetting("debug") == "true":
        Msg("[SQL] Příkaz DROP TABLE IF EXISTS LiveStreams proveden.")

    cursor.execute("""
    CREATE TABLE LiveStreams AS
    SELECT Movies.*, Streams.*
    FROM Movies
    INNER JOIN Streams ON Movies.Movie_ID = Streams.Movie_ID
    WHERE Streams.DOWNLOAD_AVAILABLE IS NOT NULL
      AND TRIM(Streams.DOWNLOAD_AVAILABLE) <> ''
    ORDER BY Movies.Year ASC;
    """)
    conn.commit()
    if addon.getSetting("debug") == "true":
        Msg("[SQL] Tabulka LiveStreams byla vytvořena.")

    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='LiveStreams';")
    if addon.getSetting("debug") == "true":
        Msg(f"[SQL] Existuje tabulka LiveStreams? {cursor.fetchone()}")

    Msg("[SQL] Struktura tabulky LiveStreams:")
    cursor.execute("PRAGMA table_info(LiveStreams);")
    for row in cursor.fetchall():
        if addon.getSetting("debug") == "true":
            Msg(f"[SQL] Row: {row}")

    cursor.execute("SELECT COUNT(*) FROM LiveStreams;")
    Msg(f"[SQL] Počet záznamů v LiveStreams: {cursor.fetchone()[0]}")

    conn.close()
    Msg("[SQL] Procedura byla dokončena.\n")
    Info("Hotovo", sound=True)
