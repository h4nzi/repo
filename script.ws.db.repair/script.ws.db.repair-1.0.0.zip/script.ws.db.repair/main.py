import xbmcaddon
import xbmcgui

from resources.lib.repairer import repair
from resources.lib.generator import LiveStreams_generate
from resources.lib.strm import generate_strm_files


addon = xbmcaddon.Addon()

class RepairMenu(xbmcgui.WindowXMLDialog):
    def onClick(self, controlId):
        if controlId == 100:  # Generovat tabulku
            self.close()
            LiveStreams_generate()
        elif controlId == 101:  # Opravit odkazy
            self.close()
            repair()
        elif controlId == 102:  # Nastavení
            self.close()
            addon.openSettings()
        elif controlId == 104: #strm
            self.close()
            generate_strm_files()
        elif controlId == 103:  # Zavřít
            self.close()
if __name__ == '__main__':
    win = RepairMenu("default.xml", addon.getAddonInfo("path"), "default", "1080i")
    win.doModal()
    del win
