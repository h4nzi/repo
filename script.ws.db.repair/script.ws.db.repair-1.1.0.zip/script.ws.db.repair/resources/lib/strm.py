import os
import sqlite3
import xbmcgui
import xbmcaddon
import xbmcvfs

addon = xbmcaddon.Addon()

folder_path = addon.getSetting('path')
db_path = xbmcvfs.translatePath(folder_path)

strm_path = addon.getSetting('output_folder')
output = xbmcvfs.translatePath(strm_path)

db_file = os.path.join(db_path, 'movies.sqlite')
output_folder = os.path.join(output, "strm_files")


if not xbmcvfs.exists(output_folder):
    xbmcvfs.mkdirs(output_folder)



def generate_strm_files():
    os.makedirs(output_folder, exist_ok=True)
    try:
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT 
                COALESCE(NULLIF(TRIM(OriginalTitle), ''), Title) AS FinalTitle,
                DOWNLOAD_AVAILABLE,
                Video_Height
            FROM Live
            WHERE Video_Height >= 720 
              AND DOWNLOAD_AVAILABLE IS NOT NULL 
              AND TRIM(DOWNLOAD_AVAILABLE) <> ''
        """)

        rows = cursor.fetchall()
        count = 0

        for title, url, height in rows:
            if not title or not url:
                continue

            safe_title = "".join(c for c in title if c.isalnum() or c in " _-.").strip()
            filename = os.path.join(output_folder, f"{safe_title}.strm")

            with open(filename, "w", encoding="utf-8") as f:
                f.write(url.strip())
            count += 1

        conn.close()
        xbmcgui.Dialog().notification(addon.getAddonInfo('name'), f"Vytvořeno {count} .strm souborů", xbmcgui.NOTIFICATION_INFO, 3000)

    except Exception as e:
        xbmcgui.Dialog().notification("Chyba", str(e), xbmcgui.NOTIFICATION_ERROR, 5000)
        import traceback
        traceback.print_exc()
