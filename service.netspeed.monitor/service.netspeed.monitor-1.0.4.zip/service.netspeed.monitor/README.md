# service.netspeed.monitor

Monitoring rychlosti sítě. Addon k zobrazení datového toku rozhraním eth0/wlan0 pro skin Confluence SCC. Po nainstalování se ve skinu automaticky aktivují další možnosti jeho nastavení. K zobrazení informací v jiných skinech je nutná jejich dodatečná editace.