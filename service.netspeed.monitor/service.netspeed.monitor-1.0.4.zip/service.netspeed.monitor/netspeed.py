import time
import xbmc
import xbmcgui
import xbmcaddon
import subprocess
import os
import json
import re


addon_id = 'service.netspeed.monitor'
selfAddon = xbmcaddon.Addon(addon_id)
__version__ = selfAddon.getAddonInfo('version')
monitor = xbmc.Monitor()

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)

if selfAddon.getSetting('rozhrani') == '0':
    interface = "eth0"
elif selfAddon.getSetting('rozhrani') == '1':
    interface = "wlan0"
else:
    Msg('Netspeed Monitor - Neznámé rozhraní')
Msg('Netspeed Monitor rozhraní: {}'.format(interface))



def get_bytes(t, iface=interface):
    if os.name == 'posix':  # Linux
        with open('/sys/class/net/' + iface + '/statistics/' + t + '_bytes', 'r') as f:
            data = f.read()
        return int(data)
    
    elif os.name == 'nt':  # Windows
        command = "powershell.exe Get-NetAdapterStatistics -Name '{}'".format(iface)
        result = subprocess.run(command, capture_output=True, text=True, shell=True)
        
        if result.returncode == 0:
            output = result.stdout.strip()
            lines = output.split('\n')
            if len(lines) > 2:
                values = re.findall(r'\d+', lines[2])
                if len(values) >= 4:
                    try:
                        data = 0
                        if t == 'tx':
                            data = int(values[3]) * 100
                        elif t == 'rx':
                            data = int(values[1]) * 100
                        
                        return int(data)
                    except ValueError:
                        return None
        
        return None

if __name__ == '__main__':
    (tx_prev, rx_prev) = (0, 0)
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        try:
            tx = get_bytes('tx')
            rx = get_bytes('rx')
            if selfAddon.getSetting('debug') == 'true':
                Msg('RX:{}'.format(rx))
        except IOError:
            Msg('Netspeed Monitor - Data nejsou k dispozici:{}'.format(interface))
            break
        if tx_prev is not None and tx_prev > 0:
            tx_speed = (tx - tx_prev) / 2
            tx_b = str(round(tx_speed / 131072, 2))
            xbmcgui.Window(10000).setProperty('TX', tx_b)

        if rx_prev is not None and rx_prev > 0:
            rx_speed = (rx - rx_prev) / 2
            if selfAddon.getSetting('debug') == 'true':
                Msg('RX_speed:{}'.format(rx_speed))
            rx_b = str(round(rx_speed / 132072, 2))
            xbmcgui.Window(10000).setProperty('RX', rx_b)
            if selfAddon.getSetting('debug') == 'true':
                Msg('RXspeed:{}'.format(rx_b))
        if monitor.waitForAbort(2):
            break
        tx_prev = tx
        rx_prev = rx
