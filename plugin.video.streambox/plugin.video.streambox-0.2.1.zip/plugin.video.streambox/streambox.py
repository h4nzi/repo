# -*- coding: utf-8 -*-
# Module: default
# Author: cache-sk + Johnysko
# Created on: 10.5.2020 + 05/2025
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import io
import os
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import requests.cookies
from xml.etree import ElementTree as ET
import hashlib
from md5crypt import md5crypt
import traceback
import json
import unidecode
import re
import zipfile
import uuid
import requests
from resources.lib import tmdb
from resources.lib import serialy

# Pokus o import fuzzywuzzy modulu ze složky resources/lib
try:
    from fuzzywuzzy import fuzz, process
except ImportError as e:
    xbmcgui.Dialog().notification("Chyba", "Nepodařilo se importovat fuzzywuzzy!", xbmcgui.NOTIFICATION_ERROR, 5000)
    xbmc.log("Import fuzzywuzzy selhal: {}".format(e), xbmc.LOGERROR)


try:
    from urllib import urlencode
    from urlparse import parse_qsl, urlparse
except ImportError:
    from urllib.parse import urlencode
    from urllib.parse import parse_qsl, urlparse

try:
    from xbmc import translatePath
except ImportError:
    from xbmcvfs import translatePath

BASE = 'https://webshare.cz'
API = BASE + '/api/'
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36"
HEADERS = {'User-Agent': UA, 'Referer':BASE}
REALM = ':Webshare:'
CATEGORIES = ['','video','images','audio','archives','docs','adult']
SORTS = ['','recent','rating','largest','smallest']
SEARCH_HISTORY = 'search_history'
NONE_WHAT = '%#NONE#%'
BACKUP_DB = 'D1iIcURxlR'

_url = sys.argv[0]
_handle = int(sys.argv[1])
_addon = xbmcaddon.Addon()
_session = requests.Session()
_session.headers.update(HEADERS)
_profile = translatePath( _addon.getAddonInfo('profile'))
try:
    _profile = _profile.decode("utf-8")
except:
    pass

def get_icons_path():
    """
    #Vrátí absolutní cestu ke složce resources/media v aktuální instalaci doplňku.
    """
    addon_path = _addon.getAddonInfo('path')
    return os.path.join(addon_path, 'resources', 'media')

def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs, 'utf-8'))

def api(fnct, data):
    response = _session.post(API + fnct + "/", data=data)
    return response

def is_ok(xml):
    status = xml.find('status').text
    return status == 'OK'

def popinfo(message, heading=_addon.getAddonInfo('name'), icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False): #NOTIFICATION_WARNING NOTIFICATION_ERROR
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)

def login():
    username = _addon.getSetting('wsuser')
    password = _addon.getSetting('wspass')
    if username == '' or password == '':
        popinfo(_addon.getLocalizedString(30101), sound=True)
        _addon.openSettings()
        return
    response = api('salt', {'username_or_email': username})
    xml = ET.fromstring(response.content)
    if is_ok(xml):
        salt = xml.find('salt').text
        try:
            encrypted_pass = hashlib.sha1(md5crypt(password.encode('utf-8'), salt.encode('utf-8'))).hexdigest()
            pass_digest = hashlib.md5(username.encode('utf-8') + REALM + encrypted_pass.encode('utf-8')).hexdigest()
        except TypeError:
            encrypted_pass = hashlib.sha1(md5crypt(password.encode('utf-8'), salt.encode('utf-8')).encode('utf-8')).hexdigest()
            pass_digest = hashlib.md5(username.encode('utf-8') + REALM.encode('utf-8') + encrypted_pass.encode('utf-8')).hexdigest()
        response = api('login', {'username_or_email': username, 'password': encrypted_pass, 'digest': pass_digest, 'keep_logged_in': 1})
        xml = ET.fromstring(response.content)
        if is_ok(xml):
            token = xml.find('token').text
            _addon.setSetting('token', token)
            return token
        else:
            popinfo(_addon.getLocalizedString(30102), icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
            _addon.openSettings()
    else:
        popinfo(_addon.getLocalizedString(30102), icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
        _addon.openSettings()

def revalidate():
    token = _addon.getSetting('token')
    if len(token) == 0:
        if login():
            return revalidate()
    else:
        response = api('user_data', { 'wst': token })
        xml = ET.fromstring(response.content)
        status = xml.find('status').text
        if is_ok(xml):
            vip = xml.find('vip').text
            if vip != '1':
                popinfo(_addon.getLocalizedString(30103), icon=xbmcgui.NOTIFICATION_WARNING)
            return token
        else:
            if login():
                return revalidate()

def todict(xml, skip=[]):
    result = {}
    for e in xml:
        if e.tag not in skip:
            value = e.text if len(list(e)) == 0 else todict(e,skip)
            if e.tag in result:
                if isinstance(result[e.tag], list):
                    result[e.tag].append(value)
                else:
                    result[e.tag] = [result[e.tag],value]
            else:
                result[e.tag] = value
    #result = {e.tag:(e.text if len(list(e)) == 0 else todict(e,skip)) for e in xml if e.tag not in skip}
    return result
            
def sizelize(txtsize, units=['B','KB','MB','GB']):
    if txtsize:
        size = float(txtsize)
        if size < 1024:
            size = str(int(size)) + units[0]  # B - bajty, celé číslo
        else:
            size = size / 1024
            if size < 1024:
                size = str(int(round(size))) + units[1]  # KB - kilobajty, celé číslo
            else:
                size = size / 1024
                if size < 1024:
                    size = str(int(round(size))) + units[2]  # MB - megabajty, celé číslo
                else:
                    size = size / 1024
                    size = str(round(size,2)) + units[3]  # GB - gigabajty, dvě desetinná místa
        return size
    return str(txtsize)
    
def labelize(file):
    name = file.get('name_normalized', file['name'])
    if 'size' in file:
        size = sizelize(file['size'])
    elif 'sizelized' in file:
        size = file['sizelized']
    else:
        size = '?'
    name_lower = name.lower()
    name_normalized = re.sub(r'[.,+\-_]', ' ', name_lower)

    # [CZ] zeleně pokud je v názvu "cz", "cz dab", "cz dabing", "czdab", "cz.dab", "cz.dabing" nebo "czdabing"
    cz_tag = ''
    show_cz = False
    cz_patterns = [
        r'\bcz\b',
        r'\bcz\s+dab\b',
        r'\bcz\s+dabing\b',
        r'\bczdab\b',
        r'\bcz\s+dab\b',
        r'\bcz\s+dabing\b',
        r'\bczdabing\b'  # přidáno pro detekci "czdabing"
    ]
    for pat in cz_patterns:
        if re.search(pat, name_normalized):
            show_cz = True
            break

    forbidden = ['titulky', 'sub', 'tit']
    if show_cz:
        cz_match = re.search(r'cz', name_normalized)
        if cz_match:
            end = cz_match.end()
            after = name_normalized[end:].lstrip(" -")
            for word in forbidden:
                if after.startswith(word) or after.startswith('.' + word):
                    show_cz = False
            before = name_normalized[:cz_match.start()].rstrip(" -")
            for word in forbidden:
                if before.endswith(word) or before.endswith(word + '.'):
                    show_cz = False
        if show_cz:
            cz_tag = '[COLOR lime][CZ][/COLOR] '

    # [SK] zeleně pokud je v názvu "sk", "sk dab", "sk dabing", "skdab", "sk.dab" nebo "sk.dabing"
    sk_tag = ''
    show_sk = False
    sk_patterns = [
        r'\bsk\b',
        r'\bsk\s+dab\b',
        r'\bsk\s+dabing\b',
        r'\bskdab\b',
        r'\bsk\s+dab\b',
        r'\bsk\s+dabing\b'
    ]
    for pat in sk_patterns:
        if re.search(pat, name_normalized):
            show_sk = True
            break

    if show_sk:
        sk_match = re.search(r'sk', name_normalized)
        if sk_match:
            end = sk_match.end()
            after = name_normalized[end:].lstrip(" -")
            for word in forbidden:
                if after.startswith(word) or after.startswith('.' + word):
                    show_sk = False
            before = name_normalized[:sk_match.start()].rstrip(" -")
            for word in forbidden:
                if before.endswith(word) or before.endswith(word + '.'):
                    show_sk = False
        if show_sk:
            sk_tag = '[COLOR lime][SK][/COLOR] '

    # Sestavení společného tagu pro CZ a SK
    lang_tag = ""
    if cz_tag and sk_tag:
        lang_tag = f"[COLOR lime][CZ/SK][/COLOR] "
    elif cz_tag:
        lang_tag = cz_tag
    elif sk_tag:
        lang_tag = sk_tag

    # [1080p] červeně pokud je v názvu "1080p", "full hd" nebo "fhd"
    hd1080_tag = ''
    if any(x in name_normalized for x in ['1080p', 'full hd', 'fhd']):
        hd1080_tag = '[COLOR red][1080p][/COLOR] '

    # [4K] žlutě pokud je v názvu "2160p", "uhd" nebo "4k"
    k4_tag = ''
    if any(x in name_normalized for x in ['2160p', 'uhd', '4k']):
        k4_tag = '[COLOR yellow][4K][/COLOR] '

    # [720p] modře pouze pokud je v názvu "720p"
    hd720_tag = ''
    if '720p' in name_normalized:
        hd720_tag = '[COLOR blue][720p][/COLOR] '

    # [HDR] fialově pokud je v názvu "hdr"
    hdr_tag = ''
    if 'hdr' in name_normalized:
        hdr_tag = '[COLOR violet][HDR][/COLOR] '

    # Sestavení labelu: [CZ]/[SK]/[CZ/SK] [1080p]/[4K]/[720p] [HDR] [velikost] - název
    label = f"{lang_tag}{hd1080_tag}{k4_tag}{hd720_tag}"
    if hdr_tag:
        label += f"{hdr_tag}"
    label += f"[{size}] - {name}"
    return label
    
def tolistitem(file, addcommands=[]):
    label = labelize(file)
    listitem = xbmcgui.ListItem(label=label)
    if 'img' in file:
        listitem.setArt({'thumb': file['img']})
    listitem.setInfo('video', {'title': label})
    listitem.setProperty('IsPlayable', 'true')
    commands = []
    commands.append(( _addon.getLocalizedString(30211), 'RunPlugin(' + get_url(action='info',ident=file['ident']) + ')'))
    commands.append(( _addon.getLocalizedString(30212), 'RunPlugin(' + get_url(action='download',ident=file['ident']) + ')'))
    if addcommands:
        commands = commands + addcommands
    listitem.addContextMenuItems(commands)
    return listitem

def ask(what):
    if what is None:
        what = ''
    kb = xbmc.Keyboard(what, _addon.getLocalizedString(30007))
    kb.doModal() # Onscreen keyboard appears
    if kb.isConfirmed():
        return kb.getText() # User input
    return None
    
def loadsearch():
    history = []
    try:
        if not os.path.exists(_profile):
            os.makedirs(_profile)
    except Exception as e:
        traceback.print_exc()
    
    try:
        with io.open(os.path.join(_profile, SEARCH_HISTORY), 'r', encoding='utf8') as file:
            fdata = file.read()
            file.close()
            try:
                history = json.loads(fdata, "utf-8")
            except TypeError:
                history = json.loads(fdata)
    except Exception as e:
        traceback.print_exc()

    return history
    
def storesearch(what):
    if what:
        size = int(_addon.getSetting('shistory'))

        history = loadsearch()

        if what in history:
            history.remove(what)

        history = [what] + history
        
        if len(history)>size:
            history = history[:size]

        try:
            with io.open(os.path.join(_profile, SEARCH_HISTORY), 'w', encoding='utf8') as file:
                try:
                    data = json.dumps(history).decode('utf8')
                except AttributeError:
                    data = json.dumps(history)
                file.write(data)
                file.close()
        except Exception as e:
            traceback.print_exc()

def removesearch(what):
    if what:
        history = loadsearch()
        if what in history:
            history.remove(what)
            try:
                with io.open(os.path.join(_profile, SEARCH_HISTORY), 'w', encoding='utf8') as file:
                    try:
                        data = json.dumps(history).decode('utf8')
                    except AttributeError:
                        data = json.dumps(history)
                    file.write(data)
                    file.close()
            except Exception as e:
                traceback.print_exc()

def parse_file_size(value):
    """
    Převod hodnoty z nastavení (např. '4 GB', '1500 MB', '1000000') na bajty.
    Pokud je hodnota prázdná nebo neplatná, vrací None (neomezeně).
    """
    if not value or not value.strip():
        return None
    value = value.strip().replace(',', '.')
    import re
    match = re.match(r'^(\d+(?:\.\d+)?)\s*(b|kb|mb|gb)?$', value.strip(), re.IGNORECASE)
    if not match:
        return None
    number = float(match.group(1))
    unit = match.group(2).lower() if match.group(2) else 'b'
    if unit == 'b':
        return int(number)
    elif unit == 'kb':
        return int(number * 1024)
    elif unit == 'mb':
        return int(number * 1024 * 1024)
    elif unit == 'gb':
        return int(number * 1024 * 1024 * 1024)
    else:
        return int(number)

def dosearch(token, what, category, sort, limit, offset, action):
    response = api('search', {
        'what': '' if what == NONE_WHAT else what,
        'category': category,
        'sort': sort,
        'limit': limit,
        'offset': offset,
        'wst': token,
        'maybe_removed': 'true'
    })
    xml = ET.fromstring(response.content)
    if is_ok(xml):

        # Nastavení filtrů
        show_hdr_videos = _addon.getSetting('show_hdr_videos')
        show_4k_videos = _addon.getSetting('show_4k_videos')
        show_fullhd_videos = _addon.getSetting('show_fullhd_videos')
        show_720p_videos = _addon.getSetting('show_720p_videos')
        show_small_files_1_5gb = _addon.getSetting('show_small_files_1_5gb') == "true"
        show_small_files = _addon.getSetting('show_small_files') == "true"
        show_cz_dubbed = _addon.getSetting('show_cz_dubbed') == "true"
        max_file_size_setting = _addon.getSetting('max_file_size')
        min_file_size_setting = _addon.getSetting('min_file_size')
        max_file_size_bytes = parse_file_size(max_file_size_setting)
        min_file_size_bytes = parse_file_size(min_file_size_setting)
        filter_4k_keywords = ['2160p', 'uhd', '4k']
        filter_fullhd_keywords = ['1080p', 'full hd', 'fhd']
        sort_by_resolution = _addon.getSetting('sort_by_resolution') == "true"

        if offset > 0:  # předchozí stránka
            listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30206))
            listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
            xbmcplugin.addDirectoryItem(
                _handle,
                get_url(action=action, what=what, category=category, sort=sort, limit=limit, offset=offset - limit if offset > limit else 0),
                listitem,
                True
            )

        found_any = False

        # Filtrování duplicit
        seen = set()
        unique_files = []
        for file in xml.iter('file'):
            item = todict(file)
            name = item.get('name', '')
            # Normalizace názvu (odstranění speciálních znaků)
            name_normalized = re.sub(r'[.,+\-_/\'"]', ' ', name)
            item['name_normalized'] = name_normalized
            name_lower = name_normalized.lower()
            size = item.get('size', '')
            key = (name_lower, size)
            if key in seen:
                continue
            seen.add(key)
            unique_files.append(item)

        # Řazení podle rozlišení
        if sort_by_resolution:
            def resolution_sort_key(item):
                label = labelize(item)
                if '[4K]' in label:
                    return 0
                elif '[1080p]' in label:
                    return 1
                elif '[720p]' in label:
                    return 2
                else:
                    return 3
            unique_files.sort(key=resolution_sort_key)

        # Aplikace všech filtrů kromě relevance
        filtered_files = []
        for item in unique_files:
            name_lower = item['name'].lower() if 'name' in item else ''
            try:
                size_bytes = float(item.get('size', 0))
            except (ValueError, TypeError):
                size_bytes = 0

            if not show_small_files_1_5gb and size_bytes < 1.5 * 1024 * 1024 * 1024:
                continue
            if not show_small_files and size_bytes < 700 * 1024 * 1024:
                continue
            if min_file_size_bytes is not None and size_bytes < min_file_size_bytes:
                continue
            if max_file_size_bytes is not None and size_bytes > max_file_size_bytes:
                continue

            if show_cz_dubbed:
                label = labelize(item)
                if '[CZ]' not in label and '[COLOR lime][CZ][/COLOR]' not in label:
                    continue
            else:
                label = labelize(item)

            if show_hdr_videos != "true" and 'hdr' in name_lower:
                continue
            if show_4k_videos != "true" and any(keyword in name_lower for keyword in filter_4k_keywords):
                continue
            if show_fullhd_videos != "true" and any(keyword in name_lower for keyword in filter_fullhd_keywords):
                continue
            if show_720p_videos != "true":
                name_bdrip_normalized = re.sub(r'[.,+\-_]', ' ', name_lower)
                if '720p' in name_lower or re.search(r'\bbdrip\b', name_bdrip_normalized):
                    continue

            show_no_metadata = _addon.getSetting('show_no_metadata') == "true"
            if not show_no_metadata:
                if re.match(r'^\[\S+\] - ', label):
                    continue

            filtered_files.append(item)

        # --- FuzzyWuzzy: přesná nebo téměř přesná shoda na začátku názvu ---
        try:
            min_match_ratio = int(_addon.getSetting('min_match_ratio'))
        except Exception:
            min_match_ratio = 90  # doporučená výchozí hodnota pro téměř přesnou shodu

        search_phrase = what.lower().strip() if what else ""

        relevant_items = []
        log_lines = []
        log_lines.append(u"\n*** Hledání: '{}'\n".format(search_phrase))

        for item in filtered_files:
            name_normalized = item['name_normalized'].lower()
            # Kontrola přesné shody na začátku
            if name_normalized.startswith(search_phrase):
                score = 100
                relevant_items.append(item)
                log_lines.append(u"{:<4} {}".format(score, item['name']))
            # Kontrola téměř přesné shody na začátku (povolený překlep)
            elif search_phrase and len(name_normalized) >= len(search_phrase):
                start_substr = name_normalized[:len(search_phrase)]
                score = fuzz.ratio(search_phrase, start_substr)
                if score >= min_match_ratio:
                    relevant_items.append(item)
                    log_lines.append(u"{:<4} {}".format(score, item['name']))
            else:
                # Nepřidávej nerelevantní položky, ale loguj pro přehled
                if search_phrase and len(name_normalized) >= len(search_phrase):
                    start_substr = name_normalized[:len(search_phrase)]
                    score = fuzz.ratio(search_phrase, start_substr)
                    log_lines.append(u"{:<4} {}".format(score, item['name']))
                else:
                    log_lines.append(u"  0  {}".format(item['name']))

        # Logování výsledků do souboru
        try:
            log_path = os.path.join(_profile, "fuzzy_results.txt")
            with io.open(log_path, "a", encoding="utf-8") as logfile:
                for line in log_lines:
                    logfile.write(line + u"\n")
        except Exception as e:
            xbmc.log("Chyba při zápisu fuzzy výsledků: {}".format(e), xbmc.LOGERROR)

        found_any = False
        for item in relevant_items:
            commands = []
            commands.append((_addon.getLocalizedString(30214), 'Container.Update(' + get_url(action='search', toqueue=item['ident'], what=what, offset=offset) + ')'))
            listitem = tolistitem(item, commands)
            xbmcplugin.addDirectoryItem(_handle, get_url(action='play', ident=item['ident'], name=item['name']), listitem, False)
            found_any = True

        if not found_any:
            xbmcgui.Dialog().ok(_addon.getAddonInfo('name'), "Nenalezeny žádné streamy. Zkus změnit nastavení filtrů nebo hledaný výraz.")
            return

        try:
            total = int(xml.find('total').text)
        except:
            total = 0

        if offset + limit < total:  # další stránka
            listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30207))
            listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
            xbmcplugin.addDirectoryItem(
                _handle,
                get_url(action=action, what=what, category=category, sort=sort, limit=limit, offset=offset + limit),
                listitem,
                True
            )
    
def search(params):
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \ " + _addon.getLocalizedString(30201))
    token = revalidate()
    
    updateListing=False
    
    if 'remove' in params:
        removesearch(params['remove'])
        updateListing=True
        
    if 'toqueue' in params:
        toqueue(params['toqueue'],token)
        updateListing=True
    
    what = None
    
    if 'what' in params:
        what = params['what']
    
    if 'ask' in params:
        slast = _addon.getSetting('slast')
        if slast != what:
            what = ask(what)
            if what is not None:
                storesearch(what)
            else:
                updateListing=True

    # Pokud je aktivní složka "Naposledy hledané", zobraz pouze historii hledání
    if params.get('show_recent') == '1':
        history = loadsearch()
        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \ " + _addon.getLocalizedString(30201) + " \ Naposledy hledané")
        for search_item in history:
            listitem = xbmcgui.ListItem(label=search_item)
            listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
            commands = []
            commands.append((_addon.getLocalizedString(30213), 'Container.Update(' + get_url(action='search',remove=search_item, show_recent='1') + ')'))
            listitem.addContextMenuItems(commands)
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=search_item,ask=1), listitem, True)
        xbmcplugin.endOfDirectory(_handle, updateListing=updateListing)
        return

    if what is not None:
        if 'offset' not in params:
            _addon.setSetting('slast',what)
        else:
            _addon.setSetting('slast',NONE_WHAT)
            updateListing=True
        
        category = params['category'] if 'category' in params else CATEGORIES[int(_addon.getSetting('scategory'))]
        sort = params['sort'] if 'sort' in params else SORTS[int(_addon.getSetting('ssort'))]
        limit = int(params['limit']) if 'limit' in params else int(_addon.getSetting('slimit'))
        offset = int(params['offset']) if 'offset' in params else 0
        dosearch(token, what, category, sort, limit, offset, 'search')
    else:
        _addon.setSetting('slast',NONE_WHAT)
        history = loadsearch()
        
        # Nové hledání
        listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30205))
        listitem.setArt({'icon': os.path.join(get_icons_path(), 'novehledani.png'), 'thumb': os.path.join(get_icons_path(), 'novehledani.png')})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search', ask=1), listitem, True)

        # Nová složka "Naposledy hledané" - pouze pokud existuje historie hledání
        if history:
            listitem = xbmcgui.ListItem(label="Naposledy hledané")
            listitem.setArt({'icon': os.path.join(get_icons_path(), 'nedavnohledane.png'), 'thumb': os.path.join(get_icons_path(), 'nedavnohledane.png')})
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search', show_recent='1'), listitem, True)
        
        # Nejnovější na WS
        listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30208))
        listitem.setArt({'icon': os.path.join(get_icons_path(), 'novenaws.png'), 'thumb': os.path.join(get_icons_path(), 'novenaws.png')})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=NONE_WHAT,sort=SORTS[1]), listitem, True)
        
        # Největší na WS
        listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30209))
        listitem.setArt({'icon': os.path.join(get_icons_path(), 'nejvetsi.png'), 'thumb': os.path.join(get_icons_path(), 'nejvetsi.png')})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=NONE_WHAT,sort=SORTS[3]), listitem, True)        
    xbmcplugin.endOfDirectory(_handle, updateListing=updateListing)

def queue(params):
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \ " + _addon.getLocalizedString(30202))
    token = revalidate()
    updateListing=False
    
    if 'dequeue' in params:
        response = api('dequeue_file',{'ident':params['dequeue'],'wst':token})
        xml = ET.fromstring(response.content)
        if is_ok(xml):
            popinfo(_addon.getLocalizedString(30106))
        else:
            popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        updateListing=True
    
    response = api('queue',{'wst':token})
    xml = ET.fromstring(response.content)
    if is_ok(xml):
        for file in xml.iter('file'):
            item = todict(file)
            commands = []
            commands.append(( _addon.getLocalizedString(30215), 'Container.Update(' + get_url(action='queue',dequeue=item['ident']) + ')'))
            listitem = tolistitem(item,commands)
            xbmcplugin.addDirectoryItem(_handle, get_url(action='play',ident=item['ident'],name=item['name']), listitem, False)
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
    xbmcplugin.endOfDirectory(_handle,updateListing=updateListing)

def toqueue(ident,token):
    response = api('queue_file',{'ident':ident,'wst':token})
    xml = ET.fromstring(response.content)
    if is_ok(xml):
        popinfo(_addon.getLocalizedString(30105))
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)

def history(params):
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \ " + _addon.getLocalizedString(30203))
    token = revalidate()
    updateListing=False
    
    if 'remove' in params:
        remove = params['remove']
        updateListing=True
        response = api('history',{'wst':token})
        xml = ET.fromstring(response.content)
        ids = []
        if is_ok(xml):
            for file in xml.iter('file'):
                if remove == file.find('ident').text:
                    ids.append(file.find('download_id').text)
        else:
            popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        if ids:
            rr = api('clear_history',{'ids[]':ids,'wst':token})
            xml = ET.fromstring(rr.content)
            if is_ok(xml):
                popinfo(_addon.getLocalizedString(30104))
            else:
                popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
    
    if 'toqueue' in params:
        toqueue(params['toqueue'],token)
        updateListing=True
    
    response = api('history',{'wst':token})
    xml = ET.fromstring(response.content)
    files = []
    if is_ok(xml):
        for file in xml.iter('file'):
            item = todict(file, ['ended_at', 'download_id', 'started_at'])
            if item not in files:
                files.append(item)
        for file in files:
            commands = []
            commands.append(( _addon.getLocalizedString(30213), 'Container.Update(' + get_url(action='history',remove=file['ident']) + ')'))
            commands.append(( _addon.getLocalizedString(30214), 'Container.Update(' + get_url(action='history',toqueue=file['ident']) + ')'))
            listitem = tolistitem(file, commands)
            xbmcplugin.addDirectoryItem(_handle, get_url(action='play',ident=file['ident'],name=file['name']), listitem, False)
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
    xbmcplugin.endOfDirectory(_handle,updateListing=updateListing)
    
def settings(params):
    _addon.openSettings()
    xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

def infonize(data,key,process=str,showkey=True,prefix='',suffix='\n'):
    if key in data:
        return prefix + (key.capitalize() + ': ' if showkey else '') + process(data[key]) + suffix
    return ''

def fpsize(fps):
    x = round(float(fps),3)
    if int(x) == x:
       return str(int(x))
    return str(x)
    
def getinfo(ident,wst):
    response = api('file_info',{'ident':ident,'wst': wst})
    xml = ET.fromstring(response.content)
    ok = is_ok(xml)
    if not ok:
        response = api('file_info',{'ident':ident,'wst': wst, 'maybe_removed':'true'})
        xml = ET.fromstring(response.content)
        ok = is_ok(xml)
    if ok:
        return xml
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        return None

def info(params):
    token = revalidate()
    xml = getinfo(params['ident'],token)
    
    if xml is not None:
        info = todict(xml)
        text = ''
        text += infonize(info, 'size', sizelize)   
        text += infonize(info, 'name')        
        text += infonize(info, 'type')
        text += infonize(info, 'width')
        text += infonize(info, 'height')
        text += infonize(info, 'format')
        text += infonize(info, 'fps', fpsize)
        text += infonize(info, 'bitrate', lambda x:sizelize(x,['bps','Kbps','Mbps','Gbps']))
        if 'video' in info and 'stream' in info['video']:
            streams = info['video']['stream']
            if isinstance(streams, dict):
                streams = [streams]
            for stream in streams:
                text += 'Video stream: '
                text += infonize(stream, 'width', showkey=False, suffix='')
                text += infonize(stream, 'height', showkey=False, prefix='x', suffix='')
                text += infonize(stream,'format', showkey=False, prefix=', ', suffix='')
                text += infonize(stream,'fps', fpsize, showkey=False, prefix=', ', suffix='')
                text += '\n'
        if 'audio' in info and 'stream' in info['audio']:
            streams = info['audio']['stream']
            if isinstance(streams, dict):
                streams = [streams]
            for stream in streams:
                text += 'Audio stream: '
                text += infonize(stream, 'format', showkey=False, suffix='')
                text += infonize(stream,'channels', prefix=', ', showkey=False, suffix='')
                text += infonize(stream,'bitrate', lambda x:sizelize(x,['bps','Kbps','Mbps','Gbps']), prefix=', ', showkey=False, suffix='')
                text += '\n'
        text += infonize(info, 'removed', lambda x:'Yes' if x=='1' else 'No')
        xbmcgui.Dialog().textviewer(_addon.getAddonInfo('name'), text)

def getlink(ident,wst,dtype='video_stream'):
    #uuid experiment
    duuid = _addon.getSetting('duuid')
    if not duuid:
        duuid = str(uuid.uuid4())
        _addon.setSetting('duuid',duuid)
    data = {'ident':ident,'wst': wst,'download_type':dtype,'device_uuid':duuid}
    #TODO password protect
    #response = api('file_protected',data) #protected
    #xml = ET.fromstring(response.content)
    #if is_ok(xml) and xml.find('protected').text != 0:
    #    pass #ask for password
    response = api('file_link',data)
    xml = ET.fromstring(response.content)
    if is_ok(xml):
        return xml.find('link').text
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        return None

def play(params):
    token = revalidate()
    link = getlink(params['ident'],token)
    if link is not None:
        #headers experiment
        headers = _session.headers
        if headers:
            headers.update({'Cookie':'wst='+token})
            link = link + '|' + urlencode(headers)
        listitem = xbmcgui.ListItem(label=params['name'],path=link)
        listitem.setProperty('mimetype', 'application/octet-stream')
        xbmcplugin.setResolvedUrl(_handle, True, listitem)
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

def join(path, file):
    if path.endswith('/') or path.endswith('\\'):
        return path + file
    else:
        return path + '/' + file

def download(params):
    token = revalidate()
    where = _addon.getSetting('dfolder')
    if not where or not xbmcvfs.exists(where):
        popinfo('set folder!', sound=True)#_addon.getLocalizedString(30101)
        _addon.openSettings()
        return
        
    local = os.path.exists(where)
        
    normalize = 'true' == _addon.getSetting('dnormalize')
    notify = 'true' == _addon.getSetting('dnotify')
    every = _addon.getSetting('dnevery')
    try:
        every = int(re.sub(r'[^\d]+', '', every))
    except:
        every = 10
        
    try:
        link = getlink(params['ident'],token,'file_download')
        info = getinfo(params['ident'],token)
        name = info.find('name').text
        if normalize:
            name = unidecode.unidecode(name)
        bf = io.open(os.path.join(where,name), 'wb') if local else xbmcvfs.File(join(where,name), 'w')
        response = _session.get(link, stream=True)
        total = response.headers.get('content-length')
        if total is None:
            popinfo(_addon.getLocalizedString(30301) + name, icon=xbmcgui.NOTIFICATION_WARNING, sound=True)
            bf.write(response.content)
        elif not notify:
            popinfo(_addon.getLocalizedString(30302) + name)
            bf.write(response.content)
        else:
            popinfo(_addon.getLocalizedString(30302) + name)
            dl = 0
            total = int(total)
            pct = total / 100
            lastpop=0
            for data in response.iter_content(chunk_size=4096):
                dl += len(data)
                bf.write(data)
                done = int(dl / pct)
                if done % every == 0 and lastpop != done:
                    popinfo(str(done) + '% - ' + name)
                    lastpop = done
        bf.close()
        popinfo(_addon.getLocalizedString(30303) + name, sound=True)
    except Exception as e:
        #TODO - remove unfinished file?
        traceback.print_exc()
        popinfo(_addon.getLocalizedString(30304) + name, icon=xbmcgui.NOTIFICATION_ERROR, sound=True)

def loaddb(dbdir,file):
    try:
        data = {}
        with io.open(os.path.join(dbdir, file), 'r', encoding='utf8') as file:
            fdata = file.read()
            file.close()
            try:
                data = json.loads(fdata, "utf-8")['data']
            except TypeError:
                data = json.loads(fdata)['data']
        return data
    except Exception as e:
        traceback.print_exc()
        return {}

def db(params):
    token = revalidate()
    updateListing=False

    dbdir = os.path.join(_profile,'db')
    if not os.path.exists(dbdir):
        link = getlink(BACKUP_DB,token)
        dbfile = os.path.join(_profile,'db.zip')
        with io.open(dbfile, 'wb') as bf:
            response = _session.get(link, stream=True)
            bf.write(response.content)
            bf.flush()
            bf.close()
        with zipfile.ZipFile(dbfile, 'r') as zf:
            zf.extractall(_profile)
        os.unlink(dbfile)
    
    if 'toqueue' in params:
        toqueue(params['toqueue'],token)
        updateListing=True
    
    if 'file' in params and 'key' in params:
        data = loaddb(dbdir,params['file'])
        item = next((x for x in data if x['id'] == params['key']), None)
        if item is not None:
            for stream in item['streams']:
                commands = []
                commands.append(( _addon.getLocalizedString(30214), 'Container.Update(' + get_url(action='db',file=params['file'],key=params['key'],toqueue=stream['ident']) + ')'))
                listitem = tolistitem({'ident':stream['ident'],'name':stream['quality'] + ' - ' + stream['lang'] + stream['ainfo'],'sizelized':stream['size']},commands)
                xbmcplugin.addDirectoryItem(_handle, get_url(action='play',ident=stream['ident'],name=item['title']), listitem, False)
    elif 'file' in params:
        data = loaddb(dbdir,params['file'])
        for item in data:
            listitem = xbmcgui.ListItem(label=item['title'])
            if 'plot' in item:
                listitem.setInfo('video', {'title': item['title'],'plot': item['plot']})
            xbmcplugin.addDirectoryItem(_handle, get_url(action='db',file=params['file'],key=item['id']), listitem, True)
    else:
        if os.path.exists(dbdir):
            dbfiles = [f for f in os.listdir(dbdir) if os.path.isfile(os.path.join(dbdir, f))]
            for dbfile in dbfiles:
                listitem = xbmcgui.ListItem(label=os.path.splitext(dbfile)[0])
                xbmcplugin.addDirectoryItem(_handle, get_url(action='db',file=dbfile), listitem, True)
    xbmcplugin.addSortMethod(_handle,xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(_handle, updateListing=updateListing)

def menu():
    revalidate()
    ICONS_PATH = get_icons_path()

    # Filmy
    listitem = xbmcgui.ListItem(label="Filmy")
    icon_file = os.path.join(ICONS_PATH, 'filmy.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='filmy'), listitem, True)

    # Seriály
    listitem = xbmcgui.ListItem(label="Seriály")
    icon_file = os.path.join(ICONS_PATH, 'serialy.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='serialy'), listitem, True)

    # Vyhledávání
    listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30201))
    icon_file = os.path.join(ICONS_PATH, 'vyhledavani.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='search'), listitem, True)
    
    # Stahování
    listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30202))
    icon_file = os.path.join(ICONS_PATH, 'chcistahnout.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='queue'), listitem, True)

    # Historie sledování
    listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30203))
    icon_file = os.path.join(ICONS_PATH, 'historiesledovani.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='history'), listitem, True)
    
    if 'true' == _addon.getSetting('experimental'):
        listitem = xbmcgui.ListItem(label='Backup DB')
        listitem.setArt({'icon': 'DefaultAddonsZip.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='db'), listitem, True)

    # Nastavení
    listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30204))
    icon_file = os.path.join(ICONS_PATH, 'nastaveni.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='settings'), listitem, False)

    xbmcplugin.endOfDirectory(_handle)

def filmy_menu(params):
    ICONS_PATH = get_icons_path()

    # Hledat film
    listitem = xbmcgui.ListItem(label="Hledat film")
    icon_file = os.path.join(ICONS_PATH, 'vyhledavani.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='hledat_film'), listitem, True)

    # Populární filmy
    listitem = xbmcgui.ListItem(label="Populární")
    icon_file = os.path.join(ICONS_PATH, 'popularni.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='filmy_popularni'), listitem, True)

    # Trendy filmy
    listitem = xbmcgui.ListItem(label="Trendy")
    icon_file = os.path.join(ICONS_PATH, 'trendy.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='filmy_trendy'), listitem, True)

    # Novinky dabované
    listitem = xbmcgui.ListItem(label="Novinky dabované")    
    icon_file = os.path.join(ICONS_PATH, 'novinkydabovane.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='filmy_novinkydabovane'), listitem, True)

    # Brzy vychází/jde do kin
    listitem = xbmcgui.ListItem(label="Brzy vychází/jde do kin")
    icon_file = os.path.join(ICONS_PATH, 'upcoming.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='filmy_upcoming'), listitem, True)

    # Nejlépe hodnocené filmy
    listitem = xbmcgui.ListItem(label="Nejlépe hodnocené")
    icon_file = os.path.join(ICONS_PATH, 'nejlepehodnocene.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='filmy_nejlepehodnocene'), listitem, True)

    # Žánry - filmy
    listitem = xbmcgui.ListItem(label="Žánry")
    icon_file = os.path.join(ICONS_PATH, 'zanry.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='filmy_zanry'), listitem, True)

    # Populární na VOD
    listitem = xbmcgui.ListItem(label="Populární na VOD")
    icon_file = os.path.join(ICONS_PATH, 'vod.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='filmy_vod'), listitem, True)

    # Hledat filmové kolekce
    listitem = xbmcgui.ListItem(label="Hledat filmové kolekce")
    icon_file = os.path.join(ICONS_PATH, 'kolekce.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='filmy_kolekce'), listitem, True)

    # Tématické seznamy
    listitem = xbmcgui.ListItem(label="Tématické seznamy")
    icon_file = os.path.join(ICONS_PATH, 'tematickeseznamy.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='filmy_tematickeseznamy'), listitem, True)
    
    # Filmy pro děti
    listitem = xbmcgui.ListItem(label="Filmy pro děti")
    icon_file = os.path.join(ICONS_PATH, 'deti.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='filmy_deti'), listitem, True)

    # Filmy podle roku
    listitem = xbmcgui.ListItem(label="Filmy podle roku")
    icon_file = os.path.join(ICONS_PATH, 'podleroku.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='filmy_rok'), listitem, True)

    xbmcplugin.endOfDirectory(_handle)    

def serialy_menu(params):
    ICONS_PATH = get_icons_path()

    # Hledat seriál
    listitem = xbmcgui.ListItem(label="Hledat seriál")
    icon_file = os.path.join(ICONS_PATH, 'vyhledavani.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='hledat_serial'), listitem, True)

    # Populární na VOD
    listitem = xbmcgui.ListItem(label="Populární na VOD")
    icon_file = os.path.join(ICONS_PATH, 'popularni.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='tv_popularnivod'), listitem, True)
    
    # Novinky na VOD
    listitem = xbmcgui.ListItem(label="Novinky na VOD")
    icon_file = os.path.join(ICONS_PATH, 'vod.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='tv_novinkyvod'), listitem, True)

    # Trendy seriály
    listitem = xbmcgui.ListItem(label="Trendy")
    icon_file = os.path.join(ICONS_PATH, 'trendy.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='tv_trendy'), listitem, True)

    # Nejoblíbenější seriály
    listitem = xbmcgui.ListItem(label="Nejoblíbenější")
    icon_file = os.path.join(ICONS_PATH, 'nejoblibenejsi.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='tv_nejoblibenejsi'), listitem, True)

    # Nejlépe hodnocené seriály
    listitem = xbmcgui.ListItem(label="Nejlépe hodnocené")
    icon_file = os.path.join(ICONS_PATH, 'nejlepehodnocene.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='tv_nejlepehodnocene'), listitem, True)

    # Žánry - seriály
    listitem = xbmcgui.ListItem(label="Žánry")
    icon_file = os.path.join(ICONS_PATH, 'zanry.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='tv_zanry'), listitem, True)    

    # Streamovací služby
    listitem = xbmcgui.ListItem(label="Streamovací služby")
    icon_file = os.path.join(ICONS_PATH, 'streamovacisluzby.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='vod_menu'), listitem, True)    

    # Seriály pro děti
    listitem = xbmcgui.ListItem(label="Seriály pro děti")
    icon_file = os.path.join(ICONS_PATH, 'deti.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='tv_prodeti'), listitem, True)

    # Seriály podle roku
    listitem = xbmcgui.ListItem(label="Seriály podle roku")
    icon_file = os.path.join(ICONS_PATH, 'podleroku.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='tv_podleroku'), listitem, True)

    xbmcplugin.endOfDirectory(_handle)

def filmy_tematickeseznamymenu(params):
    ICONS_PATH = get_icons_path() 

    # Vánoce
    listitem = xbmcgui.ListItem(label="Vánoce")
    icon_file = os.path.join(ICONS_PATH, 'vanoce.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='filmy_vanoce'), listitem, True)

    # Zamilované páry
    listitem = xbmcgui.ListItem(label="Zamilované páry")
    icon_file = os.path.join(ICONS_PATH, 'zamilovanepary.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='filmy_zamilovanepary'), listitem, True)

    # Letní pohoda
    listitem = xbmcgui.ListItem(label="Letní pohoda")
    icon_file = os.path.join(ICONS_PATH, 'letnipohoda.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='filmy_letnipohoda'), listitem, True)

    # Nejlepší české filmy
    listitem = xbmcgui.ListItem(label="Nejlepší české filmy")
    icon_file = os.path.join(ICONS_PATH, 'ceskefilmy.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='filmy_ceske'), listitem, True)

    # Uživatelské TMDB seznamy
    user_lists = _addon.getSetting('vlastniseznamy')
    if user_lists:
        for entry in user_lists.split(','):
            entry = entry.strip()
            if ':' in entry:
                list_id, name = entry.split(':', 1)
                list_id = list_id.strip()
                name = name.strip()
                listitem = xbmcgui.ListItem(label=name)
                icon_file = os.path.join(ICONS_PATH, 'userlist.png')
                listitem.setArt({'icon': icon_file, 'thumb': icon_file})
                xbmcplugin.addDirectoryItem(_handle, get_url(action='userlist', list_id=list_id, name=name), listitem, True)

    xbmcplugin.endOfDirectory(_handle)   

def vod_menu(params):
    ICONS_PATH = get_icons_path() 

    # Netflix
    listitem = xbmcgui.ListItem(label="Netflix")
    icon_file = os.path.join(ICONS_PATH, 'netflix.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='tv_netflix'), listitem, True)

    # HBO MAX
    listitem = xbmcgui.ListItem(label="HBO MAX")
    icon_file = os.path.join(ICONS_PATH, 'hbo.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='tv_hbo'), listitem, True)

    # Disney+
    listitem = xbmcgui.ListItem(label="Disney+")
    icon_file = os.path.join(ICONS_PATH, 'disney.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='tv_disney'), listitem, True)
    
    # Apple TV+
    listitem = xbmcgui.ListItem(label="Apple TV+")
    icon_file = os.path.join(ICONS_PATH, 'apple.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='tv_apple'), listitem, True)

    # Amazon Prime Video
    listitem = xbmcgui.ListItem(label="Amazon Prime Video")
    icon_file = os.path.join(ICONS_PATH, 'amazon.png')
    listitem.setArt({'icon': icon_file, 'thumb': icon_file})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='tv_amazon'), listitem, True)

    xbmcplugin.endOfDirectory(_handle)

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params['action'] == 'search':
            search(params)
        elif params['action'] == 'queue':
            queue(params)
        elif params['action'] == 'history':
            history(params)
        elif params['action'] == 'settings':
            settings(params)
        elif params['action'] == 'info':
            info(params)
        elif params['action'] == 'play':
            play(params)
        elif params['action'] == 'download':
            download(params)
        elif params['action'] == 'db':
            db(params)
        elif params['action'] == 'filmy':
            filmy_menu(params)
        elif params['action'] == 'filmy_tematickeseznamy':
            filmy_tematickeseznamymenu(params)
        elif params['action'] == 'tv_tematickeseznamy':
            serialy_tematickeseznamymenu(params)
        elif params['action'] == 'vod_menu':
            vod_menu(params)
        elif params['action'] == 'serialy':
            serialy_menu(params)

        elif params['action'] == 'userlist':
            list_id = params.get('list_id')
            name = params.get('name')            
            if tmdb and list_id:
                page = int(params.get('page', 1))
                tmdb.vlastniseznam(_handle, list_id, name, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB ID není zadáno nebo TMDB modul není dostupný.")
        
        # Hledání filmů přes TMDB (interaktivní vyhledávač)
        elif params['action'] == 'hledat_film':
            if tmdb:
                page = int(params.get('page', 1))
                query = params.get('query')
                tmdb.interactive_movie_search(_handle, page=page, query=query)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.") 

        # Hledání filmových kolekcí přes TMDB (interaktivní vyhledávač)
        elif params['action'] == 'filmy_kolekce':
            if tmdb:
                page = int(params.get('page', 1))
                query = params.get('query')
                tmdb.search_movie_collections(_handle, page=page, query=query)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")

        elif params['action'] == 'show_collection_detail':
            if tmdb:
                collection_id = params.get('collection_id')
                name = params.get('name')
                tmdb.show_collection_detail(_handle, collection_id=collection_id, name=name)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")                      

        # Zobrazí obsah pro Novinky dabované
        elif params['action'] == 'filmy_novinkydabovane':
            if tmdb:
                page = int(params.get('page', 1))
                tmdb.show_novinkydabovane(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")

        # TÉMATICKÉ SEZNAMY FILMŮ - VÁNOCE
        elif params['action'] == 'filmy_vanoce':
            if tmdb:
                page = int(params.get('page', 1))
                tmdb.show_vanoce(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")

        # TÉMATICKÉ SEZNAMY FILMŮ - LETNÍ POHODA
        elif params['action'] == 'filmy_letnipohoda':
            if tmdb:
                page = int(params.get('page', 1))
                tmdb.show_letnipohoda(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")        

        # TÉMATICKÉ SEZNAMY FILMŮ - ZAMILOVANÉ PÁRY
        elif params['action'] == 'filmy_zamilovanepary':
            if tmdb:
                page = int(params.get('page', 1))
                tmdb.show_zamilovane_pary(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")               
        
        # Zobrazí obsah pro Nejlépe hodnocené filmy pomocí TMDB
        elif params['action'] == 'filmy_nejlepehodnocene':            
            if tmdb:
                page = int(params.get('page', 1))
                tmdb.show_top_rated_movies(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")

        # Zobrazí obsah pro filmy podle roku přes TMDB
        elif params['action'] == 'filmy_rok':
            if tmdb:
                year = params.get('year')
                page = int(params.get('page', 1))
                tmdb.show_movies_by_year(_handle, page=page, year=year)   
        
        # Zobrazí obsah pro Populární filmy pomocí TMDB
        elif params['action'] == 'filmy_popularni':            
            if tmdb:
                page = int(params.get('page', 1))
                tmdb.show_popular_movies(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")

        # Zobrazí obsah pro nadcházející filmy pomocí TMDB
        elif params['action'] == 'filmy_upcoming':            
            if tmdb:
                page = int(params.get('page', 1))
                tmdb.show_upcoming_movies(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")        
        
        # Zobrazí obsah pro Trendy filmy pomocí TMDB
        elif params['action'] == 'filmy_trendy':            
            if tmdb:
                page = int(params.get('page', 1))
                tmdb.show_trending_movies(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")

        # Zobrazí obsah pro nejlepší české filmy
        elif params['action'] == 'filmy_ceske':
            if tmdb:
                page = int(params.get('page', 1))
                tmdb.show_best_czech_movies(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")

        # Zobrazí seznam populárních filmů na VOD
        elif params['action'] == 'filmy_vod':
            if tmdb:
                page = int(params.get('page', 1))
                tmdb.show_popular_streaming_movies(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")      
        
        # Zobrazí seznam populárních filmů pro děti
        elif params['action'] == 'filmy_deti':
            if tmdb:
                page = int(params.get('page', 1))
                tmdb.show_kids_and_family_movies(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")
        #-------------------------------------------------------------------SERIÁLY ROUTER------------------------------------------------------------      
        
        # Zobrazí seznam sezón pro vybraný seriál
        elif params['action'] == 'show_tv_seasons':
            if serialy:
                tv_id = params.get('tv_id')
                title = params.get('title')
                serialy.show_tv_seasons(_handle, tv_id=tv_id, title=title)
            else:
                xbmcgui.Dialog().ok("Chyba", "Modul pro seriály není dostupný.")

        # Zobrazí seznam epizod pro vybraný seriál a sezónu
        elif params['action'] == 'show_tv_episodes':
            if serialy:
                tv_id = params.get('tv_id')
                season_number = params.get('season_number')
                title = params.get('title')
                serialy.show_tv_episodes(_handle, tv_id=tv_id, season_number=season_number, title=title)
            else:
                xbmcgui.Dialog().ok("Chyba", "Modul pro seriály není dostupný.")
        
        # Hledání seriálů přes TMDB (interaktivní vyhledávač)
        elif params['action'] == 'hledat_serial':
            if serialy:
                page = int(params.get('page', 1))
                query = params.get('query')
                serialy.interactive_tv_search(_handle, page=page, query=query)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")
        
        # Zobrazí seznam populárních seriálů na VOD pomocí TMDB
        elif params['action'] == 'tv_popularnivod':
            if serialy:
                page = int(params.get('page', 1))
                serialy.tv_popularnivod(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")

        # Zobrazí seznam seriálů pro děti TMDB
        elif params['action'] == 'tv_prodeti':
            if serialy:
                page = int(params.get('page', 1))
                serialy.tv_prodeti(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")

        # Zobrazí obsah pro seriály podle roku přes TMDB
        elif params['action'] == 'tv_podleroku':
            if serialy:
                year = params.get('year')
                page = int(params.get('page', 1))
                serialy.tv_podleroku(_handle, page=page, year=year)

        # Zobrazí seznam nových seriálů na VOD pomocí TMDB
        elif params['action'] == 'tv_novinkyvod':
            if serialy:
                page = int(params.get('page', 1))
                serialy.tv_novinkyvod(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.") 

        # Zobrazí nejoblíbenější seriály pomocí TMDB
        elif params['action'] == 'tv_nejoblibenejsi':
            if serialy:
                page = int(params.get('page', 1))
                serialy.tv_nejoblibenejsi(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")               

        # Zobrazí seznam trendy seriálů pomocí TMDB
        elif params['action'] == 'tv_trendy':
            if serialy:
                page = int(params.get('page', 1))
                serialy.tv_trendy(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")

        # Zobrazí seznam nejlépe hodnocených seriálů pomocí TMDB
        elif params['action'] == 'tv_nejlepehodnocene':
            if serialy:
                page = int(params.get('page', 1))
                serialy.tv_nejlepehodnocene(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")

        # Zobrazí populární seriály na Neflixu pomocí TMDB
        elif params['action'] == 'tv_netflix':
            if serialy:
                page = int(params.get('page', 1))
                serialy.tv_netflix(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")

        # Zobrazí populární seriály na HBO MAX pomocí TMDB
        elif params['action'] == 'tv_hbo':
            if serialy:
                page = int(params.get('page', 1))
                serialy.tv_hbo(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")          

        # Zobrazí populární seriály na Disney+ pomocí TMDB
        elif params['action'] == 'tv_disney':
            if serialy:
                page = int(params.get('page', 1))
                serialy.tv_disney(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")

        # Zobrazí populární seriály na Apple TV+ pomocí TMDB
        elif params['action'] == 'tv_apple':
            if serialy:
                page = int(params.get('page', 1))
                serialy.tv_apple(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")

        # Zobrazí populární seriály na Amazon Prime Video pomocí TMDB
        elif params['action'] == 'tv_amazon':
            if serialy:
                page = int(params.get('page', 1))
                serialy.tv_amazon(_handle, page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")

        elif params['action'] == 'tv_zanry':
            if serialy:
                page = int(params.get('page', 1))
                genre_id = params.get('genre_id')
                genre_name = params.get('genre_name')
                serialy.tv_zanry(_handle, page=page, genre_id=genre_id, genre_name=genre_name)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")        

        # Zobrazí výsledky pro žánry seriálů pomocí TMDB
        elif params['action'] == 'tv_zanry_popularni':
            # Zobrazí seriály podle vybraného žánru včetně stránkování
            if serialy and 'genre_id' in params:
                page = int(params.get('page', 1))
                serialy.tv_zanry_popularni(_handle, params['genre_id'], page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "Žánr nebyl vybrán nebo TMDB modul není dostupný.")    

        # --------------------------------------------------------------------------------------------------------------------------------------------------
        # Zobrazí seznam žánrů a umožní vybrat filmy podle žánru pomocí TMDB
        elif params['action'] == 'filmy_zanry':            
            if tmdb:
                # Získání seznamu žánrů z TMDB
                genres_url = f"{tmdb.TMDB_API_URL}/genre/movie/list"
                params_genres = {
                    "api_key": tmdb.TMDB_API_KEY,
                    "language": tmdb.TMDB_LANGUAGE
                }
                try:
                    response = requests.get(genres_url, params=params_genres, timeout=8)
                    response.raise_for_status()
                    data = response.json()
                    genres = data.get("genres", [])
                    for genre in genres:
                        genre_id = genre.get("id")
                        genre_name = genre.get("name")
                        listitem = xbmcgui.ListItem(label=genre_name)
                        xbmcplugin.addDirectoryItem(
                            _handle,
                            get_url(action='filmy_zanr_filmy', genre_id=genre_id),
                            listitem,
                            True
                        )
                    xbmcplugin.endOfDirectory(_handle)
                except Exception as e:
                    xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání žánrů: {e}", xbmcgui.NOTIFICATION_ERROR)
            else:
                xbmcgui.Dialog().ok("Chyba", "TMDB modul není dostupný.")

        elif params['action'] == 'filmy_zanr_filmy':
            # Zobrazí filmy podle vybraného žánru včetně stránkování
            if tmdb and 'genre_id' in params:
                page = int(params.get('page', 1))
                tmdb.show_movies_by_genre(_handle, params['genre_id'], page=page)
            else:
                xbmcgui.Dialog().ok("Chyba", "Žánr nebyl vybrán nebo TMDB modul není dostupný.")
        
        else:
            menu()
    else:
        menu()
