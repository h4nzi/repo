# Propojení StreamBoxu s TMDB API - 06/2025 by Johnysko

import requests
import xbmc
import xbmcgui
import xbmcplugin
import sys
from urllib.parse import urlencode
import os


def debugoutput():
    key_path = os.path.join(os.path.dirname(__file__), "debug_output.txt")
    try:
        with open(key_path, "r", encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        xbmcgui.Dialog().notification("TMDB", "Nepodařilo se načíst TMDB API klíč.", xbmcgui.NOTIFICATION_ERROR)
        return ""

TMDB_API_URL = "https://api.themoviedb.org/3"
TMDB_API_KEY = debugoutput()
TMDB_LANGUAGE = "cs-CZ"

# Šablony pro časté endpointy
TMDB_SEARCH_TV = f"{TMDB_API_URL}/search/tv"
TMDB_TV_DETAILS = f"{TMDB_API_URL}/tv/{{tv_id}}"
TMDB_TV_SEASON_DETAILS = f"{TMDB_API_URL}/tv/{{tv_id}}/season/{{season_number}}"
TMDB_TV_EPISODE_DETAILS = f"{TMDB_API_URL}/tv/{{tv_id}}/season/{{season_number}}/episode/{{episode_number}}"
TMDB_GENRES_TV = f"{TMDB_API_URL}/genre/tv/list"
TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p/"

# Výchozí velikosti obrázků (dle dokumentace TMDB)
TMDB_POSTER_SIZE = "w500"
TMDB_BACKDROP_SIZE = "w780"

# Výchozí parametry pro dotazy
TMDB_DEFAULT_PARAMS = {
    "api_key": TMDB_API_KEY,
    "language": TMDB_LANGUAGE
}

def get_url(**kwargs):
    base_url = sys.argv[0]
    return '{0}?{1}'.format(base_url, urlencode(kwargs, encoding='utf-8'))

#-------------------------------------------------------------------------------------------------------------------------------------------------------------
# DEFINUJ FUNKCE PRO ZOBRAZENÍ SEZON
def show_tv_seasons(handle, tv_id, title):
    url = f"{TMDB_API_URL}/tv/{tv_id}"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE
    }
    try:
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        seasons = data.get("seasons", [])
        for season in seasons:
            season_number = season.get("season_number")
            season_name = season.get("name", f"Sezóna {season_number}")
            poster_path = season.get("poster_path")
            poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
            listitem = xbmcgui.ListItem(label=season_name)
            if poster_url:
                listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
            url = get_url(action='show_tv_episodes', tv_id=tv_id, season_number=season_number, title=title)
            xbmcplugin.addDirectoryItem(handle, url, listitem, True)
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání sezón: {e}", xbmcgui.NOTIFICATION_ERROR)

# DEFINUJ FUNKCE PRO ZOBRAZENÍ EPIZOD
def show_tv_episodes(handle, tv_id, season_number, title):
    url = f"{TMDB_API_URL}/tv/{tv_id}/season/{season_number}"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE
    }
    try:
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        episodes = data.get("episodes", [])
        for episode in episodes:
            ep_number = episode.get("episode_number")
            ep_name = episode.get("name", f"Díl {ep_number}")
            plot = episode.get("overview", "")
            still_path = episode.get("still_path")
            still_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{still_path}" if still_path else ""
            label = f"{ep_number}. {ep_name}"
            # Nové sestavení hodnoty 'what' ve formátu: Title S01E01
            season_str = f"S{int(season_number):02d}"
            episode_str = f"E{int(ep_number):02d}"
            what = f"{title} {season_str}{episode_str}"
            # Přidání hodnoty what do popisku položky
            label_with_what = f"{label}  [COLOR grey][I]{what}[/I][/COLOR]"
            listitem = xbmcgui.ListItem(label=label_with_what)
            listitem.setInfo('video', {'plot': plot})
            if still_url:
                listitem.setArt({'thumb': still_url, 'poster': still_url})
            url_search = get_url(action='search', what=what)
            xbmcplugin.addDirectoryItem(handle, url_search, listitem, True)
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání epizod: {e}", xbmcgui.NOTIFICATION_ERROR)

# POPULÁRNÍ SERIÁLY NA VOD
def tv_popularnivod(handle, page=1):
    url = f"{TMDB_API_URL}/discover/tv"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "region": "CZ",
        "sort_by": "popularity.desc",
        "watch_region": "CZ",
        "with_watch_providers": "8|1899|337|531|350|119",
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        menu_url = get_url(action='serialy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---

        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        shows = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        for show in shows:
            tv_id = show.get("id")
            what = show.get("name", "Neznámý název")
            title = what
            rating = show.get("vote_average")
            year = show.get("first_air_date", "")[:4] if show.get("first_air_date") else ""
            if rating is not None and year:
                title_disp = f"{title} ({year}) [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif rating is not None:
                title_disp = f"{title} [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif year:
                title_disp = f"{title} ({year})"
            else:
                title_disp = title
            plot = show.get("overview", "")
            poster_path = show.get("poster_path")
            poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
            listitem = xbmcgui.ListItem(label=title_disp)
            listitem.setInfo('video', {'plot': plot})
            if poster_url:
                listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
            url = get_url(action='show_tv_seasons', tv_id=tv_id, title=title)
            xbmcplugin.addDirectoryItem(handle, url, listitem, True)
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='tv_popularnivod', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání VOD seriálů: {e}", xbmcgui.NOTIFICATION_ERROR)

# TRENDY SERIÁLY
def tv_trendy(handle, page=1):
    url = f"{TMDB_API_URL}/trending/tv/week"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        menu_url = get_url(action='serialy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        shows = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        for show in shows:
            tv_id = show.get("id")
            what = show.get("name", "Neznámý název")
            title = what
            rating = show.get("vote_average")
            year = show.get("first_air_date", "")[:4] if show.get("first_air_date") else ""
            if rating is not None and year:
                title_disp = f"{title} ({year}) [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif rating is not None:
                title_disp = f"{title} [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif year:
                title_disp = f"{title} ({year})"
            else:
                title_disp = title
            plot = show.get("overview", "")
            poster_path = show.get("poster_path")
            poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
            listitem = xbmcgui.ListItem(label=title_disp)
            listitem.setInfo('video', {'plot': plot})
            if poster_url:
                listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
            url = get_url(action='show_tv_seasons', tv_id=tv_id, title=title)
            xbmcplugin.addDirectoryItem(handle, url, listitem, True)
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='tv_trendy', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání trendy seriálů: {e}", xbmcgui.NOTIFICATION_ERROR)

# NEJLÉPE HODNOCENÉ SERIÁLY
def tv_nejlepehodnocene(handle, page=1):
    url = f"{TMDB_API_URL}/tv/top_rated"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        menu_url = get_url(action='serialy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        shows = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        for show in shows:
            tv_id = show.get("id")
            what = show.get("name", "Neznámý název")
            title = what
            rating = show.get("vote_average")
            year = show.get("first_air_date", "")[:4] if show.get("first_air_date") else ""
            if rating is not None and year:
                title_disp = f"{title} ({year}) [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif rating is not None:
                title_disp = f"{title} [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif year:
                title_disp = f"{title} ({year})"
            else:
                title_disp = title
            plot = show.get("overview", "")
            poster_path = show.get("poster_path")
            poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
            listitem = xbmcgui.ListItem(label=title_disp)
            listitem.setInfo('video', {'plot': plot})
            if poster_url:
                listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
            url = get_url(action='show_tv_seasons', tv_id=tv_id, title=title)
            xbmcplugin.addDirectoryItem(handle, url, listitem, True)
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='tv_nejlepehodnocene', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání nejlépe hodnocených seriálů: {e}", xbmcgui.NOTIFICATION_ERROR)



# Novinky na VOD
def tv_novinkyvod(handle, page=1):
    import datetime
    today = datetime.date.today()
    from_date = today - datetime.timedelta(days=14)
    url = f"{TMDB_API_URL}/discover/tv"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "region": "CZ",
        "sort_by": "first_air_date.desc",
        "watch_region": "CZ",
        # Netflix(8), HBO Max(1899), Disney+(337), SkyShowtime(531), Apple TV+(350), Amazon Prime Video(119)
        "with_watch_providers": "8|1899|337|531|350|119",
        "first_air_date.gte": from_date.isoformat(),
        "first_air_date.lte": today.isoformat(),
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        menu_url = get_url(action='serialy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        shows = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        for show in shows:
            tv_id = show.get("id")
            what = show.get("name", "Neznámý název")
            title = what
            rating = show.get("vote_average")
            year = show.get("first_air_date", "")[:4] if show.get("first_air_date") else ""
            if rating is not None and year:
                title_disp = f"{title} ({year}) [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif rating is not None:
                title_disp = f"{title} [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif year:
                title_disp = f"{title} ({year})"
            else:
                title_disp = title
            plot = show.get("overview", "")
            poster_path = show.get("poster_path")
            poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
            listitem = xbmcgui.ListItem(label=title_disp)
            listitem.setInfo('video', {'plot': plot})
            if poster_url:
                listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
            url = get_url(action='show_tv_seasons', tv_id=tv_id, title=title)
            xbmcplugin.addDirectoryItem(handle, url, listitem, True)
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='tv_novinkyvod', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání novinek na VOD: {e}", xbmcgui.NOTIFICATION_ERROR)

# NEJOBLÍBENĚJŠÍ SERIÁLY
def tv_nejoblibenejsi(handle, page=1):
    
    url = f"{TMDB_API_URL}/discover/tv"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "region": "CZ",
        "sort_by": "vote_count.desc",  # řazení podle počtu hlasů
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        menu_url = get_url(action='serialy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        shows = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        for show in shows:
            tv_id = show.get("id")
            what = show.get("name", "Neznámý název")
            title = what
            rating = show.get("vote_average")            
            year = show.get("first_air_date", "")[:4] if show.get("first_air_date") else ""
            if rating is not None and year:
                title_disp = f"{title} ({year}) [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif rating is not None:
                title_disp = f"{title} [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif year:
                title_disp = f"{title} ({year})"
            else:
                title_disp = title
            plot = show.get("overview", "")
            poster_path = show.get("poster_path")
            poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
            listitem = xbmcgui.ListItem(label=title_disp)
            listitem.setInfo('video', {'plot': plot})
            if poster_url:
                listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
            url = get_url(action='show_tv_seasons', tv_id=tv_id, title=title)
            xbmcplugin.addDirectoryItem(handle, url, listitem, True)
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='tv_nejoblibenejsi', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání nejoblíbenějších seriálů: {e}", xbmcgui.NOTIFICATION_ERROR)

# POPULÁRNÍ SERIÁLY NA NETFLIXU
def tv_netflix(handle, page=1):
    
    url = f"{TMDB_API_URL}/discover/tv"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "region": "CZ",
        "sort_by": "popularity.desc",
        "with_watch_providers": "8",  # 8 = Netflix
        "watch_region": "CZ",
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        menu_url = get_url(action='serialy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        shows = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        for show in shows:
            tv_id = show.get("id")
            what = show.get("name", "Neznámý název")
            title = what
            rating = show.get("vote_average")
            year = show.get("first_air_date", "")[:4] if show.get("first_air_date") else ""
            if rating is not None and year:
                title_disp = f"{title} ({year}) [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif rating is not None:
                title_disp = f"{title} [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif year:
                title_disp = f"{title} ({year})"
            else:
                title_disp = title
            plot = show.get("overview", "")
            poster_path = show.get("poster_path")
            poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
            listitem = xbmcgui.ListItem(label=title_disp)
            listitem.setInfo('video', {'plot': plot})
            if poster_url:
                listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
            url = get_url(action='show_tv_seasons', tv_id=tv_id, title=title)
            xbmcplugin.addDirectoryItem(handle, url, listitem, True)
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='tv_netflix', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání populárních seriálů na Netflixu: {e}", xbmcgui.NOTIFICATION_ERROR)

# POPULÁRNÍ SERIÁLY NA DISNEY+
def tv_disney(handle, page=1):

    url = f"{TMDB_API_URL}/discover/tv"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,        
        "sort_by": "popularity.desc",
        "with_watch_providers": "337",  # 337 = Disney+
        "watch_region": "CZ",
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        menu_url = get_url(action='serialy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        shows = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        for show in shows:
            tv_id = show.get("id")
            what = show.get("name", "Neznámý název")
            title = what
            rating = show.get("vote_average")
            year = show.get("first_air_date", "")[:4] if show.get("first_air_date") else ""
            if rating is not None and year:
                title_disp = f"{title} ({year}) [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif rating is not None:
                title_disp = f"{title} [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif year:
                title_disp = f"{title} ({year})"
            else:
                title_disp = title
            plot = show.get("overview", "")
            poster_path = show.get("poster_path")
            poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
            listitem = xbmcgui.ListItem(label=title_disp)
            listitem.setInfo('video', {'plot': plot})
            if poster_url:
                listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
            url = get_url(action='show_tv_seasons', tv_id=tv_id, title=title)
            xbmcplugin.addDirectoryItem(handle, url, listitem, True)
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='tv_disney', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání populárních seriálů na Disney+: {e}", xbmcgui.NOTIFICATION_ERROR)

# POPULÁRNÍ SERIÁLY NA APPLE TV+
def tv_apple(handle, page=1):

    url = f"{TMDB_API_URL}/discover/tv"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,        
        "sort_by": "popularity.desc",
        "with_watch_providers": "350",  # 350 = Apple TV+
        "watch_region": "CZ",
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        menu_url = get_url(action='serialy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        shows = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        for show in shows:
            tv_id = show.get("id")
            what = show.get("name", "Neznámý název")
            title = what
            rating = show.get("vote_average")
            year = show.get("first_air_date", "")[:4] if show.get("first_air_date") else ""
            if rating is not None and year:
                title_disp = f"{title} ({year}) [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif rating is not None:
                title_disp = f"{title} [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif year:
                title_disp = f"{title} ({year})"
            else:
                title_disp = title
            plot = show.get("overview", "")
            poster_path = show.get("poster_path")
            poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
            listitem = xbmcgui.ListItem(label=title_disp)
            listitem.setInfo('video', {'plot': plot})
            if poster_url:
                listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
            url = get_url(action='show_tv_seasons', tv_id=tv_id, title=title)
            xbmcplugin.addDirectoryItem(handle, url, listitem, True)
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='tv_apple', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání populárních seriálů na Apple TV+: {e}", xbmcgui.NOTIFICATION_ERROR)

# POPULÁRNÍ SERIÁLY NA Amazon Prime Video
def tv_amazon(handle, page=1):

    url = f"{TMDB_API_URL}/discover/tv"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,        
        "sort_by": "popularity.desc",
        "with_watch_providers": "119",  # 119 = Amazon Prime Video
        "watch_region": "CZ",
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        menu_url = get_url(action='serialy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        shows = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        for show in shows:
            tv_id = show.get("id")
            what = show.get("name", "Neznámý název")
            title = what
            rating = show.get("vote_average")
            year = show.get("first_air_date", "")[:4] if show.get("first_air_date") else ""
            if rating is not None and year:
                title_disp = f"{title} ({year}) [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif rating is not None:
                title_disp = f"{title} [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif year:
                title_disp = f"{title} ({year})"
            else:
                title_disp = title
            plot = show.get("overview", "")
            poster_path = show.get("poster_path")
            poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
            listitem = xbmcgui.ListItem(label=title_disp)
            listitem.setInfo('video', {'plot': plot})
            if poster_url:
                listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
            url = get_url(action='show_tv_seasons', tv_id=tv_id, title=title)
            xbmcplugin.addDirectoryItem(handle, url, listitem, True)
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='tv_amazon', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání populárních seriálů na Amazon Prime Video: {e}", xbmcgui.NOTIFICATION_ERROR)

# POPULÁRNÍ SERIÁLY NA HBO MAX
def tv_hbo(handle, page=1):

    url = f"{TMDB_API_URL}/discover/tv"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,        
        "sort_by": "popularity.desc",
        "with_watch_providers": "1899",  # 1899 = HBO Max
        "watch_region": "CZ",
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        menu_url = get_url(action='serialy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        shows = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        for show in shows:
            tv_id = show.get("id")
            what = show.get("name", "Neznámý název")
            title = what
            rating = show.get("vote_average")
            year = show.get("first_air_date", "")[:4] if show.get("first_air_date") else ""
            if rating is not None and year:
                title_disp = f"{title} ({year}) [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif rating is not None:
                title_disp = f"{title} [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif year:
                title_disp = f"{title} ({year})"
            else:
                title_disp = title
            plot = show.get("overview", "")
            poster_path = show.get("poster_path")
            poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
            listitem = xbmcgui.ListItem(label=title_disp)
            listitem.setInfo('video', {'plot': plot})
            if poster_url:
                listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
            url = get_url(action='show_tv_seasons', tv_id=tv_id, title=title)
            xbmcplugin.addDirectoryItem(handle, url, listitem, True)
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='tv_hbo', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání populárních seriálů na HBO Max: {e}", xbmcgui.NOTIFICATION_ERROR)

# POPULÁRNÍ SERIÁLY PRO DĚTI
def tv_prodeti(handle, page=1):

    url = f"{TMDB_API_URL}/discover/tv"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "region": "CZ",
        "sort_by": "popularity.desc",
        "with_genres": "16,10762,10751",  # 16=Animovaný, 10762=Dětský, 10751=Rodinný
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        menu_url = get_url(action='serialy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        shows = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        for show in shows:
            tv_id = show.get("id")
            what = show.get("name", "Neznámý název")            
            title = what
            rating = show.get("vote_average")
            year = show.get("first_air_date", "")[:4] if show.get("first_air_date") else ""
            if rating is not None and year:
                title_disp = f"{title} ({year}) [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif rating is not None:
                title_disp = f"{title} [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif year:
                title_disp = f"{title} ({year})"
            else:
                title_disp = title
            plot = show.get("overview", "")
            poster_path = show.get("poster_path")
            poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
            listitem = xbmcgui.ListItem(label=title_disp)
            listitem.setInfo('video', {'plot': plot})
            if poster_url:
                listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
            url = get_url(action='show_tv_seasons', tv_id=tv_id, title=title)
            xbmcplugin.addDirectoryItem(handle, url, listitem, True)
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='tv_prodeti', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání dětských seriálů: {e}", xbmcgui.NOTIFICATION_ERROR)

# SERIÁLY PODLE ROKU
def tv_podleroku(handle, page=1, year=None):
    # Pokud není rok zadán, zeptej se uživatele
    if not year:
        year = xbmcgui.Dialog().input("Zadejte rok prvního vysílání (např. 2020)", type=xbmcgui.INPUT_NUMERIC)
        if not year or not year.isdigit() or len(year) != 4:
            xbmcgui.Dialog().notification("TMDB", "Neplatný rok.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(handle)
            return

    url = f"{TMDB_API_URL}/discover/tv"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "first_air_date_year": year,
        "sort_by": "popularity.desc",
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        menu_url = get_url(action='serialy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        shows = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        if not shows:
            listitem = xbmcgui.ListItem(label="Žádné výsledky")
            xbmcplugin.addDirectoryItem(handle, "", listitem, False)
        else:
            for show in shows:
                tv_id = show.get("id")
                what = show.get("name", "Neznámý název")
                title = what
                rating = show.get("vote_average")
                first_air_date = show.get("first_air_date", "")
                year_show = ""
                if first_air_date and len(first_air_date) >= 4:
                    year_show = first_air_date[:4]
                if rating is not None and year_show:
                    title_disp = f"{title} ({year_show}) [COLOR yellow]({float(rating):.1f})[/COLOR]"
                elif rating is not None:
                    title_disp = f"{title} [COLOR yellow]({float(rating):.1f})[/COLOR]"
                elif year_show:
                    title_disp = f"{title} ({year_show})"
                else:
                    title_disp = title
                plot = show.get("overview", "")
                poster_path = show.get("poster_path")
                poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
                listitem = xbmcgui.ListItem(label=title_disp)
                listitem.setInfo('video', {'plot': plot})
                if poster_url:
                    listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
                url = get_url(action='show_tv_seasons', tv_id=tv_id, title=title)
                xbmcplugin.addDirectoryItem(handle, url, listitem, True)
        # Stránkování
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='tv_podleroku', year=year, page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání seriálů podle roku: {e}", xbmcgui.NOTIFICATION_ERROR)

# HLEDÁNÍ SERIÁLŮ
def interactive_tv_search(handle, page=1, query=None):
    # Nejprve se zeptej na hledanou frázi, pokud není zadána
    if not query:
        query = xbmcgui.Dialog().input("Zadejte název seriálu pro hledání")
        if not query:
            xbmcgui.Dialog().notification("Hledání", "Nebyla zadána žádná fráze.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(handle)
            return

    url = f"{TMDB_API_URL}/search/tv"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "query": query,
        "page": page
    }
    try:
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        shows = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        if not shows:
            listitem = xbmcgui.ListItem(label="Žádné výsledky")
            xbmcplugin.addDirectoryItem(handle, "", listitem, False)
        else:
            for show in shows:
                tv_id = show.get("id")
                what = show.get("name", "Neznámý název")
                title = what
                rating = show.get("vote_average")
                year = show.get("first_air_date", "")[:4] if show.get("first_air_date") else ""
                if rating is not None and year:
                    title_disp = f"{title} ({year}) [COLOR yellow]({float(rating):.1f})[/COLOR]"
                elif rating is not None:
                    title_disp = f"{title} [COLOR yellow]({float(rating):.1f})[/COLOR]"
                elif year:
                    title_disp = f"{title} ({year})"
                else:
                    title_disp = title
                plot = show.get("overview", "")
                poster_path = show.get("poster_path")
                poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
                listitem = xbmcgui.ListItem(label=title_disp)
                listitem.setInfo('video', {'plot': plot})
                if poster_url:
                    listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
                url = get_url(action='show_tv_seasons', tv_id=tv_id, title=title)
                xbmcplugin.addDirectoryItem(handle, url, listitem, True)
        # Stránkování
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='hledat_serial', query=query, page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při hledání seriálů: {e}", xbmcgui.NOTIFICATION_ERROR)

# Zobrazí seznam žánrů pro seriály
def tv_zanry(handle, page=1, genre_id=None, genre_name=None):

    url = f"{TMDB_API_URL}/genre/tv/list"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE
    }
    try:
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        genres = data.get("genres", [])
        if not genres:
            listitem = xbmcgui.ListItem(label="Žádné žánry nenalezeny")
            xbmcplugin.addDirectoryItem(handle, "", listitem, False)
        else:
            for genre in genres:
                genre_id = genre.get("id")
                genre_name = genre.get("name")
                listitem = xbmcgui.ListItem(label=genre_name)
                url_zanr = get_url(action='tv_zanry_popularni', genre_id=genre_id, genre_name=genre_name)
                xbmcplugin.addDirectoryItem(handle, url_zanr, listitem, True)
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání žánrů: {e}", xbmcgui.NOTIFICATION_ERROR)

# ZOBRAZÍ JEDNOTLIVÉ SERIÁLY V ŽÁNRU
def tv_zanry_popularni(handle, genre_id, page=1, genre_name=None):
    
    url = f"{TMDB_API_URL}/discover/tv"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "sort_by": "popularity.desc",
        "with_genres": genre_id,
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        menu_url = get_url(action='serialy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        shows = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        if not shows:
            listitem = xbmcgui.ListItem(label=f"Žádné seriály v žánru {genre_name}")
            xbmcplugin.addDirectoryItem(handle, "", listitem, False)
        else:
            for show in shows:
                tv_id = show.get("id")
                what = show.get("name", "Neznámý název")
                title = what
                rating = show.get("vote_average")
                year = show.get("first_air_date", "")[:4] if show.get("first_air_date") else ""
                if rating is not None and year:
                    title_disp = f"{title} ({year}) [COLOR yellow]({float(rating):.1f})[/COLOR]"
                elif rating is not None:
                    title_disp = f"{title} [COLOR yellow]({float(rating):.1f})[/COLOR]"
                elif year:
                    title_disp = f"{title} ({year})"
                else:
                    title_disp = title
                plot = show.get("overview", "")
                poster_path = show.get("poster_path")
                poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
                listitem = xbmcgui.ListItem(label=title_disp)
                listitem.setInfo('video', {'plot': plot})
                if poster_url:
                    listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
                url_detail = get_url(action='show_tv_seasons', tv_id=tv_id, title=title)
                xbmcplugin.addDirectoryItem(handle, url_detail, listitem, True)
        # Stránkování
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='tv_zanry_popularni', genre_id=genre_id, genre_name=genre_name, page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu seriálů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání seriálů v žánru: {e}", xbmcgui.NOTIFICATION_ERROR)

        
