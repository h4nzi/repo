# Propojení StreamBoxu s TMDB API - 06/2025 by Johnysko

import requests
import xbmc
import xbmcgui
import xbmcplugin
import sys
from urllib.parse import urlencode
from datetime import datetime
import os

def Msg(message):
        xbmc.log(message, level=xbmc.LOGINFO)

def load_tmdb_key():
    key_path = os.path.join(os.path.dirname(__file__), "debug_output.txt")
    try:
        with open(key_path, "r", encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        xbmcgui.Dialog().notification("TMDB", "Nepodařilo se načíst TMDB API klíč.", xbmcgui.NOTIFICATION_ERROR)
        return ""

TMDB_API_URL = "https://api.themoviedb.org/3"
TMDB_API_KEY = load_tmdb_key()
TMDB_LANGUAGE = "cs-CZ"

# Šablony pro časté endpointy
TMDB_SEARCH_MOVIE = f"{TMDB_API_URL}/search/movie"
TMDB_MOVIE_DETAILS = f"{TMDB_API_URL}/movie/{{movie_id}}"
TMDB_GENRES_MOVIE = f"{TMDB_API_URL}/genre/movie/list"
TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p/"

# Výchozí velikosti obrázků (dle dokumentace TMDB)
TMDB_POSTER_SIZE = "w500"
TMDB_BACKDROP_SIZE = "w780"

# Výchozí parametry pro dotazy
TMDB_DEFAULT_PARAMS = {
    "api_key": TMDB_API_KEY,
    "language": TMDB_LANGUAGE
}

GENRE_MAP = {
    28: "Akční",
    12: "Dobrodružný",
    16: "Animovaný",
    35: "Komedie",
    80: "Krimi",
    99: "Dokument",
    18: "Drama",
    10751: "Rodinný",
    14: "Fantasy",
    36: "Historický",
    27: "Horor",
    10402: "Hudební",
    9648: "Mysteriózní",
    10749: "Romantický",
    878: "Sci-Fi",
    10770: "TV film",
    53: "Thriller",
    10752: "Válečný",
    37: "Western"
}


def get_url(**kwargs):
    base_url = sys.argv[0]
    return '{0}?{1}'.format(base_url, urlencode(kwargs, encoding='utf-8'))
    
def create_movie_listitems(movies, handle, action="search"):
    for movie in movies:
        movie_id = movie.get("id")  # potřebujeme pro detailní dotaz
        if not movie_id:
            continue

        # 🔹 Načti detailní data z TMDB /movie/{id}
        try:
            details_url = f"{TMDB_API_URL}/movie/{movie_id}"
            details_params = {
                "api_key": TMDB_API_KEY,
                "language": TMDB_LANGUAGE
            }
            details_response = requests.get(details_url, params=details_params, timeout=8)
            details_response.raise_for_status()
            details = details_response.json()
        except Exception as e:
            Msg(f"[Chyba] Detail filmu selhal ({movie_id}): {e}")
            details = {}

        what = movie.get("title", "Neznámý název")
        title = movie.get("title", "Neznámý název")
        rating = movie.get("vote_average")
        release_date = movie.get("release_date", "")
        year = release_date[:4] if release_date and len(release_date) >= 4 else ""
        plot = movie.get("overview", "")
        genre_ids = movie.get("genre_ids", [])
        genres = [GENRE_MAP.get(gid) for gid in genre_ids if GENRE_MAP.get(gid)]
        genre_str = ", ".join(genres)

        runtime = details.get("runtime", 0)  # získané z detailu

        poster_path = movie.get("poster_path")
        backdrop_path = movie.get("backdrop_path")
        poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
        fanart_url = f"{TMDB_IMAGE_BASE}{TMDB_BACKDROP_SIZE}{backdrop_path}" if backdrop_path else ""

        listitem = xbmcgui.ListItem(label=title)
        listitem.setInfo('video', {
            'rating': float(rating) if rating else 0.0,
            'year': int(year) if year else 0,
            'votes': movie.get('vote_count', 0),
            'genre': genre_str,
            'duration': runtime,  # ✔️ teď je to správně
            'plot': plot
        })

        if poster_url:
            listitem.setArt({
                'icon': poster_url,
                'thumb': poster_url,
                'poster': poster_url,
                'fanart': fanart_url
            })

        xbmcplugin.setContent(handle, "movies")
        xbmcplugin.addDirectoryItem(handle, get_url(action=action, what=title), listitem, True)


# --------------------------------------------------------------------------------------------------------------------------------------------------------------
# POPULÁRNÍ FILMY
def show_popular_movies(handle, page=1):
    url = f"{TMDB_API_URL}/movie/popular"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        menu_url = get_url(action='filmy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        movies = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        
        create_movie_listitems(movies, handle)

        # Přidání položky "Další stránka" pokud existuje další stránka
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='filmy_popularni', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        xbmcplugin.setContent(handle, "movies")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání populárních filmů: {e}", xbmcgui.NOTIFICATION_ERROR)

# TRENDY FILMY
def show_trending_movies(handle, page=1, time_window="week"):
    url = f"{TMDB_API_URL}/trending/movie/{time_window}"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "page": page
    }
    try:        
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        menu_url = get_url(action='filmy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---

        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        movies = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        create_movie_listitems(movies, handle)

        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='filmy_trendy', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        xbmcplugin.setContent(handle, "movies")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání trendy filmů: {e}", xbmcgui.NOTIFICATION_ERROR)

# NEJLÉPE HODNOCENÉ FILMY
def show_top_rated_movies(handle, page=1):
    url = f"{TMDB_API_URL}/movie/top_rated"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        menu_url = get_url(action='filmy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        movies = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        create_movie_listitems(movies, handle)

        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='filmy_nejlepehodnocene', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        xbmcplugin.setContent(handle, "movies")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání nejlépe hodnocených filmů: {e}", xbmcgui.NOTIFICATION_ERROR)

# PŘIPRAVOVANÉ FILMY
def show_upcoming_movies(handle, page=1):
    from datetime import datetime
    url = f"{TMDB_API_URL}/movie/upcoming"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "region": "CZ",  # Přidáno pro filtrování podle regionu CZ
        "page": page
    }
    try:
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        movies = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        create_movie_listitems(movies, handle)

        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='filmy_upcoming', page=current_page + 1)
            xbmcplugin.setContent(handle, "movies")
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání připravovaných filmů: {e}", xbmcgui.NOTIFICATION_ERROR)

# FILMY PODLE ŽÁNRU
def show_movies_by_genre(handle, genre_id, page=1):
    url = f"{TMDB_API_URL}/discover/movie"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "with_genres": genre_id,
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        menu_url = get_url(action='filmy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        movies = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        create_movie_listitems(movies, handle)

        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='filmy_zanr_filmy', genre_id=genre_id, page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        xbmcplugin.setContent(handle, "movies")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání filmů podle žánru: {e}", xbmcgui.NOTIFICATION_ERROR)

# POPULÁRNÍ FILMY NA STREAMOVACÍCH PLATFORMÁCH
def show_popular_streaming_movies(handle, page=1, region="CZ"):
    url = f"{TMDB_API_URL}/discover/movie"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "sort_by": "popularity.desc",
        "with_watch_monetization_types": "flatrate",
        "watch_region": region,
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        menu_url = get_url(action='filmy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        movies = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        create_movie_listitems(movies, handle)

        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='filmy_vod', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        xbmcplugin.setContent(handle, "movies")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání populárních filmů na streamovacích platformách: {e}", xbmcgui.NOTIFICATION_ERROR)

# NEJLEPŠÍ ČESKÉ FILMY
def show_best_czech_movies(handle, page=1, min_votes=50):
    url = f"{TMDB_API_URL}/discover/movie"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "with_original_language": "cs",
        "sort_by": "vote_average.desc",
        "vote_count.gte": min_votes,
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        menu_url = get_url(action='filmy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        movies = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        create_movie_listitems(movies, handle)

        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='filmy_ceske', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        xbmcplugin.setContent(handle, "movies")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání českých filmů: {e}", xbmcgui.NOTIFICATION_ERROR)

# FILMY PODLE ROKU
def show_movies_by_year(handle, page=1, year=None):
    # Pokud není rok zadán, zeptej se uživatele
    if not year:
        year = xbmcgui.Dialog().input("Zadejte rok (např. 2020)", type=xbmcgui.INPUT_NUMERIC)
        if not year or not year.isdigit() or len(year) != 4:
            xbmcgui.Dialog().notification("TMDB", "Neplatný rok.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(handle)
            return

    url = f"{TMDB_API_URL}/discover/movie"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "primary_release_year": year,
        "sort_by": "popularity.desc",
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        menu_url = get_url(action='filmy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        movies = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        if not movies:
            listitem = xbmcgui.ListItem(label="Žádné výsledky")
            xbmcplugin.addDirectoryItem(handle, "", listitem, False)
        else:
            for movie in movies:
                what = movie.get("title", "Neznámý název")
                title = what
                rating = movie.get("vote_average")
                release_date = movie.get("release_date", "")
                year_movie = ""
                if release_date and len(release_date) >= 4:
                    year_movie = release_date[:4]
                plot = movie.get("overview", "")
                poster_path = movie.get("poster_path")
                poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
                listitem = xbmcgui.ListItem(label=title)
                listitem.setInfo('video', {'plot': plot})
                if poster_url:
                    listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
                xbmcplugin.setContent(handle, "movies")
                xbmcplugin.addDirectoryItem(handle, get_url(action='search', what=what), listitem, True)
        # Stránkování
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='filmy_rok', year=year, page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání filmů podle roku: {e}", xbmcgui.NOTIFICATION_ERROR)

# NOVINKY DABOVANÉ
def show_novinkydabovane(handle, list_id="8539026", page=1):
    url = f"{TMDB_API_URL}/list/{list_id}"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE
    }
    try:
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        Msg(f"[DEBUG] Data {data}")
        movies = data.get("items", [])
        create_movie_listitems(movies, handle)

        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání TMDB seznamu: {e}", xbmcgui.NOTIFICATION_ERROR)

# INTERAKTIVNÍ VYHLEDÁVÁNÍ FILMŮ
def interactive_movie_search(handle, page=1, query=None):
    # Pokud není query zadané, zeptej se uživatele pouze při prvním spuštění
    if not query:
        query = xbmcgui.Dialog().input("Zadejte název filmu pro vyhledávání")
        if not query:
            xbmcgui.Dialog().notification("TMDB", "Nebyl zadán žádný výraz.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(handle)
            return

    url = f"{TMDB_API_URL}/search/movie"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "query": query,
        "page": page
    }
    try:
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        movies = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        if not movies:
            listitem = xbmcgui.ListItem(label="Žádné výsledky")
            xbmcplugin.addDirectoryItem(handle, "", listitem, False)
        else:
            for movie in movies:
                what = movie.get("title", "Neznámý název")
                title = what
                rating = movie.get("vote_average")
                release_date = movie.get("release_date", "")
                year = ""
                if release_date and len(release_date) >= 4:
                    year = release_date[:4]
                if rating is not None and year:
                    title = f"{title} ({year}) [COLOR yellow]({float(rating):.1f})[/COLOR]"
                elif rating is not None:
                    title = f"{title} [COLOR yellow]({float(rating):.1f})[/COLOR]"
                elif year:
                    title = f"{title} ({year})"
                plot = movie.get("overview", "")
                poster_path = movie.get("poster_path")
                poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
                listitem = xbmcgui.ListItem(label=title)
                listitem.setInfo('video', {'plot': plot})
                if poster_url:
                    listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
                xbmcplugin.addDirectoryItem(handle, get_url(action='search', what=what), listitem, True)
        # Stránkování
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='hledat_film', query=query, page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při vyhledávání filmů: {e}", xbmcgui.NOTIFICATION_ERROR)



# TÉMATICKÉ SEZNAMY - VÁNOCE
def show_vanoce(handle, list_id="8539322", page=1):
    url = f"{TMDB_API_URL}/list/{list_id}"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "page": page
        
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        menu_url = get_url(action='filmy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        movies = data.get("items", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        create_movie_listitems(movies, handle)
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='filmy_vanoce', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání dětských a rodinných filmů: {e}", xbmcgui.NOTIFICATION_ERROR)  

# TÉMATICKÉ SEZNAMY - ZAMILOVANÉ PÁRY
def show_zamilovane_pary(handle, list_id="8539319", page=1):
    url = f"{TMDB_API_URL}/list/{list_id}"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        menu_url = get_url(action='filmy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        movies = data.get("items", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        for movie in movies:
            what = movie.get("title", "Neznámý název")
            title = what
            rating = movie.get("vote_average")
            release_date = movie.get("release_date", "")
            year = ""
            if release_date and len(release_date) >= 4:
                year = release_date[:4]
            if rating is not None and year:
                title = f"{title} ({year}) [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif rating is not None:
                title = f"{title} [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif year:
                title = f"{title} ({year})"
            plot = movie.get("overview", "")
            poster_path = movie.get("poster_path")
            poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
            listitem = xbmcgui.ListItem(label=title)
            listitem.setInfo('video', {'plot': plot})
            if poster_url:
                listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
            xbmcplugin.addDirectoryItem(handle, get_url(action='search', what=what), listitem, True)
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='filmy_zamilovanepary', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání dětských a rodinných filmů: {e}", xbmcgui.NOTIFICATION_ERROR)

# TÉMATICKÉ SEZNAMY - LETNÍ POHODA
def show_letnipohoda(handle, list_id="8539501", page=1):
    url = f"{TMDB_API_URL}/list/{list_id}"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        menu_url = get_url(action='filmy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        movies = data.get("items", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        create_movie_listitems(movies, handle)

        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='filmy_letnipohoda', page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání dětských a rodinných filmů: {e}", xbmcgui.NOTIFICATION_ERROR)

# FILMY PRO DĚTI A RODINU
def show_kids_and_family_movies(handle, page=1):
    
    url = f"{TMDB_API_URL}/discover/movie"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "with_genres": "16,10751",  # 16 = Animované, 10751 = Rodinné
        "sort_by": "popularity.desc",
        "page": page
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        menu_url = get_url(action='filmy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        movies = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        create_movie_listitems(movies, handle)

        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání dětských a rodinných filmů: {e}", xbmcgui.NOTIFICATION_ERROR)

# INTERAKTIVNÍ VYHLEDÁVÁNÍ KOLEKCÍ
def search_movie_collections(handle, page=1, query=None):    
    if not query:
        query = xbmcgui.Dialog().input("Zadejte název kolekce pro vyhledávání")
        if not query:
            xbmcgui.Dialog().notification("TMDB", "Nebyl zadán žádný výraz.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(handle)
            return

    url = f"{TMDB_API_URL}/search/collection"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "query": query,
        "page": page
    }
    try:
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        collections = data.get("results", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        if not collections:
            listitem = xbmcgui.ListItem(label="Žádné kolekce nenalezeny")
            xbmcplugin.addDirectoryItem(handle, "", listitem, False)
        else:
            for collection in collections:
                collection_id = collection.get("id")
                name = collection.get("name", "Neznámá kolekce")
                overview = collection.get("overview", "")
                poster_path = collection.get("poster_path")
                poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
                listitem = xbmcgui.ListItem(label=name)
                listitem.setInfo('video', {'plot': overview})
                if poster_url:
                    listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
                url_detail = get_url(action='show_collection_detail', collection_id=collection_id, name=name)
                xbmcplugin.addDirectoryItem(handle, url_detail, listitem, True)
        # Stránkování
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='filmy_kolekce', query=query, page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při vyhledávání kolekcí: {e}", xbmcgui.NOTIFICATION_ERROR)

# ZOBRAZÍ DETAIL FILMOVÉ KOLEKCE
def show_collection_detail(handle, collection_id, name=None):
    
    url = f"{TMDB_API_URL}/collection/{collection_id}"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE
    }
    try:
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        parts = data.get("parts", [])
        overview = data.get("overview", "")
        poster_path = data.get("poster_path")
        poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
        # Hlavní položka kolekce (popis)
        if name:
            listitem = xbmcgui.ListItem(label=f"[B]{name}[/B]")
        else:
            listitem = xbmcgui.ListItem(label="Kolekce")
        listitem.setInfo('video', {'plot': overview})
        if poster_url:
            listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
        xbmcplugin.addDirectoryItem(handle, "", listitem, False)
        # Výpis filmů v kolekci
        for movie in parts:
            what = movie.get("title", "Neznámý název")
            title = what
            rating = movie.get("vote_average")
            release_date = movie.get("release_date", "")
            year = ""
            if release_date and len(release_date) >= 4:
                year = release_date[:4]
            if rating is not None and year:
                title_disp = f"{title} ({year}) [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif rating is not None:
                title_disp = f"{title} [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif year:
                title_disp = f"{title} ({year})"
            else:
                title_disp = title
            plot = movie.get("overview", "")
            poster_path = movie.get("poster_path")
            poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
            listitem = xbmcgui.ListItem(label=title_disp)
            listitem.setInfo('video', {'plot': plot})
            if poster_url:
                listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})            
            url_detail = get_url(action='search', what=title)
            xbmcplugin.addDirectoryItem(handle, url_detail, listitem, True)
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání detailu kolekce: {e}", xbmcgui.NOTIFICATION_ERROR)

# UŽIVATELSKÉ SEZNAMY TMDB
def vlastniseznam(handle, list_id, name=None, page=1):
    url = f"{TMDB_API_URL}/list/{list_id}"
    params = {
        "api_key": TMDB_API_KEY,
        "language": TMDB_LANGUAGE,
        "page": page
        
    }
    try:
        # --- Přidání návratu do menu na začátek ---
        menu_item_start = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        menu_url = get_url(action='filmy')
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_start, True)
        # --- Konec přidání na začátek ---
        
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        movies = data.get("items", [])
        current_page = data.get("page", 1)
        total_pages = data.get("total_pages", 1)
        for movie in movies:
            what = movie.get("title", "Neznámý název")
            title = what
            rating = movie.get("vote_average")
            release_date = movie.get("release_date", "")
            year = ""
            if release_date and len(release_date) >= 4:
                year = release_date[:4]
            if rating is not None and year:
                title = f"{title} ({year}) [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif rating is not None:
                title = f"{title} [COLOR yellow]({float(rating):.1f})[/COLOR]"
            elif year:
                title = f"{title} ({year})"
            plot = movie.get("overview", "")
            poster_path = movie.get("poster_path")
            poster_url = f"{TMDB_IMAGE_BASE}{TMDB_POSTER_SIZE}{poster_path}" if poster_path else ""
            listitem = xbmcgui.ListItem(label=title)
            listitem.setInfo('video', {'plot': plot})
            if poster_url:
                listitem.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
            xbmcplugin.addDirectoryItem(handle, get_url(action='search', what=what), listitem, True)
        if current_page < total_pages:
            next_page_item = xbmcgui.ListItem(label=">> Další stránka")
            next_url = get_url(action='userlist', list_id=list_id, name=name, page=current_page + 1)
            xbmcplugin.addDirectoryItem(handle, next_url, next_page_item, True)
        # --- Přidání návratu do menu na konec ---
        menu_item_end = xbmcgui.ListItem(label="<< Návrat do menu filmů")
        xbmcplugin.addDirectoryItem(handle, menu_url, menu_item_end, True)
        # --- Konec přidání na konec ---
        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmcgui.Dialog().notification("TMDB", f"Chyba při načítání vlastních TMDB seznamů: {e}", xbmcgui.NOTIFICATION_ERROR)        





