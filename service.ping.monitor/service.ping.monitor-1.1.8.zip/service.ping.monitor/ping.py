# -*- coding: utf-8 -*-

import os
import time
import xbmc
import xbmcgui
import xbmcaddon
import platform
import socket

addon_id = 'service.ping.monitor'
selfAddon = xbmcaddon.Addon(addon_id)
__version__ = selfAddon.getAddonInfo('version')

interval = int(selfAddon.getSetting("interval"))
monitor = xbmc.Monitor()
system = platform.system()
dialog = xbmcgui.Dialog()

def Msg(message):
    xbmc.log(message,level=xbmc.LOGINFO)

def ping_host_linux(ip):
    response = os.system("ping -c 1 " + ip)
    if response == 0:
        return 0
    else:
        return 1
        
def ping_host_windows(ip):
    try:
        socket.create_connection((ip, 80), timeout=1)
        return 0
    except (socket.timeout, ConnectionRefusedError):
        return 1

def ping_host_system(ip):
    if system == 'Windows':
        return ping_host_windows(ip)
    elif system == 'Linux':
        return ping_host_linux(ip)

if __name__ == '__main__':
    while not monitor.abortRequested():
        inet_status = 'N/A'
        router_status = 'N/A'
        avr_status = 'N/A'
        nas_status = 'N/A'
        scc_status = 'N/A'
        if selfAddon.getSetting('inet_on') == "true":
            inet_ip = selfAddon.getSetting("inet_ip")
            response_inet = ping_host_system(inet_ip)
            if response_inet == 0:
                inet_status = str(0)
                xbmcgui.Window(10000).setProperty('inet', inet_status)
            else:
                inet_status = str(1)
                xbmcgui.Window(10000).setProperty('inet', inet_status)
                if selfAddon.getSetting('inet_on') == "true":
                    dialog.notification("Ping Monitor", "Internet není dostupný", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
                Msg('[Ping Monitor] Internet není dostupný {} '.format(inet_ip))
                
        if selfAddon.getSetting('router_on') == "true":
            router_ip = selfAddon.getSetting("router_ip")
            response_router = ping_host_system(router_ip)
            if response_router == 0:
                router_status = str(0)
                xbmcgui.Window(10000).setProperty('router', router_status)
            else:
                router_status = str(1)
                xbmcgui.Window(10000).setProperty('router', router_status)
                dialog.notification("Ping Monitor", "Router není dostupný", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
    
        if selfAddon.getSetting('avr_on') == "true":
            avr_ip = selfAddon.getSetting("avr_ip")
            response_avr = ping_host_system(avr_ip)
            if response_avr == 0:
                avr_status = str(0)
                xbmcgui.Window(10000).setProperty('AVR', avr_status)
            else:
                avr_status = str(1)
                xbmcgui.Window(10000).setProperty('AVR', avr_status)
                if selfAddon.getSetting('avr_on') == "true":
                    dialog.notification("Ping Monitor", "AVR není dostupný", icon=xbmcgui.NOTIFICATION_ERROR, sound=False)
    
        if selfAddon.getSetting('nas_on') == "true":
            nas_ip = selfAddon.getSetting("nas_ip")
            response_nas = ping_host_system(nas_ip)
            if response_nas == 0:
                nas_status = str(0)
                xbmcgui.Window(10000).setProperty('NAS', nas_status)
            else:
                nas_status = str(1)
                xbmcgui.Window(10000).setProperty('NAS', nas_status)
                if selfAddon.getSetting('nas_on') == "true":
                    dialog.notification("Ping Monitor", "NAS není dostupný", icon=xbmcgui.NOTIFICATION_ERROR, sound=False)
    
        if selfAddon.getSetting('scc_on') == "true":
            scc_ip = selfAddon.getSetting("scc_ip")
            response_scc = ping_host_system(scc_ip)   
            if response_scc == 0:
                scc_status = str(0)
                xbmcgui.Window(10000).setProperty('SCC', scc_status)
            else:
                scc_status = str(1)
                xbmcgui.Window(10000).setProperty('SCC', scc_status)
                if selfAddon.getSetting('scc_on') == "true":
                    dialog.notification("Ping Monitor", "SCC není dostupný", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
                
        if selfAddon.getSetting('debug') == 'true':        
            Msg('[Inet] {}'.format(inet_status))
            Msg('[Router] {}'.format(router_status))
            Msg('[AVR] {}'.format(avr_status))
            Msg('[NAS] {}'.format(nas_status))
            Msg('[SCC] {}'.format(scc_status))
    
        if monitor.waitForAbort(interval):
            break