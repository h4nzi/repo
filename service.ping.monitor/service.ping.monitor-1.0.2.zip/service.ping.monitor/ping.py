

import time
import os
import xbmc
import xbmcgui

inet = "dns.google"
router = "192.168.1.1"
nas = "192.168.1.100"
avr = "192.168.1.124"
scc = "plugin.sc2.zone"
monitor = xbmc.Monitor()



while not monitor.abortRequested():
    # xbmc.log("*********Ping Running*****************", 1)
    response_inet = os.system("ping -c 1 " + inet)
    response_router = os.system("ping -c 1 " + router)
    response_nas = os.system("ping -c 1 " + nas)
    response_avr = os.system("ping -c 1 " + avr)
    response_scc = os.system("ping -c 1 " + scc)
    if monitor.waitForAbort(5):
        xbmc.log("********Ping Abort Called*****************", 2)
        break
    if response_inet == 0:
        # print ('inet', 'OK')
        i_net = str(0)
        xbmcgui.Window(10000).setProperty('inet', i_net)
        # xbmc.log("*********Ping Google OK*****************", 1)
    else:
        # print ('inet', 'NOK')
        xbmcgui.Window(10000).setProperty('inet', 'NOK')
        xbmcgui.Dialog().notification("Ping Monitor", "Internet není dostupný", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
    if response_router == 0:
        # print ('router', 'OK')
        network = str(0)
        xbmcgui.Window(10000).setProperty('router', network)
    else:
        # print ('router', 'NOK')
        xbmcgui.Window(10000).setProperty('router', 'NOK')
        xbmcgui.Dialog().notification("Ping Monitor", "Router není dostupný", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
    if response_nas == 0:
        # print ('NAS', 'OK')
        server = str(0)
        xbmcgui.Window(10000).setProperty('NAS', server)
    else:
        # print ('NAS', 'NOK')
        xbmcgui.Window(10000).setProperty('NAS', 'NOK')
        # xbmcgui.Dialog().notification("Ping Monitor", "NAS není dostupný", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
    if response_avr == 0:
        # print ('AVR', 'OK')
        avr = str(0)
        xbmcgui.Window(10000).setProperty('AVR', avr)
    else:
        # print ('AVR', 'NOK')
        xbmcgui.Window(10000).setProperty('AVR', 'NOK')
        xbmcgui.Dialog().notification("Ping Monitor", "AVR není dostupný", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
    if response_scc == 0:
        # print ('SCC', 'OK')
        scc = str(0)
        xbmcgui.Window(10000).setProperty('SCC', scc)
    else:
        # print ('SCC', 'NOK')
        xbmcgui.Window(10000).setProperty('SCC', 'NOK')
        xbmcgui.Dialog().notification("Ping", "SCC není dostupný", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)