import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import os
from xbmcvfs import translatePath

# Načtení cesty k addon adresáři
addon = xbmcaddon.Addon()
addon_path = translatePath(addon.getAddonInfo('path'))

# Načtení nastavení cesty k výstupnímu adresáři
output_dir = translatePath(addon.getSetting('output_dir'))
output_file_path = translatePath("%s/snimek.jpg" % output_dir)

# Cesta k souboru weather.py
weather_script = os.path.join(addon_path, 'resources', 'lib', 'weather.py')

# Funkce pro spuštění weather.py
def run_weather():
    try:
        xbmc.log(f"[Weather] Spouštím script", xbmc.LOGINFO)
        exec(open(weather_script).read())  # Spustí celý skript weather.py
    except Exception as e:
        if addon.getSetting('debug') == "true":
            xbmc.log(f"[Weather] Chyba při spuštění weather.py: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Weather", "Chyba při spouštění skriptu!", xbmcgui.NOTIFICATION_ERROR, 5000)

# Funkce pro zobrazení uloženého obrázku
def show_image():
    if os.path.exists(output_file_path):
        xbmc.log(f"[Weather] Zobrazuji obrázek: {output_file_path}", xbmc.LOGINFO)
        xbmc.executebuiltin(f'ShowPicture("{output_file_path}")')
    else:
        xbmc.log(f"[Weather] Obrázek nebyl nalezen: {output_file_path}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Weather", "Obrázek nebyl nalezen!", xbmcgui.NOTIFICATION_ERROR, 5000)

# Hlavní logika
if __name__ == '__main__':
    xbmc.log(f"[Weather] Skript je spuštěn jako hlavní skript", xbmc.LOGINFO)
    dialog = xbmcgui.Dialog()
    ret = dialog.yesno("Weather", "Chcete vygenerovat nový snímek?", yeslabel="Generovat", nolabel="Zobrazit uložený")
    
    xbmc.log(f"[Weather] Výběr uživatele: {'Generovat' if ret else 'Zobrazit'}", xbmc.LOGINFO)
    
    if ret:  # Uživatel zvolil "Generovat"
        run_weather()
    else:  # Uživatel zvolil "Zobrazit"
        show_image()
else:
    xbmc.log(f"[Weather] Skript byl importován jako modul, ne jako hlavní skript", xbmc.LOGINFO)
