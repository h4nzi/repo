# Knihovna Pillow pro práci s rastrovými daty
# https://pillow.readthedocs.io/en/stable/

import os
import sys
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
from datetime import datetime, timedelta
from time import sleep
import requests

from PIL import Image, ImageDraw, ImageFont
import pytz
from io import BytesIO
import struct

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path')

logovani = True

# Absolutni cesta k souborum v pripade spousteni skriptu z jineho adresare
cesta = "/storage/.kodi/userdata/addon_data/script.weather.map/data/"


# Vytvoření a uložení nového obrázku (např. 800x600 pixelů)
podklad = Image.new('RGB', (800, 600), color='white')
podklad.save("/storage/.kodi/userdata/addon_data/script.weather.map/data/podklad.png")


# Sedmibarevná paleta pro displeje E-ink ACeP/Gallery Palette
# Použijeme ji pro vytvoření bitmapy pro náš 7,3" 800x480 e-ink displej GDEY073D46 https://www.good-display.com/product/442.html
paleta = [
    [  0,   0,   0], # CERNA,    eink kod: 0x0
    [255, 255, 255], # BILA,     eink kod: 0x1
    [  0, 255,   0], # ZELENA,   eink kod: 0x2
    [  0,   0, 255], # MODRA,    eink kod: 0x3
    [255,   0,   0], # CERVENA,  eink kod: 0x4
    [255, 255,   0], # ZLUTA,    eink kod: 0x5
    [255, 128,   0]  # ORANZOVA, eink kod: 0x6
]

# Naivní funkce pro převod RGB odstínu na nejpodobnější/nejbližší barvu sedmibarevné palety
def prevedPixel(r, g, b):
    nejmensi_rozdil = 100e6
    nova_barva = 0
    for i, barva in enumerate(paleta):
        rozdil_r = r - barva[0]
        rozdil_g = g - barva[1]
        rozdil_b = b - barva[2]
        rozdil = (rozdil_r**2) + (rozdil_g**2) + (rozdil_b**2)
        if(rozdil < nejmensi_rozdil):
            nejmensi_rozdil = rozdil
            nova_barva =  i
    return nova_barva

# Funkce pro okamžité psaní do výstupu, pokud je povoleno logování
def printl(txt):
    if logovani:
        print(txt, flush=True)


# Funkce pro stažení teplotní heatmapy z webu In-pocasi.cz
# Teplotní snímky se generují každých celých třicet minut
# :00, :30  místního času (SEČ/SELČ)
def stahni_snimek_heatmapa(datum=None, pokusy=5):
    if datum == None:
        datum = datetime.now()

    while pokusy > 0:
        datum = datum.replace(minute=(datum.minute // 30) * 30)
        datum_txt = datum.strftime("%H%M")
        url = f"https://www.in-pocasi.cz/data/teplotni_mapy_cz_actual/t{datum_txt}.png"           
        xbmc.log(f"[Weather] Stahuji soubor: {url}", xbmc.LOGINFO)
        r = requests.get(url)
        if r.status_code != 200:
            xbmc.log(f"[Weather] nemohu stáhnout soubor", xbmc.LOGINFO)
            xbmc.log(f"[Weather] Pokusím se stáhnout o 30 minut starší soubor", xbmc.LOGINFO)
            datum -= timedelta(minutes=30)
            pokusy -= 1
            sleep(.5)
        else:
            return True, r.content, datum
    return False, None, datum

# Funkce pro stažení radarového snímky z webu ČHMÚ
# Radarové snímky se generují každých celých deset minut
# :00, :10, :20, ... UTC času
def stahni_snimek_radar(datum=None, pokusy=5):
    if datum == None:
        datum = datetime.utcnow()

    while pokusy > 0:
        # Získáme UTC datum a čas ve formátu YYYYmmdd.HHMM pro posledních celých deset minut
        datum = datum.replace(minute=(datum.minute // 10) * 10)
        datum_txt = datum.strftime("%Y%m%d.%H%M")
        url = f"https://www.chmi.cz/files/portal/docs/meteo/rad/inca-cz/data/czrad-z_max3d/pacz2gmaps3.z_max3d.{datum_txt}.0.png"           
        xbmc.log(f"[Weather] stahuji soubor: {url}", xbmc.LOGINFO)
        r = requests.get(url)
        if r.status_code != 200:
            xbmc.log(f"[Weather] HTTP {r.status_code}: Nemohu stáhnout soubor", xbmc.LOGINFO)
            xbmc.log(f"[Weather] Pokusím se stáhnout o 10 minut starší soubor", xbmc.LOGINFO)
            datum -= timedelta(minutes=10)
            pokusy -= 1
            sleep(.5)
        else:
            return True, r.content, datum
    return False, None, datum

# Funkce pro stažení družicového snímku z webu ČHMÚ
# Družicové snímky se generují každou celou čtvrthodinu
# :00, :15, :30, :45 UTC času
def stahni_snimek_druzice(datum=None, pokusy=5):    
    if datum == None:
        datum = datetime.utcnow()

    while pokusy > 0:
        # Získáme UTC datum a čas ve formátu YYYYmmdd.HHMM pro poslední celou čtvrthodinu
        datum = datum.replace(minute=(datum.minute // 15 * 15))
        datum_txt = datum.strftime("%Y%m%d.%H%M")
        url = f"https://www.chmi.cz/files/portal/docs/meteo/sat/msg_hrit/img-msgcz-1160x800-ir108/msgcz-1160x800.ir108.{datum_txt}.0.jpg"
        xbmc.log(f"[Weather] stahuji soubor: {url}", xbmc.LOGINFO)
        r = requests.get(url)
        if r.status_code != 200:
            xbmc.log(f"[Weather] HTTP {r.status_code}: Nemohu stáhnout soubor", xbmc.LOGINFO)
            xbmc.log(f"[Weather] Pokusím se stáhnout o 15 minut starší soubor", xbmc.LOGINFO)
            datum -= timedelta(minutes=15)
            pokusy -= 1
            sleep(.5)
        else:
            return True, r.content, datum
    return False, None, datum

def rgb_text(r,g,b, text):
    return f"\x1b[38;2;{r};{g};{b}m{text}\x1b[0m"

if __name__ == "__main__":
    xbmc.log(f"[Weather]*** Dashboard pro eink ***\n", xbmc.LOGINFO)

    # Stáhneme snímky radaru, družice a teplotní mapy
    # Snímky radaru ČHMÚ jsou k dispozici pod svobodnou licencí CC
    # Snímky z družice jsou k dispozici pod licencí EUMETSAT (https://www.chmi.cz/files/portal/docs/meteo/sat/info/EUM_licence.html), používáme v dobré víře pro edukační účely/soukromé použití
    # Snímky teplotní heatmapy stahujeme z webu In-pocasi.cz opět výhradně pro demonstrační a edukační účely a pro soukromé použití. Data náleží společnosti InMeteo, s.r.o.
    ok_radar, bajty_radar, datum_radar = stahni_snimek_radar()
    ok_heatmapa, bajty_heatmapa, datum_heatmapa = stahni_snimek_heatmapa()
    ok_druzice, bajty_druzice, datum_druzice = stahni_snimek_druzice()
    # Pokud se některé snímky nestáhly, ukončíme skript,
    # protože nemáme kompletní data ke konstrukci dashboardu pro e-ink
    if not ok_radar or not ok_heatmapa or not ok_druzice:
        xbmc.log(f"[Weather] Nepodařilo se stáhnout snimky, končím :-(", xbmc.LOGINFO)
    else:
        try:
            # Načteme stažené snímky
            snimek_radar = Image.open(BytesIO(bajty_radar))
            snimek_heatmapa = Image.open(BytesIO(bajty_heatmapa))
            snimek_druzice = Image.open(BytesIO(bajty_druzice))
        except:
            xbmc.log(f"[Weather] Nepodařilo se načíst bitmapy", xbmc.LOGINFO)
            sys.exit(1)

        # Některé stažené snímky jsou v indexovaných barvách,
        # a tak všechny sjeednotíme převodem na formát RGB
        xbmc.log(f"[Weather] Převádím snímky na RGB...", xbmc.LOGINFO)
        snimek_radar = snimek_radar.convert("RGB")
        snimek_heatmapa = snimek_heatmapa.convert("RGB")
        snimek_druzice = snimek_druzice.convert("RGB")

        # Načtení předpřipraveného pokladu 800x480 px se statickými kresbami (ikony aj.)
        xbmc.log(f"[Weather] Nahrávám podkladovou bitmapu...", xbmc.LOGINFO)
        podklad = Image.open(f"{cesta}podklad.png")
        podklad.convert("RGB")

        # Zmenšení stažených snímků a načtení černobílých masek republiky
        xbmc.log(f"[Weather] Zmenšuji snímky a načítám masky republiky...", xbmc.LOGINFO)
        snimek_radar = snimek_radar.resize((400,240))
        snimek_heatmapa = snimek_heatmapa.resize((400,240))
        snimek_druzice = snimek_druzice.resize((400,240))
        maska_cesko_druzice = Image.open(f"{cesta}maska_cesko_druzice.png")
        maska_cesko_druzice = maska_cesko_druzice.convert("RGB")
        maska_cesko_radar = Image.open(f"{cesta}maska_cesko_radar.png")
        maska_cesko_radar = maska_cesko_radar.convert("RGB")

        # ---------------------------------
        # KRESBA BLOKU S TEPLOTNÍM SNÍMKEM
        # ---------------------------------
        xbmc.log(f"[Weather] Kreslím heatmapu...", xbmc.LOGINFO)
        podklad.paste(snimek_heatmapa, (0, 0))

        # ---------------------------------
        # KRESBA BLOKU S DRUŽICOVÝM SNÍMKEM
        # ---------------------------------
        xbmc.log(f"[Weather] Kreslím družicový snímek v umělých barvách a s maskou republiky...", xbmc.LOGINFO)
        # Protože budeme zjišťovat a modifikovat stav jednotlivých pixelů, projdeme je jeden po druhém
        # Pomalý, ale jednoduchý/naivní postup
        for y in range(snimek_druzice.height):
            for x in range(snimek_druzice.width):
                r,g,b  = snimek_druzice.getpixel((x,y))
                _r,_g,_b  = maska_cesko_druzice.getpixel((x,y))
                # Pokud je pixel masky černý, nakresli pixel masky
                if _r == 0:
                    podklad.putpixel((x+400, y+240), (1, 1, 1))
                # V opačném případě kreslíme oblačnost v umělých barvách od žluté po modrou
                # Nemáme e-ink s odstíny šedi, takže nemůžeme použít originální barvy
                # Tímto způsobem můžeme dofiltrovat nejslabší oblačnost a kreslit jen tu zajímavou
                else:
                    if r >= 70 and r <= 80: # Nejslabsi mrak
                        podklad.putpixel((x+400, y+240), (255, 255, 0))
                    elif r > 80 and r <= 90: # Slaby mrak
                        podklad.putpixel((x+400, y+240), (255, 128, 0))
                    elif r > 90 and r <= 100: # Stredni mrak
                        podklad.putpixel((x+400, y+240), (0, 255, 0))
                    elif r > 100: # Silny mrak
                        podklad.putpixel((x+400, y+240), (0, 0, 255))
                    else:
                        podklad.putpixel((x+400, y+240), (255, 255, 255))

        # --------------------------------
        # KRESBA BLOKU S RADAROVÝM SNÍMKEM
        # --------------------------------
        xbmc.log(f"[Weather] Kreslím radarový snímek a s maskou republiky...", xbmc.LOGINFO)
        # Protože budeme zjišťovat a modifikovat stav jendotlivých pixelů, projdeme je jeden po druhém
        # Pomalý, ale jednoduchý/naivní postup
        for y in range(snimek_radar.height):
            for x in range(snimek_radar.width):
                r,g,b  = snimek_radar.getpixel((x,y))
                _r,_g,_b  = maska_cesko_radar.getpixel((x,y))
                # Pokud je pixel masky černý, nakresli pixel masky
                if _r == 0:
                    podklad.putpixel((x, y+240), (1, 1, 1))
                # V opačném případě vykreslíme radarová data
                # Ignoroujeme hodnotu kanálu 0 (černá/transparentní/pozadí)
                else:
                    if (r+g+b) > 0:
                        podklad.putpixel((x, y+240), (r, g, b))
            
        xbmc.log(f"[Weather] Kreslím popisky...", xbmc.LOGINFO)
        platno = ImageDraw.Draw(podklad)
        pismo_mapy = ImageFont.truetype(f"{cesta}BakbakOne-Regular.ttf", 20)

        # Popisky teplotní mapy
        platno.text((10,10), "TEPLOTA", font=pismo_mapy, fill="black")
        platno.text((10,30), datum_heatmapa.strftime("%H:%M"), font=pismo_mapy, fill="black")

        # Popisky radarové mapy
        # Datum radarové mapy je v UTC, takže převedeme na časové pásmo Česka
        casova_zona_cr = pytz.timezone("Europe/Prague")
        datum_radar = datum_radar.replace(tzinfo=pytz.utc).astimezone(casova_zona_cr)
        platno.text((10,250), "SRÁŽKY", font=pismo_mapy, fill="black")
        platno.text((10,270), datum_radar.strftime("%H:%M"), font=pismo_mapy, fill="black")

        # Popisky družicové mapy
        # Datum družicového snímku je také v UTC, takže opět převedeme na čas Česka
        datum_druzice = datum_druzice.replace(tzinfo=pytz.utc).astimezone(casova_zona_cr)
        platno.text((410,250), "DRUŽICE", font=pismo_mapy, fill="black")
        platno.text((410,270), datum_druzice.strftime("%H:%M"), font=pismo_mapy, fill="black")

       # Nakreslení dat z meteostanice
        xbmc.log(f"[Weather] Zjišťuji stav domácí meteostanice...", xbmc.LOGINFO)
        
        # ZDE SI DOPLŇTE SVŮJ VLASTNÍ KOD, JAK ZÍSKAT DATA Z VLASTNÍCH ZDROJŮ
        import requests

        # Získání dat z URL adresy
        url = "http://192.168.1.23/json"
        response = requests.get(url)
        xbmc.log(f"[Weather] Response {response}", xbmc.LOGINFO)
        if response.status_code == 200:
            data = response.json()  # Zpracování JSON dat
            
            #Hledání dat teploty a vlhkosti v JSON struktuře
            sensors = data.get("Sensors", [])
            if sensors:
                task_values = sensors[0].get("TaskValues", [])
                for value in task_values:
                    if value["Name"] == "Temperature":
                        teplota = str(value["Value"])
                    if value["Name"] == "Humidity":
                        vlhkost = str(value["Value"])

            # print(f"Teplota: {teplota} °C")
            # print(f"Vlhkost: {vlhkost} %")
            xbmc.log(f"[Weather] Teplota {teplota} °C.", xbmc.LOGINFO)
            xbmc.log(f"[Weather] Vlhkost {vlhkost} °C.", xbmc.LOGINFO)
        else:
            print(f"Chyba při získávání dat z URL, kód chyby: {response.status_code}")

        # teplota = str(temp)
        # vlhkost = str(hum)
        svetlo = "25698"
        baterie = "3.95"

        xbmc.log(f"[Weather] Kreslím údaje z meteostanice...", xbmc.LOGINFO)
        pismo_meteo_datum = ImageFont.truetype(f"{cesta}BakbakOne-Regular.ttf", 80)
        pismo_meteo_data = ImageFont.truetype(f"{cesta}BakbakOne-Regular.ttf", 35)
        pismo_meteo_data_mensi = ImageFont.truetype(f"{cesta}BakbakOne-Regular.ttf", 25)
        platno.text((480, 90), f"{teplota.replace('.',',')} °C", font=pismo_meteo_data, fill="black")
        platno.text((670, 90), f"{vlhkost.replace('.',',')} %", font=pismo_meteo_data, fill="black")
        platno.text((480, 177), f"{svetlo.replace('.',',')} lx", font=pismo_meteo_data_mensi, fill="black")
        platno.text((670, 166), f"{baterie.replace('.',',')} V", font=pismo_meteo_data, fill="black")
        dny_v_tydnu = ["Po", "Út", "St", "Čt", "Pá", "So", "Ne"]
        datum = datetime.now()
        platno.text((425, -20), f"{datum.strftime('%d.%m.')} {dny_v_tydnu[datum.weekday()]}", font=pismo_meteo_datum, fill="black")

        # Ještě nakreslíme mřížku
        platno.line([(400,0),(400,480)], fill="black", width=1)
        platno.line([(0,240),(800,240)], fill="black", width=1)


        # Převod bitmapy na sedmibarevnou paletu ACeP/Gallery Palette 
        xbmc.log(f"[Weather] Převádím RGB na sedmibarevnou paletu E-ink ACeP/Gallery Palette...", xbmc.LOGINFO)
        xbmc.log(f"[Weather] Provádím základní bezztrátovou kompresi RLE...", xbmc.LOGINFO)
        binarni = open(f"{cesta}dashboard_rle.bin", "wb")
        bajty = []
        for y in range(podklad.height):
            for x in range((int(podklad.width/2))):
                px1 = podklad.getpixel(((x * 2), y))
                px2 = podklad.getpixel(((x * 2) + 1, y))
                barva1 = prevedPixel(px1[0], px1[1], px1[2])
                barva2 = prevedPixel(px2[0], px2[1], px2[2])
                par = barva2 | (barva1 << 4) 
                bajty.append(par)
        komprimovano = []
        hodnota = bajty[0]
        pocet = 0
        # Bezztrátová komprese základním algoritmem RLE s osmibitovou délkou
        # Naivní a pomalý přístup pro demonstraci a pochopení
        for bajt in bajty:
            if bajt != hodnota:
                komprimovano.append(pocet)
                komprimovano.append(hodnota)
                hodnota = bajt
                pocet = 1
            else:
                if pocet == 255:
                    komprimovano.append(pocet)
                    komprimovano.append(hodnota)
                    hodnota = bajt
                    pocet = 1
                else:
                    pocet += 1
        xbmc.log(f"[Weather] Komprimováno: {len(komprimovano)} bajtů", xbmc.LOGINFO)
       
        # Uložíme zkomprimovanou bitmapu do souboru
        printl("Ukládám...")
        xbmc.log(f"[Weather] Ukládám", xbmc.LOGINFO)
        for bajt in komprimovano:
            binarni.write(struct.pack("B", bajt))
        binarni.close()
        
        import os

        # Zjistíme, zda soubor existuje a má nenulovou velikost
        cesta_souboru = "/home/jk/Plocha/weather/dashboard_rle.bin"
        if os.path.exists(cesta_souboru) and os.path.getsize(cesta_souboru) > 0:
            xbmc.log(f"[Weather] Soubor byl úspěšně vytvořen a uložen.", xbmc.LOGINFO)
        else:
            xbmc.log(f"[Weather] Chyba: soubor nebyl vytvořen nebo je prázdný.", xbmc.LOGINFO)
        xbmc.log(f"[Weather] Uloženo", xbmc.LOGINFO)
        
# Ukládání obrázku do různých formátů na základě volby uživatele
def uloz_obrazek(podklad, cesta, format='PNG'):
    if format.upper() == 'PNG':
        podklad.save(f"{cesta}dashboard.png", format="PNG")
        printl("Obrázek byl uložen ve formátu PNG.")
    elif format.upper() == 'JPEG':
        podklad.save(f"{cesta}dashboard.jpeg", format="JPEG")
        printl("Obrázek byl uložen ve formátu JPEG.")
    elif format.upper() == 'BMP':
        podklad.save(f"{cesta}dashboard.bmp", format="BMP")
        printl("Obrázek byl uložen ve formátu BMP.")
    else:
        xbmc.log(f"[Weather] Neznámý formát, obrázek nebyl uložen.", xbmc.LOGINFO)

if __name__ == "__main__":
    # Zde bude probíhat kreslení dashboardu...
    
    # Uložíme obrázek v požadovaném formátu (např. PNG, JPEG, BMP)
    format_obrazku = 'PNG'  # Můžete změnit na 'JPEG', 'BMP' nebo 'PNG'
    uloz_obrazek(podklad, cesta, format_obrazku)
    
    # Ověření, zda soubor existuje
    cesta_souboru = f"/home/jk/Plocha/weather/dashboard.{format_obrazku.lower()}"
    if os.path.exists(cesta_souboru) and os.path.getsize(cesta_souboru) > 0:
        xbmc.log(f"[Weather] Soubor {cesta_souboru} byl úspěšně vytvořen a uložen.", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Weather", f"Soubor {cesta_souboru} byl úspěšně vytvořen a uložen.", xbmcgui.NOTIFICATION_INFO, 5000)
    else:
        xbmc.log(f"[Weather] Chyba: soubor nebyl vytvořen nebo je prázdný.", xbmc.LOGINFO)




