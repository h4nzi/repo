# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon

addon = xbmcaddon.Addon()
player = xbmc.Player()

def wait_for_abort():
    if monitor.waitForAbort(1):
        return True
    return False

def stop_slideshow():
    while True:
        if wait_for_abort():
            return
        if not xbmc.getCondVisibility('Slideshow.IsActive'):
            break
    player.stop()
    start_slideshow()

def start_slideshow():
    while True:
        if wait_for_abort():
            return
        if addon.getSetting("music_enabled") == "true" and xbmc.getCondVisibility('Slideshow.IsActive'):
            player.play(addon.getSetting('playlist'))
            break
    stop_slideshow()

if __name__ == "__main__":
    monitor = xbmc.Monitor()
    start_slideshow()
