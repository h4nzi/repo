# -*- coding: utf-8 -*-

import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import unicodedata
import requests
import hashlib
from xml.etree import ElementTree as ET
from urllib.parse import urlparse, parse_qs, urlencode, parse_qsl
try:
    from resources.lib.md5crypt import md5_crypt
except:
    from md5crypt import md5_crypt


_url = sys.argv[0]
try:
    _handle = int(sys.argv[1])
except:
    pass
addon = xbmcaddon.Addon(id='plugin.image.ws-private-media')
path = '/'
headers = {'Connection': 'Keep-Alive', 'Content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'User-Agent': 'Apache-HttpClient/4.3.4 (java 1.4)', 'Host': 'webshare.cz'}
ptypes = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'tiff', 'raw']
vtypes = ['mp4', 'avi', 'mkv', 'ts', 'mov', 'wmv', 'flv', 'mpeg', '3gp']
atypes = ['mp3', 'm4a', 'flac', 'wav', 'wma', 'aac']


def encode(string):
    string = str(unicodedata.normalize('NFKD', string).encode('ascii', 'ignore'), "utf-8")
    return string


def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs, 'utf-8'))


def hash_password(password, salt):
    return hashlib.sha1(md5_crypt(password, salt).encode('utf-8')).hexdigest()


def login():
    user = addon.getSetting('user')
    passw = addon.getSetting('pass')
    req = requests.post('https://webshare.cz/api/salt/', data = {'username_or_email': user}).content
    status = ET.fromstring(req).find('status').text
    if status == 'OK':
        salt = ET.fromstring(req).find('salt').text
        psw = hash_password(passw, salt)
        req = requests.post('http://webshare.cz/api/login/', data = { 'username_or_email': user, 'password': psw, 'keep_logged_in': 1 }).content
        status = ET.fromstring(req).find('status').text
        if status == 'OK':
            token = ET.fromstring(req).find('token').text
            return token
        else:
            message = ET.fromstring(req).find('message').text
            xbmcgui.Dialog().notification("Webshare Private Media",message, xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)
    else:
        message = ET.fromstring(req).find('message').text
        xbmcgui.Dialog().notification("Webshare Private Media",message, xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)


def get_vip():
    token = addon.getSetting('token')
    if token == '':
        token = login()
    if token:
        response = requests.post('http://webshare.cz/api/user_data/', data = urlencode({'wst': token}), headers = headers).content
        vip = ET.fromstring(response).find('status').text
        if vip == 'OK':
            u = ET.fromstring(response).find('username').text
            e = ET.fromstring(response).find('email').text
            v = ET.fromstring(response).find('vip_days').text
            xbmcgui.Dialog().ok('Webshare Private Media', 'Username: ' + u + '\nEmail: ' + e + '\nVIP days: ' + v)


def get_img_url(ident, token):
    response = requests.post('http://webshare.cz/api/file_link/', data = urlencode({'wst': token, 'ident': ident}), headers = headers).content
    return ET.fromstring(response).find('link').text


def play(stream):
    listitem = xbmcgui.ListItem(path=stream)
    xbmcplugin.setResolvedUrl(_handle, True, listitem)


def folders(path, id):
    token = addon.getSetting('token')
    if token == '':
        token = login()
    if token:
        response = requests.post('http://webshare.cz/api/files/', data = urlencode({'wst': token, 'path': path, 'private': id}), headers = headers).content
        xml = ET.fromstring(response)
        if xml.find('status').text == 'OK':
            for folder in xml.findall('folder'):
                name = folder.find('name').text
                listitem = xbmcgui.ListItem(label=name)
                listitem.setIsFolder(True)
                url = get_url(action = 'folders', path = encode(folder.find('path').text), id = id)
                xbmcplugin.addDirectoryItem(_handle, url, listitem, True)
            for file in xml.findall('file'):
                name = file.find('name').text
                type = file.find('type').text.lower()
                if type in ptypes:
                    listitem = xbmcgui.ListItem(label=name)
                    listitem.setInfo('pictures', {'title': name})
                    if addon.getSetting("thumb_enabled") == "false":
                        listitem.setArt({'thumb': 'DefaultPicture.png', 'icon': 'DefaultPicture.png'})
                    url = get_img_url(file.find('ident').text, token)
                    xbmcplugin.addDirectoryItem(_handle, url, listitem, False)
                elif type in vtypes:
                    listitem = xbmcgui.ListItem(label=name)
                    listitem.setInfo('video', {'title': name, 'mediatype': 'movie'})
                    url = get_url(action='play', stream = get_img_url(file.find('ident').text, token))
                    listitem.setProperty('IsPlayable', 'true')
                    xbmcplugin.addDirectoryItem(_handle, url, listitem, False)
                elif type in atypes:
                    listitem = xbmcgui.ListItem(label=name)
                    listitem.setInfo('audio', {'title': name, 'mediatype': 'music'})
                    listitem.setArt({'thumb': 'DefaultAudio.png', 'icon': 'DefaultAudio.png'})
                    url = get_url(action='play', stream = get_img_url(file.find('ident').text, token))
                    listitem.setProperty('IsPlayable', 'true')
                    xbmcplugin.addDirectoryItem(_handle, url, listitem, False)
        xbmcplugin.endOfDirectory(_handle)


def menu():
    name_list = [('Soukromé soubory', 1), ('Veřejné soubory', 0)]
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        url = get_url(action='folders', path = path, id = category[1])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        try:
            if params['action'] == 'folders':
                folders(params["path"], params["id"])
            elif params['action'] == 'play':
                play(params['stream'])
            else:
                menu()
        except:
            menu()
    else:
        menu()