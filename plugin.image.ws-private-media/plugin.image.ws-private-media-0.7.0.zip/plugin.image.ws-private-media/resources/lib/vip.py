# -*- coding: utf-8 -*-

import plugin
plugin.get_vip()