import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.driver_utils import get_driver_path
import xbmc
import xbmcaddon
from bs4 import BeautifulSoup
from resources.libs.utils import check_chromedriver

addon = xbmcaddon.Addon()

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)

def get_driver():
    """Inicializuje a vrátí WebDriver podle nastavení."""
    options = Options()
    options.add_argument('--headless')
    options.add_argument('--disable-gpu')
    options.add_argument('--no-sandbox')
    options.add_argument('--remote-debugging-port=9222')
    options.add_argument('--disable-software-rasterizer')
    options.add_argument('--disable-extensions')

    driver = None

    try:
        browser_type = addon.getSetting("browser")
        if browser_type == "lokální Google Chrome":
            driver_path = str(get_driver_path('chromedriver'))
            check_chromedriver(driver_path)
            if addon.getSetting("debug") == "true":
                Msg(f"[iDnes] Driver Path: {driver_path}")
            driver = webdriver.Chrome(executable_path=driver_path, options=options)
        elif browser_type == "Selenium Grid (Docker URL)":
            docker_url = addon.getSetting("docker_url")
            driver = webdriver.Remote(command_executor=docker_url, options=options)
        else:
            raise ValueError(f"[iDnes] Neplatné nastavení prohlížeče: {browser_type}")
    except Exception as e:
        Msg(f"[iDnes] Chyba inicializace Selenium driveru: {str(e)}")
    
    return driver
    
def load_page(url):
    """Načte stránku pomocí Selenium WebDriver a vrátí její obsah jako BeautifulSoup objekt."""
    driver = get_driver()
    if not driver:
        Msg("[iDnes] Selenium WebDriver se nepodařilo inicializovat")
        return None, None
    
    try:
        driver.get(url)
        time.sleep(3)
        real_loaded_url = driver.current_url

        if addon.getSetting("debug") == "true":
            Msg(f"[iDnes] Skutečně načtená URL: {real_loaded_url}\n")

        soup = BeautifulSoup(driver.page_source, 'html.parser')
        return soup, real_loaded_url
    finally:
        driver.quit()

# if __name__ == "__main__":
    # # TEST SPUŠTĚNÍ mimo Kodi
    # test_url = "https://www.idnes.cz"
    # soup, url = load_page(test_url)
    # if soup:
        # Msg(f"[iDnes] Načtená stránka: {url}")
