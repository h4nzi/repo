# 1.3.1

# -*- coding: utf-8 -*-
import routing
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import requests
import re
from resources.libs.utils import check_kodi_version, load_page

from bs4 import BeautifulSoup
import time
import urllib.parse
import json


addon = xbmcaddon.Addon()
plugin = routing.Plugin()
player = xbmc.Player()
dialog = xbmcgui.Dialog()
kodi_version = check_kodi_version()
BASE_URL = "https://tv.idnes.cz/"
KINO_URL = "https://kino.idnes.cz/"


def Msg(message):
        xbmc.log(message, level=xbmc.LOGINFO)
        
def MsgErr(message):
        xbmc.log(message, level=xbmc.LOGERROR)


@plugin.route('/')
def main_menu():
    """Hlavní menu."""
    xbmcplugin.setContent(plugin.handle, 'directories')
    listing = []

    sections = {
        "iDnes>TV": BASE_URL,
        "Technika": BASE_URL + "technika",
        "Slow": BASE_URL + "slow",
        "Pořady": BASE_URL + "porady",
        "Archiv": BASE_URL + "archiv",
        "Rozstřel": BASE_URL + "rozstrel",
        "Živě": BASE_URL + "zive",
        "iDnes Kino": KINO_URL + "serialy.aspx"
    }

    for label, url in sections.items():
        encoded_url = urllib.parse.quote(url, safe='')
        if addon.getSetting("debug") == "true":
            decoded = urllib.parse.unquote(encoded_url)
            if addon.getSetting("debug") == "true":
                Msg(f"[iDnes] Main menu: {label} -> {decoded}")

        list_item = xbmcgui.ListItem(label=label)
        list_item.setArt({'icon': 'DefaultTVShows.png'})
        listing.append((plugin.url_for(list_submenu, menu_url=encoded_url), list_item, True))

    xbmcplugin.addDirectoryItems(plugin.handle, listing, len(listing))
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/submenu/<menu_url>/')
def list_submenu(menu_url):
    """Obsluha submenu podle dané kategorie."""
    decoded_url = urllib.parse.unquote(menu_url)
    
    if addon.getSetting("debug") == "true":
        Msg(f"[iDnes] Navigating to submenu URL: {decoded_url}")
        
    xbmcplugin.setContent(plugin.handle, 'videos')

    submenu_listing = []
    video_listing = []
    current_url = decoded_url
    last_valid_url = None

    while current_url:
        soup, real_loaded_url = load_page(current_url)
        if not soup:
            return

        if last_valid_url and real_loaded_url == last_valid_url:
            Msg("[iDnes] Další strana není k dispozici.\n")
            break

        last_valid_url = real_loaded_url        

        entries = soup.find_all('div', class_='entry-in')
        entries_kino = soup.find_all('a', class_='video-art')

        url_pattern = re.compile(r'.*\.(aspx|K\d+)$')

        parsed_entries = []

        # entry-in
        for entry in entries:
            title = entry.find('h3').get_text(strip=True) if entry.find('h3') else "Neznámý pořad"
            link_tag = entry.find('a')
            url = link_tag['href'] if link_tag else None
            data_id = link_tag.get('data-id', 'N/A') if link_tag else 'N/A'
            time_tag = entry.find('span', class_='time')
            year = int(time_tag['datetime'].split('-')[0]) if time_tag and 'datetime' in time_tag.attrs else 0
            
            fanart_tag = entry.find('div', class_='art-img')
            image_url = None
            if fanart_tag:
                style = fanart_tag.get("style", "")
                url_start = style.find("url('") + 5
                url_end = style.find("')", url_start)
                if url_start > 4 and url_end > url_start:
                    image_url = "https:" + style[url_start:url_end]

            length_tag = entry.find('span', class_='length')
            duration = 0
            if length_tag:
                try:
                    parts = list(map(int, length_tag.get_text(strip=True).lower().split(':')))
                    hours, minutes, seconds = (parts if len(parts) == 3 else (0, *parts)) if len(parts) in [2, 3] else (0, 0, 0)
                    duration = hours * 3600 + minutes * 60 + seconds
                except ValueError:
                    pass
                    
            if addon.getSetting("debug") == "true":
                Msg(f"[iDnes] title: {title}")
                Msg(f"[iDnes] url: {url}")
                Msg(f"[iDnes] data-id: {data_id}")
                Msg(f"[iDnes] year: {year}")
                Msg(f"[iDnes] image: {image_url}")
                Msg(f"[iDnes] length: {duration} sec\n")
                
            Msg(f"[iDnes] Appending entry: title={title},\n url={url},\n data_id={data_id},\n year={year},\n duration={duration},\n fanart={image_url}, type=entry")
            parsed_entries.append({"title": title, "url": url, "data_id": data_id, "year": year, "duration": duration, "fanart": image_url, "type": "entry"})

        # video-art
        for entry in entries_kino:
            img_tag = entry.find('img')
            if img_tag and 'alt' in img_tag.attrs:
                title = img_tag['alt']
            else:
                span_tag = entry.find('span')
                title = span_tag.text if span_tag else ''
            url = entry['href'] if entry.has_attr('href') else None
            if url:
                parts = url.split('.')
                if len(parts) > 1:
                    data_id = parts[-1]
                    if data_id.lower() == "aspx":
                        data_id = 'N/A'
                    elif data_id.startswith("A"):
                        data_id = "V" + data_id[1:]
                else:
                    data_id = 'N/A'
                    Msg(f"[iDnes] data_id 3: {data_id}")
            else:
                data_id = 'N/A'
                Msg(f"[iDnes] data_id 4: {data_id}")

            fanart_tag = entry.find('img')
            image_url = None
            if fanart_tag:
                image_url = fanart_tag.get("src")
                if image_url and not image_url.startswith("http"):
                    image_url = "https:" + image_url

            duration = 0
            year = 0
            
            if addon.getSetting("debug") == "true":
                Msg(f"[iDnes Kino] title: {title}")
                Msg(f"[iDnes Kino] url: {url}")
                Msg(f"[iDnes Kino] data-id: {data_id}")
                Msg(f"[iDnes Kino] year: {year}")
                Msg(f"[iDnes Kino] image: {image_url}")
                Msg(f"[iDnes Kino] length: {duration} sec\n")

            parsed_entries.append({"title": title, "url": url, "data_id": data_id, "year": year, "duration": duration, "fanart": image_url, "type": "kino"})

        for item in parsed_entries:
            #full_url = urllib.parse.urljoin(BASE_URL, item["url"]) if item["url"] and not item["url"].startswith('http') else item["url"]
            full_url = item["url"] if item["url"] and item["url"].startswith('http') else urllib.parse.urljoin(KINO_URL, item["url"] or "")

            encoded_full_url = urllib.parse.quote(full_url, safe='') if full_url else None

            list_item = xbmcgui.ListItem(label=item["title"])
            list_item.setArt({'fanart': item["fanart"], 'poster': item["fanart"]})

            if kodi_version >= 20:
                info_tag = list_item.getVideoInfoTag()
                info_tag.setTitle(item["title"])
                info_tag.setPlot(item["title"])
                info_tag.setDuration(item["duration"])
                if item["year"]:
                    info_tag.setYear(item["year"])
            else:
                info = {'title': item["title"], 'plot': item["title"], item:["duration"]}
                if item["year"]:
                    info["year"] = item["year"]
                list_item.setInfo('video', info)

            if item["url"] and url_pattern.match(item["url"]):
                submenu_listing.append((plugin.url_for(list_submenu, menu_url=encoded_full_url), list_item, True))

            if item["data_id"] and item["data_id"] != "N/A":
                video_listing.append((plugin.url_for(list_videos, data_id=item["data_id"]), list_item, False))

        next_page_number = check_next_page(real_loaded_url)

        if addon.getSetting('auto_load') == 'Ručně':
            if next_page_number is not None:
                next_page_url = re.sub(r'/\d+$', f"/{next_page_number}", real_loaded_url) if re.search(r'/\d+$', real_loaded_url) else f"{real_loaded_url}/{next_page_number}"
                encoded_next_page_url = urllib.parse.quote(next_page_url, safe='')
                list_item = xbmcgui.ListItem(label="Další strana")
                submenu_listing.append((plugin.url_for(list_submenu, menu_url=encoded_next_page_url), list_item, True))
            break

        if addon.getSetting('auto_load') == 'Automaticky':
            if next_page_number is not None:
                current_url = re.sub(r'/\d+$', f"/{next_page_number}", real_loaded_url) if re.search(r'/\d+$', real_loaded_url) else f"{real_loaded_url}/{next_page_number}"
            else:
                current_url = None
    if addon.getSetting("debug") == "true":
        Msg(f"[iDnes] submenu_listing count: {len(submenu_listing)}")
        Msg(f"[iDnes] video_listing count: {len(video_listing)}")

    xbmcplugin.addDirectoryItems(plugin.handle, submenu_listing + video_listing, len(submenu_listing) + len(video_listing))
    xbmcplugin.endOfDirectory(plugin.handle)

def check_next_page(current_url):
    """Zjistí, zda existuje další stránka."""
    base_match = re.match(r'(.*?K\d+)(/\d+)?$', current_url)
    if base_match:
        base_url = base_match.group(1)
        current_page = int(base_match.group(2)[1:]) if base_match.group(2) else 1
        next_page = current_page + 1
        if addon.getSetting("debug") == "true":
            Msg(f"[iDnes] Next page: {next_page}")
        dialog.notification('iDnes TV', f'Načítám {next_page}. stránku', xbmcgui.NOTIFICATION_INFO, 2000)
        
        test_url = f"{base_url}/{next_page}"
        if addon.getSetting("debug") == "true":
            Msg(f"[iDnes] Checking next page: {test_url}")
        
        soup, real_loaded_url = load_page(current_url)
        if not soup:
            return
        
        if soup.find('div', class_='entry-in'):
            return next_page
    return None

@plugin.route('/video/<data_id>/')
def list_videos(data_id):
    """Sestavení linku na stream, výběr streamu."""
    video_url = f"https://tv.idnes.cz/_servix/media/video.aspx?idvideo={data_id}&type=js"
    #video_url = f"https://kino.idnes.cz/_servix/media/video.aspx?idvideo={data_id}&type=js" ## je jedno, jestli i kino volám na tv.idnes.cz, proč

    if addon.getSetting("debug") == "true":
        Msg(f"[iDnes] Video URL: {video_url}")
    
    request = video_url
    response = requests.get(video_url)
    if addon.getSetting("request") == "true":
        Msg(f"[iDnes] Video Link:\n {request}")

    try:
        response = requests.get(video_url, timeout=5)
        response.raise_for_status()
        json_data = response.text
    except requests.RequestException as e:
        MsgErr(f"[iDnes] Chyba při stahování JSON: {str(e)}")
        return

    mp4_links = re.findall(r'"file":"(https://vod\.idnes\.cz/.*?\.mp4)"', json_data)
    m3u8_links = re.findall(r'"file"\s*:\s*"(https://live\.idnes\.cz/[^"]*\.m3u8)"', json_data)

    stream_urls = mp4_links + m3u8_links
    Msg(f"[iDnes] Stream URLs:{stream_urls}")
    
    def m3u8_resolution(url):
        if addon.getSetting("auto_play_best_stream") == "true":
            links = m3u8_links
            match = re.search(r'(\d{3,4})p', url)
            return int(match.group(1)) if match else 0
        return none

    def extract_resolution(url):
        if addon.getSetting("auto_play_best_stream") == "true":
            links = mp4_links
            if 'high' in url:
                return 2
            elif 'middle' in url:
                return 1
            else:
                return 0
        return none

    def select_stream():
        if addon.getSetting("auto_play_best_stream") == "true":
            if m3u8_links:
                best_m3u8 = max(m3u8_links, key=m3u8_resolution)
                Msg(f"[iDnes] Best m3u8: {best_m3u8}")
                stream_url = best_m3u8
            elif mp4_links:
                best_mp4 = max(mp4_links, key=extract_resolution)
                Msg(f"[iDnes] Best mp4: {best_mp4}")
                stream_url = best_mp4
            else:
                return None
        else:
            stream_urls = m3u8_links + mp4_links
            if not stream_urls:
                return None
            vyber = xbmcgui.Dialog().select("Výběr streamu", stream_urls)
            Msg(f"[iDnes] vyber: {vyber}")
            if vyber < 0:
                return None
            
            stream_url = stream_urls[vyber]
        
        return stream_url

    stream_url = select_stream()

    title = xbmc.getInfoLabel('ListItem.Label')
    duration = xbmc.getInfoLabel('ListItem.Duration')
    play_video(stream_url, title=title)

    
def play_video(stream_url, title="Neznámý název"):
    if not stream_url:
        if addon.getSetting("debug") == "true":
            MsgErr("[iDnes] Žádný stream URL pro přehrání")
        return
    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setLabel(title)
    list_item.setProperty("title", title)
    list_item.setProperty("genre", "Live")

    player.play(stream_url, list_item)

def run():
    plugin.run()
    