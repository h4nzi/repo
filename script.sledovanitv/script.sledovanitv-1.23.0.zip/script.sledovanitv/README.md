<h1>Archiv SledovaniTV - Kodi Video Addon</h1>
<p>
Až 7 dní zpětného sledování televizních pořadů ze serveru SledováníTV (placená služba)
<p>
<a href="https://www.xbmc-kodi.cz/showthread.php?tid=4645">Forum</a>
<img src="http://saros.wz.cz/repo/plugin.video.archivsledovanitv/scr1.png" style="max-width:50%;">
<img src="http://saros.wz.cz/repo/plugin.video.archivsledovanitv/scr2.png" style="max-width:50%;">
<img src="http://saros.wz.cz/repo/plugin.video.archivsledovanitv/scr3.png" style="max-width:50%;">
</p>