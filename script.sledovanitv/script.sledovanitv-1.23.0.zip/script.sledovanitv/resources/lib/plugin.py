# -*- coding: utf-8 -*-

import sys
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from urllib.parse import urlencode, quote, urlparse, parse_qsl
from urllib.request import urlopen, Request
import json
import uuid
import requests
import xbmcvfs
import os
import pickle
import time
import calendar
from datetime import datetime, timedelta
import xml.etree.ElementTree as xml
from urllib import request
try:
    from resources.lib import xmltv
except:
    import xmltv


_url = sys.argv[0]
_handle = int(sys.argv[1])
user_agent = xbmc.getUserAgent()
headers= {'User-Agent':user_agent,}
product_list = {"0": "Xiaomi%3ARedmi+Note+7", "1": "iPhone%3A8+Plus"}
dev_list = {"0": "androidportable", "1": "ios"}
addon = xbmcaddon.Addon(id='script.sledovanitv')
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
history_path = os.path.join(profile, "history")
playing_path = os.path.join(profile, "history_playing")
lng = addon.getLocalizedString
playlist_type = {"0": "", "1": "tv", "2": "radio"}
addon_dir = xbmcvfs.translatePath( xbmcaddon.Addon().getAddonInfo('path') )
addon_icon = os.path.join(addon_dir, "icon.png")

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)

def unpair():
    if addon.getSetting("id") != "":
        try:
            request = Request("https://sledovanitv.cz/api/delete-pairing/?deviceId=" + addon.getSetting("id") + "&password=" + addon.getSetting("passwordid") + "&unit=default", None,headers)
            html = urlopen(request).read()
        except:
            xbmcgui.Dialog().notification("Script SledovaniTV",lng(30024), xbmcgui.NOTIFICATION_ERROR, 4000)
        addon.setSetting(id='id', value= "")
        addon.setSetting(id='passwordid', value= "")
    else:
        xbmcgui.Dialog().notification("Script SledovaniTV",lng(30024), xbmcgui.NOTIFICATION_ERROR, 4000)

def pairing():
    mac_num = hex(uuid.getnode()).replace('0x', '').upper()
    mac = ':'.join(mac_num[i : i + 2] for i in range(0, 11, 2))
    request = Request("https://sledovanitv.cz/api/create-pairing?username=" + quote(addon.getSetting("username")) + "&password=" + quote(addon.getSetting("password")) + "&type=" + dev_list[addon.getSetting("idd")] + "&product=" + product_list[addon.getSetting("idd")] + "&serial=" + mac, None,headers)
    html = urlopen(request).read()
    data = json.loads(html)
    if data["status"] == 1:
        addon.setSetting(id='id', value=str(data["deviceId"]))
        addon.setSetting(id='passwordid', value=str(data["password"]))
    else:
        xbmcgui.Dialog().notification("Script SledovaniTV",lng(30025), xbmcgui.NOTIFICATION_ERROR, 4000)
        sys.exit()

def getsessid():
    if xbmc.getLanguage().lower() == "slovak":
        api_lng = "sk"
    elif xbmc.getLanguage().lower() == "czech":
        api_lng = "cs"
    else:
        api_lng = "en"
    html = urlopen("https://sledovanitv.cz/api/device-login?deviceId=" + addon.getSetting("id") + "&password=" + addon.getSetting("passwordid") + "&version=2.44.16&lang=" + api_lng + "&unit=default&capabilities=clientvast%2Cvast%2Cadaptive2%2Cwebvtt").read()
    data = json.loads(html)
    if data["status"] == 1:
        PHPSESSID = data["PHPSESSID"]
    else:
        pairing()
        html = urlopen("https://sledovanitv.cz/api/device-login?deviceId=" + addon.getSetting("id") + "&password=" + addon.getSetting("passwordid") + "&version=2.44.16&lang=" + api_lng + "&unit=default&capabilities=clientvast%2Cvast%2Cadaptive2%2Cwebvtt").read()
        data = json.loads(html)
        if data["status"] == 1:
            PHPSESSID = data["PHPSESSID"]
        else:
            xbmcgui.Dialog().notification("Script SledovaniTV",lng(30025), xbmcgui.NOTIFICATION_ERROR, 4000)
            sys.exit()
    if addon.getSetting("pin") != "":
        pinunlock = urlopen("https://sledovanitv.cz/api/pin-unlock?pin=" + addon.getSetting("pin") + "&PHPSESSID=" + PHPSESSID).read()
        data = json.loads(pinunlock)
        if data["status"] == 0:
            PIN = 0
        else:
            PIN = 1
    else:
        PIN = 1
    return PHPSESSID, PIN


if addon.getSetting("id") == "":
    pairing()
SESSID, PIN = getsessid()
kd = {"0": "h265%2C", "1": ""}
lq = {"0": "quality=10&capabilities=" + kd[addon.getSetting("codec")] + "webvtt%2Cadaptive2", "1": "quality=20&capabilities=" + kd[addon.getSetting("codec")] + "webvtt%2Cadaptive2", "2": "quality=40&capabilities=" + kd[addon.getSetting("codec")] + "webvtt%2Cadaptive2"}


def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs))

class NoRedirect(request.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
    https_response = http_response

def list_menu():
    name_list = [("Archiv", "DefaultAddonPVRClient.png", "0"), ("Generovat", "DefaultRecentlyAddedMovies.png", "1"), ("Zrušit párování", "DefaultRecentlyAddedMovies.png", "2")]
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        list_item.setArt({'thumb':category[1] , 'icon': category[1]})
        url = get_url(action='listing_menu', id = category[2])
        if category[0] == lng(30003):
            list_item.addContextMenuItems([(lng(30130),'RunPlugin({})'.format(get_url(action = "add_library")))])
        if category[0] == lng(30005):
            list_item.addContextMenuItems([(lng(30006),'RunPlugin({})'.format(get_url(action = "del_history_playing")))])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


# if xbmcaddon.Addon().getSetting("auto_update_start") == "true":
    # update_playlist()    
def update_playlist():
    xbmc.executebuiltin('RunPlugin(plugin://script.sledovanitv/?action=playlist&dlg=1)')

def playlist(dlg):
    channels = []
    ch = []
    path = addon.getSetting("playlist_folder")
    
    if path == '':
        xbmcgui.Dialog().notification("Script SledovaniTV",lng(30037), xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)
        return
    f = open(path + "stvcz.m3u", "w", encoding="utf-8")
    f.write("#EXTM3U\n")
    html = urlopen("https://sledovanitv.cz/api/playlist?format=m3u8&" + lq[addon.getSetting("quality")] + "&whitelogo=1&type=" + playlist_type[addon.getSetting("playlist_type")] + "&PHPSESSID=" + SESSID).read()
    data = json.loads(html)["channels"]
    groups = json.loads(html)["groups"]
    Msg('~STVCZ test~ {}'.format(dlg))
    for d in data:
        if d["locked"] == "none":
            ch.append(d["id"])
            if d["type"] == "radio":
                radio = ' radio="true" '
            else:
                radio = ' '
            group = 'group-title="' + groups[d["group"]] + '"'
            if "PHPSESSID" in d["url"]:
                url = 'plugin://script.sledovanitv/?action=play_pvr&t=' + d["type"] + '&id=' + d["id"]
                inputstream = ""
            else:
                url = d["url"]
                if addon.getSetting("inputstream") == "true":
                    inputstream = "#KODIPROP:inputstreamaddon=inputstream.adaptive\n#KODIPROP:inputstream.adaptive.manifest_type=hls\n#KODIPROP:mimetype=application/vnd.apple.mpegurl\n"
                else:
                    inputstream = ""
            f.write('#EXTINF:-1 ' + group + radio + 'tvg-logo="' + d["logoUrl"] + '" catchup="default" catchup-source="plugin://plugin.video.archivsledovanitv/?action=play_pvr_epg&t=' + d["type"] + '&id=' + d["id"] + '&date={Y}-{m}-{d}+{H}:{M}" catchup-correction="-0.1",' + d["name"] +'\n' + inputstream + url + '\n')
            channels.append({'display-name': [(d["name"], u'cs')], 'id': d["id"],'icon': [{'src': 'https://sledovanitv.cz/cache/biglogos/' + d["id"] + '.png'}]})
    f.close()
    xbmcgui.Dialog().notification("Script SledovaniTV",lng(30140), sound = False, icon = addon_icon)
    if addon.getSetting("epg_enable") == "true":
        if dlg == "1":
            dialog = xbmcgui.DialogProgressBG()
            dialog.create("Script SledovaniTV", "")
            dialog.update(0, "Script SledovaniTV", lng(30142))
        days = int(addon.getSetting("num_days"))
        days_back = int(addon.getSetting("num_days_back"))
        st = 1
        programmes = []
        now = datetime.now()
        local_now = now.astimezone()
        TS = " " + str(local_now)[-6:].replace(":", "")
        for i in range(days_back*-1, days):
            next_day = now + timedelta(days = i)
            date_from = next_day.strftime("%Y-%m-%d")
            date_ = next_day.strftime("%d.%m.%Y")
            req = requests.get("https://sledovanitv.cz/api/epg?time=" + date_from + "+00%3A44&duration=1439&detail=description,poster&posterSize=234&channels=" + ",".join(ch) + "&PHPSESSID=" + SESSID, headers = headers).json()["channels"]
            for k in req.keys():
                for x in req[k]:
                    programm = {'channel': k, 'start': x["startTime"].replace("-", "").replace(" ", "").replace(":", "") + "00" + TS, 'stop': x["endTime"].replace("-", "").replace(" ", "").replace(":", "") + "00" + TS, 'title': [(x["title"], u'')], 'desc': [(x["description"], u'')]}
                    try:
                        icon = x["poster"]
                    except:
                        icon = None
                    if icon != None:
                        programm['icon'] = [{"src": icon}]
                    if programm not in programmes:
                        programmes.append(programm)
            per = int(days_back) + int(days)
            percent = int((float(st*100) / per))
            if dlg == "1":
                dialog.update(percent, "Script SledovaniTV", date_)
            st += 1
        w = xmltv.Writer(encoding="utf-8", source_info_url="http://www.funktronics.ca/python-xmltv", source_info_name="Funktronics", generator_info_name="python-xmltv", generator_info_url="http://www.funktronics.ca/python-xmltv")
        for c in channels:
            w.addChannel(c)
        for p in programmes:
            w.addProgramme(p)
        w.write(path + "epg_stvcz.xml", pretty_print=True)
        if dlg == "1":
            dialog.update(100, "Script SledovaniTV", lng(30017))
            xbmc.sleep(1000)
            dialog.close()
            del dialog
        xbmcgui.Dialog().notification("Script SledovaniTV",lng(30141), sound = False, icon = addon_icon)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params["action"] == "listing_menu":
            if params["id"] == "0":
                list_channels()
            elif params["id"] == "1":
                update_playlist()
            elif params["id"] == "2":
                unpair()
        elif params['action'] == 'un_pair':
            unpair()
        elif params['action'] == 'playlist':
            playlist(params["dlg"])
        else:
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        if PIN == 0:
            xbmcgui.Dialog().notification("Script SledovaniTV",lng(30031), xbmcgui.NOTIFICATION_ERROR, 3000, sound = False)
        list_menu()

        
#playlist()
