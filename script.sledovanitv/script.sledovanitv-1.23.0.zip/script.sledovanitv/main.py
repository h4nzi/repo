import sys
from resources.lib import plugin


if __name__ == '__main__':
    plugin.router(sys.argv[2][1:])

