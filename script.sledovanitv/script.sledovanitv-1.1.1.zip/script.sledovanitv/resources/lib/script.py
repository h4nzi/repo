# -*- coding: utf-8 -*-
#1.1.2

import xbmc
import xbmcgui
import xbmcaddon
import os
import json
import requests
import xbmcvfs

import uuid
from datetime import datetime, timedelta
from resources.lib import xmltv

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
PROFILE = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}")
os.makedirs(PROFILE, exist_ok=True)

# Login
username =  ADDON.getSetting("username")
password =  ADDON.getSetting("password")
pin =  ADDON.getSetting("pin")
# EPG nastavení
days =  int(ADDON.getSetting("num_days"))
days_back =  int(ADDON.getSetting("num_days_back"))
ids = ""

playlist_folder = ADDON.getSetting("playlist_folder")
PLAYLIST_PATH = os.path.join(playlist_folder, "playlist.m3u")
EPG_PATH = os.path.join(playlist_folder, "epg.xml")
DATA_PATH = os.path.join(PROFILE, "data.json")

# Zařízení
product_list = ["CE", "Xiaomi Redmi Note 7", "iPhone Plus", "Samsung TV", "LG TV"]
dev_list = ["androidportable", "ios", "samsungtv", "lgtv"]

playlist_type_map = {"0": "", "1": "tv", "2": "radio"}
codec_map = {"0": "h265%2C", "1": ""}
quality_map = {"0": "10", "1": "20", "2": "40"}

playlist_type = playlist_type_map[ADDON.getSetting("playlist_type")]

codec = ADDON.getSetting("codec")      # "0" nebo "1"
quality = ADDON.getSetting("quality")  # "0", "1", "2"

capabilities = f"{codec_map.get(codec, '')}webvtt%2Cadaptive2"
quality_params = f"quality={quality_map.get(quality, '40')}&capabilities={capabilities}"

enable_ISA = ADDON.getSettingBool("enable_inputstream")

headers = {"User-Agent": "okhttp/3.12.12"}

def Msg(msg):
    xbmc.log(f"[Script SledovaniTV] {msg}", level=xbmc.LOGINFO)

def dialog(msg):
    xbmcgui.Dialog().notification("Script SledovaniTV", msg, xbmcgui.NOTIFICATION_INFO, 2000)

def pair_device():
    device_index = 0
    product = product_list[device_index]
    dev = dev_list[device_index]
    mac = ':'.join(hex(uuid.getnode())[2:].upper()[i:i+2] for i in range(0, 12, 2))

    url = f"https://sledovanitv.cz/api/create-pairing?username={username}&password={password}&type={dev}&product={product}&serial={mac}"
    data = requests.get(url, headers=headers).json()

    if data["status"] != 1:
        dialog(f"Chyba párování: {data.get('error', 'neznámá chyba')}")
        if ADDON.getSetting('debug') == 'true':
            Msg("Chyba párování")
        return None
    with open(DATA_PATH, "w") as f:
        json.dump(data, f, indent=4)
    Msg("Párování OK")
    return data
    
def load_or_pair_device():
    if os.path.exists(DATA_PATH):
        with open(DATA_PATH, "r") as f:
            return json.load(f)
    return pair_device()

def login_device(data):
    deviceId = data["deviceId"]
    passwordId = data["password"]
    if ADDON.getSetting('debug') == 'true':
        Msg(f"Dev {deviceId}")
        Msg(f"Pass {passwordId}")

    login_url = f"https://sledovanitv.cz/api/device-login?deviceId={deviceId}&password={passwordId}&version=2.44.16&lang=cs&unit=default&capabilities=clientvast,vast,adaptive2,webvtt"
    data = requests.get(login_url, headers=headers).json()

    if data["status"] != 1:
        dialog("Chyba login")
        Msg("Chyba login")
        return None
    Msg("Login OK")
    return data["PHPSESSID"]

def unlock_pin(phpsessid):
    if not pin:
        return True
    pin_url = f"http://sledovanitv.cz/api/pin-unlock?pin={pin}&PHPSESSID={phpsessid}"
    pin_data = requests.get(pin_url, headers=headers).json()
    if pin_data["status"] != 1:
        dialog("Chybný pin")
        Msg("Chybný pin")
        return False
    return True

def get_catchup_url(channel_id, phpsessid):
    # Spočítáme časový interval pro catchup (např. 24 hodin zpět)
    date_time_start = datetime.utcnow()  # Start aktuálního času
    d_start = date_time_start.strftime("%Y-%m-%d+%H:%M:%S")
    Msg(f"date_time_start {date_time_start}")
    Msg(f"d_start {d_start}")
    req = requests.get(
        f"http://sledovanitv.cz/api/epg?time={d_start}&duration=1439&detail=poster&channels={channel_id}&PHPSESSID={phpsessid}",
        headers=headers
    ).json()
    Msg(f"req {req}")
    if req["status"] == 1:
        eventId = req["channels"][channel_id][0]["eventId"]
        Msg(f"eventId {eventId}")
        # Požadavek pro získání URL pro catchup
        req = requests.get(
            f"https://sledovanitv.cz/api/event-timeshift?format=m3u8&quality={quality}&capabilities={kd[addon.getSetting('stvcz_codec')]}&force=true&eventId={eventId}&overrun=1&PHPSESSID={phpsessid}",
            headers=headers
        ).json()
        Msg(f"req1 {req}")
        if req["status"] == 1:
            return req["url"]
    return None

def save_playlist(phpsessid, quality_params, enable_catchup=False):
    playlist_url = (
        f"https://sledovanitv.cz/api/playlist?"
        f"{quality_params}"
        f"&force=true&format=m3u8&logosize=96"
        f"&whitelogo=true&drm=&subtitles=1"
        f"{'&type=' + playlist_type if playlist_type else ''}"
        f"&PHPSESSID={phpsessid}"
    )

    resp = requests.get(playlist_url, headers=headers).json()
    if resp["status"] != 1:
        dialog("Chyba při získávání playlistu")
        return None, None

    ch = []
    channels = []

    with open(PLAYLIST_PATH, "w", encoding="utf-8") as f:
        dialog("Stahuji playlist")
        f.write("#EXTM3U\n")

        for d in resp["channels"]:
            if d["locked"] != "none":
                continue
            if ids == "" or d["id"] in ids.split(","):
                group = f'group-title="{resp["groups"][d["group"]]}"'
                f.write(
                            f'#EXTINF:-1 provider="SledovaniTV.cz" {group} '
                            f'tvg-id="stv-{d["id"]}" '
                            f'tvg-logo="{d["logoUrl"]}" '
                            f'catchup="append" catchup-source="&utc={{utc}}&utcend={{utcend}}",{d["name"]}\n'
                        )
                f.write("#KODIPROP:mimetype=application/vnd.apple.mpegurl\n")
                if enable_ISA:
                    f.write("#KODIPROP:inputstream=inputstream.adaptive\n")

                stream_url = d["url"]
                if "catchup_url" in d:
                    stream_url = d["catchup_url"]
                f.write(f"{stream_url}\n")
                ch.append(d["id"])  # jednoduchý seznam ID
                channels.append({
                    "id": f"stv-{d['id']}",
                    "display-name": [(d["name"], "cs")],
                    "icon": [{"src": d["logoUrl"]}],
                })
    Msg("Playlist uložen")
    return ch, channels

    #info <general>: AddOnLog: pvr.iptvsimple: pvr.iptvsimple - GetEPGTagStreamProperties - EPG Catchup URL: plugin://plugin.video.archivsledovanitv/?action=play_pvr_epg&t=tv&id=stv1&date=2025-04-09+20:36

def save_epg(phpsessid, ch, channels):

    if playlist_type == "1":
        filtered_channels = [c for c in channels if ' radio="true" ' not in str(c)]
    elif playlist_type == "2":
        filtered_channels = [c for c in channels if ' radio="true" ' in str(c)]
    else:
        filtered_channels = channels

    # Seznam ID zúžený podle filtru
    ch_filtered = [c['id'].replace('stv-', '') for c in filtered_channels]

    programmes = []
    now = datetime.now()
    local_offset = " " + now.astimezone().strftime("%z")

    for i in range(days_back * -1, days):
        dialog("Stahuji EPG")
        Msg("Stahuji EPG")
        d = now + timedelta(days=i)
        date_from = d.strftime("%Y-%m-%d")
        epg_url = f"https://sledovanitv.cz/api/epg?time={date_from}+00%3A44&duration=1439&detail=description,poster,genres&posterSize=234&channels={','.join(ch_filtered)}&PHPSESSID={phpsessid}"
        epg_data = requests.get(epg_url, headers=headers).json().get("channels", {})

        for cid, programs in epg_data.items():
            for p in programs:
                prog = {
                    'channel': f"stv-{cid}",
                    'start': p["startTime"].replace("-", "").replace(" ", "").replace(":", "") + "00" + local_offset,
                    'stop': p["endTime"].replace("-", "").replace(" ", "").replace(":", "") + "00" + local_offset,
                    'title': [(p["title"], '')],
                    'desc': [(p["description"], '')]
                }
                if "genres" in p:
                    try:
                        prog['category'] = [(g["name"], '') for g in p["genres"]]
                    except Exception as e:
                        Msg(f"Chyba v genres: {e}")
                if "poster" in p:
                    prog['icon'] = [{'src': p["poster"]}]
                programmes.append(prog)

    writer = xmltv.Writer(encoding="utf-8")
    for c in filtered_channels:
        writer.addChannel(c)
    for p in programmes:
        writer.addProgramme(p)
    writer.write(EPG_PATH, pretty_print=True)
    Msg("EPG uložen")

def run():
    data = load_or_pair_device()
    phpsessid = login_device(data)
    if pin:
        unlock_pin(phpsessid)
    ch, channels = save_playlist(phpsessid, quality_params)
    if channels:  # změna podmínky
        save_epg(phpsessid, ch, channels)
    dialog("Hotovo")
    # if ADDON.getSetting('debug') == 'true':
        # qurl = f"https://sledovanitv.cz/api/get-stream-qualities?PHPSESSID={phpsessid}"
        # qres = requests.get(qurl, headers=headers).json()
        # device_info_url = f"https://sledovanitv.cz/api/device-info?PHPSESSID={phpsessid}"
        # device_info = requests.get(device_info_url, headers=headers).json()
        # Msg(f"qres {qres}")
        # Msg(f"device_info {device_info}")
