from resources.lib.script import run

if __name__ == '__main__':
    run()