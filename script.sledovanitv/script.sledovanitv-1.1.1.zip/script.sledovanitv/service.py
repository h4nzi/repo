import xbmc
import xbmcaddon
import xbmcgui
import time
from resources.lib.script import run

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
        
def Msg(msg):
    xbmc.log(f"[Script SledovaniTV] {msg}", level=xbmc.LOGINFO)
    
if ADDON.getSetting("auto_update") == "true":
    Msg("SERVICE.PY: starting up...")
    if __name__ == '__main__':
        time.sleep(60)
        run()

