import xbmc
import xbmcaddon

addon = xbmcaddon.Addon()

startup_plugin = addon.getSetting("startup_plugin").strip()
if startup_plugin != "":
    xbmc.executebuiltin('RunAddon(%s)' % startup_plugin)
    xbmc.log("[service.autoexec.video] starting Plugin: " + startup_plugin, xbmc.LOGINFO)
    
