
import xbmc
import re
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin

def Msg(message):
    xbmc.log("[Kindgirls] " + message, level=xbmc.LOGINFO)

class KindGirls:
    main_url = 'http://www.kindgirls.com/%s'
    photo_url = main_url % 'photo-archive'
    girls_url = main_url % 'girls'
    video_url = main_url % 'video-archive'

    def GetMonths(self):
        HTML = self.GetHTML(self.photo_url)
        Months = []
        if HTML:
            Soup = BeautifulSoup(HTML, 'html.parser')
            Msg(f"Soup: {Soup}")

            Select = Soup.find('select', {'name': 's'})
            Msg(f"Select: {Select}")
            Galleries = Soup.find_all('div', {'class': 'gal_list'})
            Msg(f"Galleries: {Galleries}")
            if Select:
                for Option in Select.find_all('option'):
                    Months.append({
                        'Date': Option.get('value', ''),
                        'Name': Option.text.strip()
                    })
        return Months

    def GetCountries(self):
        HTML = self.GetHTML(self.girls_url)
        Countries = []
        if HTML:
            Soup = BeautifulSoup(HTML, 'html.parser')
            Select = Soup.find('select', {'name': 'c'})
            if Select:
                for Option in Select.find_all('option'):
                    val = Option.get('value')
                    if val and int(val) != 0:
                        Countries.append({
                            'Id': int(val),
                            'Name': Option.text.strip()
                        })
        return Countries

    def GetLetters(self):
        HTML = self.GetHTML(self.girls_url)
        Letters = []
        if HTML:
            Soup = BeautifulSoup(HTML, 'html.parser')
            Select = Soup.find('select', {'name': 'i'})
            if Select:
                for Option in Select.find_all('option'):
                    val = Option.get('value')
                    if val and val != '0':
                        Letters.append({
                            'Id': val,
                            'Name': Option.text.strip()
                        })
        return Letters

    def GetMonthGalleries(self, Month):
        HTML = self.GetHTML(f"{self.photo_url}?s={Month}")
        GalleriesList = []
        if HTML:
            Soup = BeautifulSoup(HTML, 'html.parser')
            Galleries = Soup.find_all('div', {'class': 'gal_list'})
            for Gallery in Galleries:
                Link = Gallery.find('a')
                Img = Gallery.find('img')
                if Link and Img:
                    GalleriesList.append({
                        'Url': self.main_url % Link['href'].strip('/'),
                        'Title': Img.get('alt', '').strip(),
                        'Img': Img.get('src', '')
                    })
        return GalleriesList

    def GetGirls(self, letter=None, country=None):
        if letter is not None:
            Url = f"{self.girls_url}?i={letter}"
        else:
            Url = f"{self.girls_url}?c={country}"

        HTML = self.GetHTML(Url)
        Girls = []
        if HTML:
            Soup = BeautifulSoup(HTML, 'html.parser')
            Models = Soup.find_all('div', {'class': 'model_list'})
            for Model in Models:
                Link = Model.find('a')
                Img = Model.find('img')
                if Link and Img:
                    Girls.append({
                        'Url': self.main_url % Link['href'].strip('/'),
                        'Title': Img.get('alt', '').strip(),
                        'Img': urljoin(self.main_url % '', Img.get('src', '').strip('/'))
                    })
        return Girls

    def GetGirlGalleries(self, Url):
        HTML = self.GetHTML(Url)
        GirlGalleries = []
        if HTML:
            Soup = BeautifulSoup(HTML, 'html.parser')
            Galleries = Soup.find_all('div', {'class': 'gal_list'})
            for Gallery in Galleries:
                Link = Gallery.find('a')
                Img = Gallery.find('img')
                if Link and Img:
                    GirlGalleries.append({
                        'Url': self.main_url % Link['href'].strip('/'),
                        'Title': Link.get('title', '').strip(),
                        'Img': Img.get('src', '')
                    })
        return GirlGalleries

    def GetGallery(self, Url):
        HTML = self.GetHTML(Url)
        Gallery = []
        if HTML:
            Soup = BeautifulSoup(HTML, 'html.parser')
            Images = Soup.find_all('div', {'class': 'gal_list'})
            for Image in Images:
                Img = Image.find('img')
                Links = Image.find_all('a')
                if Img and len(Links) > 1:
                    Gallery.append({
                        'Title': Img.get('title', '').strip(),
                        'ThumbUrl': Img.get('src', ''),
                        'PhotoUrl': Links[1].get('href', '')
                    })

            Girls = Soup.find('div', {'id': 'up_izq'})
            if Girls:
                GirlsLink = Girls.find_all('a')
                for Girl in GirlsLink:
                    href = Girl.get('href')
                    if href:
                        Gallery.append({
                            'Name': Girl.text.strip(),
                            'Url': self.main_url % href.strip('/')
                        })
        return Gallery

    def GetVideoGallery(self, Page):
        Url = f"{self.video_url}/{Page}"
        HTML = self.GetHTML(Url)
        Gallery = []
        if HTML:
            Soup = BeautifulSoup(HTML, 'html.parser')
            Videos = Soup.find_all('div', {'class': 'video_list'})
            for Video in Videos:
                Link = Video.find('a')
                Img = Link.find('img') if Link else None
                if Link and Img:
                    Gallery.append({
                        'Title': Link.text.strip(),
                        'Url': self.main_url % Link['href'].strip('/'),
                        'ThumbUrl': self.main_url % Img['src'].strip('/')
                    })

            Pagination = Soup.find('div', {'class': 'paginar'})
            if Pagination:
                NextPage = Pagination.find('a', text=re.compile('Next'))
                if NextPage and NextPage.parent and 'href' in NextPage.parent.attrs:
                    Url = NextPage.parent['href']
                    match = re.findall(r'[0-9]+', Url)
                    if match:
                        Gallery.append({'NextPage': match[0]})
        return Gallery

    def GetVideoUrl(self, Url):
        HTML = self.GetHTML(Url)
        if HTML:
            Soup = BeautifulSoup(HTML, 'html.parser')
            Source = Soup.find('source', {'type': 'video/mp4'})
            if Source:
                return Source.get('src')
        return None

    def GetHTML(self, url):
        Headers = {
            'User-agent': 'Mozilla/5.0 (X11; Linux x86_64)',
            'referer': self.main_url % ''
        }
        try:
            r = requests.get(url, headers=Headers, timeout=10)
            r.raise_for_status()
            r.encoding = 'utf-8'
            print(f"[DEBUG] URL načteno: {url}")
            print(r.text[:1000])  # vypiš prvních 1000 znaků HTML
            return r.text
        except Exception as e:
            print(f"[KindGirls] Chyba při načítání {url}: {e}")
            return ''
