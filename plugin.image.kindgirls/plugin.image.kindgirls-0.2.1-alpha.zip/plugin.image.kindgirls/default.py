# -*- coding: utf-8 -*-

import os
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from urllib.parse import parse_qs, urlencode
import xbmcvfs

addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_path = addon.getAddonInfo('path')
addon_url = sys.argv[0]
addon_handle = int(sys.argv[1])
addon_args = parse_qs(sys.argv[2][1:])
addon_resources = xbmcvfs.translatePath(os.path.join(addon_path, 'resources', 'lib'))
sys.path.append(addon_resources)

from kindgirls import KindGirls

def log(msg):
    xbmc.log(f"### [{addon_name}] - {msg}", level=xbmc.LOGDEBUG)

def notify(title, msg):
    xbmc.executebuiltin(f'Notification("{title}", "{msg}", 5000)')

def getAddonUrl(params, **kwargs):
    params.update(kwargs)
    return f"{addon_url}?{urlencode(params)}"

def getAddonParam(name):
    val = addon_args.get(name)
    return None if val is None else val[0]

KindGirls = KindGirls()
Mode = getAddonParam('mode')

if Mode is None:
    xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'month'}), xbmcgui.ListItem('Galleries by month'), True)
    xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'country'}), xbmcgui.ListItem('Galleries by country'), True)
    xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'letter'}), xbmcgui.ListItem('Galleries by letter'), True)
    xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'video'}), xbmcgui.ListItem('Video gallery'), True)

elif Mode == 'month':
    Month = getAddonParam('month')

    if Month is None:
        for month in KindGirls.GetMonths():
            item = xbmcgui.ListItem(month['Name'])
            xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'month', 'month': month['Date']}), item, True)
    else:
        for gallery in KindGirls.GetMonthGalleries(Month):
            item = xbmcgui.ListItem(label=gallery['Title'])
            item.setArt({'thumb': gallery['Img'], 'icon': gallery['Img']})
            xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'gallery', 'url': gallery['Url']}), item, True)

elif Mode in ['country', 'letter']:
    Id = getAddonParam(Mode)

    if Id is None:
        items = KindGirls.GetCountries() if Mode == 'country' else KindGirls.GetLetters()
        for item_data in items:
            item = xbmcgui.ListItem(item_data['Name'])
            xbmcplugin.addDirectoryItem(
                addon_handle,
                getAddonUrl({'mode': Mode, Mode: item_data['Id']}),
                item,
                True
            )
    else:
        girls = KindGirls.GetGirls(country=Id) if Mode == 'country' else KindGirls.GetGirls(letter=Id)
        for girl in girls:
            item = xbmcgui.ListItem(label=girl['Title'])
            item.setArt({'thumb': girl['Img'], 'icon': girl['Img']})
            xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'girl', 'url': girl['Url']}), item, True)

elif Mode == 'girl':
    url = getAddonParam('url')
    for gallery in KindGirls.GetGirlGalleries(url):
        item = xbmcgui.ListItem(label=gallery['Title'])
        item.setArt({'thumb': gallery['Img'], 'icon': gallery['Img']})
        xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'gallery', 'url': gallery['Url']}), item, True)

elif Mode == 'gallery':
    gallery_url = getAddonParam('url')
    if gallery_url:
        gallery = KindGirls.GetGallery(gallery_url)
        for image in gallery:
            if 'Title' in image:
                item = xbmcgui.ListItem(label=image['Title'])
                item.setArt({'thumb': image['ThumbUrl'], 'icon': image['PhotoUrl']})
                xbmcplugin.addDirectoryItem(addon_handle, image['PhotoUrl'], item)
            else:
                item = xbmcgui.ListItem(f"More galleries {image['Name']}")
                xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'girl', 'url': image['Url']}), item, True)

elif Mode == 'video':
    page = int(getAddonParam('page') or 1)
    gallery = KindGirls.GetVideoGallery(page)

    for video in gallery:
        if 'NextPage' in video:
            item = xbmcgui.ListItem(label=f"Next page ({video['NextPage']})")
            xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'video', 'page': video['NextPage']}), item, True)
        else:
            item = xbmcgui.ListItem(video['Title'])
            item.setArt({'thumb': video['ThumbUrl'], 'icon': 'DefaultVideo.png'})
            item.setInfo(type='Video', infoLabels={'Title': video['Title']})
            item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'video_play', 'url': video['Url']}), item)

elif Mode == 'video_play':
    url = getAddonParam('url')
    video_url = KindGirls.GetVideoUrl(url)
    if not video_url:
        notify('Error', 'Not found video')
    else:
        item = xbmcgui.ListItem(path=video_url)
        xbmcplugin.setResolvedUrl(addon_handle, True, item)

xbmcplugin.endOfDirectory(addon_handle)
