# -*- coding: utf-8 -*-
 
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

import os
import sys
import urllib.parse
import urllib
import random
import json
import time

from resources.lib.kindgirls import KindGirls
from resources.lib.views import View
from resources.lib.videodb import readVideodb, writeVideodb
from resources.lib.utils.utils import logNot, logErr, notification, notify, getSettingLog, getSettingNum, setProperty

addon = xbmcaddon.Addon()
addon_language = addon.getLocalizedString
addon_path = addon.getAddonInfo('path')

addon_url = sys.argv[0]
addon_handle = int(sys.argv[1])
addon_args = urllib.parse.parse_qs(sys.argv[2][1:])
media_path = os.path.join(addon_path, 'resources', 'media' )
kindGirls = KindGirls()

def mediaFile(path, file):
    try:
        return xbmcvfs.translatePath(os.path.join(media_path, path, file))
    except:
        return None

def getAddonUrl(params, **kwargs):
    params.update(kwargs)
    return "%s?&%s" % (addon_url, urllib.parse.urlencode(params))

def getAddonParam(name):
    return (lambda val: None if val is None else val[0])(addon_args.get(name, None))

def settingsMenu(name, icon, parameters):
    item = xbmcgui.ListItem(label = name)
    item.setArt({'icon': icon})
    xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl(parameters), item, True)

def numberOfText(number):
    return addon_language(number)

def mainMenu(parameter, icon, parameters, visible, enable = True):
    if not enable or not getSettingLog(visible):
        return
    if isinstance(parameter, int):
        text = addon_language(parameter)
        info = addon_language(parameter + 1)
    else:
        text = parameter
        info = ''
    item = xbmcgui.ListItem(label = text)
    picture = mediaFile('icons', icon)
    item.setArt({'icon': picture, 'thumb': picture})
    item.setInfo(type='Video', infoLabels={'plot': info})
    xbmcplugin.setProperty(addon_handle, 'category', text)
    xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl(parameters), item, True)

def playVideo(parameter, icon, parameters, visible, enable = True):
    if not enable or not getSettingLog(visible):
        return
    if isinstance(parameter, int):
        text = addon_language(parameter)
        info = addon_language(parameter + 1)
    else:
        text = parameter
        info = ''
    videos = readVideodb()
    index = random.randint(0,len(videos) - 1)
    logNot('video index: %i' % index)
    video = videos[index]
    url = video['Url']
    videoUrl = kindGirls.GetVideoUrl(url)
    videoUrl = videoUrl.replace('https://', 'http://') # workaround due certification problem
    if videoUrl is None:
        notify('Error', 'Video not found')
    else:
        item = xbmcgui.ListItem(label = text)
        picture = mediaFile('icons', icon)
        if getSettingLog('play_randomvideo_details'):
            plot = '%s\n\n%s' % (info, video['Title'])
            item.setArt({'icon': 'DefaultVideo.png', 'thumb': video['ThumbUrl']})
            item.setInfo(type='Video', infoLabels={'Title': video['Title'], 'plot': plot})
        else:
            plot = info
            item.setArt({'icon': picture})
            item.setInfo(type='Video', infoLabels={'plot': plot})
        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'videoplay', 'url': video['Url']}), item)

def playVideos():
    videos = readVideodb()
    random.shuffle(videos)
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    for video in videos:
        title = video['Title']
        url = video['Url']
        stream = video['Stream']
        item = xbmcgui.ListItem(path=video['Title'])
        item.setInfo(type='Video', infoLabels={'Title': video['Title'], 'plot': video['Title']})
        item.setArt({'icon': video['ThumbUrl'], 'thumb': video['ThumbUrl']})
        playlist.add(stream, item)
    xbmc.Player().play(playlist)
    xbmc.executebuiltin('PlayerControl(RepeatAll)')
    xbmc.executebuiltin('PlayerControl(RandomOn)')

def route():
    view = View()
    mode = getAddonParam('mode')
    query = getAddonParam('query')
    logNot('addon_args: %s' % str(addon_args))

    if mode is None:
        query = '?'
        mainMenu(30136, 'search.png', {'mode': 'search', 'query': '?'}, 'view_search')
        mainMenu(30132, 'home.png', {'mode': 'new'}, 'view_home')
        mainMenu(30122, 'home.png', {'mode': 'previously'}, 'view_home')
        mainMenu(30100, 'star.png', {'mode': 'today'}, 'view_today')
        mainMenu(30110, 'galleries.png', {'mode': 'month', 'month': 1}, 'view_month1')
        mainMenu(30112, 'galleries.png', {'mode': 'month', 'month': 2}, 'view_month2')
        mainMenu(30114, 'galleries.png', {'mode': 'month', 'month': 3}, 'view_month3')
        mainMenu(30106, 'random.png', {'mode': 'random'}, 'view_random')
        mainMenu(30108, 'rotation.png', {'mode': 'rotation'}, 'view_rotation')
        mainMenu(30116, 'bymonth.png', {'mode': 'bymonth'}, 'view_bymonth')
        mainMenu(30118, 'bycountry.png', {'mode': 'bycountry'}, 'view_bycountry')
        mainMenu(30120, 'byletter.png', {'mode': 'byletter'}, 'view_byletter')
        mainMenu('Generace Videodb', 'video.png', {'mode': 'videodb'}, 'videodb', enable=False)
        mainMenu(30124, 'video.png', {'mode': 'video'}, 'view_video')
        mainMenu(30126, 'video.png', {'mode': 'videobypages'}, 'view_videobypages')     
        mainMenu(30128, 'video.png', {'mode': 'videopages'}, 'view_videopages')
        playVideo(30130, 'random.png', {'mode': 'randomvideo'}, 'play_randomvideo')
        mainMenu(30138, 'rotation.png', {'mode': 'randomvideos'}, 'play_randomvideos')
        # playVideos(30140, 'random.png', {'mode': 'randomvideos'}, 'play_randomvideos', enable=False)
        xbmcplugin.endOfDirectory(addon_handle, True, False, False)
    elif mode == 'search':
        view.search(addon_handle, getAddonParam('query'))
    elif mode == 'searchedfor':
        view.tosearch(addon_handle, getAddonParam('query'))
    elif mode == 'new':
        view.galleries(addon_handle, 30132, mode)
    elif mode == 'previously':
        view.galleries(addon_handle, 30122, mode)
    elif mode == 'today':
        view.today(addon_handle, 30100, getAddonParam('widget'))
    elif mode == ('random'):
        view.random(addon_handle, 30106, mode, getAddonParam('widget'), getSettingNum('randomPeriod'))
    elif mode.startswith('rotation'):
        view.rotation(addon_handle, 30108)
    elif mode == 'month':
        month = int(getAddonParam('month'))
        if month == 1:
            view.months(addon_handle, 30110, 0)
        elif month == 2:
            view.months(addon_handle, 30112, 1)
        elif month == 3:
            view.months(addon_handle, 30114, 2)
        else:
            logErr('Unknow call with params: %s' % str(addon_args))
    elif mode == 'bymonth':
        view.bymonth(addon_handle, 30116, getAddonParam('month'))
    elif mode == 'bycountry':
        view.bycountry(addon_handle, 30118, mode, getAddonParam('country'))
    elif mode == 'byletter':
        view.byletter(addon_handle, 30120, mode, getAddonParam('letter'))
    elif mode == 'girl':
        view.girl(addon_handle, 30055, getAddonParam('url'))
    elif mode == 'gallery':
        view.gallery(addon_handle, 30056, getAddonParam('url'))
    elif mode == 'videodb':
        writeVideodb()
    elif mode == 'video':
        view.video(addon_handle, 30124)
    elif mode == 'videobypages':
        view.videopage(addon_handle, 30126, getAddonParam('page'), getAddonParam('next'))
    elif mode == 'videopages':
        view.videopages(addon_handle, 30128)
    elif mode == 'randomvideo':
        view.randomvideo(addon_handle, 30130)
    elif mode == 'randomvideos':
        playVideos()
    elif mode == 'videoplay':
        view.videoplay(addon_handle, getAddonParam('url'))
    else:
        logErr('Unknow call with params: %s' % str(addon_args))
