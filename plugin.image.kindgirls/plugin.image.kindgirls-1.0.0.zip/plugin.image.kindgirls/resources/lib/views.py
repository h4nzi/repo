# -*- coding: utf-8 -*-

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import os, sys
import urllib.parse, urllib, random, json, time

from resources.lib.kindgirls import KindGirls
from resources.lib.videodb import readVideodb
from resources.lib.countries import countryFlag
from resources.lib.script import ScreenSaver
from resources.lib.utils.utils import logNot, logErr, notification, notify, getSettingLog, getSettingNum, setProperty

VIDEO_PAGES = 13
RANDOM_VIDEOS = 16

addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')
addon_version = addon.getAddonInfo('version')
addon_icon = addon.getAddonInfo('icon')
addon_fanart = addon.getAddonInfo('fanart')
addon_language = addon.getLocalizedString
addon_path = addon.getAddonInfo('path')
addon_profile = addon.getAddonInfo('profile')

kindGirls = KindGirls()
random_file=xbmcvfs.translatePath(os.path.join(addon_profile, 'random.json'))

def getAddonUrl(params, **kwargs):
    params.update(kwargs)
    return "%s?&%s" % (sys.argv[0], urllib.parse.urlencode(params))

def mediaFile(path, file):
    try:
        return xbmcvfs.translatePath(os.path.join(media_path, path, file))
    except:
        return None

def loadRandom(delta):
    try:
        with open(random_file) as f:
            random = json.load(f)
        if time.time() - random[0] < int(addon.getSetting('randomPeriod'))*60:
            # logNot('Random period not exceeded')
            return False, random[1], random[2]
        else:
            # logNot('Random period exceeded, new random gallery will be used!')
            return True, None, None
    except:
        # logNot('Random file not exist, new random gallery will be used!')
        return True, None, None

def saveRandom(month, gallery, title):
    time_saved = time.time()
    time_string = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    random_data = [time_saved, month, gallery, title, time_string]
    setProperty('debug', '%s %s' % (title, time_string))
    with open(random_file, "w") as file:
        json.dump(random_data, file)
    # logNot('Random gallery parameters saved')

class View():
    
    def search(self, addon_handle, query):
        logNot('search - query: %s' % query)
        if query == '?':
            keyboard = xbmc.Keyboard('' ,'Zadejte hledaný text', False)
            keyboard.doModal()
            query = keyboard.getText().strip()
            # logNot('query: %s lenght: %i' % (query.strip(), len(query.strip())))
            if keyboard.isConfirmed():
                if len(query.strip()) > 2:
                    galleries = kindGirls.GetSearchedGalleries(query)
                    if galleries != None:
                        for gallery in galleries:
                            item = xbmcgui.ListItem(label = gallery['Title'])
                            item.setArt({'icon': gallery['Img'], 'thumb': gallery['Img']})
                            xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'girl', 'url': gallery['Url']}), item, True)
                else:
                    notification('Zadejte nejméně 3 znaky')
        xbmcplugin.endOfDirectory(addon_handle, True, False, False)

    def searchedfor(self, addon_handle, query):
        if query:
            galleries = kindGirls.GetSearchedGalleries(query)
            for gallery in galleries:
                item = xbmcgui.ListItem(label = gallery['Title'])
                item.setArt({'icon': gallery['Img'], 'thumb': gallery['Img']})
                xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'girl', 'url': gallery['Url']}), item, True)
        xbmcplugin.endOfDirectory(addon_handle, True, False, False)

    def today(self, addon_handle, view_title, widget):
        months = kindGirls.GetMonths()
        # logNot(str(months[0]['Date']))
        galleries = kindGirls.GetMonthGalleries(months[0]['Date'])
        # logNot('galleries: {}'.format(str(galleries[0])))
        if galleries != None:
            galleryUrl = galleries[0]['Url']
            galleryTitle = galleries[0]['Title']
            galleryImg = galleries[0]['Img']
            gallery = kindGirls.GetGallery(galleryUrl)
            if widget == 'on':
                item = xbmcgui.ListItem(label = galleryTitle, label2 = galleryTitle)
                item.setArt({'icon': galleryImg, 'thumb': galleryImg})
                xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'gallery', 'url': galleryUrl}), item, True)
            if(gallery):
                for image in gallery:
                    if 'Title' in image:
                        item = xbmcgui.ListItem(label = image['Title'], label2 = galleryTitle)
                        item.setArt({'icon': image['PhotoUrl'], 'thumb': image['ThumbUrl']})
                        xbmcplugin.addDirectoryItem(addon_handle, image['PhotoUrl'], item)
                    else:
                        item = xbmcgui.ListItem(label = "More galleries %s" % image['Name'])
                        xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'girl', 'url': image['Url']}), item, True)
        xbmcplugin.setPluginCategory(addon_handle, addon_language(view_title))
        xbmcplugin.endOfDirectory(addon_handle, True, False, False)

    def galleries(self, addon_handle, view_title, mode):
        if mode == 'new':
            galleries = kindGirls.GetNewGalleries()
        elif mode == 'previously':
            galleries = kindGirls.GetPreviouslyGalleries()
        else:
            galleries = kindGirls.GetGalleries(mode)
        if galleries != None:
            for gallery in galleries:
                item = xbmcgui.ListItem(label = gallery['Title'])
                item.setArt({'icon': gallery['Img'], 'thumb': gallery['ThumbUrl']})
                if not gallery['Type'] == 'video':
                    xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'gallery', 'url': gallery['Url']}), item, True)
                else:
                    item.setInfo(type='Video', infoLabels={ 'Title': gallery['Title'] })
                    item.setProperty('IsPlayable', 'true')
                    xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'videoplay', 'url': gallery['Url']}), item)
        xbmcplugin.setPluginCategory(addon_handle, addon_language(view_title))
        xbmcplugin.endOfDirectory(addon_handle, True, False, False)

    def months(self, addon_handle, view_title, month):
        months = kindGirls.GetMonths()
        galleries = kindGirls.GetMonthGalleries(months[month]['Date'])
        if galleries != None:
            for gallery in galleries:
                item = xbmcgui.ListItem(label = gallery['Title'])
                item.setArt({'icon': gallery['Img'], 'thumb': gallery['Img']})
                xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'gallery', 'url': gallery['Url']}), item, True)
        xbmcplugin.setPluginCategory(addon_handle, addon_language(view_title))
        xbmcplugin.endOfDirectory(addon_handle, True, False, False)

    def random(self, addon_handle, view_title, mode, widget, randomPeriod):
        months = kindGirls.GetMonths()
        if widget == 'on':
            # logNot('randomPeriod: %i' % randomPeriod)
            new, month, gallery = loadRandom(randomPeriod)
            # logNot('randomPeriod: %i' % randomPeriod)
            if new:
                month = random.randint(0,len(months) - 1)
            galleries = kindGirls.GetMonthGalleries(months[month]['Date'])
            if new:
                gallery = random.randint(0,len(galleries) - 1)
            galleryUrl = galleries[gallery]['Url']
            galleryTitle = galleries[gallery]['Title']
            galleryImg = galleries[gallery]['Img']
            gallery = kindGirls.GetGallery(galleryUrl)
            if new:
                saveRandom(month, gallery, galleryTitle)
            item = xbmcgui.ListItem(label = galleryTitle, label2 = galleryTitle)
            item.setArt({'icon': galleryImg, 'thumb': galleryImg})
            xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'gallery', 'url': galleryUrl}), item, True)
        else:
            month = random.randint(0,len(months) - 1)
            galleries = kindGirls.GetMonthGalleries(months[month]['Date'])
            gallery = random.randint(0,len(galleries) - 1)
            galleryUrl = galleries[gallery]['Url']
            galleryTitle = galleries[gallery]['Title']
            galleryImg = galleries[gallery]['Img']
            gallery = kindGirls.GetGallery(galleryUrl)
            saveRandom(month, gallery, galleryTitle)

        if gallery:
            for image in gallery:
                if 'Title' in image:
                    item = xbmcgui.ListItem(label = image['Title'], label2 = galleryTitle)
                    item.setArt({'icon': image['PhotoUrl'], 'thumb': image['ThumbUrl']})
                    xbmcplugin.addDirectoryItem(addon_handle, image['PhotoUrl'], item)
                else:
                    item = xbmcgui.ListItem(label = "More galleries %s" % image['Name'])
                    item.setArt({'icon': mediaFile('icons', 'galleries.png')})
                    xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'girl', 'url': image['Url']}), item, True)
        xbmcplugin.setPluginCategory(addon_handle, addon_language(view_title))
        xbmcplugin.endOfDirectory(addon_handle, True, False, False)

    def rotation(self, addon_handle, view_title):
        screenSaverInhibited = xbmc.getCondVisibility('System.IsScreensaverInhibited')
        if not screenSaverInhibited:
            xbmc.executebuiltin('InhibitScreensaver(true)', True)
        screenSaver = ScreenSaver('default.xml', addon_path, 'default')
        screenSaver.doModal()
        screenSaver.close()
        del screenSaver
        if not screenSaverInhibited:
            xbmc.executebuiltin('InhibitScreensaver(false)', True)

    def bymonth(self, addon_handle, view_title, month):
        if(month is None):
            months = kindGirls.GetMonths()
            for month in months:
                item = xbmcgui.ListItem(label = month['Name'])
                item.setArt({'icon': mediaFile('icons', 'galleries.png')})
                xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'bymonth', 'month': month['Date']}), item, True)
        else:
            galleries = kindGirls.GetMonthGalleries(month)
            if galleries != None:
                for gallery in galleries:
                    item = xbmcgui.ListItem(label = gallery['Title'])
                    item.setArt({'icon': gallery['Img'], 'thumb': gallery['Img']})
                    xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'gallery', 'url': gallery['Url']}), item, True)
        xbmcplugin.setPluginCategory(addon_handle, addon_language(view_title))
        xbmcplugin.endOfDirectory(addon_handle, True, False, False)

    def bycountry(self, addon_handle, view_title, mode, ident):
        if(ident is None):
            countries = kindGirls.GetCountries()
            # logNot(str(countries))
            for country in countries:
                item = xbmcgui.ListItem(country['Name'])
                countryName = country['Name'].split(" (", 1)[0] # Country name splitting
                if countryName == 'Stonia': # Workaround due non exist Stonia country
                    continue
                url = getAddonUrl({'mode': mode, 'country': country['Id']})
                item.setArt({'icon': countryFlag(countryName)})
                xbmcplugin.addDirectoryItem(addon_handle, url, item, True)        
        else:
            girls = kindGirls.GetGirls(country = ident)
            # logNot('girls: %s' % str(girls))
            for girl in girls:
                item = xbmcgui.ListItem(label = girl['Title'])
                item.setArt({'icon': girl['Img'], 'thumb': girl['Img']})
                xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'girl', 'url': girl['Url']}), item, True)
        xbmcplugin.setPluginCategory(addon_handle, addon_language(view_title))
        xbmcplugin.endOfDirectory(addon_handle, True, False, False)

    def byletter(self, addon_handle, view_title, mode, ident):
        if(ident is None):
            letters = kindGirls.GetLetters()
            for letter in letters:
                item = xbmcgui.ListItem(letter['Name'])
                url = getAddonUrl({'mode': mode, 'letter': letter['Id']})
                xbmcplugin.addDirectoryItem(addon_handle, url, item, True)        
        else:
            girls = kindGirls.GetGirls(letter = ident)
            for girl in girls:
                item = xbmcgui.ListItem(label = girl['Title'])
                item.setArt({'icon': girl['Img'], 'thumb': girl['Img']})
                xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'girl', 'url': girl['Url']}), item, True)
        xbmcplugin.setPluginCategory(addon_handle, addon_language(view_title))
        xbmcplugin.endOfDirectory(addon_handle, True, False, False)

    def recent(self, addon_handle, view_title):
        girls = kindGirls.GetRecentlyAdded()
        for girl in girls:
            item = xbmcgui.ListItem(label = girl['Title'])
            item.setArt({'icon': girl['ThumbUrl'], 'thumb': girl['ThumbUrl']})
            xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'girl', 'url': girl['Url']}), item, True)
        xbmcplugin.setPluginCategory(addon_handle, addon_language(view_title))
        xbmcplugin.endOfDirectory(addon_handle, True, False, False)

    def girl(self, addon_handle, view_title, url):
        galleries = kindGirls.GetGirlGalleries(url)
        for gallery in galleries:
            item = xbmcgui.ListItem(label = gallery['Title'])
            item.setArt({'icon': gallery['Img'], 'thumb': gallery['Img']})
            xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'gallery', 'url': gallery['Url']}), item, True)
        videos = kindGirls.GetGirlVideos(url)
        if (videos):
            for video in videos:
                item = xbmcgui.ListItem(video['Title'])
                item.setArt({'icon': 'DefaultVideo.png', 'thumb': video['Img']})
                item.setInfo(type='Video', infoLabels={'Title': video['Title'], 'plot': video['Title']})
                item.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'videoplay', 'url': video['Url']}), item)
        xbmcplugin.setPluginCategory(addon_handle, addon_language(view_title))
        xbmcplugin.endOfDirectory(addon_handle, True, False, False)

    def gallery(self, addon_handle, view_title, galleryUrl):
        if(galleryUrl is not None):
            gallery = kindGirls.GetGallery(galleryUrl)
            if(gallery):
                for image in gallery:
                    if 'Title' in image:
                        item = xbmcgui.ListItem(label = image['Title'])
                        item.setArt({'icon': image['PhotoUrl'], 'thumb': image['ThumbUrl']})
                        xbmcplugin.addDirectoryItem(addon_handle, image['PhotoUrl'], item)
                    else:
                        item = xbmcgui.ListItem(label = "More galleries %s" % image['Name'])
                        item.setArt({'icon': mediaFile('icons', 'galleries.png')})
                        xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'girl', 'url': image['Url']}), item, True)
        xbmcplugin.setPluginCategory(addon_handle, addon_language(view_title))
        xbmcplugin.endOfDirectory(addon_handle, True, False, False)

    def video(self, addon_handle, view_title):
        videos = readVideodb()
        for video in videos:
            item = xbmcgui.ListItem(video['Title'])
            item.setArt({'icon': 'DefaultVideo.png', 'thumb': video['ThumbUrl']})
            item.setInfo(type='Video', infoLabels={'Title': video['Title'], 'plot': video['Title']})
            item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'videoplay', 'url': video['Url']}), item)
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.setPluginCategory(addon_handle, addon_language(view_title))
        xbmcplugin.endOfDirectory(addon_handle, True, False, False)

    def videopage(self, addon_handle, view_title, pageStr, nextView):
        if pageStr is None:
            page = 1
        else:
            page = int(pageStr)
        logNot(f'page: {page} nextView: {nextView}')
        videos = readVideodb()
        lastPage = videos[-1]['Page']
        condition = lambda item: item['Page'] == page
        gallery = list(filter(condition, videos))
        if(gallery):
            for video in gallery:
                item = xbmcgui.ListItem(video['Title'])
                item.setArt({'icon': 'DefaultVideo.png', 'thumb': video['ThumbUrl']})
                item.setInfo(type='Video', infoLabels={'Title': video['Title'], 'plot': video['Title']})
                item.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'videoplay', 'url': video['Url']}), item)
            nextPage = page + 1
            if nextView != 'off' and nextPage <= lastPage:
                item = xbmcgui.ListItem(label = 'Next page (%i)' % nextPage)
                item.setArt({'icon': 'defaultaddonvideo.png'})
                xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'videobypages', 'page': nextPage}), item, True)
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.setPluginCategory(addon_handle, f'{addon_language(view_title)} No. {page}')
        xbmcplugin.endOfDirectory(addon_handle, True, False, False)

    def videopages(self, addon_handle, view_title):
        page = 0
        videos = readVideodb()
        if(videos):
            for video in videos:
                if video['Page'] != page:
                    page = video['Page']
                    item = xbmcgui.ListItem(label = 'Page No. %i, started with %s' % (page, video['Title']))
                    item.setArt({'icon': video['ThumbUrl'], 'thumb': video['ThumbUrl']})
                    item.setInfo(type='Video', infoLabels={'Title': video['Title'], 'plot': video['Title']})
                    xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'videobypages', 'page': page, 'next': 'off'}), item, True)
                else:
                    continue
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.setPluginCategory(addon_handle, addon_language(view_title))
        xbmcplugin.endOfDirectory(addon_handle, True, False, True)

    def randomvideo(self, addon_handle, view_title):
        videos = readVideodb()
        index = random.randint(0,len(videos) - 1)
        logNot('video index: %i' % index)
        video = videos[index]
        url = video['Url']
        videoUrl = kindGirls.GetVideoUrl(url)
        videoUrl = videoUrl.replace('https://', 'http://') # workaround due certification problem
        if videoUrl is None:
            notify('Error', 'Video not found')
        else:
            item = xbmcgui.ListItem(video['Title'])
            item.setArt({'icon': 'DefaultVideo.png', 'thumb': video['ThumbUrl']})
            item.setInfo(type='Video', infoLabels={ 'Title': video['Title'] })
            item.setProperty('IsPlayable', 'true')
            item.setProperty('IsFolder', 'false')
            xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'videoplay', 'url': video['Url']}), item)
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.setPluginCategory(addon_handle, addon_language(view_title))
        xbmcplugin.endOfDirectory(addon_handle, True, False, False)

    def randomvideos(self, addon_handle, view_title):
        maxPage = VIDEO_PAGES
        for item in range(RANDOM_VIDEOS):
            page = random.randint(1,maxPage)
            gallery = kindGirls.GetVideoGallery(page)
            lenght = len(gallery)
            index = random.randint(0,len(gallery) - 2)
            if 'NextPage' in gallery:
                index -= 1
            logNot('video index: ' + str(index))
            video = gallery[index]
            url = video['Url']
            videoUrl = kindGirls.GetVideoUrl(url)
            videoUrl = videoUrl.replace('https://', 'http://') # workaround due certification problem
            if videoUrl is None:
                notify('Error', 'Video not found')
            else:
                item = xbmcgui.ListItem(video['Title'])
                item.setArt({'icon': 'DefaultVideo.png', 'thumb': video['ThumbUrl']})
                item.setInfo(type='Video', infoLabels={ 'Title': video['Title'] })
                item.setProperty('IsPlayable', 'true')
                item.setProperty('IsFolder', 'false')
                xbmcplugin.addDirectoryItem(addon_handle, getAddonUrl({'mode': 'videoplay', 'url': video['Url']}), item)
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.setPluginCategory(addon_handle, addon_language(view_title))
        xbmcplugin.endOfDirectory(addon_handle, True, False, False)

    def videoplay(self, addon_handle, url):
        videoUrl = kindGirls.GetVideoUrl(url)
        videoUrl = videoUrl.replace('https://', 'http://') # workaround due certification problem
        if videoUrl is None:
            notify('Error', 'Video not found')
        else:
            item = xbmcgui.ListItem(path = videoUrl)
            xbmcplugin.setResolvedUrl(addon_handle, True, item)
        # xbmcplugin.endOfDirectory(addon_handle, True, False, False)
