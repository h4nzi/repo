# -*- coding: utf-8 -*-

import xbmc

import re
import requests
# import json

from bs4 import BeautifulSoup
from resources.lib.utils.utils import logNot

class KindGirls():
    
    main_url = 'http://www.kindgirls.com/%s'
    photo_url = main_url % ('photo-archive')
    girls_url = main_url % ('girls')
    video_url = main_url % ('video-archive')

    def GetMonths(self):
        HTML = self.GetHTML(self.photo_url)
        Months = None
        
        if(HTML):
            Soup = BeautifulSoup(HTML, 'html.parser' )
            Select = Soup.find('select', {'name': 's'});
            
            if(Select):
                Months = []
                Options = Select.findAll('option')
                
                for Option in Options:                
                    Months.append({'Date': Option['value'], 'Name': Option.text})
            
        return Months

    def GetCountries(self):
        HTML = self.GetHTML(self.girls_url)
        Countries = None
        
        if(HTML):
            Soup = BeautifulSoup(HTML, 'html.parser')
            Select = Soup.find('select', {'name': 'c'});
            
            if(Select):
                Countries = []
                Options = Select.findAll('option')
                
                for Option in Options:
                    if(int(Option['value']) != 0):
                        Countries.append({'Id': int(Option['value']), 'Name': Option.text})
            
        return Countries
        
    def GetLetters(self):
        HTML = self.GetHTML(self.girls_url)
        Letters = None
        
        if(HTML):
            Soup = BeautifulSoup(HTML, 'html.parser')
            Select = Soup.find('select', {'name': 'i'});
            
            if(Select):
                Letters = []
                Options = Select.findAll('option')
                
                for Option in Options:
                    if(Option['value'] != '0'):
                        Letters.append({'Id': Option['value'], 'Name': Option.text})

        return Letters

    def GetMonthGalleries(self, Month):
        month_url = self.photo_url + '?s=%s' % (Month)
        HTML = self.GetHTML(month_url)
        # logNot(str(HTML))
        MonthGalleries = None

        if(HTML):
            Soup = BeautifulSoup(HTML, 'html.parser')
            Galleries = Soup.findAll('div', {'class': 'box1'})
            # logNot(str(Galleries))

            if(Galleries):
                MonthGalleries = []

                for Gallery in Galleries:
                    Link = Gallery.find('a')
                    Img = Gallery.find('img')

                    MonthGalleries.append({
                        'Url': self.main_url % (Link['href'].strip('/')),
                        'Title': Img['alt'],
                        'Img': Img['src']
                    })

        return MonthGalleries

    def GetGirls(self, letter = None, country = None):
        
        if(letter is None):
            Url = self.girls_url + '?c=%s' % (country)
        else:
            Url = self.girls_url + '?i=%s' % (letter)
        
        HTML = self.GetHTML(Url)
        Girls = None

        if(HTML):
            Soup = BeautifulSoup(HTML, 'html.parser')
            Models = Soup.findAll('div', {'class': 'box3'})
            
            if(Models):
                Girls = []
                
                for Model in Models:
                    Link = Model.find('a')
                    Img = Model.find('img')
                    
                    Girls.append({
                        'Url': self.main_url % (Link['href'].strip('/')),
                        'Title': Img['alt'],
                        'Img': self.main_url % (Img['src'].strip('/')),
                    })

        return Girls

    def GetSearchedGalleries(self, Text):
        # https://www.kindgirls.com/girls.php?s=Aaliyah
        Url = self.girls_url + '.php?s=%s' % Text
        HTML = self.GetHTML(Url)
        GirlGalleries = None

        if(HTML):
            Soup = BeautifulSoup(HTML, 'html.parser')
            Galleries = Soup.findAll('div', {'class': 'box3'})

            if(Galleries):
                GirlGalleries = []

                for Gallery in Galleries:
                    Link = Gallery.find('a')
                    Img = Gallery.find('img')

                    GirlGalleries.append({
                        'Url': self.main_url % (Link['href'].strip('/')),
                        'Title': Img['alt'],
                        'Img': self.main_url % (Img['src'].strip('/'))
                    })

        return GirlGalleries

    def GetGirlGalleries(self, Url):
        HTML = self.GetHTML(Url)
        GirlGalleries = None

        if(HTML):
            Soup = BeautifulSoup(HTML, 'html.parser')
            Galleries = Soup.findAll('div', {'class': 'box1'})

            if(Galleries):
                GirlGalleries = []

                for Gallery in Galleries:
                    Link = Gallery.find('a')
                    Img = Gallery.find('img')

                    GirlGalleries.append({
                        'Url': self.main_url % (Link['href'].strip('/')),
                        'Title': Link['title'],
                        'Img': Img['src']
                    })

        return GirlGalleries

    def GetGallery(self, Url):
        HTML = self.GetHTML(Url)
        Gallery = None

        if(HTML):
            Soup = BeautifulSoup(HTML, 'html.parser')
            Images = Soup.findAll('div', {'class': 'box1'})

            if(Images):
                Gallery = []

                for Image in Images:
                    Img = Image.find('img')
                    Link = Image.findAll('a')[1]
                    # Link = Image.findAll('a')

                    Gallery.append({
                        'Title': Img['title'],
                        # 'Title': Img['alt'],
                        'ThumbUrl': Img['src'],
                        'PhotoUrl': Link['href']
                    })

                # Girls = Soup.find('div', {'class': 'pub'})
                # GirlsLink = Girls.findAll('a')
                
                # if(Girls):
                    
                    # for Girl in GirlsLink:
                        # Gallery.append({
                            # 'Name': Girl.text,
                            # 'Url': self.main_url % (Girl['href'].strip('/')),
                        # })
    
        return Gallery

    def GetVideoGallery(self, Page):
        Url = self.video_url + "/.php?p=" + str(Page)
        HTML = self.GetHTML(Url)
        Gallery = None

        if(HTML):
            Soup = BeautifulSoup(HTML, 'html.parser')
            Videos = Soup.findAll('div', {'class': 'box2'})
            
            if(Videos):
                Gallery = []
                
                for Video in Videos:
                    Link = Video.find('a')
                    Img = Link.find('img')
                    
                    Gallery.append({
                        'Title': Link.text,
                        'Url': self.main_url % (Link['href'].strip('/')),
                        'ThumbUrl': self.main_url % (Img['src'].strip('/'))
                    })
                
                Pagination = Soup.find('p', {'class': 'paginar'})
                # logNot('Pagination: %s' % str(Pagination))
                Pages = Soup.findAll('option')
                ActualPage = 1
                LastPage = len(Pages)
                NextPage = 0
                for Page in Pages:
                    # logNot('Page: %s ActualPage: %i' % (Page, ActualPage))
                    if 'selected' in str(Page):
                        break
                    ActualPage += 1
                if ActualPage < LastPage:
                    NextPage = ActualPage + 1
                # logNot('ActualPage: %i LastPage: %i NextPage: %i' % (ActualPage, LastPage, NextPage))

                if NextPage > 0:
                    # https://www.kindgirls.com/video-archive.php?p=2
                    Url = self.video_url + ('.php?p=%i' % NextPage)
                    # logNot('Url: ' + str(Url))

                    Gallery.append({
                        'NextPage': str(NextPage)
                    })
                
        return Gallery
        
    def GetVideoUrl(self, Url):
        HTML = self.GetHTML(Url)
        VideoUrl = None

        if(HTML):
            Soup = BeautifulSoup(HTML, 'html.parser')
            Source = Soup.find('source', {'type': 'video/mp4'})
            
            if(Source):
                VideoUrl = Source['src']
        
        return VideoUrl

    def GetHTML(self, url):
        # logNot('HTML Url: %s' % url)
        HTML = None
        Headers = {
            'User-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36',
            'referer': self.main_url % ('')
        }
        try:
            r = requests.get(url, headers = Headers)
            if(r.status_code == 200):
                HTML = r.text.encode('utf-8')
                # logNot('HTML OK 1')
            else:
                pass
                # logNot('HTML Error 1')
            return HTML
        except:
            xbmc.sleep(500)
            # logNot('HTML Except')
            r = requests.get(url, headers = Headers)
            if(r.status_code == 200):
                HTML = r.text.encode('utf-8')
                # logNot('HTML OK 2')
            else:
                pass
                # logNot('HTML Error 2')
            return HTML
      
    def GetRecentlyAdded(self):
        Url = self.main_url
        HTML = self.GetHTML(Url)
        Gallery = None

        if(HTML):
            Soup = BeautifulSoup(HTML, 'html.parser')
            Girls = Soup.findAll('div', {'class': 'box3'})
            
            if(Girls):
                Gallery = []
                
                for Girl in Girls:
                    Link = Girl.find('a')
                    Img = Link.find('img')
                    
                    Gallery.append({
                        'Title': Img['alt'],
                        'Url': self.main_url % (Link['href'].strip('/')),
                        'ThumbUrl': self.main_url % (Img['src'].strip('/'))
                    })
    
        return Gallery

    def GetGalleries(self, mode):
        Url = self.main_url
        HTML = self.GetHTML(Url)
        Galleries = None

        if(HTML):
            Soup = BeautifulSoup(HTML, 'html.parser')
            Girls = Soup.findAll('div', {'class': 'box1'})
            logNot(str(Girls))
            
            if(Girls):
                Galleries = []
                
                for Girl in Girls:
                    # logNot(str(Girl))
                    Text = Girl.text
                    isNew = ('photos' in Text or 'video' in Text)
                    if (mode == 'randomgalleries' and isNew) or (mode == 'newgalleries' and not isNew):
                        continue
                    Text = Text.replace('photos', 'photos, ')
                    Text = Text.replace('video', 'video, ')
                    Link = Girl.find('a')
                    Img = Link.find('img')
                    if Img['src'].startswith('http'):
                        Img = Img['src']
                        Type = 'picture'
                    else:
                        Img = self.main_url % (Img['src'].strip('/'))
                        Type = 'video'

                    Galleries.append({
                        'Title': Text,
                        'Url': self.main_url % (Link['href'].strip('/')),
                        'Type': Type,
                        'Img': Img,
                        'ThumbUrl': Img
                    })
    
        return Galleries

    def GetNewGalleries(self):
        Url = self.main_url
        HTML = self.GetHTML(Url)
        Gallery = None

        if(HTML):
            Soup = BeautifulSoup(HTML, 'html.parser')
            Girls = Soup.findAll('div', {'class': 'box1'})
            # logNot(str(Girls))
            
            if(Girls):
                Galleries = []
                
                for Girl in Girls:
                    # logNot(str(Girl))
                    Text = Girl.text
                    if not ('photos' in Text or 'video' in Text):
                        break
                    Text = Text.replace('photos', 'photos, ')
                    Text = Text.replace('video', 'video, ')
                    Link = Girl.find('a')
                    Img = Link.find('img')
                    if Img['src'].startswith('http'):
                        Img = Img['src']
                        Type = 'picture'
                    else:
                        Img = self.main_url % (Img['src'].strip('/'))
                        Type = 'video'

                    Galleries.append({
                        'Title': Text,
                        'Url': self.main_url % (Link['href'].strip('/')),
                        'Type': Type,
                        'Img': Img,
                        'ThumbUrl': Img
                    })
    
        return Galleries

    def GetPreviouslyGalleries(self):
        Url = self.main_url
        HTML = self.GetHTML(Url)
        Gallery = None

        if(HTML):
            Soup = BeautifulSoup(HTML, 'html.parser')
            Previously = Soup.find('div', {'id': 'randon'})
            logNot(str(Previously))
            Girls = Previously.findAll('div', {'class': 'box1'})
            logNot(str(Girls))
            
            if(Girls):
                Galleries = []
                
                for Girl in Girls:
                    # logNot(str(Girl))
                    Text = Girl.text
                    # if 'photos' in Text or 'video' in Text:
                        # continue
                    Text = Text.replace('photos', 'photos, ')
                    Text = Text.replace('video', 'video, ')
                    Link = Girl.find('a')
                    Img = Link.find('img')
                    if Img['src'].startswith('http'):
                        Img = Img['src']
                        Type = 'picture'
                    else:
                        Img = self.main_url % (Img['src'].strip('/'))
                        Type = 'video'

                    Galleries.append({
                        'Title': Text,
                        'Url': self.main_url % (Link['href'].strip('/')),
                        'Type': Type,
                        'Img': Img,
                        'ThumbUrl': Img
                    })
    
        return Galleries

    def GetGirlVideos(self, Url):
        HTML = self.GetHTML(Url)
        GirlVideos = None

        if(HTML):
            Soup = BeautifulSoup(HTML, 'html.parser')
            # Videos = Soup.findAll('div', {'class': 'video_list'})
            Videos = Soup.findAll('div', {'class': 'box2'})


            if(Videos):
                GirlVideos = []

                for Video in Videos:
                    Link = Video.find('a')
                    Img = Video.find('img')

                    GirlVideos.append({
                        'Title': Img['alt'],
                        'Url': self.main_url % (Link['href'].strip('/')),
                        'Img': self.main_url % (Img['src'].strip('/'))
                    })

        return GirlVideos
