# -*- coding: utf-8 -*-

import xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs
import sys, json, os, random, time, datetime, itertools, requests
import urllib

from resources.lib.kindgirls import KindGirls
from resources.lib.utils.utils import logNot, logErr, logTracking, logBackend, logDebug, getSettingLog, getSettingNum, setProperty, clearProperty

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION  = ADDON.getAddonInfo('version')
ADDON_ICON = ADDON.getAddonInfo('icon')
ADDON_FANART = ADDON.getAddonInfo('fanart')
ADDON_LANGUAGE = ADDON.getLocalizedString
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_PROFILE = ADDON.getAddonInfo('profile')

SCREEN_FILE = xbmcvfs.translatePath(os.path.join(ADDON_PROFILE, 'screen.json'))

IMG_CONTROLS   = [30000,30005]

ACTION_MOVE_RIGHT = 2
ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92

def loadScreen():
    try:
        with open(SCREEN_FILE) as f:
            screen = json.load(f)
            return screen[0], screen[1], screen[2], int(screen[3])
        logErr('SaveScreen file error reading')
        return None, None, None, None
    except:
        logErr('SaveScreen file error reading')
        return None, None, None, None

def saveScreen(galleryUrl, title, pictureUrl, picture):
    try:
        time_string = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        screen_data = [galleryUrl, title, pictureUrl, picture, time_string]
        with open(SCREEN_FILE, "w") as file:
            json.dump(screen_data, file)
    except:
        pass

class ScreenSaver(xbmcgui.WindowXMLDialog):
        
    def onInit(self):
        logTracking('onInit')
        self.monitor = xbmc.Monitor()
        self.kindGirls = KindGirls()
        self.stop = False
        self.right = False
        self.onePicture = getSettingLog('onePicture')
        self.rotationPeriod = getSettingNum('rotationPeriod')
        winId = xbmcgui.Window(xbmcgui.getCurrentWindowDialogId())
        winId.setProperty('kindgirls_picturebackground', 'ON' if getSettingLog('pictureBackground') else 'OFF')
        winId.setProperty('kindgirls_pictureanimation', 'ON' if getSettingLog('pictureAnimation') else 'OFF')
        winId.setProperty('kindgirls_overlay', 'ON' if getSettingLog('pictureOverlay') else 'OFF')
        winId.setProperty('kindgirls_logodisplay', 'ON' if getSettingLog('logoDisplay') else 'OFF')
        winId.setProperty('kindgirls_logoanimation', 'ON' if getSettingLog('logoAnimation') else 'OFF')
        winId.setProperty('kindgirls_galleryinfo', 'ON' if getSettingLog('galleryInfo') else 'OFF')
        self.startRotation()
         
    def onExit(self):
        logTracking('onExit')
        self.timeToEnd = time.time()
        self.stop = True
        self.right = False
        self.close()

    def onAction(self, action):
        actionCode = action.getId() 
        self.stop = False
        self.right = False
        if actionCode == ACTION_NAV_BACK or actionCode == ACTION_PREVIOUS_MENU:
            logTracking('onAction: Back')
            self.timeToEnd = time.time()
            self.stop = True
            self.close()
        elif actionCode == ACTION_MOVE_RIGHT:
            logTracking('onAction: Move Right')
            self.right = True
        else:
            pass

    def waitForTime(self, wait):
        for i in range(int(wait * 2)):
            xbmc.sleep(500)
            if self.stop or self.right:
                break
        else:
            return False
        if self.stop:
            return True
        if self.right:
            return False
 
    def setImage(self, id, galleryUrl, gallery, title, pictureUrl, picture):
        logTracking('setImage')
        logDebug('setImage before galleryUrl: %s, title: %s, pictureUrl: %s, picture: %d:' % (galleryUrl, title, pictureUrl, picture))
        galleryUrl, gallery, title, pictureUrl, picture = self.getPicture(galleryUrl, gallery, title, picture)
        logDebug('setImage after  galleryUrl: %s, title: %s, pictureUrl: %s, picture: %d:' % (galleryUrl, title, pictureUrl, picture))
        self.getControl(id+1).setImage(pictureUrl)
        self.getControl(id+2).setImage(pictureUrl)
        if self.onePicture:
            self.getControl(id+3).setLabel(title)
        else:
            self.getControl(id+3).setLabel('#%d, %s' % (picture + 1, title))
        return galleryUrl, gallery, title, pictureUrl, picture

    def swap(self, x, y):
        return y, x

    def startRotation(self):
        logTracking('startRotation')
        galleryUrl, title, pictureUrl, picture = loadScreen()
        logDebug('loadScreen galleryUrl: %s, title: %s, pictureUrl: %s, picture: %s' % (galleryUrl, title, pictureUrl, str(picture)))
        gallery = None
        currentId = IMG_CONTROLS[0]
        nextId = IMG_CONTROLS[1]
        if pictureUrl == None or title == None:
            logTracking('Clear start')
            galleryUrl, gallery, title, pictureUrl, picture = self.setImage(currentId, galleryUrl, gallery, title, pictureUrl, 0)
        else:
            logTracking('Start from save position')
            logDebug('previousRun galleryUrl: %s, title: %s, pictureUrl: %s, picture: #%d:' % (galleryUrl, title, pictureUrl, picture))
            self.getControl(currentId+1).setImage(pictureUrl)
            self.getControl(currentId+2).setImage(pictureUrl)
            self.getControl(currentId+3).setLabel(title)
            if self.onePicture:
                self.getControl(currentId+3).setLabel(title)
            else:
                self.getControl(currentId+3).setLabel('#%d, %s' % (picture + 1, title))
        while not self.monitor.abortRequested():
            self.right = False
            self.getControl(nextId).setVisible(False)
            self.getControl(currentId).setVisible(True)
            currentId, nextId = self.swap(currentId, nextId)
            galleryUrl, gallery, title, pictureUrl, picture = self.setImage(currentId, galleryUrl, gallery, title, pictureUrl, picture)
            if self.stop or self.waitForTime(self.rotationPeriod):
                saveScreen(galleryUrl, title, pictureUrl, picture)
                logDebug('saveScreen')
                break

    def getGallery(self):
        logTracking('getGallery')
        months = self.kindGirls.GetMonths()
        imonth = random.randint(0,len(months) - 1)
        galleries = self.kindGirls.GetMonthGalleries(months[imonth]['Date'])
        igallery = random.randint(0,len(galleries) - 1)
        galleryUrl = galleries[igallery]['Url']
        logDebug('getGallery url: %s' % (galleryUrl))
        gallery = self.kindGirls.GetGallery(galleryUrl)
        title = galleries[igallery]['Title']
        logDebug('getGallery: %s\n%s' % (str(gallery), title))
        return galleryUrl, gallery, title

    def getPicture(self, galleryUrl, gallery, title, picture):
        logTracking('getPicture')
        if self.onePicture:
            galleryUrl, gallery, title = self.getGallery()
            lenght = len(gallery)
            picture = random.randint(0,lenght - 1)
            while 'Title' not in gallery[picture]:
                picture = random.randint(0,lenght - 1)
            pictureUrl = gallery[picture]['PhotoUrl']
            logDebug('Random picture of the random gallery url: %s' % galleryUrl)
            return galleryUrl, gallery, title, pictureUrl, picture
        else:
            if gallery == None and galleryUrl != None:
                gallery = self.kindGirls.GetGallery(galleryUrl)
            try:
                picture += 1
                if 'Title' not in gallery[picture] or galleryUrl == None:
                    galleryUrl, gallery, title = self.getGallery()
                    picture = 0
            except:
                galleryUrl, gallery, title = self.getGallery()
                picture = 0
            finally:
                pictureUrl = gallery[picture]['PhotoUrl']
                logDebug('Picture No.%i/%i of the random gallery pictureUrl: %s' % (picture + 1, len(gallery), pictureUrl))
                logDebug('getUrl pictureUrl: %s title: n%s' % (pictureUrl, title))
                return galleryUrl, gallery, title, pictureUrl, picture
