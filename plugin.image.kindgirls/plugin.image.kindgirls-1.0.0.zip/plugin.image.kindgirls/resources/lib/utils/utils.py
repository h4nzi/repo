# -*- coding: utf-8 -*-

import xbmc, xbmcaddon, xbmcgui, xbmcvfs
import os
import json, time

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_ICON = ADDON.getAddonInfo('icon')
ADDON_PROFILE = ADDON.getAddonInfo('profile')

WINDOW_HOME = 10000

TRACKING = True
BACKEND = True
DEBUG = True

SCREEN_FILE = xbmcvfs.translatePath(os.path.join(ADDON_PROFILE, 'screen.json'))

def getSettingLog(name):
    return True if xbmcaddon.Addon().getSetting(name).upper() == 'TRUE' else False

def getSettingNum(name):
    return int(xbmcaddon.Addon().getSetting(name))
    
def log(msg, level=xbmc.LOGDEBUG):
    if type(msg).__name__=='unicode':
        msg = msg.encode('utf-8')
    xbmc.log("[%s] %s" % (ADDON_NAME,msg.__str__()), level)

def logNot(msg):
    log(msg,level=xbmc.LOGINFO)

def logWrn(msg):
    log(msg,level=xbmc.LOGWARNING)

def logDbg(msg):
    log(msg,level=xbmc.LOGDEBUG)

def logErr(msg):
    log(msg,level=xbmc.LOGFATAL)
    
def logTracking(msg):
    if TRACKING:
        log('[TRACKING] ' + msg,level=xbmc.LOGINFO)

def logBackend(msg):
    if BACKEND:
        log('[ BACKEND] ' + msg,level=xbmc.LOGINFO)

def logDebug(msg):
    if DEBUG:
        log('[   DEBUG] ' + msg,level=xbmc.LOGINFO)

def notification(message, icon=ADDON_ICON, time=5000, notify=True):
    if not notify: return
    if icon == 'INFO':
        icon = xbmcgui.NOTIFICATION_INFO
    elif icon == 'WARNING':
        icon = xbmcgui.NOTIFICATION_WARNING
    elif icon == 'FATAL':
        icon = xbmcgui.NOTIFICATION_ERROR
    xbmcgui.Dialog().notification(ADDON_NAME, message, icon, time)
    # xbmc.executebuiltin("XBMC.Notification(%s,%s,%i,%s)" % (ADDON_NAME, message, time, icon))

def notify(title, msg):
    xbmc.executebuiltin('XBMC.Notification('+ title +','+ msg +',10)') 

def setProperty(variable, value):
    xbmcgui.Window(WINDOW_HOME).setProperty(variable, value)

def clearProperty(variable):
    xbmcgui.Window(WINDOW_HOME).clearProperty(variable)

def loadScreen():
    try:
        with open(SCREEN_FILE) as f:
            screen = json.load(f)
            return screen[0], screen[1]
        return None, None
    except:
        return None, None

def saveScreen(url, title):
    try:
        time_string = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        screen_data = [url, title, time_string]
        with open(SCREEN_FILE, "w") as file:
            json.dump(screen_data, file)
    except:
        pass
