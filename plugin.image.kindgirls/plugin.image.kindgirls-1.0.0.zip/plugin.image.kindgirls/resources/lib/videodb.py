# -*- coding: utf-8 -*-

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import os, sys
import urllib.parse, urllib, random, json, time

from resources.lib.kindgirls import KindGirls
from resources.lib.utils.utils import logNot, logErr, notification, notify, getSettingLog, getSettingNum, setProperty

VIDEO_PAGES = 13
RANDOM_VIDEOS = 16

addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')
addon_version = addon.getAddonInfo('version')
addon_icon = addon.getAddonInfo('icon')
addon_fanart = addon.getAddonInfo('fanart')
addon_language = addon.getLocalizedString
addon_path = addon.getAddonInfo('path')
addon_profile = addon.getAddonInfo('profile')

path = addon_profile
name = 'videodb.json'

def mediaFile(path, file):
    try:
        return xbmcvfs.translatePath(os.path.join(media_path, path, file))
    except:
        return None

def writedb(videodb):
    with open(xbmcvfs.translatePath(os.path.join(path, name)), 'w') as db:
        db.write(json.dumps(videodb, indent=2))

def readVideodb():
    with open(xbmcvfs.translatePath(os.path.join(path, name))) as db:
        return json.load(db)

def writeVideodb():
    kindGirls = KindGirls()
    page = 1
    count = 0
    newVideodb = []
    while True:
        gallery = kindGirls.GetVideoGallery(page)
        if(gallery):
            for video in gallery:
                if 'NextPage' in video:
                        continue
                else:
                    count += 1
                    video.update({"Stream": kindGirls.GetVideoUrl(video['Url'])})
                    video.update({"Page": page})
                    newVideodb.append(video)
            page += 1
        else:
            break
    with open(xbmcvfs.translatePath(os.path.join(addon_profile, 'videodb.json')), 'w') as db:
        db.write(json.dumps(newVideodb, indent=2))
        db.close
    logNot('Videodb: %i galleries in %i pages' % (count, page - 1))
    