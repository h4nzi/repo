# -*- coding: utf-8 -*-
 
from resources.lib.plugin import route

if __name__ == '__main__':
    route()
