import subprocess
import xbmc
import xbmcaddon
import xbmcgui
import time

addon = xbmcaddon.Addon()

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)

def run_iperf3():
    mode = addon.getSetting("mode")
    server_ip = addon.getSetting("server_ip")

    if addon.getSetting("debug") == "true":
        Msg(f"[iPerf3] Mode: {mode}")
        Msg(f"[iPerf3] Server IP: {server_ip}")

    if not xbmc.getCondVisibility('System.HasAddon(virtual.network-tools)'):
        xbmc.executebuiltin('InstallAddon(virtual.network-tools)')
        time.sleep(5)
        if xbmc.getCondVisibility('System.HasAddon(virtual.network-tools)'):
            xbmcgui.Dialog().ok("Info", "Závislost nainstalována, před spuštěním je nutný restart Kodi")
        else:
            xbmcgui.Dialog().ok("Chyba", "Instalace závislosti selhala. Skript nemůže pokračovat.")
        return

    try:
        command = ["iperf3"]
        if mode == "0":  # Server
            command.append("-s")
        elif mode == "1":  # Klient
            if not server_ip:
                xbmcgui.Dialog().ok("Chyba", "IP adresa serveru nebyla nastavena!")
                if addon.getSetting("debug") == "true":
                    Msg("[iPerf3] Chyba: IP adresa serveru je prázdná!")
                return
            command.extend(["-c", server_ip, "-R"]) # měří směr s -> c
            # command.extend(["-c", server_ip]) # měří směr c -> s
        else:
            xbmcgui.Dialog().ok("Chyba", "Neplatný režim. Zvolte Server nebo Klient.")
            return

        if addon.getSetting("debug") == "true":
            Msg(f"[iPerf3] Command to execute: {' '.join(command)}")

        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        output, error = process.communicate()

        dialog = xbmcgui.Dialog()
        if process.returncode == 0:
            dialog.textviewer("Výstup iPerf3", output)
        else:
            dialog.textviewer("Chyba iPerf3", error)

    except Exception as e:
        xbmc.executebuiltin(f'Notification(Chyba, {str(e)}, 5000)')

if __name__ == "__main__":
    run_iperf3()
    Msg("[iPerf3] Script run")
