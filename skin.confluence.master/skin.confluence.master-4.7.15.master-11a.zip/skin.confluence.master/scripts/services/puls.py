
import os
import time
import xbmc
import xbmcgui

puls = (":")
zero = (" ")
monitor = xbmc.Monitor()

if __name__ == '__main__':
    while not monitor.abortRequested():
        xbmcgui.Window(10000).setProperty('Puls', puls)
        time.sleep(1)
        xbmcgui.Window(10000).setProperty('Puls', zero)
        if monitor.waitForAbort(1):
            xbmc.log("********Puls Abort Called*****************", 2)
            break
            