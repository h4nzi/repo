from resources.libs import calendar

if __name__ == '__main__':
    calendar.run()