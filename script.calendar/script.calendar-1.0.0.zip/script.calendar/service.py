import xbmc
import xbmcaddon
import xbmcgui

addon = xbmcaddon.Addon()
        

if __name__ == '__main__':
    xbmc.executebuiltin('RunScript("special://home/addons/script.calendar/main.py")')

