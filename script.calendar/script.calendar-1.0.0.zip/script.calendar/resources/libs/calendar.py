# -*- coding: utf-8 -*-

import os
import xbmcgui
import xbmc
import time
import xbmcaddon
import xbmcvfs
import json
import requests
from requests.structures import CaseInsensitiveDict

from datetime import datetime, timedelta

addon = xbmcaddon.Addon(id='script.calendar')
userpath = addon.getAddonInfo('profile')
monitor = xbmc.Monitor()
file = xbmcvfs.translatePath("%s/names.txt" % userpath)
if not xbmcvfs.exists(userpath):
    xbmcvfs.mkdir(userpath)

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)
def MsgWrn(message):
    xbmc.log(message, level=xbmc.LOGWARNING)
def MsgErr(message):
    xbmc.log(message, level=xbmc.LOGERROR)
def MsgDbg(message):
    xbmc.log(message, level=xbmc.LOGDEBUG)

def run_holidays():
    url = "https://svatky.steelants.cz/api/json"
    Msg('[Calendar] Holidays running')
    xbmcgui.Dialog().notification("Kalendář", "Svátky se spouští", icon=xbmcgui.NOTIFICATION_INFO, time=2000, sound=True)    
    headers = CaseInsensitiveDict()
    headers["Accept"] = "application/json"
    RG = requests.get(url, headers=headers)
    date = RG.json()["date"]
    name_day = RG.json()["name"]
    if addon.getSetting("debug") == "true":
        Msg(f"[Calendar] svátek: {name_day}")
    public_holiday = RG.json()["isPublicHoliday"]
    xbmcgui.Window(10000).setProperty('public_holiday' , str(public_holiday))
    xbmcgui.Window(10000).setProperty('name_day' , name_day)
    if public_holiday == True:
        name_public_holiday = RG.json()["holidayName"]
        shopping = str(RG.json()["shopsClosed"])
        xbmcgui.Window(10000).setProperty('Státní svátek' , name_public_holiday)
        xbmcgui.Window(10000).setProperty('obchody' , shopping)
        if addon.getSetting("debug") == "true":
            Msg(f"[Calendar] Státní svátek: {name_public_holiday}")
            Msg(f"[Calendar] Obchody: {shopping}")
    else:
        Msg("[Calendar] Není státní svátek")
        
def run_birthdays():
    Msg('[Calendar] Birthdays running')
    xbmcgui.Dialog().notification("Kalendář", "Narozeniny se spouští", icon=xbmcgui.NOTIFICATION_INFO, time=2000, sound=True)
    # today = time.strftime('%d%m')
    tomorrow = datetime.now() + timedelta(days=1)
    tm = tomorrow.strftime('%d%m')

    try:
        fileName = open(file, 'r')
        if addon.getSetting("debug") == "true":
            Msg(f"[Calendar] : {fileName}")
    except FileNotFoundError:
        xbmcgui.Dialog().notification("Kalendář", "Soubor nenalezen", xbmcgui.NOTIFICATION_ERROR)
    flag = 0
    bd = ""
    for line in fileName:
        if tm in line:
            line = line.split(' ')
            flag = 1
            bd = f'{line[1]}'  # den+měsíc, jméno
            break  # Pokud najde záznam, ukončí smyčku
    fileName.close()  # Zavřít soubor po dokončení procházení
    if flag == 1:
        xbmcgui.Window(10000).setProperty('Birthday', bd)
        # xbmc.log("*********Birthday1 Running*****************", 1)
        print("BD", bd)
    else:
        xbmcgui.Window(10000).setProperty('Birthday', bd)
        # xbmc.log("*********No Birthday*****************", 1)
        print("BD", bd)

def run():
    if addon.getSetting("holidays_on") == "true":
       run_holidays()
    xbmc.sleep(2000) #2 sec.
    if addon.getSetting("birthdays_on") == "true":
       run_birthdays()
