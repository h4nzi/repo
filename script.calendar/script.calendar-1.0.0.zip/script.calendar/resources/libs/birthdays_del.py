# -*- coding: utf-8 -*-

import os
import xbmcaddon
import xbmcgui
import xbmcvfs

addon = xbmcaddon.Addon(id='script.calendar')
userpath = addon.getAddonInfo('profile')
names = xbmcvfs.translatePath("%s/names.txt" % userpath)

if xbmcvfs.exists(names):
    if xbmcgui.Dialog().yesno('Smazat soubor', 'Opravdu chcete smazat soubor?'):
        xbmcvfs.delete(names)
        xbmcgui.Dialog().notification('Soubor smazán', '')
else:
    xbmcgui.Dialog().notification('Soubor neexistuje', '')
