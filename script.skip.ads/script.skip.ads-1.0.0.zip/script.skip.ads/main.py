#!/usr/bin/python3

# https://www.xbmc-kodi.cz/prispevek-mapovani-tlacitek-do-tipy-a-triky?pid=112724#pid112724

import xbmc, xbmcgui, xbmcaddon, xbmcvfs
import os

__addon__           = xbmcaddon.Addon()
__addon_id__        = __addon__.getAddonInfo('id')
__addon_name__      = __addon__.getAddonInfo('name')
__addon_lang__      = __addon__.getLocalizedString
__addon_version__   = __addon__.getAddonInfo('version')

__addon_path__      = xbmcvfs.translatePath(__addon__.getAddonInfo('path'))
__addon_profile__   = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))

# _icon_ = xbmcvfs.translatePath(os.path.join(__addon_path__ + '/resources', 'icon.png' ))

def log(msg, level=xbmc.LOGDEBUG):
    if type(msg).__name__=='unicode':
        msg = msg.encode('utf-8')
    xbmc.log("[%s] %s" % (__addon_name__,msg.__str__()), level)
def logNot(msg):
    log(msg,level=xbmc.LOGINFO)
def logWrn(msg):
    log(msg,level=xbmc.LOGWARNING)
def logDbg(msg):
    log(msg,level=xbmc.LOGDEBUG)
def logErr(msg):
    log(msg,level=xbmc.LOGFATAL)
    
skipDef = {
'Barrandov Krimi' : '240',
'Kino Barrandov' : '240',
'TV Barrandov' : '240',
'Barrandov TV HD' : '240',
'CS Film' : '300',
'CS Mystery' : '300',
'JOJ Family' : '300',
'JOJ Family HD' : '300',
'NGC' : '260',
'National Geographic HD' : '260',
'Nova' : '390',
'Nova HD' : '390',
'Nova Action' : '390',
'Nova Action HD' : '390',
'Nova Cinema' : '390',
'Nova Cinema HD' : '390',
'Nova Fun' : '390',
'Nova Fun HD' : '390',
'Nova Gold' : '390',
'Nova Gold HD' : '390',
'Nova Lady' : '390',
'Prima' : '390',
'Prima HD' : '390',
'Prima COOL' : '390',
'Prima COOL HD' : '390',
'Prima Krimi' : '430',
'Prima KRIMI HD' : '430',
'Prima Love' : '390',
'Prima Love HD' : '390',
'Prima Max' : '390',
'Prima Max HD' : '390',
'Prima Zoom' : '390',
'Prima ZOOM HD' : '390',
'Prima Show' : '390',
'Prima Show HD' : '390',
'Prima Star' : '390',
'Prima Star HD' : '390',
'CNN Prima News' : '390',
'Filmbox' : '300',
'Filmbox HD' : '300',
'Paramount Network' : '360',
'Televize Seznam' : '360',
'Seznam TV HD' : '360',
'Viasat History' : '180'
}

if (__name__ == "__main__"):
    logNot('Start')
    channelName = xbmc.getInfoLabel('VideoPlayer.ChannelName')
    logDbg('channelName: %s' % channelName)
    xbmcgui.Dialog().notification("Skip Ads  " + channelName, xbmc.getInfoLabel("ListItem.Tag"), xbmcgui.NOTIFICATION_INFO, sound=True) # https://kodi.wiki/view/InfoLabels#Video_player
    try:
        seekTime = skipDef[channelName]
    except:
        logNot('Skip time for channelName %s isn\'t defined' % channelName)
        xbmcgui.Dialog().notification("Skip Ads", "Time for   " + channelName + "   isn't defined", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
        
    else:
        xbmc.executebuiltin('Seek(%s)' % seekTime)
    logNot('Finish')
