# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import xbmcaddon
import requests
import json
from requests.structures import CaseInsensitiveDict
from datetime import date
# import locale

addon_id = 'service.scc.availability'
selfAddon = xbmcaddon.Addon(addon_id)
__version__ = selfAddon.getAddonInfo('version')

URL = "https://stats.uptimerobot.com/api/getMonitorList/649DYsPwRp"
monitor = xbmc.Monitor()

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)
def MsgWrn(message):
    xbmc.log(message, level=xbmc.LOGWARNING)
def MsgErr(message):
    xbmc.log(message, level=xbmc.LOGERROR)
def MsgDbg(message):
    xbmc.log(message, level=xbmc.LOGDEBUG)

while not monitor.abortRequested():
    if selfAddon.getSetting('info') == 'true':
        Msg('~SCC Status~ Running')
    library_status = "not success"
    libraryCF_status = "not success"
    streams_status = "not success"
    streamsCF_status = "not success"
    try:
        headers = CaseInsensitiveDict()
        headers["Accept"] = "application/json"
        resp = requests.get(URL, headers=headers)
        data = resp.json()

        if "psp" in data:
            Monitors = data["psp"]["monitors"]
            for Monitor in Monitors:
                name = Monitor.get("name", "N/A")
                status_class = Monitor.get("statusClass", "N/A")
                if name == "Library":
                    if status_class == "success":
                        library_status = "success"
                    else:
                        library_status = "not success"
                        xbmcgui.Dialog().notification("SCC Status", "Library is down", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
                        MsgErr('~SCC Status~ Library is down')
                if name == "Library - Cloudflare":
                    if status_class == "success":
                        libraryCF_status = "success"
                    else:
                        libraryCF_status = "not success"
                        xbmcgui.Dialog().notification("SCC Status", "Library - CF is down", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
                        MsgErr('~SCC Status~ Library - CF is down')
                if name == "Streams":
                    if status_class == "success":
                        streams_status = "success"
                    else:
                        streams_status = "not success"
                        xbmcgui.Dialog().notification("SCC Status", "Streams is down", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
                        MsgErr('~SCC Status~ Streams is down')
                if name == "Streams - Cloudflare":
                    if status_class == "success":
                        if selfAddon.getSetting('test') == 'false':
                            streamsCF_status = "success"
                        else:
                            streamsCF_status = "not success"
                    else:
                        streamsCF_status = "not success"
                        xbmcgui.Dialog().notification("SCC Status", "Streams CF is down", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
                        MsgErr('~SCC Status~ Streams CF is down')
                        
        days_data = data.get("days", "")
        date_today = date.today().strftime("%B %-d, %Y")
        if days_data: # Pokud jsou data dostupná
            if isinstance(days_data, list):
                days_data = days_data[0]
                if days_data == date_today:
                    if selfAddon.getSetting('info') == 'true':
                        Msg('~SCC Status~ SCC online')
                else:
                    Msg('~SCC Status~ Dnes dd {}'.format(days_data))
                    Msg('~SCC Status~ Dnes dt {}'.format(date_today))
                    MsgErr("~SCC Status~ Nepodařilo se zpracovat datum.")

        if library_status == "success" and libraryCF_status == "success" and streams_status == "success" and streamsCF_status == "success":
            status = "0"
        else:
            status = "1"
            xbmcgui.Dialog().notification("SCC Status", "Služby jsou nedostupné nebo omezené", icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
            MsgErr('~SCC Status~ SCC Services unavailable or limited')
            
        xbmcgui.Window(10000).setProperty("SCCStatus", status)

        if selfAddon.getSetting('debug') == 'true':      
            Msg('~SCC Status~ Dnes {}'.format(days_data))
            Msg('~SCC Status~ Library {}'.format(library_status))
            Msg('~SCC Status~ Streams {}'.format(streams_status))
            Msg('~SCC Status~ Library - Cloudflare {}'.format(libraryCF_status))
            Msg('~SCC Status~ Streams - Cloudflare {}'.format(streamsCF_status))
            Msg('~SCC Status~ Overall OK {}'.format(status))

    except Exception as e:
        error_message = "~SCC Status~ Error: {} occurred at line {}".format(e, sys.exc_info()[-1].tb_lineno)
        MsgErr(error_message)

    if monitor.waitForAbort(60):
        MsgWrn('~SCC Status~ Abort Called')
        break
