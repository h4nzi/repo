# -*- coding: utf-8 -*-

import os
import xbmcgui
import xbmc
import time
import xbmcaddon
import xbmcvfs

from datetime import datetime, timedelta

addon = xbmcaddon.Addon()
userpath = addon.getAddonInfo('profile')
file = xbmcvfs.translatePath("%s/names.txt" % userpath)
if not xbmcvfs.exists(userpath):
    xbmcvfs.mkdir(userpath)

monitor = xbmc.Monitor()

def Msg(message):
    xbmc.log(message, level=xbmc.LOGINFO)
def MsgWrn(message):
    xbmc.log(message, level=xbmc.LOGWARNING)
def MsgErr(message):
    xbmc.log(message, level=xbmc.LOGERROR)
def MsgDbg(message):
    xbmc.log(message, level=xbmc.LOGDEBUG)

def run_script():
    xbmc.sleep(30000) #4 sec.
    Msg('[Birthdays] started')
    xbmcgui.Dialog().notification("Birthdays", "Script se spouští", icon=xbmcgui.NOTIFICATION_INFO, sound=True)
    # today = time.strftime('%d%m')
    tomorrow = datetime.now() + timedelta(days=1)
    tm = tomorrow.strftime('%d%m')

    try:
        fileName = open(file, 'r')
    except FileNotFoundError:
        xbmcgui.Dialog().notification("Chyba", "Soubor nenalezen", xbmcgui.NOTIFICATION_ERROR)
    flag = 0
    bd = ""
    for line in fileName:
        if tm in line:
            line = line.split(' ')
            flag = 1
            bd = f'{line[1]}'  # den+měsíc, jméno
            break  # Pokud najde záznam, ukončí smyčku
    fileName.close()  # Zavřít soubor po dokončení procházení
    if flag == 1:
        xbmcgui.Window(10000).setProperty('Birthday', bd)
        # xbmc.log("*********Birthday1 Running*****************", 1)
        print("BD", bd)
    else:
        xbmcgui.Window(10000).setProperty('Birthday', bd)
        # xbmc.log("*********No Birthday*****************", 1)
        print("BD", bd)

run_script()
