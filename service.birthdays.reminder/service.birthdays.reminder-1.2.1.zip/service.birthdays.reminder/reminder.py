import xbmcgui
import xbmc
import time
import xbmcaddon
import os
from datetime import datetime, timedelta

addon = xbmcaddon.Addon()
addon_data_path = addon.getAddonInfo('profile')

file_name = addon.getSetting('file_name')
folder = addon.getSetting('folder')

birthdayFile = os.path.join(addon_data_path, folder, file_name)
monitor = xbmc.Monitor()

while not monitor.abortRequested():
    # xbmc.log("*********Birthday Running*****************", 1)
    # today = time.strftime('%d%m')
    tomorrow = datetime.now() + timedelta(days=1)
    tm = tomorrow.strftime('%d%m')

    try:
        fileName = open(birthdayFile, 'r')
    except FileNotFoundError:
        xbmcgui.Dialog().notification("Chyba", "Soubor na zadané cestě nebyl nalezen", xbmcgui.NOTIFICATION_ERROR)
        break
    flag = 0
    bd = ""
    for line in fileName:
        if tm in line:
            line = line.split(' ')
            flag = 1
            bd = f'{line[1]}'  # den+měsíc, jméno
            break  # Pokud najde záznam, ukončí smyčku
    fileName.close()  # Zavřít soubor po dokončení procházení
    if flag == 1:
        xbmcgui.Window(10000).setProperty('Birthday', bd)
        # xbmc.log("*********Birthday1 Running*****************", 1)
        print("BD", bd)
    else:
        xbmcgui.Window(10000).setProperty('Birthday', bd)
        # xbmc.log("*********No Birthday*****************", 1)
        print("BD", bd)

    if monitor.waitForAbort(10):
        xbmc.log("********Birthdays Abort Called*****************", 2)
        break
