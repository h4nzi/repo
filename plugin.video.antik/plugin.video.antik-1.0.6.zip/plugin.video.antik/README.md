<h1>Antik TV</h1>
<p>
<h3>Kodi doplněk pro Antik TV (CZ i SK)</h3>
<p>
<a href="https://www.xbmc-kodi.cz/prispevek-antik-tv--13396">Vlákno na fóru XBMC-Kodi.cz</a><br><br>
v1.0.6 (27.5.2025)<br>
- ošetření problémových znaků v EPG<br><br>

v1.0.5 (22.4.2025)<br>
- oprava přehrávání archivu<br><br>

v1.0.4 (15.4.2025)<br>
- oprava přehrávání archivu (posun začátku)<br><br>

v1.0.3 (21.2.2025)<br>
- ošetření chybějících žánrů v datech<br><br>

v1.0.2 (21.2.2025)<br>
- přidání žánrů<br>
- filtrování kanálů pro archiv/catchup<br>
- úprava linku na fórum<br><br>
</p>
