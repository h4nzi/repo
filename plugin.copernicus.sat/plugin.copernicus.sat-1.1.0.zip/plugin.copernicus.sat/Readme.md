## Stahujeme družicové snímky Sentinel-2 z programu Copernicus
Vyzkoušíme si katalogové a procesní API pro vyhledávání a generování/stahování čerstvých snímků z družic mise Sentinel-2. Skript sentinel2.py stahuje, skript katalog.py vhledává.
 - **[Článek na Živě.cz](https://www.zive.cz/clanky/programujeme-v-pythonu-jak-uplne-zadarmo-stahnout-cerstve-druzicove-snimky-libovolneho-mista-v-cesku/sc-3-a-229892/default.aspx)**
