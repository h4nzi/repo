import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import os

# Načtení cesty k addon adresáři
addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path')

# Cesta k souboru sentinel.py
sentinel_script = os.path.join(addon_path, 'resources', 'lib', 'sentinel.py')

# Funkce pro spuštění sentinel.py
def run_sentinel():
    try:
        xbmc.log(f"Spouštím script: {sentinel_script}", xbmc.LOGINFO)
        # Ladící výstup pro argumenty
        xbmc.log(f"Argumenty: {sys.argv}", xbmc.LOGINFO)
        exec(open(sentinel_script).read())
        xbmcgui.Dialog().notification("Sentinel", "Skript sentinel.py byl úspěšně spuštěn", xbmcgui.NOTIFICATION_INFO, 5000)
    except Exception as e:
        xbmc.log(f"Chyba při spuštění sentinel.py: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Sentinel", "Chyba při spouštění skriptu!", xbmcgui.NOTIFICATION_ERROR, 5000)

if __name__ == '__main__':
    run_sentinel()

